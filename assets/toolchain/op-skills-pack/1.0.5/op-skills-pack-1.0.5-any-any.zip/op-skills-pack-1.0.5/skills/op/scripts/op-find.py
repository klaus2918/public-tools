# -*- coding: utf-8 -*-
"""op-find.py — op-find.sh 的检索核心（Python 实现，规避 MSYS awk 在中文环境下的偶发崩溃）
用法：python op-find.py <关键词...> [--project <项目根>] [--execution-mode all|constrained|autonomous]
匹配字段：change.yaml 的 name / title / summary / keywords / usage_scene / usage_tags（OR 匹配，大小写不敏感）
输出：change-name | phase | 🗂/📎parent/⏸ 徽标 | title，多命中含摘要首行
编排增强（I-20）：type=epic 命中显示 🗂 与子变更完成度；parent 命中显示 📎<父变更名> 归属列
执行模式过滤（第10组轮115自主执行演练）：--execution-mode 按 change.yaml execution_mode 过滤
（缺省视为 constrained，与 change.yaml 契约一致；不传 = 全部）
"""
import glob
import os
import re
import sys

# 强制 stdout/stderr 为 UTF-8：本工具输出含 emoji 徽标（🗂 / 📎 / ⏸），
# Windows 下 python 管道输出默认走本地代码页（GBK），会抛 UnicodeEncodeError 直接中断检索
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")


# YAML 空值归一：null / none / nil / ~ / 空串 一律视为「无值」
# （历史缺陷：change.yaml 写 `parent: null` 时父变更名显示为「null」，📎 徽标误显示）
_NULLISH = ('', 'null', 'none', 'nil', '~', 'n/a', 'na')


def _clean(value):
    v = (value or '').strip()
    return '' if v.lower() in _NULLISH else v


def parse_yaml_fields(filepath):
    """提取检索所需全部字段（name/title/phase/paused/keywords/summary/usage_scene/usage_tags）"""
    fields = {
        'name': '', 'title': '', 'phase': '', 'paused': '',
        'keywords': '', 'usage_scene': '', 'summary': '', 'usage_tags': '',
        'type': '', 'parent': '', 'execution_mode': '',
    }
    try:
        with open(filepath, 'r', encoding='utf-8-sig') as f:
            lines = f.readlines()
    except OSError:
        return fields

    in_summary = False
    in_usage_tags = False
    for raw in lines:
        line = raw.rstrip('\r\n')
        if line.startswith('summary:'):
            in_summary = True
            in_usage_tags = False
            continue
        if line.startswith('usage_tags:'):
            in_usage_tags = True
            in_summary = False
            continue
        if line and not line[0].isspace():
            in_summary = False
            in_usage_tags = False
        if in_usage_tags:
            m = re.match(r'^\s*-\s+(.*)$', line)
            if m:
                tag = m.group(1).strip().strip('"')
                fields['usage_tags'] += tag + ' '
            continue
        if in_summary:
            if line.strip() and not fields['summary']:
                fields['summary'] = line.strip()
            continue
        for key in ('name', 'title', 'phase', 'paused', 'keywords', 'usage_scene', 'type', 'parent', 'execution_mode'):
            if line.startswith(key + ':'):
                val = line.split(':', 1)[1].strip()
                if len(val) >= 2 and val[0] == '"' and val[-1] == '"':
                    val = val[1:-1]
                fields[key] = _clean(val)
                break
    return fields


def epic_progress(root, name):
    """读父变更 orchestration.yaml，返回 (archived, total)；缺失返回 None。"""
    p = os.path.join(root, '.op', 'changes', name, 'orchestration.yaml')
    if not os.path.isfile(p):
        return None
    total = done = 0
    cur = None
    try:
        with open(p, 'r', encoding='utf-8-sig') as f:
            for ln in f:
                s = ln.strip()
                if s.startswith('- name:'):
                    total += 1
                    cur = 'open'
                elif cur and s.startswith('status:'):
                    if s.split(':', 1)[1].strip() == 'archived':
                        done += 1
                    cur = None
    except OSError:
        return None
    return (done, total) if total else None


def main(argv):
    if not argv:
        sys.stderr.write('用法: op-find.py <关键词...> [--project <项目根>]\n')
        return 2

    root = ''
    keywords = []
    exec_mode = 'all'  # all / constrained / autonomous（第10组轮115自主执行演练）
    i = 0
    while i < len(argv):
        if argv[i] == '--project' and i + 1 < len(argv):
            root = argv[i + 1]
            i += 2
        elif argv[i] == '--execution-mode' and i + 1 < len(argv):
            exec_mode = argv[i + 1].lower()
            if exec_mode not in ('all', 'constrained', 'autonomous'):
                sys.stderr.write('--execution-mode 取值：all / constrained / autonomous（当前：%s）\n' % exec_mode)
                return 2
            i += 2
        else:
            keywords.append(argv[i])
            i += 1

    if not keywords:
        sys.stderr.write('用法: op-find.py <关键词...> [--project <项目根>]\n')
        return 2

    if not root:
        cur = os.getcwd()
        while True:
            if os.path.isdir(os.path.join(cur, '.op', 'changes')):
                root = cur
                break
            parent = os.path.dirname(cur)
            if parent == cur:
                break
            cur = parent

    if not root:
        sys.stderr.write('未找到 .op/changes 目录（当前目录向上未命中；可用 --project 指定项目根）\n')
        return 1

    changes_dir = os.path.join(root, '.op', 'changes')
    if not os.path.isdir(changes_dir):
        sys.stderr.write('不存在 %s\n' % changes_dir)
        return 1

    # 构建 OR 正则（关键词原样拼接，转义特殊字符）
    pat_parts = []
    for kw in keywords:
        pat_parts.append(re.escape(kw))
    pat = re.compile('|'.join(pat_parts), re.IGNORECASE)

    found = 0
    # 检索范围：顶层变更 + 编排子变更（.op/changes/<parent>/<child>/change.yaml，I-20）
    paths = sorted(glob.glob(os.path.join(changes_dir, '*', 'change.yaml')))
    for sub in sorted(glob.glob(os.path.join(changes_dir, '*', '*', 'change.yaml'))):
        if sub not in paths:
            paths.append(sub)
    for yaml in paths:
        f = parse_yaml_fields(yaml)
        # 执行模式过滤（缺省视为 constrained，与 change.yaml 契约一致）
        mode = f['execution_mode'] or 'constrained'
        if exec_mode != 'all' and mode != exec_mode:
            continue
        hay = '|'.join([f['name'], f['title'], f['summary'],
                        f['keywords'], f['usage_scene'], f['usage_tags']])
        if pat.search(hay):
            found += 1
            mark = '⏸ ' if f['paused'].lower() in ('true', 'yes', '1') else ''
            name = f['name'] or '?'
            phase = f['phase'] or '?'
            # 编排标记（I-20）：epic 父变更 → 🗂；子变更 → 📎<父名>
            tag = ''
            if f['type'] == 'epic':
                tag = '🗂'
            elif f['parent']:
                tag = '📎%s' % f['parent']
            label = (tag + ' ' + mark).strip() if (tag or mark) else ''
            print('%-30s %-8s %-16s %s' % (name, phase, label, f['title']))
            # 父变更：附加子变更完成度（读 orchestration.yaml）
            if f['type'] == 'epic':
                prog = epic_progress(root, name)
                if prog:
                    print('     ↳ 子变更 %d/%d archived（%s/orchestration.yaml）' % (prog[0], prog[1], name))
            if f['summary']:
                print('     ↳ %s' % f['summary'][:80])

    if found == 0:
        print('ℹ️  无命中（检索范围：%s）' % changes_dir)
        print('   提示：先确认项目根 .op 位置正确；仍无命中才允许搜索外部知识库（openspec/shared）')
    else:
        print('── %d 个命中 ──' % found)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
