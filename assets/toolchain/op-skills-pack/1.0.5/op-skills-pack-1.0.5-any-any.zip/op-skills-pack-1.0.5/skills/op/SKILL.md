---
name: op
category: core
status: active
phase_role: entry
description: op 工作流入口。负责任务创建、任务接续、路由。核心 2 的唯一入口。
version: "3.2.2"
updated_at: 2026-09-14
dispatches:
  - op-plan
  - op-build
  - op-done
  - op-orchestrate
---

# op — op 工作流入口

## Overview

op 是核心 2 的唯一入口，负责两件事：
1. **建立任务**：创建变更，引导信息采集
2. **接续任务**：检索变更，恢复上下文，路由到对应 skill

不负责具体阶段工作，只做检索与路由。

---

## When to Use

- 用户输入 `/op` 或 `/op <change-name>` 或 `/op init <name>`
- 用户说"开始""继续""接着上次""恢复工作"
- 用户以业务主题恢复（如"继续讨论区级文件交换"）

---

## Quick Reference

| Command | Action |
|---------|--------|
| `/op` | 列出活跃变更；若只有一个则直接进入 |
| `/op <change-name>` | 直接操作指定变更 |
| `/op find <keyword...>` | 按业务主题检索变更 |
| `/op list` | 列出所有变更，含已归档（已归档从 `.op/archive/` 目录扫描） |
| `/op status [--detail] [<change-name>]` | 查看变更状态 |
| `/op init <name> [title]` | 创建新变更 |
| `/op <change-name> plan/build/done` | 强制进入指定阶段 |
| `/op collect <描述>` | 快速记录需求/问题/优化点 |
| `/op inbox` | 展示待采集需求列表 |

---

## Core Rules

### 1. Resume Flow — 先检索，再路由

用户以业务主题恢复时，**必须按以下顺序**：

1. **内部检索**：运行 `scripts/op-find.sh <关键词>`（检索 change.yaml 的 name/title/summary/keywords 字段）
2. **单命中** → 读取该变更恢复上下文：`change.yaml` + `plan.md` + `tasks.md`
3. **多命中** → 列出命中选择面板，等用户选择
4. **零命中** → 检查 `.op/index.json`，仍无命中才允许搜索外部知识库（知识库配置不存在时，按 op-knowledge「消费方接入协议」询问引导，禁止静默跳过）

**禁止**：不查 `.op/changes/` 就直接搜外部知识库。

### 2. 事实源仲裁

`change.yaml` 是唯一事实源。`index.json` 是派生产物：
- 读取状态/路由：**以 `change.yaml.phase` 为准**
- 发现 index.json 与 change.yaml 漂移 → 按 change.yaml 修正 index.json

### 3. 路由

按选中的变更 + `change.yaml.phase` 路由到对应子 Skill。更新 `change.yaml.phase` 后由下一次 `/op` 自动路由，子 Skill 不得互相直接调用。

### 4. 需求采集

- `/op collect <描述>` 自动创建 type=tweak 变更，标记 collected=true，不进入 op-plan
- `/op inbox` 展示待采集需求列表（collected=true 且 phase=plan）

### 5. 用户确认

创建新变更目录需用户明确确认。

### 6. 文档优先 — 新需求必须先建变更（P14）

用户描述新需求 / 要改某个功能时，**必须先创建变更（`/op init`）进入 plan 阶段**，禁止不建变更直接改代码：

- 需求 → 变更（change.yaml）→ 方案（plan.md）→ 用户确认 → 才能执行
- 宁可把 tweak 升为 feature 走完整流程，不可把 feature 当 tweak 直接改
- hotfix 例外：生产紧急修复可直改，但仍需建 change.yaml 记录

---

## Routing Decision

| Condition | Result |
|-----------|--------|
| 用户给精确 change-name | 直接读该 change.yaml 路由 |
| `type=epic` 或 `orchestration.enabled=true` | 路由到 `op-orchestrate` |
| 用户给业务主题 | 走 Resume Flow |
| 无活跃变更 | 提示初始化 |
| 单个活跃变更 | 直接路由到其 phase |
| 多个活跃变更 | 展示列表，等用户选择 |
| `collected=true` 且 `phase=plan` | 展示待采集标记，询问是否进入正式 plan |
| `phase=plan` | 加载 op-plan |
| `phase=build` | 加载 op-build |
| `phase=done` | 加载 op-done |
| `phase=archive` | 扫描 `.op/archive/` 目录读归档摘要 |

---

## Change Workspace

```
.op/
├── index.json                       # 派生路由索引（仅 active，以 change.yaml 为准；archived 不保留）
├── changes/                         # 仅活跃变更（phase != archive）
│   └── <change-name>/
│       ├── change.yaml              # 事实源
│       ├── plan.md                  # 方案文档（frontmatter 含 confirmed 确认标记）
│       ├── tasks.md                 # 任务清单
│       └── <执行产物>                # SQL 脚本/数据迁移/验证记录等，与 plan.md 平级
└── archive/                         # 已归档变更（物理外迁）
    └── YYYY/MM/
        └── <change-name>/
```

**执行产物归位**：变更执行过程中产生的交付材料（SQL 脚本、数据迁移、配置变更、验证记录）一律写入本变更目录 `.op/changes/<name>/`，与 plan.md 平级；只有项目源代码进项目代码库。禁止散落在项目根或代码目录里。

### change.yaml 字段（14 个）

```yaml
# 核心身份（必填）
name: "变更名"              # 目录名，唯一键
title: "标题"               # 人类可读标题
type: feature               # hotfix | tweak | feature | complex | epic
phase: plan                 # plan | build | done | archive

# 状态（必填）
active: true                # 是否活跃
paused: false               # 搁置标记
created: "时间戳"            # 创建时间

# 检索（推荐）
summary: "一句话摘要"
keywords: [关键词]

# 需求采集（可选）
collected: false            # true=待采集需求
collected_from: null        # chat | user | auto
collected_at: null          # 采集时间戳

# epic 关联（可选）
parent: null                # 父变更名
```

### 恢复机制

不使用 resume.yaml。恢复靠：
1. change.yaml（phase 路由）
2. tasks.md（当前进度）
3. plan.md（方案上下文）

### 归档外迁

phase=archive 的变更从 `.op/changes/` 物理移出至 `.op/archive/YYYY/MM/`。

---

## Red Flags — STOP

| Smell | Action |
|-------|--------|
| 未查 `.op/changes/` 就去搜外部知识库 | STOP：先跑 op-find.sh |
| `change.yaml.phase` 与 index.json 不一致 | 以 change.yaml 为准，修正 index.json |
| Multiple changes but user gave no target | Always show list; do not guess |
| type=epic 父变更按 phase 直接路由 | 先判定 epic → 路由到 op-orchestrate |
| 用户描述新需求，agent 不建变更直接改代码 | STOP：先 `/op init` 建 change.yaml 走 plan（文档优先 P14） |
| 知识库配置不存在就静默跳过检索/沉淀 | 按 op-knowledge「消费方接入协议」询问：引导配置 / 本次跳过 |
| 执行产物写在变更目录外（项目根/代码目录） | 移入 `.op/changes/<name>/`，与 plan.md 平级 |

---

## Common Mistakes

- **先查外部知识库再查 `.op`。** 先 op-find.sh。
- **直接信任 index.json 的 phase/active。** 以 change.yaml 为准。
- **子 Skill 互相直接调用。** 只有 op 路由。
- **跳过用户选择当多个变更存在。** 不猜测。
- **不建变更直接改代码。** 用户描述新需求时先 `/op init`（文档优先 P14）；hotfix 也要留 change.yaml。
- **执行产物写在变更目录外。** SQL 脚本/验证记录等交付材料写 `.op/changes/<name>/`，与 plan.md 平级。
- **归档时仍往 index.json 写 archived 摘要。** index.json 只保留进行态；归档查询走 `.op/archive/` 目录扫描。

---

## Version

| Field | Value |
|-------|-------|
| Skill | op |
| Version | 3.2.2 |
| Updated | 2026-09-14 |
| Key change | v3.2.2: op-find.py YAML 空值归一（`parent: null` 等不再被当作有效父变更名，修复「📎null」误显示；同时避免 null 进入检索文本造成误命中）；v3.2.1: op-find.py 强制 stdout/stderr 为 UTF-8（🗂/📎 徽标在 Windows GBK 管道下抛 UnicodeEncodeError 致检索中断）；v3.2.0: index.json 归档摘要清除（保持纯进行态，归档查询走 `.op/archive/` 目录）+ 知识库零命中接入「消费方接入协议」；v3.1.0: 文档优先入口守卫（新需求必须先建变更）+ 执行产物归位规则（与 plan.md 平级）；v3.0.0: 删除 resume.yaml，change.yaml 精简为 14 字段，统一路由 |
