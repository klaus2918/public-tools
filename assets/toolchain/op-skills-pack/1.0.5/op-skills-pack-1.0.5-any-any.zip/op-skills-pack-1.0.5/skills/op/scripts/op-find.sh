#!/usr/bin/env bash
# ==============================================================
# op-find.sh — 在 .op/changes/ 中按业务主题检索变更（op 入口 Resume Flow 的检索工具）
#
# 用法：
#   ./op-find.sh <关键词...> [--project <项目根>]
#   ./op-find.sh 文件交换
#   ./op-find.sh 区级 公文 --project D:/path/to/project
#
# 匹配字段：change.yaml 的 name / title / summary / keywords / usage_scene / usage_tags（OR 匹配，大小写不敏感）
# 输出：change-name | phase | ⏸(paused) | title，多命中含摘要首行
# 实现：检索核心由 op-find.py 完成（MSYS awk 在中文参数环境下偶发崩溃，改用 Python）
# ==============================================================
set -uo pipefail

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)

ROOT=""
KEYWORDS=()
while [ $# -gt 0 ]; do
  case "$1" in
    --project)
      ROOT="$2"
      shift 2
      ;;
    *)
      KEYWORDS+=("$1")
      shift
      ;;
    esac
done

if [ ${#KEYWORDS[@]} -eq 0 ]; then
  echo "❌ 用法: op-find.sh <关键词...> [--project <项目根>]" >&2
  exit 2
fi

# 探测可用的 python（Windows 上 python3 可能是 Microsoft Store 占位符；
# 本机实测 python 常不在 PATH，仅 py launcher 可用——脚本不得裸调 python）
PY_CMD=""
for c in py python3 python; do
  if command -v "$c" >/dev/null 2>&1; then
    if "$c" -c 'import sys' >/dev/null 2>&1; then
      PY_CMD="$c"
      break
    fi
  fi
done

if [ -z "$PY_CMD" ]; then
  echo "❌ 未找到可用的 python（尝试 py/python3/python），op-find 依赖 Python 实现检索核心" >&2
  exit 2
fi

if [ -n "$ROOT" ]; then
  exec "$PY_CMD" "$SCRIPT_DIR/op-find.py" "${KEYWORDS[@]}" --project "$ROOT"
else
  exec "$PY_CMD" "$SCRIPT_DIR/op-find.py" "${KEYWORDS[@]}"
fi
