---
name: operate-prg-project
category: support
status: active
phase_role: support
version: "1.2.0"
updated_at: 2026-09-15
description: 当需要用 agent 工具（而非打开 Project Graph 应用）直接读取或修改 .prg 工程文件内容时使用。提供 29 个图操作工具的调用契约、三条前置条件、Open/Closed 分支差异、Section（分组框）能力边界、错误码速查与推荐调用序列。
---

# operate-prg-project — 用 agent 工具直接读写 .prg 工程文件内容

## Overview

Project Graph 的 `.prg` 是 **ZIP 容器**（`stage/tags/reference/metadata.msgpack` + 可选 `README.md` / `attachments/*` / `thumbnail.png`），不是文本文件——拿文本工具改不了。

仓库自带 CLI 工具集就是给 agent 用的 `.prg` 语义接口：**29 个图操作工具**（读 / 建 / 改 / 删节点与连线、批量改色、DAG 排版、图片），不启动桌面应用即可读写磁盘上的工程文件。

工具集对 **Section（分组框）** 只有有限支持：能读引用关系、能改色、能连线、按固定语义删除，但**不能创建 / 改名 / 收纳成员 / 折叠**——见下文专节。

适用仓库：`graphif/project-graph`（本机示例 `D:\githup-workspace\project-graph`）。

## When to Use

- 要在没打开 Project Graph 的情况下读某个 `.prg` 里有哪些节点 / 连线。
- 要用工具直接改 `.prg` 内容：改文本、建节点、连线、删节点、批量改色、自动排版。
- 要批量处理一堆 `.prg`（例如给多个工程的根节点挂同一批子节点）。

**不适用**：应用内编辑器操作、扩展（extension）开发、`.prg` 之外的文本文件编辑（本工具集不做通用文件读写）。

## Quick Reference

```powershell
$env:PROJECT_GRAPH_OWNERSHIP_HELPER_PATH="<repo>\app\src-tauri\target\release\project-graph-ownership-helper.exe"
$prg="<目标 .prg 绝对路径>"

pnpm cli -- tool list                       # 29 个工具 + 入参 JSON Schema
pnpm cli -- tool describe edit_text_node    # 单工具 schema
pnpm cli -- tool invoke get_all_nodes --project $prg --input "{}" --allow-upgrade

$input='{\"ref\":\"n3\",\"data\":{\"text\":\"新文本\"}}'
pnpm cli -- tool invoke edit_text_node --project $prg --input $input --allow-upgrade
```

> 本机实测可直接跑仓库源码入口：`node <repo>/node_modules/@graphif/project-graph-cli/src/cli.mjs`（该文件仅 100 B，`import "tsx/esm"` 后加载 `app/src/cli/project-graph.ts`，即**当前 TS 源码**，不是预编译产物）。

## Core Rules

1. **三条前置，缺一即失败**
   - `PROJECT_GRAPH_OWNERSHIP_HELPER_PATH` → 指向原生 ownership helper 二进制（`<repo>/app/src-tauri/target/release/project-graph-ownership-helper.exe`），否则 `OWNERSHIP_HELPER_UNAVAILABLE`。
   - 旧 schema 工程加 `--allow-upgrade`，否则 `PROJECT_UPGRADE_REQUIRED`；升级过一次后该工程不再需要。
   - **先读后写**：`n1` / `e1` 这类引用是运行时分配的、不写在文件里、不跨调用保证复用；改之前先跑一次 `get_all_nodes`，否则 `unknown_ref`。
2. **参数顺序固定**：`tool invoke <tool> --project <path> --input <JSON> [--allow-upgrade]`，错序报 `INVALID_COMMAND`。
3. **PowerShell 5.1 里 JSON 必须转义成 `\"`**，否则 `INVALID_JSON`；cmd / bash 用单引号包 JSON。直接 `& node ... --input '{"ref":"n1"}'` 会被 PowerShell 吃掉引号 → `INVALID_JSON`，须走 `ProcessStartInfo` 或先转义。
4. **写操作会按当前 schema 整体重打包容器**（不可逆格式升级）——操作前先备份目标文件。
5. **执行分支决定落盘语义**（见下条）；Closed 项目写成功后立即重打包落盘，Open 项目改动只留内存。
6. **两条分支，行为不同**
   - **Open 分支**（桌面应用正打开该路径）：改动只留内存、不落盘；选中/视口类工具可用。
   - **Closed 分支**（无人打开）：从磁盘一次性加载，19 个 closed-capable 工具可跑；6 个 selection 工具与 4 个 viewport 工具返回 `PROJECT_MUST_BE_OPEN`（实测被拒：`create_text_node`、`generate_node_tree_by_text`、`select_objects`、`get_selected_refs`、`get_nodes_in_viewport`）。
   - 输出结构也不同：同一对象 `type` 在 Open 分支是**内部字符**（TextNode→`Y`、边→`Aj`、Section→`$`），Closed 分支是**类名**（`TextNode` / `LineEdge` / `Section`）。别写死字符串判断。
7. **实测耗时**：小工程单次调用约 **3–5 秒**；299 对象工程写操作 **15–30 秒**（加载 + 重打包）。批量改动按此预算；CLI 声明 Node ≥ 26，本机 v24.11.0 仅告警可跑。

## 工具分类（29 个）

- **读**：`get_all_nodes`（万能入口，顺带分配全部引用）· `get_object_details` · `search_text_nodes_by_regex` · `get_children` · `get_parents` · `check_connections` · `get_selected_nodes`\* · `get_selected_refs`\*
- **建**：`create_text_node`（落视野中心；`width` 只能配 `sizeAdjust:"manual"`，manual 必须给 `width`）· `breadth_expand_node`（一次给源节点建一层子节点 + 自动连线，右侧 100px / 纵向 60px）· `depth_expand_node`（链式，间距 150）· `generate_node_tree_by_text`（按 **2 空格缩进**建整棵树，不返回引用，会自动补一个 `root` 根节点）· `expand_node_tree_from_node`
- **改**：`edit_text_node`（至少给一个字段；auto 模式会重算尺寸；失败自动回滚）· `edit_image_node`（`displaySize:{basis:"width"|"height"|"longest_edge", value:16–4096}` + `isBackground`，**保持原始宽高比**，只能作用于 `ImageNode`）· `batch_change_color`（`[R,G,B,A]`，A 为 0–1）· `change_edge_text`
- **连线**：`create_edges`（**部分成功**语义，逐条看 `success` / `edgeRef`；schema 标 `text` 必填，实测省略也能成功并按 `""` 处理；Section 也是可连线的 `ConnectableEntity`，可作 source/target）
- **删**：`delete_node` · `delete_nodes` · `delete_selected_nodes`\* · `delete_all_nodes`
- **排版**：`auto_layout_dag`（前置：≥2 个不重复引用、非 Section 的可连接节点、同一父 Section 层级、`refs` 内 ≥1 条有向连线、整体构成 DAG；实测仅重排 refs 内的节点，返回 `movedCount` / `internalEdgeCount`）· `sort_selected_nodes_by_x`\* · `sort_selected_nodes_by_y`\*
- **图片**：`search_and_add_image_node`（联网 Openverse，本机若无法访问 `api.openverse.org` 会直接 `TOOL_EXECUTION_FAILED`）· `recognize_image`（需模型能力，支持传 Section）
- **选中 / 视口**：`select_objects`\* · `get_nodes_in_viewport`\*

\* 需工程处于打开态（Closed 项目下返回 `PROJECT_MUST_BE_OPEN`）。

## Section（分组框）与嵌套

**没有任何工具能创建 / 改名 / 收纳成员 / 折叠 Section。** Section 只来自两种途径：应用内 UI 创建，或直接改 `stage.msgpack`（对象形如 `{"_":"Section","text":"…","children":[{"$":"/index"}],"_collisionBoxNormal":…}`，对象间引用是 JSON 指针 `{"$":"/索引"}`；改完以压缩级别 0 重新打包成 ZIP）。手工构造经 CLI 加载验证可行。

以下矩阵在 **Open 分支（桌面应用正打开工程，Section 由 UI 创建）与 Closed 分支（手工构造的嵌套 Section 副本）双边实测**：

| 工具 | 对 Section 的行为 |
|------|------------------|
| `get_all_nodes` / `get_object_details` / `get_selected_nodes` | 返回 `type`、`position`、`size`、`color`、`childRefs`（嵌套时 `childRefs` 里是子 Section 的引用）——**不含 `text`，分区标题读不到**（数据层保留，仅输出层丢弃） |
| `edit_text_node` | 拒绝：`wrong_node_type`（expected `TextNode`，actual `Section` / Open 分支为 `"$"`）——**不能改标题** |
| `batch_change_color` | 生效，Section 颜色可改 |
| `get_children` / `get_parents` | 空 / 只反映**连线**关系——分区成员关系与连线父子是两套体系 |
| `search_text_nodes_by_regex` | 不匹配 Section 标题（只搜 TextNode） |
| `create_edges` | 可把 Section 当 source / target |
| `auto_layout_dag` | 跨 Section 层级 → `mixed_containers`；Section 自身不能作为 refs 成员 |
| `create_text_node` / `breadth_expand_node` / `depth_expand_node` | 新建节点**不会自动进入 Section**，即使几何位置完全落在框内（Open 分支实测：新建 n22/n23 落在 Section 矩形内部，`childRefs` 不变；源码里只有 UI 的 `addTextNode` 会调 `sectionInOutManager.goInSections`） |
| `recognize_image` | **唯一“懂 Section 内容”的工具**：递归查找 Section（含多层嵌套 Section）内的 ImageNode 并识别，实测两层嵌套可穿透 |
| `select_objects` / `get_selected_refs` / `get_selected_nodes`（Open 分支） | 实测可选中：`selectedCount:1` → `refs:["n21"]` → 详情返回 `type:"$"` + `childRefs`（仍无 `text`）；选择状态跨调用保留 |
| `sort_selected_nodes_by_x/y`（Open 分支） | 实测：选中 `[TextNode,TextNode,Section]` 时 `movedCount:2` —— 只移动 TextNode，Section 原地不动 |
| `delete_selected_nodes`（Open 分支） | 实测：选中 Section 后删除 → `{deletedNodeCount:1, deletedAssociationCount:0}`，**只删 Section 自身、children 全部提升到顶层**（与 `delete_node` 同语义，不连坐） |

**删除语义（最容易踩坑，实测）**：

| 场景 | 结果 |
|------|------|
| 删**展开态** Section（顶层） | `deletedNodeCount:1`，只删自己，children 提升回顶层 |
| 删**展开态** Section（嵌套内层） | 只删自己，children **移交给父 Section** |
| 删**折叠态** Section（`isCollapsed: true`） | **递归删除全部后代**（实测工程 300 → 285 个对象，含关联边） |
| Open 分支 `delete_selected_nodes`（选中 Section） | `{deletedNodeCount:1, deletedAssociationCount:0}`，4 个 children 全部保留并提升到顶层——展开态不连坐，与 `delete_node` 语义一致 |

> Section 的尺寸由 `adjustLocationAndSize()` 按 children 自动重算，构造时写入的矩形会被覆盖；嵌套时外层会再包住内层。

## 推荐调用序列

**改一个节点文本**：`get_all_nodes` → `edit_text_node {ref,data:{text}}` → `get_all_nodes` 复核

**在一个节点下长一棵子树**：
```
get_all_nodes
→ breadth_expand_node {ref,texts:[…]}     # 或 depth_expand_node / expand_node_tree_from_node
→ auto_layout_dag {refs:[根,子…]}          # 需要 refs 内 ≥1 条内部连线
→ get_all_nodes
```

**从零搭一小张图**：`get_all_nodes` → `create_text_node` ×2 → `create_edges` → `auto_layout_dag` → `get_all_nodes`
> 顺序要求：改文本 / 改宽度要在 `auto_layout_dag` **之前**做，否则排版被破坏。

**批量改文字 + 改色**：无批量替换工具，`edit_text_node` 逐个改；颜色用 `batch_change_color` 一次完成。

**要带分组的图**：工具只能生成「无分组」的平面结构；先用 CLI 建节点与连线，再在应用里手动框选建 Section（或直接改 `stage.msgpack` 造 Section）。

## 错误码速查

| 错误码 | 处理 |
|--------|------|
| `OWNERSHIP_HELPER_UNAVAILABLE` | 设 `PROJECT_GRAPH_OWNERSHIP_HELPER_PATH`；退出码 1 |
| `PROJECT_UPGRADE_REQUIRED` | 加 `--allow-upgrade` |
| `PROJECT_VERSION_UNSUPPORTED` | 工程比运行时新，需新版应用 |
| `unknown_ref`（`details.ref`） | 引用不存在；先跑 `get_all_nodes` 重新分配引用；退出码 1 |
| `stale_ref`（`details.ref`） | 引用指向**已删除**对象；重新 `get_all_nodes` 取新引用；退出码 1 |
| `PROJECT_MUST_BE_OPEN` | 该工具需要应用打开此工程（selection / viewport 类）；退出码 1 |
| `PROJECT_BUSY` / `PROJECT_NOT_FOUND` / `PROJECT_LOAD_FAILED` | 被占用 / 不存在 / 非 ZIP 或损坏；退出码 1 |
| `INVALID_JSON` / `INVALID_COMMAND` / `UNKNOWN_TOOL` | 引号转义 / 参数顺序 / 工具名错；退出码 2 |
| `TOOL_INPUT_INVALID` | 入参不符合工具 schema（例：`auto_layout_dag` refs < 2、把边 ref 传给 `delete_node`）；退出码 2 |
| `TOOL_EXECUTION_FAILED` | 执行阶段异常（例：`search_and_add_image_node` 联网失败）；退出码 1 |
| `CANCELLED` | SIGINT/SIGTERM，退出码 130，Closed 项目不留半成品 |
| 工具内 `wrong_node_type` / `no_changes` / `invalid_size_mode` / `missing_width` / `not_dag` / `mixed_containers` 等 | 见各工具前置；**这类错误走 stdout 且退出码为 0**（`{"success":false,"error":{...}}`），与进程级错误码要分开判断 |

## Red Flags — STOP

| 情形 | 处理 |
|------|------|
| 想用文本编辑器 / Read / Write 直接改 `.prg` | STOP：`.prg` 是 ZIP + msgpack 二进制，改不了；走 CLI 工具 |
| 拿上次会话的 `n1` / `e1` 直接去改 | STOP：引用不跨调用保证复用，先 `get_all_nodes` |
| 直接对真实工程写而不备份 | STOP：写操作会重打包并升级 schema，先复制备份 |
| 应用正开着该工程却期待落盘 | 确认 Open 语义：改动只在内存 |
| 指望工具创建 / 改名 / 收纳 Section | STOP：工具集无此能力；Section 只能来自 UI 或直接改 `stage.msgpack` |
| 以为删一个 Section 只影响它自己 | 先看 `isCollapsed`：折叠态会**连坐全部后代** |

## Common Mistakes

- 忘记设 ownership helper 路径 → 误判为「工具不可用」。
- 老工程不加 `--allow-upgrade` → `PROJECT_UPGRADE_REQUIRED`；加了才在内存升级。
- PowerShell 里 JSON 用普通双引号 → `INVALID_JSON`。
- 以为 `create_edges` 的 `text` 必填 → 实测省略也能成功（按空串处理）。
- 把 `type` 写死成字符串判断 → Open 分支是 `Y` / `Aj` / `$`，Closed 分支是 `TextNode` / `LineEdge` / `Section`。
- 想读分区标题 → 当前工具输出不含 `Section.text`，只能从应用里看或解析 `stage.msgpack`。
- 以为在 Section 内新建节点会自动成为成员 → 不会；工具创建的节点永远挂在顶层。
- 先 `auto_layout_dag` 再改文本 / 宽度 → 排版被打乱。
- 期待「按文本批量替换节点内容」的原生工具——**不存在**，只能逐条 `edit_text_node`。
- 期待「新建 `.prg`」的原生工具——**不存在**：工程必须先存在，或自行拼 ZIP（`stage/tags/reference/metadata.msgpack`，压缩级别 0，版本 2.7.0）。

## References（目标仓库内）

- CLI 对外契约：`docs/agents/cli.md`
- 工具定义与执行语义：`app/src/core/service/dataManageService/aiEngine/BuiltInToolRegistry.ts` / `BuiltInToolExecutors.tsx`
- Closed 分支能力白名单与分支路由：`app/src/core/service/dataManageService/aiEngine/BuiltInToolRuntimeProfiles.ts` · `app/src/cli/ClosedProjectInvocation.ts` · `app/src/cli/ProjectGraphCliRuntime.ts`
- Section 模型与收纳/删除语义：`app/src/core/stage/stageObject/entity/Section.tsx` · `stageManager/concreteMethods/StageSectionInOutManager.tsx` · `stageManager/concreteMethods/StageDeleteManager.tsx`
- 容器读写与所有权：`app/src/core/Project.tsx`（`getFileContent`）· `app/src/cli/OwnershipHelper.ts` · `app/src/cli/ClosedProjectFileSystemProvider.ts`
