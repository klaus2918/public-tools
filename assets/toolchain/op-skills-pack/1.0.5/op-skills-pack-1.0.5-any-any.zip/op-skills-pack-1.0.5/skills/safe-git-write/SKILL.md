---
name: safe-git-write
category: generic
status: active
phase_role: support
description: Git 写操作唯一入口。所有 git 写操作（commit/push/merge/rebase/reset/stash/branch -D 等）必须经此 skill。三级 commit 框架 + 混合提交检测 + 格式校验。
version: "3.1.0"
updated_at: 2026-09-12
---

# safe-git-write — 安全 Git 写操作

## 调用方式

```
/safe-git-write <git 操作意图> [附加说明]
```

示例：
```
/safe-git-write commit 提交刚才的改动
/safe-git-write push 推到 origin
/safe-git-write git branch -D old-feature
```

**入口规则**：
1. 收到 `/safe-git-write` 后，立即进入操作类型识别
2. 若用户只输入 `/safe-git-write`，询问需要执行哪种 git 写操作
3. 所有 git 写命令必须由本 Skill 流程内部执行；禁止绕过

---

## 三级操作等级框架（commit 操作）

| 等级 | 名称 | 适用场景 | 安全逻辑 |
|:----:|:----:|---------|---------|
| **L1** | 🚀 快速 | hotfix / tweak / 单文件小改 | 跳过混合提交检测，一次 ask 确认后直接提交 |
| **L2** | ✅ 标准 | 普通 feature / 日常维护 | 混合提交检测→提示（不拒绝），一次 ask 含完整预览 |
| **L3** | 🔒 严格 | 大变更 / 跨模块 / 高风险 | 混合提交检测硬拒绝，保留全部安全逻辑 |

非 commit 操作（push / merge / branch -D 等）不涉及等级选择。

---

## 提交信息格式规范

所有 commit message **必须**遵循以下格式：

```
<type>(<scope>): 【<中文标签>】<title> @AI G

<body>

<footer>
```

### 字段说明

| 字段 | 必填 | 规则 |
|------|:----:|------|
| **type** | ✅ | feat / fix / refactor / docs / style / test / chore / perf / update |
| **scope** | ✅ | 变更范围（模块名/包名/目录名） |
| **中文标签** | ✅ | 中文关键词，用 `【】` 包裹 |
| **title** | ✅ | 简短描述，首字母小写，结尾无句号 |
| **@AI G** | ✅ | 末尾固定后缀，标识 AI 生成的提交 |

### 示例

```
feat(bpm-todo): 【新增】待办列表批量审批功能 @AI G
fix(op-browser): 【修复】verify_mode=dom 模式下截图校验残留 @AI G
```

---

## 操作类型识别

| 操作 | 流程 |
|------|------|
| commit | 选择等级 → 分析暂存区 → **提交前强制校验** → 混合提交检测 → 确认 → 执行 |
| push | 确认远程和分支 → 执行 |
| merge/rebase | 确认源和目标 → 执行 |
| branch -D | 确认分支名 → 检查未合并提交 → 执行 |
| reset/stash | 确认操作类型 → 执行 |

---

## 提交前强制校验（安全门禁）

暂存区确定后、ask 确认前，**必须**依次执行以下两项；任一失败即禁止提交，回退修复后重跑（不得跳过、不得放宽）。

### 1. 敏感信息扫描

```bash
python -X utf8 skills/safe-git-write/scripts/scan-sensitive.py
```

- 默认扫描**暂存区**文件；`--all` 扫描全部受跟踪文件（发布前审计）；`--path <目录>` 扫描工作区目录。
- 退出码 1 表示命中**阻断级**（凭据/私钥/连接串/内网地址/身份证手机号/本地阻断词），必须修复。
- **提示级**命中（本地提示词，如内部项目代号）只提示不阻断；私有仓库可接受，公开前必须清理。
- 误报处理：优先改写为占位写法（`<占位名>`、`${ENV_VAR}`、RFC 5737 地址、`example.com`），
  不要放宽规则；确需调整白名单时同步更新 `references/sensitive-terms.example` 说明。
- 组织专有敏感词放在**不入库**的 `.sensitive-terms`（阻断级）/ `.sensitive-terms.warn`（提示级），
  格式见 `references/sensitive-terms.example`。

### 2. 文本文件兜底校验（validate-text）

对暂存区中的非 .java 文本文件（.md/.json/.xml/.yaml/.js/.ts/.vue 等）逐一校验：

```bash
python -c "import sys;sys.argv=['x','validate-text','<文件路径>']"
# 或经 java-fs skill：validate-text <文件路径>
```

校验内容：UTF-8 可解码、U+FFFD 乱码计数、BOM 检测、结构化文件语义解析、转义残留检测。
.java 文件由 java-fs 的 `validate-java` 覆盖。

### 3. 提交后自查

- 确认未误加忽略文件（`git status` 中不应出现 `.env`、`config.local.*`、`.sensitive-terms*`、密钥扩展名）。
- 确认提交信息符合格式规范。
- 确认无 `--no-verify` / `--no-gpg-sign`（任何情况禁止）。

---

## 安全约束

1. **禁止绕过**：所有 git 写操作必须经此 skill
2. **禁止 --no-verify / --no-gpg-sign**：任何情况下不得使用
3. **提交前强制校验**：敏感信息扫描 + 文本兜底校验，见上节
4. **混合提交检测**：L2 提示，L3 硬拒绝
5. **提交前清理**：自动删除 *.stackdump 文件
6. **格式校验**：commit message 必须符合规范

---

## Version

| Field | Value |
|-------|-------|
| Skill | safe-git-write |
| Version | 3.1.0 |
| Updated | 2026-09-12 |
