#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""暂存区敏感信息扫描（提交前闸门）

用途：在 git 提交前扫描将要入库的内容，拦截凭据、私钥、真实基础设施地址、
个人身份信息等敏感串，避免其进入提交历史。

设计要点：
  1. 内置规则只覆盖「通用安全类别」（私钥/云密钥/连接串/凭据键值/内网地址等），
     不含任何组织专有名词，因此本脚本可安全入库与分发。
  2. 组织专有敏感词（内部项目代号、客户名、内部域名等）由本地配置文件提供，
     该配置文件**不入库**（见 .gitignore 的敏感词防线）。这样既保护内部信息，
     又不会因扫描器本身泄露这些词。
  3. 支持白名单：允许文档/占位符中的示例值（如 example.com、RFC 5737 文档地址、
     noreply 邮箱）通过。

用法：
  python -X utf8 scan-sensitive.py                # 扫描已暂存文件（默认，提交前用）
  python -X utf8 scan-sensitive.py --all          # 扫描工作区全部受跟踪文件（发布前用）
  python -X utf8 scan-sensitive.py --path <目录>  # 扫描指定目录（含未跟踪文件）
  python -X utf8 scan-sensitive.py --staged --json

退出码：0 = 通过；1 = 命中敏感串（禁止提交）；2 = 用法或环境错误。

本地敏感词文件（可选，默认路径，均不入库）：
  <仓库根>/.sensitive-terms       阻断级：命中即禁止提交（凭据、真实基础设施、客户与个人身份）
  <仓库根>/.sensitive-terms.warn  提示级：仅提示（如内部项目代号，私有仓库内属已知残留）
  每行一个词，# 开头为注释；匹配大小写不敏感、按子串匹配。
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys

# ---------------------------------------------------------------- 内置规则
# 只放通用安全类别；组织专有词一律走本地敏感词文件
BUILTIN_RULES = [
    ("私钥块", re.compile(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP )?PRIVATE KEY-----")),
    ("云厂商/平台密钥", re.compile(
        r"\b(?:AKIA[0-9A-Z]{16}|LTAI[0-9A-Za-z]{12,}|ghp_[0-9A-Za-z]{36,}"
        r"|github_pat_[0-9A-Za-z_]{20,}|xox[baprs]-[0-9A-Za-z-]{10,}"
        r"|sk-[A-Za-z0-9]{20,})\b")),
    ("URL 内嵌凭据", re.compile(r"[a-zA-Z][a-zA-Z0-9+.-]*://[^\s/@:]+:[^\s/@]+@[^\s\"'<>]+")),
    ("数据库/服务连接串", re.compile(
        r"(?i)\b(?:jdbc:[a-z0-9]+|mongodb(?:\+srv)?|redis|rediss|postgres(?:ql)?"
        r"|mysql|oracle|dm8|ftp|sftp)://[^\s\"'<>]+")),
    ("凭据键值对", re.compile(
        r"(?i)\b(?:password|passwd|pwd|secret|api[_-]?key|access[_-]?key"
        r"|secret[_-]?key|private[_-]?key|app[_-]?secret|client[_-]?secret"
        r"|auth[_-]?token|credential)\b\s*[:=]\s*[\"']([^\s\"',;#]{6,})[\"']")),
    ("内网 IPv4", re.compile(
        r"(?<![\d.])(?:10\.\d{1,3}|172\.(?:1[6-9]|2\d|3[01])|192\.168)\.\d{1,3}\.\d{1,3}(?![\d.])")),
    ("中国手机号", re.compile(r"(?<!\d)1[3-9]\d{9}(?!\d)")),
    ("身份证号", re.compile(r"(?<!\d)\d{17}[\dXx](?!\d)")),
    ("Windows 用户目录", re.compile(r"(?i)\b[a-z]:\\users\\[^\\\s\"'<>|,)]+")),
]

# 默认白名单：文档中合法的示例值与占位值
DEFAULT_ALLOW = [
    re.compile(r"(?i)\b(?:example|sample|demo|test|localhost|invalid)\.[a-z]{2,}\b"),
    re.compile(r"(?i)@(?:example\.(?:com|org|net)|localhost)\b"),
    re.compile(r"192\.0\.2\.\d{1,3}"),          # RFC 5737 TEST-NET-1
    re.compile(r"198\.51\.100\.\d{1,3}"),       # RFC 5737 TEST-NET-2
    re.compile(r"203\.0\.113\.\d{1,3}"),        # RFC 5737 TEST-NET-3
    re.compile(r"127\.0\.0\.1"),
    re.compile(r"0\.0\.0\.0"),
    # 占位符写法：<占位名>（含中文说明，如 <口令已脱敏>）
    re.compile(r"<[^<>]{0,60}>"),
    # shell 变量展开：${VAR} / ${!var:-} / $VAR
    re.compile(r"\$\{[^{}]{0,80}\}"),
    re.compile(r"(?i)\b(?:your|xxx|placeholder|example|changeme|redacted)\b"),
]

SKIP_EXT = {".png", ".jpg", ".jpeg", ".gif", ".ico", ".zip", ".gz", ".pdf",
            ".pyc", ".xlsx", ".docx", ".jar", ".woff", ".woff2", ".ttf", ".lock"}
# 敏感词文件自身参与扫描会自我命中，按文件名跳过
SKIP_NAMES = {".sensitive-terms", ".sensitive-terms.warn"}
MAX_BYTES = 4 * 1024 * 1024


def git(repo: str, *args: str) -> tuple[int, str]:
    p = subprocess.run(["git", "-C", repo] + list(args), capture_output=True)
    return p.returncode, p.stdout.decode("utf-8", "replace")


def repo_root(start: str) -> str:
    code, out = git(start, "rev-parse", "--show-toplevel")
    if code != 0:
        print("[错误] 当前目录不是 git 仓库", file=sys.stderr)
        sys.exit(2)
    return out.strip()


def list_staged(repo: str) -> list[str]:
    code, out = git(repo, "diff", "--cached", "--name-only", "--diff-filter=ACM")
    if code != 0:
        print("[错误] 无法读取暂存区", file=sys.stderr)
        sys.exit(2)
    return [l.strip() for l in out.splitlines() if l.strip()]


def list_tracked(repo: str) -> list[str]:
    code, out = git(repo, "ls-files")
    return [l.strip() for l in out.splitlines() if l.strip()] if code == 0 else []


def walk_dir(path: str) -> list[str]:
    found = []
    for dirpath, dirnames, filenames in os.walk(path):
        if ".git" in dirpath.split(os.sep):
            continue
        dirnames[:] = [d for d in dirnames if d != ".git"]
        for fn in filenames:
            found.append(os.path.relpath(os.path.join(dirpath, fn), path).replace("\\", "/"))
    return found


def load_terms(repo: str, name: str) -> list[str]:
    """读取本地敏感词清单。name 为文件名（如 .sensitive-terms）。"""
    path = os.path.join(repo, name)
    if not os.path.isfile(path):
        return []
    terms = []
    with open(path, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.strip()
            if line and not line.startswith("#"):
                terms.append(line)
    return terms


# 阻断词：命中即禁止提交（凭据、真实基础设施、客户与个人身份等）
BLOCK_TERMS_FILE = ".sensitive-terms"
# 提示词：命中仅提示（如内部项目代号；私有仓库内属已知残留，公开前需清理）
WARN_TERMS_FILE = ".sensitive-terms.warn"


def collect_rules(block_terms: list[str], warn_terms: list[str]):
    """返回 (rules, rule_name -> tier)。tier ∈ {block, warn}。"""
    rules = []
    tiers = {}
    for name, rx in BUILTIN_RULES:
        rules.append((name, rx))
        tiers[name] = "block"
    if block_terms:
        rx = re.compile("|".join(re.escape(t) for t in block_terms), re.I)
        rules.append(("本地阻断词", rx))
        tiers["本地阻断词"] = "block"
    if warn_terms:
        rx = re.compile("|".join(re.escape(t) for t in warn_terms), re.I)
        rules.append(("本地提示词", rx))
        tiers["本地提示词"] = "warn"
    return rules, tiers


def list_ignored(repo: str) -> set[str]:
    """返回被 .gitignore 排除、不会被提交的路径集合（这些文件无需扫描）。"""
    code, out = git(repo, "ls-files", "--others", "--ignored", "--exclude-standard", "-z")
    if code != 0:
        return set()
    return {x for x in out.split("\0") if x}


def load_file_list(path: str) -> list[str]:
    """读取 NUL 分隔的文件清单（路径相对仓库根）。"""
    with open(path, "rb") as fh:
        raw = fh.read()
    return [x.decode("utf-8") for x in raw.split(b"\0") if x]


def is_text(data: bytes) -> bool:
    if b"\x00" in data[:4096]:
        return False
    try:
        data.decode("utf-8")
        return True
    except UnicodeDecodeError:
        return False


def allowed(line: str) -> bool:
    return any(rx.search(line) for rx in DEFAULT_ALLOW)


def scan_file(fs_path: str, rules, max_hits: int = 200):
    hits = []
    try:
        if os.path.getsize(fs_path) > MAX_BYTES:
            return hits
        with open(fs_path, "rb") as fh:
            data = fh.read()
    except OSError:
        return hits
    if not is_text(data):
        return hits
    for lineno, line in enumerate(data.decode("utf-8").splitlines(), 1):
        for name, rx in rules:
            m = rx.search(line)
            if not m:
                continue
            snippet = line.strip()
            if allowed(snippet):
                continue
            if len(snippet) > 200:
                snippet = snippet[:200] + "..."
            hits.append((lineno, name, snippet))
            break
        if len(hits) >= max_hits:
            break
    return hits


def main() -> int:
    ap = argparse.ArgumentParser(description="暂存区敏感信息扫描")
    ap.add_argument("--repo", default=".", help="仓库路径（默认当前目录）")
    ap.add_argument("--staged", action="store_true", help="扫描已暂存文件（默认行为）")
    ap.add_argument("--all", action="store_true", help="扫描全部受跟踪文件（发布前审计）")
    ap.add_argument("--path", help="扫描指定目录（含未跟踪文件）")
    ap.add_argument("--files", help="扫描清单中的文件（NUL 分隔、路径相对仓库根）")
    ap.add_argument("--json", action="store_true", help="以 JSON 输出")
    args = ap.parse_args()

    repo = repo_root(os.path.abspath(args.repo))
    block_terms = load_terms(repo, BLOCK_TERMS_FILE)
    warn_terms = load_terms(repo, WARN_TERMS_FILE)
    rules, tiers = collect_rules(block_terms, warn_terms)

    if args.path:
        base = os.path.abspath(args.path)
        files = walk_dir(base)
        prefix = base
        mode = "路径"
    elif args.files:
        files = load_file_list(args.files)
        prefix = repo
        mode = "文件清单"
    elif args.all:
        files = list_tracked(repo)
        prefix = repo
        mode = "全部受跟踪文件"
    else:
        files = list_staged(repo)
        prefix = repo
        mode = "暂存区"

    findings = []
    ignored = set() if args.path else list_ignored(repo)
    for rel in files:
        ext = os.path.splitext(rel)[1].lower()
        if ext in SKIP_EXT or os.path.basename(rel) in SKIP_NAMES:
            continue
        if rel in ignored:
            continue
        fs = os.path.join(prefix, rel.replace("/", os.sep))
        if not os.path.isfile(fs):
            continue
        for lineno, name, snippet in scan_file(fs, rules):
            findings.append({"file": rel, "line": lineno, "rule": name, "snippet": snippet,
                             "tier": tiers.get(name, "block")})

    blocked = [f for f in findings if f["tier"] == "block"]
    warned = [f for f in findings if f["tier"] == "warn"]

    if args.json:
        print(json.dumps({"mode": mode, "scanned": len(files),
                          "block_terms": len(block_terms), "warn_terms": len(warn_terms),
                          "blocked": len(blocked), "warned": len(warned),
                          "findings": findings}, ensure_ascii=False, indent=2))
    else:
        print("扫描范围：%s（候选文件 %d 个；阻断词 %d 条 / 提示词 %d 条）"
              % (mode, len(files), len(block_terms), len(warn_terms)))
        if blocked:
            print("结果：发现 %d 处【阻断级】敏感信息，禁止提交" % len(blocked))
            print()
            for f in blocked:
                print("  %s:%d  [%s]" % (f["file"], f["line"], f["rule"]))
                print("      %s" % f["snippet"])
        else:
            print("结果：阻断级检查通过")
        if warned:
            print()
            print("提示：另有 %d 处【提示级】命中（如内部代号；私有仓库可接受，公开前需清理）" % len(warned))
            for f in warned[:20]:
                print("  %s:%d  [%s]" % (f["file"], f["line"], f["rule"]))
            if len(warned) > 20:
                print("  ... 其余 %d 处（用 --json 查看全部）" % (len(warned) - 20))
    return 1 if blocked else 0


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except (AttributeError, OSError):
        pass
    sys.exit(main())
