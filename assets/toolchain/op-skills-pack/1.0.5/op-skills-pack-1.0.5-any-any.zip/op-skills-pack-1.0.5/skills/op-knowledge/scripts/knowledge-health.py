#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""op-knowledge health/heal 检测脚本 v1.2.0

用法：
  python op-knowledge/scripts/knowledge-health.py health [--kb <路径>] [--json]
  python op-knowledge/scripts/knowledge-health.py heal   [--kb <路径>] [--dry-run]
  python op-knowledge/scripts/knowledge-health.py baseline [--kb <路径>]

功能：
  health   ：体检（结构/文档/死链/过时/git/FFFD/重复），输出健康评分
  heal     ：自愈（补时间线索引/注册标签/清理 git 残留/标记死链），--dry-run 只预览
  baseline ：生成健康基线（记录当前状态供对比）
"""
import argparse
import json
import os
import re
import subprocess
import sys
import time

# fallback default KB (real path; adjust per machine if KB moved)
DEFAULT_KB = r'D:\Note\ThinkSource'

# ---------- 工具函数 ----------
def rel(kb, p):
    return os.path.relpath(p, kb).replace('\\', '/')

def git(kb, *args):
    r = subprocess.run(['git', '-C', kb] + list(args), capture_output=True, text=True, encoding='utf-8')
    return r.stdout, r.returncode

# ---------- health ----------
def check_structure(kb):
    issues = []
    for sub in ['01-收集', '02-分类', '03-输出', '时间线.md']:
        if not os.path.exists(os.path.join(kb, sub)):
            issues.append({'level': 'P1', 'item': 'structure', 'desc': '缺失目录/文件: %s' % sub})
    return issues

def check_docs(kb):
    docs = []
    for root, d, fs in os.walk(os.path.join(kb, '02-分类')):
        for f in fs:
            if f.endswith('.md'):
                docs.append(os.path.join(root, f))
    return docs

# 死链检测用：shell/bash 条件表达式等代码片段特征
_SHELL_LIKE_RE = re.compile(r'[\$"\'*;|=<>(){}\\]|^\-[a-zA-Z]|^if\s|^then\s|^fi$')


def _fenced_code_spans(txt):
    """返回围栏代码块（``` 或 ~~~）的 (start, end) 区间列表。"""
    spans = []
    open_at = None
    open_char = None
    pos = 0
    for line in txt.splitlines(keepends=True):
        stripped = line.lstrip()
        marker = None
        if stripped.startswith('```'):
            marker = '`'
        elif stripped.startswith('~~~'):
            marker = '~'
        if marker is not None:
            if open_at is None:
                open_at = pos
                open_char = marker
            elif marker == open_char:
                spans.append((open_at, pos + len(line)))
                open_at = None
                open_char = None
        pos += len(line)
    if open_at is not None:          # 未闭合的围栏：延伸到文末
        spans.append((open_at, pos))
    return spans


def check_dead_links(kb, docs):
    """死链检测：[[wikilink]] 指向不存在的 .md。

    判定改进：
    1) 全局文件名匹配：知识库所有 .md 文件名（含 02-分类/ 子目录与日期前缀归一），
       而非仅 kb/target.md 当前路径——避免子目录文档误报。
    2) 排除 TOML/代码标识（[[providers]] 数组、含 . : / 的路径、纯日期）。
    3) 排除围栏代码块（```/~~~）内的 [[...]]——bash 条件语法 [[ ... ]] 会被
       误判为 wikilink。
    4) 排除目标含 shell 特征字符（$ " * == ; 等）的匹配。
    """
    # 收集全部 .md 文件名（去 .md）与归一名（去日期前缀）
    all_names = set()
    all_basenames = set()
    for root, d, fs in os.walk(kb):
        for f in fs:
            if f.endswith('.md'):
                base = f[:-3]
                all_names.add(base)
                m = re.match(r'^(\d{4}-\d{2}-\d{2}-)(.*)$', base)
                all_basenames.add(m.group(2) if m else base)

    issues = []
    wiki = re.compile(r'\[\[([^\]]+)\]\]')
    todo_marker = re.compile(r'<!--\s*TODO[^>]*-->')
    for d in docs:
        with open(d, encoding='utf-8', errors='replace') as _f:
            txt = _f.read()
        # 提取已标记 TODO 死链注释段，跳过其中的链接
        todo_spans = [(m.start(), m.end()) for m in todo_marker.finditer(txt)]
        fence_spans = _fenced_code_spans(txt)
        for m in wiki.finditer(txt):
            if any(s <= m.start() <= e for s, e in todo_spans):
                continue
            if any(s <= m.start() < e for s, e in fence_spans):
                continue
            target = m.group(1).split('|')[0].strip()
            # 排除行内代码反引号中的 [[...]]（如 `[[providers]]` TOML 数组）
            before = txt[max(0, m.start() - 3):m.start()]
            after = txt[m.end():m.end() + 3]
            if '`' in before or '`' in after:
                continue
            # 排除非知识库目标：路径/代码标识/日期/空
            if not target:
                continue
            if re.search(r'[.:\\/]', target) or re.match(r'^\d{4}-\d{2}-\d{2}$', target):
                continue
            # 排除 shell/bash 条件表达式等代码片段
            if _SHELL_LIKE_RE.search(target):
                continue
            # 归一目标：去日期前缀后查全局文件名
            tgt_norm = re.sub(r'^\d{4}-\d{2}-\d{2}-', '', target)
            hit = (target in all_names or target in all_basenames
                   or tgt_norm in all_basenames)
            if not hit:
                issues.append({'level': 'P2', 'item': 'dead-link', 'file': rel(kb, d), 'target': target})
    return issues

def check_stale(kb, docs, days=60):
    issues = []
    now = time.time()
    for d in docs:
        age = (now - os.path.getmtime(d)) / 86400
        if age > days:
            issues.append({'level': 'P2', 'item': 'stale', 'file': rel(kb, d), 'age_days': int(age)})
    return issues

def check_git(kb):
    issues = []
    out, rc = git(kb, 'status', '--porcelain')
    dirty = [l for l in out.splitlines() if l.strip()]
    if dirty:
        issues.append({'level': 'P1', 'item': 'git-dirty', 'count': len(dirty), 'detail': '\n'.join(dirty[:10])})
    return issues

def check_fffd(kb, docs):
    issues = []
    for d in docs:
        with open(d, 'rb') as _f:
            raw = _f.read()
        if b'\xef\xbf\xbd' in raw:
            issues.append({'level': 'P1', 'item': 'fffd', 'file': rel(kb, d)})
    return issues

def check_duplicate(kb, docs):
    """重复检测：仅同一目录下同名文件才算重复（不同目录的同名如 README.md 属正常）。"""
    from collections import Counter
    by_dir = {}
    for d in docs:
        by_dir.setdefault(os.path.dirname(d), []).append(os.path.basename(d))
    issues = []
    for d, names in by_dir.items():
        dup = {k: v for k, v in Counter(names).items() if v > 1}
        for k, v in dup.items():
            issues.append({'level': 'P3', 'item': 'duplicate-name', 'name': k, 'count': v,
                           'dir': rel(kb, d)})
    return issues

def health(kb, verbose=True):
    issues = []
    docs = check_docs(kb)
    issues += check_structure(kb)
    issues += check_dead_links(kb, docs)
    issues += check_stale(kb, docs)
    issues += check_git(kb)
    issues += check_fffd(kb, docs)
    issues += check_duplicate(kb, docs)

    # 评分：P1=10, P2=5, P3=2
    score_map = {'P1': 10, 'P2': 5, 'P3': 2}
    total = sum(score_map.get(i['level'], 5) for i in issues)
    health_score = max(0, 100 - total)
    grade = 'A' if health_score >= 90 else 'B' if health_score >= 75 else 'C' if health_score >= 60 else 'D'

    result = {
        'kb': kb,
        'score': health_score,
        'grade': grade,
        'doc_count': len(docs),
        'issues': issues,
        'issue_count': len(issues),
        'p1_count': sum(1 for i in issues if i['level'] == 'P1'),
        'p2_count': sum(1 for i in issues if i['level'] == 'P2'),
        'p3_count': sum(1 for i in issues if i['level'] == 'P3'),
    }
    return result

# ---------- heal ----------
def heal(kb, dry_run=True):
    """自愈：只处理可逆项（补 git 残留由用户确认），返回建议动作列表。"""
    actions = []
    issues = health(kb, verbose=False)['issues']
    for i in issues:
        if i['item'] == 'dead-link':
            actions.append({'action': 'mark-dead-link', 'file': i.get('file'), 'target': i.get('target'),
                            'desc': '标记死链（写入文档头部 TODO 注释）'})
        elif i['item'] == 'fffd':
            actions.append({'action': 'fix-fffd', 'file': i.get('file'),
                            'desc': '修复 FFFD 乱码（需人工或脚本逐字节替换）'})
        elif i['item'] == 'git-dirty':
            actions.append({'action': 'git-status', 'count': i.get('count'),
                            'desc': 'git 未提交项，需人工确认提交/清理'})
    return actions

# ---------- main ----------
def main():
    ap = argparse.ArgumentParser(description='op-knowledge health/heal')
    ap.add_argument('cmd', choices=['health', 'heal', 'baseline'])
    ap.add_argument('--kb', default=DEFAULT_KB)
    ap.add_argument('--json', action='store_true')
    ap.add_argument('--dry-run', action='store_true')
    args = ap.parse_args()

    if args.cmd == 'health':
        r = health(args.kb)
        if args.json:
            print(json.dumps(r, ensure_ascii=False, indent=2))
        else:
            print('== op-knowledge health ==')
            print('知识库: %s' % args.kb)
            print('文档数: %d' % r['doc_count'])
            print('健康评分: %d/100 (等级 %s)' % (r['score'], r['grade']))
            print('问题: P1=%d P2=%d P3=%d' % (r['p1_count'], r['p2_count'], r['p3_count']))
            for i in r['issues'][:15]:
                print('  [%s] %s: %s' % (i['level'], i['item'], i.get('desc') or i.get('file') or i.get('name')))
        return 1 if r['p1_count'] > 0 else 0
    elif args.cmd == 'heal':
        actions = heal(args.kb, dry_run=args.dry_run)
        if args.dry_run:
            print('== heal 预览（--dry-run）==')
        else:
            print('== heal 执行 ==')
        if not actions:
            print('无自动修复项，健康。')
        for a in actions:
            print('  - %s: %s' % (a['action'], a.get('desc')))
    elif args.cmd == 'baseline':
        r = health(args.kb)
        ts = time.strftime('%Y-%m-%d %H:%M')
        print('基线已记录: score=%d grade=%s doc=%d issues=%d @ %s' % (r['score'], r['grade'], r['doc_count'], r['issue_count'], ts))
    return 0
if __name__ == '__main__':
    sys.exit(main())
