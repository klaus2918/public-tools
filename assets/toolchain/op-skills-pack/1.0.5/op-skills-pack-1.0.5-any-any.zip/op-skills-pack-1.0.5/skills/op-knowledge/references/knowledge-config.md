# 知识库配置与多库管理

> 详细配置说明，主文档见 SKILL.md。

---

## 配置位置

| 文件 | 位置 | 说明 |
|------|------|------|
| 模板配置 | `references/knowledge-bases.example.yaml` | 随 op 体系包分发，含占位路径 |
| 真实配置 | `config/knowledge-bases.yaml`（挂载点 → `.basic/evolved/op-knowledge/config/`） | 本机环境配置（含真实知识库绝对路径），**不随包分发** |

> **环境配置不打包原则**：知识库绝对路径属个人环境配置，只写真实配置（evolved 挂载点），不进入 op 体系 zip 包。op-skills 仓库内仅保留模板（example）。

---

## 首次使用引导

当真实配置不存在或为空时：

```
1. 询问用户知识库路径（支持多个，逐个添加）
2. 校验：目录存在？是 git 仓库？（非 git 则提示 init 或拒绝）
3. 探测：读取 02-分类/ 下目录，生成 category_mapping 草案
4. 用户确认草案 → 写入 `config/knowledge-bases.yaml`（挂载点 → `.basic/evolved/op-knowledge/config/`）
5. 进入正常流水线
```

---

## 配置字段说明

| 字段 | 说明 |
|------|------|
| `default` | 默认知识库 id，op-done Step 2 未指定库时使用 |
| `knowledge_bases[].id` | 库唯一标识（如 think-source） |
| `knowledge_bases[].path` | 知识库根目录绝对路径（环境配置，不进包） |
| `knowledge_bases[].pipeline` | 该库的模板目录 / 目标分类候选 |
| `knowledge_bases[].category_mapping` | 变更类型 → 分类目录映射 |
| `knowledge_bases[].precipitation_types` | 可复用沉淀类型清单 |
| `knowledge_bases[].git` | git 自动提交开关与提交信息格式 |

---

## 多库命令

| 命令 | 作用 |
|------|------|
| `/op-knowledge list` | 列出已注册知识库 |
| `/op-knowledge add <path>` | 引导新增知识库 |
| `/op-knowledge switch <id>` | 切换默认知识库 |
| `/op-knowledge status` | 校验各库路径与 git 状态 |

---

## 已存在时的管理

```
1. 读真实配置，选默认库（default）或用户指定库
2. 校验路径存在、是 git 仓库
3. 切到该库根目录，执行目录流水线（①收集→②分类→③输出→④归档）
4. 每阶段即时 git add，阶段末 git commit，最后 git status 确认干净
```
