---
name: op-knowledge
category: support
status: active
phase_role: support
description: "知识库管理 skill。管理实践验证信息，术语标签索引（G2 对接），保鲜机制按领域/项目状态驱动。"
version: "2.3.0"
updated_at: "2026-09-14"
---

# op-knowledge · 知识库管理

## Overview

将对话、变更中产生的**素材**通过目录流水线自动管理，最终沉淀为可归档的结构化 Markdown 文档。底层原则：纯 .md 文件集合（零数据库、零专有格式），所有文件变更必须立即进入 Git 版本控制。

## When to Use

- op-done：归档可复用能力/决策/经验到知识库
- op-plan：非 hotfix 变更进入 plan 阶段时检索知识库
- op-build：任务前复用检索
- 用户说"记下来"：走素材流水线

## 命令速查表

| 命令 | 作用 |
|------|------|
| `/op-knowledge list` | 列出已注册知识库 |
| `/op-knowledge add <path>` | 引导新增知识库 |
| `/op-knowledge switch <id>` | 切换默认知识库 |
| `/op-knowledge status` | 校验各库路径与 git 状态 |
| `/op-knowledge init` | 首用引导：环境探测 + 生成真实配置骨架 |
| `/op-knowledge search <关键词>` | 检索知识库（按类型/标签/关键词），返回命中摘要 |
| `/op-knowledge health` | 健康体检（结构/内容/git/死链/重复/FFFD），输出健康评分 |
| `/op-knowledge heal` | 自愈：补时间线索引/注册标签/清理 git 残留/标记死链（--dry-run 预览） |
| `/op-knowledge lifecycle` | 内容生命周期管理（active/stale/archived 迁移） |

## 多知识库管理概览

本 skill 支持管理**多个知识库**。知识库路径与管理信息由 yaml 配置维护：

- **模板配置**：`references/knowledge-bases.example.yaml`（随包分发）
- **真实配置**：`config/knowledge-bases.yaml`（本机环境，不随包分发；skill 内 `config/` 为 junction 挂载点，实际存于 `.basic/evolved/op-knowledge/config/`）

> 详细配置字段说明、首次使用引导、多库命令 → [references/knowledge-config.md](references/knowledge-config.md)

## 消费方接入协议

调用方（op / op-plan / op-build / op-done / op-000）执行知识库操作前，**必须先判断配置状态**：

```
Step 1: 检查 config/knowledge-bases.yaml 是否存在且非空
  ├─ 存在且非空 → 读取配置，按 default 指定的库执行（正常流程）
  └─ 不存在或为空 → 进入 Step 2
Step 2: 询问用户二选一
  ├─ 立即引导配置：执行首次使用引导（见 references/knowledge-config.md）
  └─ 本次跳过：提示后续可用 /op-knowledge init 补配
```

> **路径说明**：`config/`、`sites/`、`tasks/` 等均为 skill 内 junction 挂载点（映射到 `.basic/evolved/<skill>/<挂载点>`）；skill 代码与调用方只使用 skill 相对路径，无需感知实际存储位置。

**禁止**：不检查文件就触发初始化；不询问就跳过；假装已检索 / 已沉淀。

## 目录结构概览

```
<知识库根目录>
├── 时间线.md                ← 全局索引
├── 01-收集/               ← 原始素材（未加工）
├── 02-分类/               ← 已归类文档（按类型分目录）
│   ├── 021-待办/ ... 030-领域词汇/
│   ├── proj-<项目名>/     ← 项目级知识库分区
│   └── 标签索引.md        ← 标签字典
└── 03-输出/               ← 正在输出的文档
```

流水线方向：`01-收集 → 02-分类/<类型>/ → 03-输出/ → 02-分类/<类型>/`

> 详细流水线规则、处理流程、待办管理、技能管理、时间线管理、索引工程、Git 提交规范、项目分区管理 → [references/knowledge-pipeline.md](references/knowledge-pipeline.md)

## 检索概览

```
/op-knowledge search <关键词> [--type 实践总结|技术收集|踩坑经验] [--tag #标签] [--kb <id>]
```

检索范围：`02-分类/` 全部子目录（含 proj-<项目>/），返回命中文档路径 + 标题 + 一句话摘要（≤5 条）。

> 详细检索规则、来源变更元信息、可复用匹配 → [references/knowledge-search.md](references/knowledge-search.md)

## 术语同步概览（plan ↔ 知识库）

`op-plan` G2 产出的术语表与知识库 `02-分类/030-领域词汇/` 双向同步，**知识库为唯一存放**：

| 方向 | 动作 | 时机 |
|------|------|------|
| 检索优先 | G2 先 `search <术语>`；命中 → 复用既有定义，并视为「被引用」（刷新活跃标记） | plan G2 |
| 新增回写 | 未命中 → plan.md 术语表定义后，同步写入 `02-分类/030-领域词汇/` | plan 出方案前 |
| 保鲜联动 | 领域/项目状态变化按 `lifecycle` 规则迁移（active/stale） | 周期 / 归档时 |

- **禁止**：只在 plan.md 写术语而不回写知识库（会造成双份口径漂移）；
- 同步后跑 `health` 确认等级不下降；
- 未配置知识库时按「消费方接入协议」先询问，**禁止假装已同步**。

## 健康体检概览

```
/op-knowledge health [--kb <id>] [--json]
/op-knowledge heal [--dry-run]
```

体检维度：结构(P1)、死链(P2)、过时(P2)、git(P1)、FFFD(P1)、重复(P3)。健康评分：满分 100，等级 A≥90 / B≥75 / C≥60 / D<60。

> 详细体检维度、自愈规则、定时自检 → [references/knowledge-health.md](references/knowledge-health.md)

## 内容生命周期概览（领域/项目驱动）

保鲜机制完全替换为领域/项目状态驱动（非时间）：

| 驱动因素 | 说明 | 操作 |
|----------|------|------|
| 领域活跃度 | 所属领域有活跃变更 | 知识保持 active |
| 项目状态 | 项目已归档或暂停 | 知识标记 stale |
| 术语对齐度 | 术语与当前 plan.md 术语表一致 | 保持 active |
| 被引用情况 | 被新 plan 检索命中 | 刷新活跃标记 |

> 详细生命周期规则、保活机制、自更新机制 → [references/knowledge-lifecycle.md](references/knowledge-lifecycle.md)

## Version 表

| 日期 | 变更 |
|------|------|
| 2026-06-26 | 初始版本 |
| 2026-08-14 | 迁移至 op 体系，新增多知识库配置 |
| 2026-08-19 | v1.3.0 拆分 SKILL.md 为精简核心 + references/ 子文档 |
| 2026-08-20 | v2.0.0 删除 When to Use，生命周期改为领域/项目驱动 |
| 2026-09-14 | v2.1.0 新增「消费方接入协议」：无配置时调用方必须询问引导，禁止静默跳过；v2.2.0 协议增加显式检查步骤（先判断配置文件是否存在，存在则正常读取，不存在才触发初始化）；模板配置迁至 `references/knowledge-bases.example.yaml`，`config/` 明确为 junction 挂载点 |
