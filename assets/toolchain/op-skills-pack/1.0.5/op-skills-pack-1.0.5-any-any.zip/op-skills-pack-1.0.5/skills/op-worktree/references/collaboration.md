# 协作流程图

> op-worktree 与 op 流水线各阶段的协作关系

## op 工作流完整协作图

```
/op ─→ op-plan
         │
         ├── [可选] 调用 op-worktree create      # 验证方案可行性
         │         → op-worktree enter
         │         → 验证 → op-worktree remove --only
         │
         ├── plan 确认 → phase → build
         │
/op ─→ op-build
         │
         ├── [自动] 检测跨端任务
         │         → 提示用户调用 op-worktree create
         │         → 创建完成 → 进入 worktree 目录
         │
         ├── 逐 task 实现 → 验证
         │
         ├── 全部完成 → phase → done
         │
/op ─→ op-done
         │
         ├── 最终确认 → 提交/归档
         │         → 提示清理 worktree（人工执行）
         │
         └── [人工] op-worktree remove <name> --only ...
```

## 阶段适配速查

| 阶段 | op-worktree 角色 | 调用时机 |
|------|-----------------|---------|
| **plan（op-plan）** | 可选：提前创建 worktree 验证方案可行性 | op-plan 检测到方案涉及跨端改动且用户要求验证时，提示调用 op-worktree |
| **build（op-build）** | **必要入口**：op-build 启动时检测跨端标记，提示用户调用 op-worktree create | op-build 初始化检查阶段，检测到需跨端开发时 |
| **done（op-done）** | 不需要 | 归档后由人工手动调用 `remove` 清理 worktree |
| 独立调用 | 用户直接 `/op-worktree <子命令>` | 任何阶段均可 |

## 自动检测机制

op-build 启动时检测以下条件，判断是否需要 op-worktree：

- tasks.md 中任务涉及多个端标识（如"后端: xxx" + "PC前端: xxx"）
- 用户主动要求隔离开发环境

检测到需要 worktree 时，op-build 暂停并提示：

```
检测到当前变更涉及多端仓库，建议先创建配套 worktree 隔离开发环境。
是否调用 /op-worktree create <name>？ (y/n)
```

## op 从 op-worktree 获取的信息

- 当前隔离环境的路径
- 各端的分支名
- 合并状态（从配置中快速读取）
