#!/usr/bin/env bash
# ============================================================
# check-status.sh — 检查 worktree 实际状态
#
# 用途：检查指定 worktree 的分支、合并状态、未提交变更
#       合并判断使用内容 diff（覆盖标准 merge + squash merge + cherry-pick）
#       支持 --incoming 参数显示分支未合入提交清单
# 用法：bash check-status.sh <repo_path> <worktree_name> [base_branch] [--incoming]
#       示例: bash check-status.sh /d/projects/backend user-auth dev
#             bash check-status.sh /d/projects/backend user-auth dev --incoming
#
# 配置驱动模式（status/enter/remove 调用）：
#   bash check-status.sh <repo_path> <worktree_name> <base_branch> --from-config <config_yaml>
#     — 解析 config.yaml 中该端声明的分支名（兼容字符串/对象两种形式），
#       输出「配置声明分支 vs 实际分支」对比，不一致时给出警示
#
# 端字段解析（与 config-example.md 同步）：
#   ① 旧字符串：        backend: feat/contract-manage
#   ② 新对象（推荐）：  backend:
#                          branch: feat/contract-manage
#                          path:   /d/work/backend-xxx    # 可选
# ============================================================

set -e

REPO_PATH="$1"
WORKTREE_NAME="$2"
BASE_BRANCH="${3:-dev}"
SHOW_INCOMING=false
FROM_CONFIG=""
CONFIG_FILE_ARG=""

# 解析可选参数
i=0
for arg in "$@"; do
  i=$((i + 1))
  case "$arg" in
    --incoming|--summary) SHOW_INCOMING=true ;;
    --from-config)
      # 下一个参数是 config 路径
      FROM_CONFIG=true
      # 找下一个非选项参数
      ;;
  esac
done

# 单独处理 --from-config 后跟 config 路径
ARGS=("$@")
for ((idx=0; idx<${#ARGS[@]}; idx++)); do
  if [ "${ARGS[$idx]}" = "--from-config" ]; then
    if [ $((idx + 1)) -lt ${#ARGS[@]} ]; then
      CONFIG_FILE_ARG="${ARGS[$((idx + 1))]}"
    fi
  fi
done

if [ -z "$REPO_PATH" ] || [ -z "$WORKTREE_NAME" ]; then
  echo "❌ 用法: bash check-status.sh <repo_path> <worktree_name> [base_branch] [--incoming]"
  echo "   示例: bash check-status.sh /d/projects/backend user-auth dev"
  exit 1
fi

WORKTREE_DIR="$REPO_PATH/.worktrees/$WORKTREE_NAME"

if [ ! -d "$WORKTREE_DIR" ]; then
  echo "❌ Worktree 目录不存在: $WORKTREE_DIR"
  exit 1
fi

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Worktree: $WORKTREE_NAME"
echo "  仓库: $REPO_PATH"
echo "  基分支: $BASE_BRANCH"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# 当前分支
CURRENT_BRANCH=$(git -C "$WORKTREE_DIR" branch --show-current 2>/dev/null)
echo "  当前分支: ${CURRENT_BRANCH:-（无）}"

# 配置驱动模式：从 config.yaml 解析端字段声明的分支名（兼容字符串/对象两种形式）
# 调用约定：bash check-status.sh <repo_path> <worktree_name> <base_branch> --from-config <config_yaml>
# 注：本模式假设调用方已知端 key（status/enter/remove 通过 --only 或默认主端确定）
#    解析流程：从 config 的 worktrees.<name> 段内扫描第一个端字段声明的 branch 值
if [ -n "$CONFIG_FILE_ARG" ] && [ -f "$CONFIG_FILE_ARG" ]; then
  EXPECTED_BRANCH=$(awk '
    /^    worktrees:/ { in_wt_block=1; next }
    /^    [a-zA-Z0-9_-]+:/ { in_wt_block=0; next }
    in_wt_block && /^      [a-zA-Z0-9_-]+:$/ { in_wt_entry=1; next }
    in_wt_entry && /^      [a-zA-Z0-9_-]+:/ { in_wt_entry=0 }
    in_wt_entry {
      # 字符串形式：        backend: feat/contract-manage
      if ($0 ~ /^        [a-zA-Z0-9_-]+:[[:space:]]+\S/) {
        val = $0; sub(/^[[:space:]]*[^:]+:[[:space:]]*/, "", val); gsub(/"/, "", val);
        print val
      }
      # 对象形式：        backend: \n          branch: feat/contract-manage
      if ($0 ~ /^        [a-zA-Z0-9_-]+:$/) {
        getline nl
        if (nl ~ /^          branch:[[:space:]]+\S/) {
          v = nl; sub(/^[[:space:]]*[^:]+:[[:space:]]*/, "", v); gsub(/"/, "", v);
          print v
        }
      }
    }
  ' "$CONFIG_FILE_ARG" | head -1)

  if [ -n "$EXPECTED_BRANCH" ]; then
    echo "  配置声明分支: $EXPECTED_BRANCH"
    if [ "$CURRENT_BRANCH" = "$EXPECTED_BRANCH" ]; then
      echo "  ✅ 实际分支与配置声明一致"
    elif [ -n "$CURRENT_BRANCH" ]; then
      echo "  ⚠️  实际分支与配置声明不符（实际: $CURRENT_BRANCH，配置: $EXPECTED_BRANCH）"
    else
      echo "  ⚠️  当前不在任何分支上（配置期望: $EXPECTED_BRANCH）"
    fi
  else
    echo "  ⚠️  无法从 config 中解析端字段声明分支"
  fi
fi

# 未提交变更
UNCOMMITTED=$(git -C "$WORKTREE_DIR" status --short 2>/dev/null | wc -l)
if [ "$UNCOMMITTED" -gt 0 ]; then
  echo "  未提交变更: $UNCOMMITTED 个文件"
  git -C "$WORKTREE_DIR" status --short 2>/dev/null
else
  echo "  工作区干净"
fi

# 合并状态（两步判断法，覆盖标准 merge + squash cherry-pick）
if [ -n "$CURRENT_BRANCH" ]; then
  echo -n "  已合并到 $BASE_BRANCH: "
  MERGED_TYPE=""
  # 判断远程引用是否存在，不存在则降级到本地
  if git -C "$REPO_PATH" rev-parse --verify "refs/remotes/origin/$BASE_BRANCH" >/dev/null 2>&1; then
    BASE_REF="origin/$BASE_BRANCH"
  else
    BASE_REF="$BASE_BRANCH"
  fi

  # 第一步：标准 merge 检测（hash 链）
  if git -C "$REPO_PATH" merge-base --is-ancestor "$CURRENT_BRANCH" "$BASE_REF" 2>/dev/null; then
    MERGED_TYPE="标准 merge"
  else
    # 第二步：内容 diff 检测（squash merged / cherry-pick）
    # 比较分支 HEAD 与基分支的内容差异，静默模式
    if git -C "$WORKTREE_DIR" diff --exit-code "$BASE_REF...HEAD" >/dev/null 2>&1; then
      MERGED_TYPE="内容一致（squash/cherry-pick）"
    fi
  fi

  if [ -n "$MERGED_TYPE" ]; then
    echo "是（$MERGED_TYPE）"
  else
    echo "否"
    # 显示内容差异概览（未合并时有用）
    DIFF_LINES=$(git -C "$WORKTREE_DIR" diff "$BASE_REF...HEAD" --stat 2>/dev/null | tail -1)
    if [ -n "$DIFF_LINES" ]; then
      echo "  内容差异: $DIFF_LINES"
    fi
  fi
fi

# 未推送提交
if [ -n "$CURRENT_BRANCH" ]; then
  UNPUSHED=$(git -C "$WORKTREE_DIR" log "@{upstream}..HEAD" --oneline 2>/dev/null | wc -l)
  if [ "$UNPUSHED" -gt 0 ]; then
    echo "  未推送提交: $UNPUSHED 个"
    git -C "$WORKTREE_DIR" log "@{upstream}..HEAD" --oneline --format="    %h %s" 2>/dev/null | head -5
  else
    echo "  未推送提交: 全部已推送或无远程跟踪"
  fi
fi

# 推送检查（检测远程是否已同步——只在有远程引用时执行）
if [ -n "$CURRENT_BRANCH" ] && [ -n "$MERGED_TYPE" ]; then
  if git -C "$REPO_PATH" rev-parse --verify "refs/remotes/origin/$BASE_BRANCH" >/dev/null 2>&1; then
    UNPULLED=$(git -C "$REPO_PATH" rev-list --count "origin/$BASE_BRANCH..$BASE_BRANCH" 2>/dev/null)
    if [ "$UNPULLED" -gt 0 ]; then
      echo "  ⚠ 注意: 本地 $BASE_BRANCH 落后远程 $UNPULLED 个提交，建议先 git pull"
    fi
  fi
fi

# ─── --incoming / --summary 模式：显示分支未合入提交清单 ───
if [ "$SHOW_INCOMING" = true ] && [ -n "$CURRENT_BRANCH" ]; then
  echo ""
  echo "📋 分支独有提交（$BASE_BRANCH..$CURRENT_BRANCH）："

  INCOMING_CNT=$(git -C "$WORKTREE_DIR" rev-list --count "$BASE_REF..HEAD" 2>/dev/null)
  echo "   总计: $INCOMING_CNT 个提交"

  if [ "$INCOMING_CNT" -gt 0 ]; then
    echo ""
    # 按类型分组统计
    echo "   按类型分组："
    # commit subject 格式示例: "feat(contract): xxx" / "fix: xxx" / "chore(scope): xxx"
    # 提取第一个 ":" 之前的非 scope 段作为类型
    while IFS='' read -r line; do
      # 从 commit subject (去掉 hash) 中提取类型
      subject=$(echo "$line" | sed 's/^[[:space:]]*[0-9a-f]\{7,9\} //')
      type=$(echo "$subject" | sed 's/(.*)//' | sed 's/:.*//')
      case "$type" in
        feat|fix|chore|docs|refactor|style|perf|test) ;;
        *) type="其他" ;;
      esac
      echo "$type" >> /tmp/wt_incoming_types_$$.tmp
    done < <(git -C "$WORKTREE_DIR" log --oneline "$BASE_REF..HEAD" 2>/dev/null)
    if [ -f /tmp/wt_incoming_types_$$.tmp ]; then
      sort /tmp/wt_incoming_types_$$.tmp | uniq -c | sort -rn | while read count label; do
        echo "     $label: $count"
      done
      rm -f /tmp/wt_incoming_types_$$.tmp
    fi
    if [ -n "$OTHER" ]; then
      OTHER_CNT=$(echo "$OTHER" | wc -l)
      echo "     其他: $OTHER_CNT"
    fi

    echo ""
    echo "   提交列表："
    git -C "$WORKTREE_DIR" log --oneline "$BASE_REF..HEAD" --format="    %h %s" 2>/dev/null | head -30

    if [ "$INCOMING_CNT" -gt 30 ]; then
      echo "    ... 仅显示前 30 个（共 $INCOMING_CNT 个）"
    fi

    # 内容差异统计（--stat 概览）
    echo ""
    DIFF_STAT=$(git -C "$WORKTREE_DIR" diff "$BASE_REF...HEAD" --stat 2>/dev/null | tail -1)
    if [ -n "$DIFF_STAT" ]; then
      echo "   文件变更概览: $DIFF_STAT"
    fi
  fi
fi

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
