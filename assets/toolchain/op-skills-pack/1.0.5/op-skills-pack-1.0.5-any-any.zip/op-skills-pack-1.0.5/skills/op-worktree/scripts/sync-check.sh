#!/usr/bin/env bash
# ============================================================
# sync-check.sh — 扫描实际 worktree 与配置对比
#
# 用途：扫描各仓库实际 worktree 列表，与 config.yaml 配置对比
#       输出差异（新增/缺失），供 sync 子命令使用
# 用法：bash sync-check.sh <config_yaml>
#
# 端字段解析（与 config-example.md 同步）：
#   ① 旧字符串：        backend: feat/contract-manage
#   ② 新对象（推荐）：  backend:
#                          branch: feat/contract-manage
#                          path:   /d/work/backend-xxx    # 可选
#   两种形式均提取 branch 字段；path 缺省走 repos.<端key>.path
#
# 「分支不符」判定逻辑：
#   - 仅当 实际分支（git branch --show-current）≠ config 声明 branch 时告警
#   - 配置声明的合理命名分歧（如后端 feat/contract-manage 与前端 feature/contract-manage）
#     视为「配置即如此」，不会误判为不符
# ============================================================

set -e

CONFIG_FILE="$1"

if [ -z "$CONFIG_FILE" ] || [ ! -f "$CONFIG_FILE" ]; then
  echo "用法: bash sync-check.sh <config_yaml>"
  echo "示例: bash sync-check.sh workspaces/DEMO-PROJECT/config.yaml"
  exit 1
fi

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Worktree 同步检查"
echo "  配置文件: $CONFIG_FILE"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# 提取项目 ID
PROJECT_ID=$(grep -n "^projects:" "$CONFIG_FILE" | sed 's/:.*//')
if [ -z "$PROJECT_ID" ]; then
  echo "❌ 配置文件中未找到 projects 字段"
  exit 1
fi

echo ""
echo "📋 配置中登记的 worktree:"
echo ""

REGISTERED=0
MISSING=0
BRANCH_MISMATCH=0
CURRENT_WORKTREE=""
IN_WORKTREES_BLOCK=0

# 已解析但未输出的端字段队列（保证 Worktree 标题先于端字段输出）
END_QUEUE_FILE=$(mktemp)
trap 'rm -f "$END_QUEUE_FILE"' EXIT

# 暂存对象形式的中间状态（等待 branch 子字段闭合）
END_PENDING_KEY=""
END_PENDING_VALUE=""
END_PENDING_FORM=""

# 把一个端字段推到输出队列
queue_end_field() {
  local key="$1" value="$2" form="$3"
  if [ -z "$key" ] || [ -z "$CURRENT_WORKTREE" ]; then return; fi
  echo "$key|$value|$form" >> "$END_QUEUE_FILE"
}

# 把暂存的对象形式端字段入队（如有）
flush_pending_to_queue() {
  if [ -n "$END_PENDING_KEY" ] && [ -n "$CURRENT_WORKTREE" ]; then
    queue_end_field "$END_PENDING_KEY" "$END_PENDING_VALUE" "$END_PENDING_FORM"
  fi
  END_PENDING_KEY=""
  END_PENDING_VALUE=""
  END_PENDING_FORM=""
}

# 排空队列：依次输出每个端字段、做目录/分支检查
flush_end_queue() {
  if [ ! -s "$END_QUEUE_FILE" ]; then return; fi
  while IFS='|' read -r key value form; do
    echo "    端: $key → 分支: $value  [$form]"

    # 解析对应 repo 路径：仅取 repos 段内与端 key 紧邻的 path
    REPO_PATH=""
    local in_repos=0
    local cur_repo_key=""
    while IFS= read -r pline; do
      if echo "$pline" | grep -qE "^    repos:"; then in_repos=1; continue; fi
      if echo "$pline" | grep -qE "^    [a-zA-Z0-9_-]+:"; then in_repos=0; cur_repo_key=""; continue; fi
      if [ "$in_repos" = "1" ]; then
        # 6 空格缩进的端 key 行（如 "      backend:"）
        if echo "$pline" | grep -qE "^      [a-zA-Z0-9_-]+:$"; then
          cur_repo_key=$(echo "$pline" | sed 's/^[[:space:]]*//;s/:.*//')
          continue
        fi
        # 8 空格缩进的 path 行，仅当对应端 key 时采纳
        if [ "$cur_repo_key" = "$key" ] && echo "$pline" | grep -qE "^        path:"; then
          REPO_PATH=$(echo "$pline" | sed 's/^[^:]*:[[:space:]]*//;s/"//g')
        fi
      fi
    done < "$CONFIG_FILE"

    WT_DIR="${REPO_PATH}/.worktrees/${CURRENT_WORKTREE}"
    if [ -n "$REPO_PATH" ] && [ -d "$WT_DIR" ]; then
      BRANCH=$(git -C "$WT_DIR" branch --show-current 2>/dev/null)
      if [ "$BRANCH" = "$value" ]; then
        echo "      ✅ 目录存在，分支与配置一致（实际: $BRANCH）"
      elif [ -n "$BRANCH" ]; then
        echo "      ⚠️  实际分支与配置不符（实际: $BRANCH，配置: $value）"
        BRANCH_MISMATCH=$((BRANCH_MISMATCH + 1))
      else
        echo "      ⚠️  目录存在，但不在分支上"
        BRANCH_MISMATCH=$((BRANCH_MISMATCH + 1))
      fi
    elif [ -n "$REPO_PATH" ]; then
      echo "      ❌ 目录缺失: $WT_DIR"
      MISSING=$((MISSING + 1))
    else
      echo "      ⚠️  无法确定仓库路径（KEY=$key）"
    fi
  done < "$END_QUEUE_FILE"
  : > "$END_QUEUE_FILE"
}

# 边界点：把对象形式暂存字段入队，并排空队列
flush_all() {
  flush_pending_to_queue
  flush_end_queue
}

while IFS= read -r line; do
  # 段落状态：进入 worktrees 段 / 离开
  if echo "$line" | grep -qE "^    worktrees:"; then
    flush_all
    IN_WORKTREES_BLOCK=1
    continue
  fi
  if echo "$line" | grep -qE "^    [a-zA-Z0-9_-]+:"; then
    # 其他 4 空格缩进的段（repos 等）
    flush_all
    IN_WORKTREES_BLOCK=0
    continue
  fi

  # 匹配 worktree name（缩进 6 空格 + 名称 + :）——仅在 worktrees 段内识别
  if [ "$IN_WORKTREES_BLOCK" = "1" ] && echo "$line" | grep -qE "^      [a-zA-Z0-9_-]+:$"; then
    # 进入新条目：flush 上一条目所有暂存/队列
    flush_all
    CURRENT_WORKTREE=$(echo "$line" | sed 's/^[[:space:]]*//;s/://')
    continue
  fi

  # 匹配 created_at（仅在 worktree 条目内有效）—— 输出标题后立即输出端字段
  if [ "$IN_WORKTREES_BLOCK" = "1" ] && echo "$line" | grep -qE "^[[:space:]]*created_at:" && [ -n "$CURRENT_WORKTREE" ]; then
    flush_pending_to_queue
    echo "  Worktree: $CURRENT_WORKTREE"
    echo "    创建日期: $(echo "$line" | sed 's/^[^:]*:[[:space:]]*//;s/"//g')"
    REGISTERED=$((REGISTERED + 1))
    # 标题与日期先输出，再统一输出本条目已收集的端字段
    flush_end_queue
    continue
  fi

  # 匹配对象形式的端 key（8 空格缩进 + key + 冒号结尾，冒号后无值）
  if [ "$IN_WORKTREES_BLOCK" = "1" ] && echo "$line" | grep -qE "^        [a-zA-Z0-9_-]+:$" && [ -n "$CURRENT_WORKTREE" ]; then
    # 之前有对象形式暂存未闭合，先入队
    flush_pending_to_queue
    KEY=$(echo "$line" | sed 's/^[[:space:]]*//;s/:.*//')
    if [ "$KEY" != "created_at" ]; then
      END_PENDING_KEY="$KEY"
      END_PENDING_FORM="object"
      END_PENDING_VALUE=""  # 等待后续 branch 子字段
    fi
    continue
  fi

  # 匹配对象形式的 branch / path 子字段（10 空格缩进）
  if [ "$IN_WORKTREES_BLOCK" = "1" ] && echo "$line" | grep -qE "^          (branch|path):" && [ -n "$END_PENDING_KEY" ]; then
    FIELD_NAME=$(echo "$line" | sed 's/^[[:space:]]*//;s/:.*//')
    FIELD_VALUE=$(echo "$line" | sed 's/^[^:]*:[[:space:]]*//;s/"//g')
    if [ "$FIELD_NAME" = "branch" ]; then
      END_PENDING_VALUE="$FIELD_VALUE"
    fi
    # path 暂不写入配置路径解析（worktrees 端 path 字段未来支持），保留扩展点
    continue
  fi

  # 匹配字符串形式的端 key（8 空格缩进 + key: <value>）——直接入队
  if [ "$IN_WORKTREES_BLOCK" = "1" ] && echo "$line" | grep -qE "^        [a-zA-Z0-9_-]+:[[:space:]]+\S" && [ -n "$CURRENT_WORKTREE" ]; then
    # 之前有对象形式暂存未闭合，先入队
    flush_pending_to_queue
    KEY=$(echo "$line" | sed 's/^[[:space:]]*//;s/:.*//')
    VALUE=$(echo "$line" | sed 's/^[^:]*:[[:space:]]*//;s/"//g')
    if [ "$KEY" != "created_at" ]; then
      queue_end_field "$KEY" "$VALUE" "string"
    fi
    continue
  fi
done < "$CONFIG_FILE"

# 文件末尾：flush 所有未输出的字段
flush_all

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  统计摘要"
echo "  已登记: $REGISTERED 个"
echo "  缺失目录: $MISSING 个"
echo "  分支与配置不符: $BRANCH_MISMATCH 个"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# ─── 分支命名分歧清单（P004）───
# 扫描各 worktree 条目，对比各端声明分支名。出现命名分歧（如后端 feat/xxx 与前端 feature/xxx）时，
# 输出分歧清单并提示用户 ask 确认（视为同一配套 / 视为不同 worktree / 中止）。
# 注意：本段只输出检测结果与 ask 提示，不直接修改 config——
#       sync 阶段的写入由调用方根据用户选择决定。
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  分支命名分歧清单"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

DIVERGENCE_FILE=$(mktemp)
trap 'rm -f "$END_QUEUE_FILE" "$DIVERGENCE_FILE"' EXIT

# 重新遍历 config 收集每个 worktree 的端分支声明
WT_NAME=""
WT_END_FILE=$(mktemp)
trap 'rm -f "$END_QUEUE_FILE" "$DIVERGENCE_FILE" "$WT_END_FILE"' EXIT

while IFS= read -r line; do
  if echo "$line" | grep -qE "^    worktrees:"; then
    # 新段前 flush 上一个 worktree
    if [ -s "$WT_END_FILE" ] && [ -n "$WT_NAME" ]; then
      UNIQUE=$(awk -F'|' '{print $2}' "$WT_END_FILE" | grep -v '^$' | sort -u | grep -c '.' || echo 0)
      if [ "$UNIQUE" -gt 1 ]; then
        echo "$WT_NAME|$UNIQUE" >> "$DIVERGENCE_FILE"
        echo "WT_END_FILE_TMP" >> "$DIVERGENCE_FILE.tmp"
        # 复制当前条目端列表用于分歧清单输出
        cat "$WT_END_FILE" >> "$DIVERGENCE_FILE.tmp"
      fi
      : > "$WT_END_FILE"
    fi
    continue
  fi
  if echo "$line" | grep -qE "^      [a-zA-Z0-9_-]+:$"; then
    WT_NAME=$(echo "$line" | sed 's/^[[:space:]]*//;s/://')
    : > "$WT_END_FILE"
    continue
  fi
  # 字符串形式端字段
  if echo "$line" | grep -qE "^        [a-zA-Z0-9_-]+:[[:space:]]+\S"; then
    KEY=$(echo "$line" | sed 's/^[[:space:]]*//;s/:.*//')
    if [ "$KEY" = "created_at" ]; then continue; fi
    VAL=$(echo "$line" | sed 's/^[^:]*:[[:space:]]*//;s/"//g')
    echo "$KEY|$VAL" >> "$WT_END_FILE"
    continue
  fi
  # 对象形式端字段 key（8 空格 + 冒号结尾）
  if echo "$line" | grep -qE "^        [a-zA-Z0-9_-]+:$"; then
    KEY=$(echo "$line" | sed 's/^[[:space:]]*//;s/:.*//')
    if [ "$KEY" = "created_at" ]; then continue; fi
    # 下一行可能是 branch 子字段
    OBJ_KEY="$KEY"
    continue
  fi
  # 对象形式的 branch 子字段
  if echo "$line" | grep -qE "^          branch:[[:space:]]+\S" && [ -n "$OBJ_KEY" ]; then
    VAL=$(echo "$line" | sed 's/^[^:]*:[[:space:]]*//;s/"//g')
    echo "$OBJ_KEY|$VAL" >> "$WT_END_FILE"
    OBJ_KEY=""
    continue
  fi
done < "$CONFIG_FILE"

# 文件末尾 flush 最后一个 worktree
if [ -s "$WT_END_FILE" ] && [ -n "$WT_NAME" ]; then
  UNIQUE=$(awk -F'|' '{print $2}' "$WT_END_FILE" | grep -v '^$' | sort -u | grep -c '.' || echo 0)
  if [ "$UNIQUE" -gt 1 ]; then
    echo "$WT_NAME|$UNIQUE" >> "$DIVERGENCE_FILE"
    cat "$WT_END_FILE" >> "$DIVERGENCE_FILE.tmp"
  fi
fi

DIVERGENCE_COUNT=$(wc -l < "$DIVERGENCE_FILE" 2>/dev/null || echo 0)
if [ "$DIVERGENCE_COUNT" -eq 0 ]; then
  echo "✅ 未检测到分支命名分歧（各 worktree 各端声明分支一致或仅单一端登记）"
else
  echo "⚠️  检测到 $DIVERGENCE_COUNT 个 worktree 存在分支命名分歧："
  echo ""
  # 简化输出：列出每个分歧 worktree 的端列表（已知命名分歧应被识别为「正常」）
  echo "📋 详细清单（典型场景：后端 feat/xxx 与前端 feature/xxx）："
  echo ""
  cat "$DIVERGENCE_FILE.tmp" | awk -F'|' '{printf "  端 %-15s 声明分支: %s\n", $1, $2}'
  echo ""
  echo "请选择（写入 config 差异前必走）："
  echo "  [1] 视为同一配套（命名分歧属正常约定，写入 config）"
  echo "  [2] 视为不同 worktree（拆分条目，标记未登记）"
  echo "  [3] 中止（保留当前状态不写入，等待人工处理）"
  echo ""
  echo "📌 ask 提示信息须包含：端名 / 声明分支 / 实际分支 / 用户选择项"
  echo "📌 用户确认前不写入 config 差异（防止把命名分歧硬塞进同一 worktree 条目）"
fi

# 扫描实际存在的 worktree（可选）
echo ""
echo "📌 提示: 如需扫描实际的 .worktrees/ 目录检查是否有未登记的 worktree，请在各仓库执行:"
echo "  ls -d <repo_path>/.worktrees/*/"