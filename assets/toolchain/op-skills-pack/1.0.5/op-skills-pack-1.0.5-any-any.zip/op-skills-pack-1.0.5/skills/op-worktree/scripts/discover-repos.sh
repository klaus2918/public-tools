#!/usr/bin/env bash
# ============================================================
# discover-repos.sh — 自动发现配套仓库
#
# 用途：扫描当前目录的同级目录，发现其他 Git 仓库作为配套端候选
#       对前端项目推荐启用 Bun 加速（use_bun: install，已完整适配的可标 full）
# 输出：检测到的 Git 仓库列表，含 use_bun 推荐值
# 用法：bash discover-repos.sh [--base-dir <路径>]
#       bash discover-repos.sh --base-dir <路径> --check-branches <功能名> [--type <type>]
#
# 协作边界：
#   - discover 阶段：仅做仓库识别 + use_bun 推荐，不涉及分支名
#   - create 阶段  ：通过 `--branch-<end>=<分支名>` 按端指定分支名
#                    （优先级：CLI > config > 默认推断 <type>/<功能名>）
#   - config.yaml 端字段支持两种形式：
#       ① 旧字符串 = 分支名
#       ② 新对象   = {branch: <分支名>, path?: <物理路径>}
#     discover 阶段在写入 config 时不强行展开端字段（端分支名由 create 阶段登记）
#
# 分支命名一致性检测（仅 --check-branches 模式）：
#   对每个发现的端扫描其实际分支（按 <type>/<功能名>、feat/、fix/ 等前缀推断），
#   对比各端命名是否一致，不一致时输出分歧清单并提示用户 ask 确认。
#   用户选择 [1] 视为同一配套 / [2] 视为不同 worktree / [3] 中止 后方可继续。
# ============================================================

set -e
shopt -s nullglob 2>/dev/null || true

BASE_DIR=""
CHECK_BRANCHES_NAME=""
CHECK_BRANCHES_TYPE=""

# 参数解析
ARGS=("$@")
i=0
while [ $i -lt ${#ARGS[@]} ]; do
  arg="${ARGS[$i]}"
  case "$arg" in
    --base-dir)
      i=$((i + 1))
      BASE_DIR="${ARGS[$i]:-$(pwd)}"
      ;;
    --check-branches)
      i=$((i + 1))
      CHECK_BRANCHES_NAME="${ARGS[$i]:-}"
      ;;
    --type)
      i=$((i + 1))
      CHECK_BRANCHES_TYPE="${ARGS[$i]:-}"
      ;;
    --*)
      echo "❌ 未知选项: $arg"
      exit 1
      ;;
    *)
      # 兼容旧用法：第一个非选项参数作 BASE_DIR
      if [ -z "$BASE_DIR" ]; then BASE_DIR="$arg"; fi
      ;;
  esac
  i=$((i + 1))
done

if [ -z "$BASE_DIR" ]; then
  BASE_DIR="$(pwd)"
fi
PARENT_DIR="$(dirname "$BASE_DIR")"

echo "🔍 扫描仓库路径: $BASE_DIR"
echo "📂 同级目录: $PARENT_DIR"
echo ""

found=0

# 用关联数组记录发现的端：端 key → 仓库路径（key = basename，用于和 config 的端 key 对齐）
declare -A REPO_PATHS

for dir in "$PARENT_DIR"/*/; do
  # 跳过非目录（nullglob 已处理空情况）
  [ ! -d "$dir" ] && continue

  if [ -d "$dir/.git" ] || [ -f "$dir/.git" ]; then
    repo_name="$(basename "$dir")"
    use_bun="false"
    reason=""

    # 检测是否为前端项目 → 推荐 use_bun: true
    if [ -f "$dir/package.json" ]; then
      if grep -qE '"(vue|vite|vant|element-plus|react|@angular)"' "$dir/package.json" 2>/dev/null; then
        use_bun="true"
        reason="（前端框架检测）"
      fi
    fi

    echo "  ✔ 发现 Git 仓库: $repo_name"
    echo "      路径: $dir"
    echo "      推荐 use_bun: $use_bun $reason"
    REPO_PATHS["$repo_name"]="$dir"
    found=$((found + 1))
  fi
done

if [ "$found" -eq 0 ]; then
  echo ""
  echo "⚠ 未在同级目录发现其他 Git 仓库。"
  echo "  可手动指定仓库路径，或确认当前项目是单仓库模式。"
fi

echo ""
echo "总计: $found 个仓库"

# ─── 分支命名一致性检测（可选）───
# 仅当传入 --check-branches <功能名> 时执行：
#   对每个发现的端扫描其实际分支列表（按 <type>/<功能名> 推断），
#   对比各端命名是否一致。不一致时输出分歧清单并提示用户 ask 确认。
#   注意：本段只输出检测结果与提示，不直接修改任何文件——
#         discover 阶段对 config 的写入由调用方根据用户选择决定。
if [ -n "$CHECK_BRANCHES_NAME" ]; then
  echo ""
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  分支命名一致性检测"
  echo "  候选功能名: $CHECK_BRANCHES_NAME"
  if [ -n "$CHECK_BRANCHES_TYPE" ]; then
    echo "  类型前缀:   $CHECK_BRANCHES_TYPE/"
  else
    echo "  类型前缀:   feat/ (默认推断)"
  fi
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo ""

  TYPE_PREFIX="${CHECK_BRANCHES_TYPE:-feat}"
  ALL_BRANCHES_FILE=$(mktemp)
  trap 'rm -f "$ALL_BRANCHES_FILE"' EXIT

  # 收集每个端的实际分支（匹配 <type>/<功能名>）
  declare -A END_ACTUAL_BRANCH
  for end_key in "${!REPO_PATHS[@]}"; do
    repo_path="${REPO_PATHS[$end_key]}"
    # 列出该端匹配的实际分支（仅本地分支，不含远程）
    MATCHED=$(git -C "$repo_path" branch --list "${TYPE_PREFIX}/${CHECK_BRANCHES_NAME}" 2>/dev/null | sed 's/^[* ]*//' | head -1)
    if [ -z "$MATCHED" ]; then
      # 退化：尝试不带类型前缀的纯功能名匹配
      MATCHED=$(git -C "$repo_path" branch --list "*${CHECK_BRANCHES_NAME}" 2>/dev/null | sed 's/^[* ]*//' | head -1)
    fi
    END_ACTUAL_BRANCH["$end_key"]="$MATCHED"
    echo "$end_key|$MATCHED|$repo_path" >> "$ALL_BRANCHES_FILE"
  done

  # 输出每个端的实际分支
  echo "📋 各端实际分支扫描结果:"
  while IFS='|' read -r ek eb rp; do
    if [ -n "$eb" ]; then
      echo "  ├── $ek : $eb"
    else
      echo "  ├── $ek : （未找到匹配分支 ${TYPE_PREFIX}/${CHECK_BRANCHES_NAME}）"
    fi
  done < "$ALL_BRANCHES_FILE"

  # 收集唯一分支名集合
  UNIQUE_BRANCHES=$(awk -F'|' '{print $2}' "$ALL_BRANCHES_FILE" | grep -v '^$' | sort -u)
  UNIQUE_COUNT=$(echo "$UNIQUE_BRANCHES" | grep -c '.' || echo 0)

  echo ""
  if [ "$UNIQUE_COUNT" -le 1 ]; then
    echo "✅ 各端分支命名一致：$(echo "$UNIQUE_BRANCHES" | head -1)"
    echo "  → 可直接写入 config（无需 ask）"
  else
    echo "⚠️  分支命名一致性检测 — 候选功能名: $CHECK_BRANCHES_NAME"
    while IFS='|' read -r ek eb rp; do
      printf "  ├── %-15s 实际分支: %s\n" "$ek" "${eb:-（无）}"
    done < "$ALL_BRANCHES_FILE"
    echo ""
    echo "请选择（写入 config 前必走）："
    echo "  [1] 视为同一配套（命名分歧属正常约定）"
    echo "  [2] 视为不同 worktree"
    echo "  [3] 中止"
    echo ""
    echo "📌 等待用户确认后才能继续写入 config；ask 提示信息须包含："
    echo "  - 端名 / 声明分支 / 实际分支"
    echo "  - 用户选择项（视为同一配套 / 视为不同 worktree / 中止）"
  fi
fi