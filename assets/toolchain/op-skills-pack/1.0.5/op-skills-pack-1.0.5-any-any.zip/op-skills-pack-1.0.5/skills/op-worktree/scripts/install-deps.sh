#!/usr/bin/env bash
# ============================================================
# install-deps.sh — 自动安装 worktree 中的项目依赖
#
# 用途：在刚创建的 worktree 中安装项目依赖
#       自动检测项目类型（Maven / Node / Python）并执行对应命令
# 用法：bash install-deps.sh <worktree_dir> [--bun]
#       --bun  启用 Bun 临时加速器（用于 config 中该端 use_bun ∈ {install, full} 的前端端）
# ============================================================

set -e

WORKTREE_DIR="$1"
BUN_MODE=false
[ "$2" = "--bun" ] && BUN_MODE=true

if [ -z "$WORKTREE_DIR" ]; then
  echo "❌ 用法: bash install-deps.sh <worktree_dir> [--bun]"
  exit 1
fi

if [ ! -d "$WORKTREE_DIR" ]; then
  echo "❌ 目录不存在: $WORKTREE_DIR"
  exit 1
fi

cd "$WORKTREE_DIR"

echo "📦 检测项目依赖类型..."
echo "   路径: $WORKTREE_DIR"
$BUN_MODE && echo "   模式: Bun 临时加速器已启用"

deps_installed=0

# Maven 项目
if [ -f "pom.xml" ]; then
  echo "   → Maven 项目，执行 mvn compile -DskipTests..."
  if mvn compile -DskipTests 2>&1 | tail -20; then
    # 验证编译产物
    CLASS_COUNT=$(find target/classes -name "*.class" 2>/dev/null | wc -l)
    if [ "$CLASS_COUNT" -gt 0 ]; then
      echo "  ✔ Maven 编译通过（$CLASS_COUNT 个 .class 文件）"
      deps_installed=$((deps_installed + 1))
    else
      echo "  ⚠ mvn compile 成功但 target/classes/ 为空，请手动排查"
    fi
  else
    echo "  ❌ Maven 编译失败，请查看上方 ERROR 信息"
  fi
fi

# Node 项目
if [ -f "package.json" ]; then
  if $BUN_MODE && command -v bun &>/dev/null; then
    echo "   → 使用 Bun 临时加速器安装依赖..."
    if bun install 2>&1 | tail -20; then
      echo "  ✔ Bun 依赖安装完成（临时加速器）"
      # 将 bun.lock 加入 .gitignore，防止被提交
      if [ -f "bun.lock" ]; then
        if [ -f ".gitignore" ]; then
          if ! grep -q "^bun\.lock$" .gitignore; then
            echo "" >> .gitignore
            echo "# Bun 临时加速器锁文件（临时产物，不提交）" >> .gitignore
            echo "bun.lock" >> .gitignore
            echo "  ℹ 已将 bun.lock 加入 .gitignore"
          fi
        else
          echo "bun.lock" > .gitignore
          echo "  ℹ 已创建 .gitignore 并加入 bun.lock"
        fi
      fi
      deps_installed=$((deps_installed + 1))
    else
      echo "  ⚠ Bun 安装失败，降级..."
      # 降级按锁文件类型
      if [ -f "pnpm-lock.yaml" ]; then
        pnpm install 2>&1 | tail -20 && echo "  ✔ pnpm 依赖安装完成" && deps_installed=$((deps_installed + 1)) || echo "  ⚠ pnpm 安装失败"
      elif [ -f "yarn.lock" ]; then
        yarn install 2>&1 | tail -20 && echo "  ✔ yarn 依赖安装完成" && deps_installed=$((deps_installed + 1)) || echo "  ⚠ yarn 安装失败"
      else
        npm install 2>&1 | tail -20 && echo "  ✔ npm 依赖安装完成" && deps_installed=$((deps_installed + 1)) || echo "  ⚠ npm 安装失败"
      fi
    fi
  else
    # 常规安装（非 Bun 模式），按锁文件类型
    if [ -f "pnpm-lock.yaml" ]; then
      echo "   → pnpm 项目，执行 pnpm install..."
      pnpm install 2>&1 | tail -20 && echo "  ✔ pnpm 依赖安装完成" && deps_installed=$((deps_installed + 1)) || echo "  ⚠ pnpm 安装失败"
    elif [ -f "yarn.lock" ]; then
      echo "   → yarn 项目，执行 yarn install..."
      yarn install 2>&1 | tail -20 && echo "  ✔ yarn 依赖安装完成" && deps_installed=$((deps_installed + 1)) || echo "  ⚠ yarn 安装失败"
    else
      echo "   → npm 项目，执行 npm install..."
      npm install 2>&1 | tail -20 && echo "  ✔ npm 依赖安装完成" && deps_installed=$((deps_installed + 1)) || echo "  ⚠ npm 安装失败"
    fi
  fi
fi

# Python 项目
if [ -f "requirements.txt" ]; then
  echo "   → Python 项目，执行 pip install..."
  pip install -r requirements.txt 2>&1 | tail -20 && echo "  ✔ pip 依赖安装完成" && deps_installed=$((deps_installed + 1)) || echo "  ⚠ pip 安装失败"
fi

# 未检测到标准依赖文件
if [ "$deps_installed" -eq 0 ]; then
  echo "   → 未检测到标准依赖文件（pom.xml / package.json / requirements.txt）"
  echo "   → 跳过依赖安装"
fi

echo ""
echo "✅ 依赖安装完成: $deps_installed 个"
