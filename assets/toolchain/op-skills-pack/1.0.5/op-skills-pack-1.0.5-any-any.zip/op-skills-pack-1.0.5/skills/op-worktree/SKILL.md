---
name: op-worktree
category: support
status: active
phase_role: support
description: 多端 Worktree 环境管理。管理跨多端配套服务的 git worktree 全生命周期 + 开发服务管理。
version: "2.0.1"
updated_at: 2026-09-14
dependencies:
  - safe-git-write
---

# op-worktree — 多端 Worktree 环境管理

管理多端配套仓库的 git worktree 全生命周期：**创建 → 切换 → 移除（含分支）** + 开发服务管理。

---

## 核心概念

**多端映射（配套服务）**：一个功能分支跨越多个仓库，每端有独立的 worktree 和分支。

```
功能名: <功能名称>
  ├── <端1> (.worktrees/<功能名>  →  <分支名>)
  ├── <端2> (.worktrees/<功能名>  →  <分支名>)
  └── <端3> (.worktrees/<功能名>  →  <分支名>)
```

---

## 速查表

| 子命令 | 功能 | 交互要求 |
|--------|------|---------|
| `status [name]` | 查看多端 worktree 全景 | 直接执行 |
| `create <name>` | 多端同步创建分支 + worktree | **需用户确认 + safe-git-write** |
| `enter <name> [端]` | 进入指定 worktree 目录 | 直接执行 |
| `remove <name> --only <端>` | 移除 worktree + 分支 | **必须 --only，需用户确认** |
| `sync` | 同步配置与实际 worktree | 直接执行 |
| `start <name> [端]` | 启动各端开发服务 | 直接执行 |
| `build <name> [端]` | 构建指定端 | 直接执行 |
| `debug <name> [端]` | 调试模式启动 | 直接执行 |
| `stop <name> [端]` | 停止已启动的进程 | 直接执行 |
| `port <name> [端]` | 查看端口信息 | 直接执行 |
| `cmd <name> <端> <命令>` | 执行任意命令 | 直接执行 |

---

## 项目级配置文件

### 位置

```
<skill_dir>/workspaces/<project_id>/config.yaml
```

### 配置字段（完整）

| 字段 | 说明 |
|------|------|
| `projects.<id>.repos` | 多端仓库定义，每端含路径和 use_bun 标记 |
| `projects.<id>.base_branch` | 基分支（默认 dev，可自定义） |
| `projects.<id>.worktrees` | 已登记的所有 worktree 映射 |
| `projects.<id>.desc` | 可选：项目描述 |
| `projects.<id>.created_at` | 可选：项目创建时间 |
| `projects.<id>.homepage` | 可选：项目主页 |
| `projects.<id>.tags` | 可选：技术栈标签数组 |
| `projects.<id>.owner` | 可选：负责人对象 |
| `projects.<id>.remotes` | 可选：Git 远程仓库 URL 映射 |
| `worktrees.<name>.<端key>` | 各端配置（支持两种形式：旧字符串/新对象） |
| `worktrees.<name>.<端key>.branch` | 该端 worktree 的分支名 |
| `worktrees.<name>.<端key>.path` | 可选：覆盖物理路径 |
| `worktrees.<name>.created_at` | 首次登记日期 |
| `worktrees.<name>.description` | 可选：功能描述 |
| `worktrees.<name>.task_id` | 可选：任务编号 |
| `worktrees.<name>.task_url` | 可选：任务链接 |
| `worktrees.<name>.owner` | 可选：负责人 |
| `worktrees.<name>.status` | 可选：分支状态（developing/testing/merged/archived） |
| `worktrees.<name>.last_active` | 可选：最后活跃日期 |
| `repos.<端key>.use_bun` | 三态：none/install/full |
| `repos.<端key>.desc` | 可选：端描述 |
| `repos.<端key>.runtime` | 可选：运行时环境对象 |
| `repos.<端key>.port` | 可选：本地开发端口 |
| `repos.<端key>.package_manager` | 可选：包管理器 |
| `repos.<端key>.dev_cmd` | 可选：开发启动命令 |
| `repos.<端key>.build_cmd` | 可选：构建命令 |
| `repos.<端key>.debug_cmd` | 可选：调试启动命令 |
| `repos.<端key>.env` | 可选：环境变量映射 |
| `repos.<端key>.start_order` | 可选：启动顺序 |

### 端字段两种形式（向后兼容）

```yaml
# 形式 1（旧字符串）— 仅指定分支名
worktrees:
  contract-manage:
    backend: feat/contract-manage
    pc-frontend: feature/contract-manage

# 形式 2（新对象）— 分支名 + 可选物理路径
worktrees:
  contract-manage:
    backend:
      branch: feat/contract-manage
    pc-frontend:
      branch: feature/contract-manage
      path: /d/work/<worktree-name>
```

### use_bun 三态语义

| 值 | 含义 |
|------|------|
| `none` | 不使用 Bun |
| `install` | 仅 bun install 加速装包 |
| `full` | 全程 Bun（项目已适配） |

---

## 资产分离

```
op-worktree/                      ← Skill 代码（进 Git）
.basic/evolved/op-worktree/      ← 运行时配置（不进 Git，junction 链接）
└── workspaces/<project_id>/config.yaml
```

junction 由 op-000 统一管理。

---

## 安全约束

- `create`：需用户确认规划表 + safe-git-write 逐端确认
- `remove`：必须指定 --only，禁止全端删除
- 分支操作：所有 git 分支操作经 safe-git-write

---

## Version

| Field | Value |
|-------|-------|
| Skill | op-worktree |
| Version | 2.0.1 |
| Updated | 2026-09-14 |
| References | config-reference.md / service-management.md / branch-analysis.md |
