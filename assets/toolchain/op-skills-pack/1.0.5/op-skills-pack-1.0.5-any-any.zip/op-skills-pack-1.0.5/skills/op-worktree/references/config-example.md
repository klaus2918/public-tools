# op-worktree 配置文件完整示例

> 完整版 `config.yaml` 示例，位于 `<skill_dir>/workspaces/<project_id>/config.yaml`

```yaml
# op-worktree 配置文件 — 由 skill 自动维护，请勿手工编辑
version: "1.1"
updated_at: "2026-07-03T12:00:00+08:00"

projects:
  demo-app:
    label: "示例项目"
    base_branch: dev              # 基分支，可在配置中自定义
    desc: "示例政务办公平台，含门户、合同管理、公文流转等功能"
    created_at: "2025-03"
    tags: [Java, "Spring Boot", Vue3, MySQL]
    owner:
      name: "张三"
      team: "开发三组"
    remotes:
      backend: "https://gitlab.com/example-group/demo-backend.git"
      pc-frontend: "https://gitlab.com/example-group/demo-pc-frontend.git"
      app-frontend: "https://gitlab.com/example-group/demo-app-frontend.git"

    repos:
      backend:
        path: /d/projects/demo-app/backend
        label: 后端
        use_bun: none          # 非前端项目，不使用 Bun
        desc: "Java Spring Boot 后端服务"
        runtime: {lang: java, version: "17", build: maven}
        port: 8080
        package_manager: maven
        dev_cmd: "mvn spring-boot:run -Dspring-boot.run.profiles=dev"
        build_cmd: "mvn clean package -DskipTests"
        debug_cmd: "mvn spring-boot:run -Dspring-boot.run.jvmArguments=\"-agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=5005\""
        env:
          SPRING_PROFILES_ACTIVE: dev
        start_order: 1
      pc-frontend:
        path: /d/projects/demo-app/pc-frontend
        label: PC前端
        use_bun: full          # 已完成 Bun 全程适配（install + dev + build）
        desc: "Vue3 + Element Plus PC 管理端"
        runtime: {lang: node, version: "20.12.0", build: npm}
        port: 5173
        package_manager: pnpm
        dev_cmd: "pnpm dev"
        build_cmd: "pnpm build"
        debug_cmd: "pnpm dev --inspect"
        env:
          NODE_ENV: development
        start_order: 2
      app-frontend:
        path: /d/projects/demo-app/app-frontend
        label: APP前端
        use_bun: install       # 仅装包加速，dev/build 仍用 Node（待适配）
        desc: "Vue3 + Vant 移动端 H5"
        runtime: {lang: node, version: "20.12.0", build: npm}
        port: 5174
        package_manager: pnpm
        dev_cmd: "pnpm dev:h5"
        build_cmd: "pnpm build:h5"
        start_order: 2

    worktrees:
      # ───── 对象形式（新格式，推荐）───
      # 端字段为 {branch: <分支名>, path?: <物理路径>}
      # branch 必填；path 可选，缺省走 repos.<端key>.path
      # 对象形式 + 自定义 path + 元数据字段
      contract-manage:
        backend:
          branch: feat/contract-manage
        pc-frontend:
          branch: feature/contract-manage
        app-frontend:
          branch: feature/contract-manage
        created_at: "2026-07-01"
        description: "合同管理功能，含合同模板、审批流、电子签章"
        task_id: "PROJ-1234"
        task_url: "https://jira.example.com/browse/PROJ-1234"
        owner: "zhangsan"
        status: "developing"
        last_active: "2026-08-10"

      # 对象形式 + 自定义 path 覆盖 repos.<端key>.path
      user-auth:
        backend:
          branch: feat/user-auth
          path: /d/work/demo-app-backend-user-auth   # 覆盖 repos.backend.path
        pc-frontend:
          branch: feat/user-auth
        created_at: "2026-07-01"

  demo-project:
    label: "演示项目"
    base_branch: main

    repos:
      web:
        path: /d/projects/demo/web
        label: Web端
        use_bun: none
      api:
        path: /d/projects/demo/api
        label: API服务
        use_bun: none

    worktrees:
      # ───── 字符串形式（旧格式，向后兼容）───
      # 字符串自动识别为 {branch: <字符串值>}
      login-redesign:
        web: feat/login-redesign          # 等价于 {branch: feat/login-redesign}
        api: feat/login-redesign          # 等价于 {branch: feat/login-redesign}
        created_at: "2026-06-15"
```

## 字段说明

| 字段 | 说明 |
|------|------|
| `version` | 配置文件格式版本 |
| `updated_at` | 最后更新时间（ISO 8601） |
| `projects.<id>.label` | 项目显示名称 |
| `projects.<id>.base_branch` | 基分支（默认 dev，可自定义） |
| `projects.<id>.desc` | 可选：项目描述 |
| `projects.<id>.created_at` | 可选：项目创建时间（YYYY-MM） |
| `projects.<id>.homepage` | 可选：项目主页/README 链接 |
| `projects.<id>.tags` | 可选：技术栈标签数组 |
| `projects.<id>.owner` | 可选：负责人对象（name/team/contact） |
| `projects.<id>.remotes` | 可选：Git 远程仓库 URL 映射（key 与 repos 对齐） |
| `projects.<id>.repos` | 多端仓库定义 |
| `repos.<端key>.path` | 仓库默认物理路径 |
| `repos.<端key>.label` | 端显示名称 |
| `repos.<端key>.use_bun` | **三态**：`none`（不用）/ `install`（仅装包加速）/ `full`（全程 Bun，需项目已适配） |
| `repos.<端key>.desc` | 可选：端描述 |
| `repos.<端key>.runtime` | 可选：运行时环境（lang/version/build） |
| `repos.<端key>.port` | 可选：本地开发端口 |
| `repos.<端key>.package_manager` | 可选：包管理器（maven/npm/pnpm/yarn/bun） |
| `repos.<端key>.dev_cmd` | 可选：开发启动命令模板 |
| `repos.<端key>.build_cmd` | 可选：构建命令模板 |
| `repos.<端key>.debug_cmd` | 可选：调试启动命令模板 |
| `repos.<端key>.env` | 可选：环境变量映射 |
| `repos.<端key>.start_order` | 可选：启动顺序（数字越小越先） |
| `projects.<id>.worktrees` | 已登记的所有 worktree 映射 |
| `worktrees.<name>.<端key>` | **两种形式**（自动识别，向后兼容）：① 旧字符串 = 仅分支名；② 新对象 = `{branch: <分支名>, path?: <物理路径>}`。缺失表示该端无此 worktree |
| `worktrees.<name>.<端key>.branch` | 该端 worktree 的分支名。对象形式必填；字符串形式的值等同于此字段 |
| `worktrees.<name>.<端key>.path` | 可选：覆盖 `repos.<端key>.path`，指定该端 worktree 创建/检查时的物理路径。缺省走 `repos.<端key>.path` |
| `worktrees.<name>.created_at` | 首次登记日期（YYYY-MM-DD） |
| `worktrees.<name>.description` | 可选：功能描述 |
| `worktrees.<name>.task_id` | 可选：任务编号（Jira/禅道等） |
| `worktrees.<name>.task_url` | 可选：任务链接 |
| `worktrees.<name>.owner` | 可选：负责人 |
| `worktrees.<name>.status` | 可选：状态枚举（developing/testing/merged/archived） |
| `worktrees.<name>.last_active` | 可选：最后活跃日期（自动维护） |

> **端字段两种形式（向后兼容）**：
> - **旧字符串形式**：`backend: feat/contract-manage`，自动识别为 `{branch: feat/contract-manage}`，无需迁移即可正常工作
> - **新对象形式**：`backend: {branch: feat/contract-manage, path: /d/xxx}`，额外支持 `path` 字段覆盖 `repos.<端key>.path`
> - **混合形式**：同一 worktree 下不同端可分别使用字符串或对象，脚本会按端独立解析

> **分支前缀**：不在 config 中配置。create 时通过 `--type feat|fix|chore|...` 统一指定，三端共用，杜绝各端前缀分歧。
>
> **use_bun 三态**：
> - `none` — install-deps.sh 走原流程（pnpm/yarn/npm）
> - `install` — `bun install` 加速装包，失败降级；dev/build 仍用 Node
> - `full` — 项目已完成 Bun 全程适配（package.json 去 node 前缀、visualizer 条件化等），可纯 Bun 构建。标记前必须完成适配改造（见 SKILL.md「Bun 全程支持」）

