# -*- coding: utf-8 -*-
"""op-000-content-check.py 冒烟测试（第4组自动化测试轮38补建）
RED/GREEN：正常仓库应全绿；构造坏引用/坏脚本应被检出。
用法：python -X utf8 test_content_check.py <仓库根（可选，默认 repo 自身）>
"""
import io
import os
import shutil
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
# ROOT = op-skills 仓库根（本文件位于 op-000/scripts/tests/，上溯 4 层）
REPO = ROOT
SCRIPT = os.path.join(ROOT, "op-000", "scripts", "op-000-content-check.py")

MINIMAL_REGISTRY = """version: "3.5.0"
skills:
  - name: test-skill
    category: generic
    status: active
    phase_role: support
    version: "1.0.0"
"""

GOOD_SKILL = """---
name: test-skill
category: generic
status: active
phase_role: support
version: "1.0.0"
---

# test-skill

## Overview

测试用 skill。
"""

BAD_REF_SKILL = GOOD_SKILL.replace(
    "## Overview", "## Overview\n\n部署时需同步 scripts/ghost.py 中的配置。")
BAD_PY = "def broken(:\n    pass\n"

# 7.19a 生态集成基线文档（9 章，>= 9 阈值）：make_fixture 内置，防止最小夹具被 7.19a 阻塞
GOOD_BASELINE = "\n".join(
    ["# 生态集成基线（测试夹具）\n"] + ["\n## 第 %d 章 测试章节\n" % i for i in range(1, 10)])


def write(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with io.open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(content)


def run_check(target):
    r = subprocess.run([sys.executable, "-X", "utf8", SCRIPT, target],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    return r.returncode, r.stdout + r.stderr


def make_fixture():
    d = tempfile.mkdtemp(prefix="content_check_fix_")
    write(os.path.join(d, "op-000", "registry.yaml"), MINIMAL_REGISTRY)
    write(os.path.join(d, "test-skill", "SKILL.md"), GOOD_SKILL)
    write(os.path.join(d, "docs", "system", "02-历史报告",
                       "op-体系生态集成基线-2026-01-01.md"), GOOD_BASELINE)
    return d


def main():
    ok = True

    # 1. GREEN：真实仓库应全绿
    code, out = run_check(REPO)
    if code == 0 and "检查 7：内容与引用层检查通过" in out:
        print("[GREEN] 真实仓库 content-check 全绿")
    else:
        print("[FAIL] 真实仓库应全绿: exit=%d\n%s" % (code, out[-800:]))
        ok = False

    # 2. GREEN：最小夹具（registry + 合法 skill）应全绿
    d = make_fixture()
    try:
        code, out = run_check(d)
        if code == 0:
            print("[GREEN] 最小夹具通过")
        else:
            print("[FAIL] 最小夹具应通过: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 3. RED：坏引用应被 7.1 检出
        write(os.path.join(d, "test-skill", "SKILL.md"), BAD_REF_SKILL)
        code, out = run_check(d)
        if code == 1 and "ghost.py" in out:
            print("[GREEN] RED：坏引用被 7.1 检出")
        else:
            print("[FAIL] 坏引用应被检出: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 4. RED：坏 py 应被 7.11 检出
        write(os.path.join(d, "test-skill", "SKILL.md"), GOOD_SKILL)
        write(os.path.join(d, "scripts", "bad.py"), BAD_PY)
        code, out = run_check(d)
        if code == 1 and "bad.py" in out and "7.11" in out:
            print("[GREEN] RED：坏 py 被 7.11 检出")
        else:
            print("[FAIL] 坏 py 应被 7.11 检出: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 5. RED：非法 phase_role 应被 7.6 检出（阻塞）
        write(os.path.join(d, "op-000", "registry.yaml"),
              MINIMAL_REGISTRY.replace("phase_role: support", "phase_role: illegal"))
        code, out = run_check(d)
        if code == 1 and "phase_role=illegal 非法" in out:
            print("[GREEN] RED：非法 phase_role 被 7.6 检出")
        else:
            print("[FAIL] 非法 phase_role 应被 7.6 检出: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 6. RED：registry/frontmatter category 不一致应被 7.9 检出（阻塞）
        write(os.path.join(d, "op-000", "registry.yaml"), MINIMAL_REGISTRY)
        write(os.path.join(d, "test-skill", "SKILL.md"),
              GOOD_SKILL.replace("category: generic", "category: core"))
        code, out = run_check(d)
        if code == 1 and "category 不一致" in out:
            print("[GREEN] RED：category 不一致被 7.9 检出")
        else:
            print("[FAIL] category 不一致应被 7.9 检出: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 7. WARN：调度不对称应被 7.8 提示（不阻塞）
        write(os.path.join(d, "op-000", "registry.yaml"),
              MINIMAL_REGISTRY.replace(
                  'phase_role: support\n', 'phase_role: support\n    dispatches:\n      - test-skill\n'))
        code, out = run_check(d)
        if "不对称调度边" in out:
            print("[GREEN] WARN：调度不对称被 7.8 提示")
        else:
            print("[FAIL] 调度不对称应被 7.8 提示: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 8. WARN：tmp 残留应被 7.7 提示（不阻塞）
        write(os.path.join(d, "op-000", "registry.yaml"), MINIMAL_REGISTRY)
        write(os.path.join(d, "test-skill", "SKILL.md"), GOOD_SKILL)
        write(os.path.join(d, "test-skill", "tmp_scratch.py"), "x = 1\n")
        code, out = run_check(d)
        if "临时文件残留" in out:
            print("[GREEN] WARN：tmp 残留被 7.7 提示")
        else:
            print("[FAIL] tmp 残留应被 7.7 提示: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 9. RED：坏 JSON 应被 7.12 检出（阻塞）
        write(os.path.join(d, "op-000", "registry.yaml"), MINIMAL_REGISTRY)
        write(os.path.join(d, "test-skill", "SKILL.md"), GOOD_SKILL)
        write(os.path.join(d, "test-skill", "bad.json"), '{"a": 1,}')
        code, out = run_check(d)
        if code == 1 and "bad.json" in out and "7.12" in out:
            print("[GREEN] RED：坏 JSON 被 7.12 检出")
        else:
            print("[FAIL] 坏 JSON 应被 7.12 检出: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 10. RED：无依赖声明的第三方 import 应被 7.13 检出（阻塞）
        write(os.path.join(d, "op-000", "registry.yaml"), MINIMAL_REGISTRY)
        write(os.path.join(d, "test-skill", "SKILL.md"), GOOD_SKILL)
        for stale in (os.path.join(d, "scripts", "bad.py"),
                      os.path.join(d, "test-skill", "bad.json")):
            if os.path.isfile(stale):
                os.remove(stale)
        write(os.path.join(d, "test-skill", "scripts", "use_third.py"),
              "import httpx\n\ndef f():\n    return httpx.Client()\n")
        code, out = run_check(d)
        if code == 1 and "依赖声明缺失" in out and "httpx" in out:
            print("[GREEN] RED：无声明第三方 import 被 7.13 检出")
        else:
            print("[FAIL] 无声明第三方 import 应被 7.13 检出: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 11. GREEN：frontmatter 声明依赖后 7.13 放行
        write(os.path.join(d, "test-skill", "SKILL.md"),
              GOOD_SKILL.replace('version: "1.0.0"\n---', 'version: "1.0.0"\ndependencies:\n  - httpx\n---'))
        code, out = run_check(d)
        if code == 0 and "7.13" in out:
            print("[GREEN] GREEN：声明依赖后 7.13 放行")
        else:
            print("[FAIL] 声明依赖后应放行: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 12. RED：敏感文件（.pem）被跟踪应被 7.14 检出（阻塞）
        write(os.path.join(d, "op-000", "registry.yaml"), MINIMAL_REGISTRY)
        write(os.path.join(d, "test-skill", "SKILL.md"), GOOD_SKILL)
        write(os.path.join(d, "test-skill", "scripts", "bad.py"), "x = 1\n")
        write(os.path.join(d, "test-skill", "secret.pem"), "PRIVATE KEY\n")
        write(os.path.join(d, "test-skill", ".env"), "DB_PASSWORD=xxx\n")
        # 7.14 用 git ls-files：把夹具初始化为 git 仓库并 add
        git = subprocess.run(["git", "init", "-q"], cwd=d)
        git = subprocess.run(["git", "add", "-A"], cwd=d)
        code, out = run_check(d)
        if code == 1 and "敏感文件被跟踪" in out and "secret.pem" in out:
            print("[GREEN] RED：敏感文件被 7.14 检出")
        else:
            print("[FAIL] 敏感文件应被 7.14 检出: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 13. GREEN：移除敏感文件后 7.14 放行（恢复依赖声明 SKILL.md 以同时满足 7.13）
        for stale in (os.path.join(d, "test-skill", "secret.pem"),
                      os.path.join(d, "test-skill", ".env")):
            if os.path.isfile(stale):
                os.remove(stale)
        write(os.path.join(d, "test-skill", "SKILL.md"),
              GOOD_SKILL.replace('version: "1.0.0"\n---', 'version: "1.0.0"\ndependencies:\n  - httpx\n---'))
        git = subprocess.run(["git", "add", "-A"], cwd=d)
        code, out = run_check(d)
        if code == 0 and "7.14" in out:
            print("[GREEN] GREEN：移除敏感文件后 7.14 放行")
        else:
            print("[FAIL] 移除敏感文件后应放行: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 14. RED：非本机明文 http 应被 7.15 检出（阻塞）
        write(os.path.join(d, "test-skill", "scripts", "call.py"),
              "import urllib.request\nurllib.request.urlopen('http://1.2.3.4:8080/x')\n")
        git = subprocess.run(["git", "add", "-A"], cwd=d)
        code, out = run_check(d)
        if code == 1 and "明文 http 端点" in out:
            print("[GREEN] RED：非本机明文 http 被 7.15 检出")
        else:
            print("[FAIL] 非本机明文 http 应被 7.15 检出: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 15. GREEN：本机 http 与模板变量豁免
        os.remove(os.path.join(d, "test-skill", "scripts", "call.py"))
        write(os.path.join(d, "test-skill", "scripts", "local.py"),
              "import urllib.request\nurllib.request.urlopen('http://127.0.0.1:9999/health')\n"
              "url = 'http://${HOST:-127.0.0.1}:8765/rpc'\n")
        git = subprocess.run(["git", "add", "-A"], cwd=d)
        code, out = run_check(d)
        if code == 0 and "7.15" in out:
            print("[GREEN] GREEN：本机/模板变量 http 豁免")
        else:
            print("[FAIL] 本机/模板变量 http 应豁免: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 16. RED：超大跟踪文件应被 7.16 检出（阻塞）
        os.remove(os.path.join(d, "test-skill", "scripts", "local.py"))
        big = os.path.join(d, "test-skill", "big_blob.bin")
        with io.open(big, "wb") as f:
            f.write(b"x" * (6 * 1048576))  # 6MB > 5MB 阈值
        git = subprocess.run(["git", "add", "-A"], cwd=d)
        code, out = run_check(d)
        if code == 1 and "超大跟踪文件" in out and "big_blob.bin" in out:
            print("[GREEN] RED：超大跟踪文件被 7.16 检出")
        else:
            print("[FAIL] 超大跟踪文件应被 7.16 检出: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 17. GREEN：移除大文件后 7.16 放行
        os.remove(big)
        git = subprocess.run(["git", "add", "-A"], cwd=d)
        code, out = run_check(d)
        if code == 0 and "7.16" in out:
            print("[GREEN] GREEN：移除大文件后 7.16 放行")
        else:
            print("[FAIL] 移除大文件后应放行: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 18. RED：frontmatter/registry 版本不一致应被 7.17 检出（阻塞）
        write(os.path.join(d, "op-000", "registry.yaml"), MINIMAL_REGISTRY)
        write(os.path.join(d, "test-skill", "SKILL.md"),
              GOOD_SKILL.replace('version: "1.0.0"', 'version: "9.9.9"'))
        git = subprocess.run(["git", "add", "-A"], cwd=d)
        code, out = run_check(d)
        if code == 1 and "版本不一致" in out and "9.9.9" in out:
            print("[GREEN] RED：版本不一致被 7.17 检出")
        else:
            print("[FAIL] 版本不一致应被 7.17 检出: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 19. GREEN：版本一致后 7.17 放行（保留 httpx 依赖声明以同时满足 7.13）
        write(os.path.join(d, "test-skill", "SKILL.md"),
              GOOD_SKILL.replace('version: "1.0.0"\n---', 'version: "1.0.0"\ndependencies:\n  - httpx\n---'))
        git = subprocess.run(["git", "add", "-A"], cwd=d)
        code, out = run_check(d)
        if code == 0 and "7.17" in out:
            print("[GREEN] GREEN：版本一致后 7.17 放行")
        else:
            print("[FAIL] 版本一致后应放行: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 20. WARN：裸 open（无 close/with）应被 7.18 提示（不阻断）
        write(os.path.join(d, "test-skill", "scripts", "bare_open.py"),
              "def f():\n    fh = open('x.txt', 'r')\n    return fh.read()\n")
        git = subprocess.run(["git", "add", "-A"], cwd=d)
        code, out = run_check(d)
        if "裸 open" in out:
            print("[GREEN] WARN：裸 open 被 7.18 提示")
        else:
            print("[FAIL] 裸 open 应被 7.18 提示: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 21. GREEN：with 写法 7.18 放行
        os.remove(os.path.join(d, "test-skill", "scripts", "bare_open.py"))
        write(os.path.join(d, "test-skill", "scripts", "with_open.py"),
              "def f():\n    with open('x.txt', 'r') as fh:\n        return fh.read()\n")
        git = subprocess.run(["git", "add", "-A"], cwd=d)
        code, out = run_check(d)
        if "无裸 open 泄露" in out:
            print("[GREEN] GREEN：with 写法 7.18 放行")
        else:
            print("[FAIL] with 写法应放行: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 22. RED：生态集成基线文档缺失应被 7.19 检出（阻塞）
        bl = os.path.join(d, "docs", "system", "02-历史报告",
                          "op-体系生态集成基线-2026-01-01.md")
        os.remove(bl)
        git = subprocess.run(["git", "add", "-A"], cwd=d)
        code, out = run_check(d)
        if code == 1 and "生态集成基线文档缺失" in out and "7.19" in out:
            print("[GREEN] RED：基线文档缺失被 7.19 检出")
        else:
            print("[FAIL] 基线文档缺失应被 7.19 检出: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 23. GREEN：恢复基线文档后 7.19a 放行
        write(bl, GOOD_BASELINE)
        git = subprocess.run(["git", "add", "-A"], cwd=d)
        code, out = run_check(d)
        if code == 0 and "基线文档完整" in out:
            print("[GREEN] GREEN：恢复基线文档后 7.19a 放行")
        else:
            print("[FAIL] 恢复基线文档后应放行: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 24. WARN：退出码超出约定 {0,1,2,3} 应被 7.19b 提示（不阻塞）
        write(os.path.join(d, "test-skill", "scripts", "exit9.py"),
              "import sys\nsys.exit(9)\n")
        git = subprocess.run(["git", "add", "-A"], cwd=d)
        code, out = run_check(d)
        if code == 0 and "超出约定" in out and "exit(9)" in out:
            print("[GREEN] WARN：退出码超约定被 7.19b 提示")
        else:
            print("[FAIL] 退出码超约定应被 7.19b 提示: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 25. GREEN：移除超约定退出码文件后 7.19b 放行
        os.remove(os.path.join(d, "test-skill", "scripts", "exit9.py"))
        git = subprocess.run(["git", "add", "-A"], cwd=d)
        code, out = run_check(d)
        if code == 0 and "全部在约定" in out:
            print("[GREEN] GREEN：移除后 7.19b 放行")
        else:
            print("[FAIL] 移除后应放行: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 26. RED：frontmatter 依赖不存在的 skill 应被 7.19c 检出（阻塞）
        # 保留 httpx 声明（use_third.py 仍在 scripts/ 下，需同时满足 7.13），合法嵌套 YAML
        write(os.path.join(d, "test-skill", "SKILL.md"),
              GOOD_SKILL.replace('version: "1.0.0"\n---',
                                 'version: "1.0.0"\ndependencies:\n  python:\n    - httpx\n  required:\n    - skill: ghost-skill\n---'))
        git = subprocess.run(["git", "add", "-A"], cwd=d)
        code, out = run_check(d)
        if code == 1 and "跨 skill 依赖断裂" in out and "ghost-skill" in out:
            print("[GREEN] RED：依赖断裂被 7.19c 检出")
        else:
            print("[FAIL] 依赖断裂应被 7.19c 检出: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 27. GREEN：依赖真实存在的 skill 后 7.19c 放行（保留 httpx 声明满足 7.13）
        write(os.path.join(d, "test-skill", "SKILL.md"),
              GOOD_SKILL.replace('version: "1.0.0"\n---',
                                 'version: "1.0.0"\ndependencies:\n  python:\n    - httpx\n  required:\n    - skill: test-skill\n---'))
        git = subprocess.run(["git", "add", "-A"], cwd=d)
        code, out = run_check(d)
        if code == 0 and "依赖引用全部存在" in out:
            print("[GREEN] GREEN：合法依赖 7.19c 放行")
        else:
            print("[FAIL] 合法依赖应放行: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 28. RED：非法 execution_mode 应被 7.20 检出（阻塞）
        write(os.path.join(d, "op-000", "registry.yaml"), MINIMAL_REGISTRY)
        write(os.path.join(d, "test-skill", "SKILL.md"),
              GOOD_SKILL.replace('version: "1.0.0"\n---',
                                 'version: "1.0.0"\ndependencies:\n  python:\n    - httpx\n  required:\n    - skill: test-skill\n---'))
        write(os.path.join(d, ".op", "changes", "demo-change", "change.yaml"),
              "name: demo-change\ntype: feature\nphase: plan\nexecution_mode: freeform\n")
        git = subprocess.run(["git", "add", "-A"], cwd=d)
        code, out = run_check(d)
        if code == 1 and "execution_mode 非法" in out and "freeform" in out:
            print("[GREEN] RED：非法 execution_mode 被 7.20 检出")
        else:
            print("[FAIL] 非法 execution_mode 应被 7.20 检出: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 29. GREEN：合法 execution_mode（autonomous）7.20 放行
        write(os.path.join(d, ".op", "changes", "demo-change", "change.yaml"),
              "name: demo-change\ntype: feature\nphase: plan\nexecution_mode: autonomous\n")
        git = subprocess.run(["git", "add", "-A"], cwd=d)
        code, out = run_check(d)
        if code == 0 and "execution_mode 全部在" in out:
            print("[GREEN] GREEN：合法 autonomous 7.20 放行")
        else:
            print("[FAIL] 合法 autonomous 应放行: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 30. GREEN：缺省（无 execution_mode）视为 constrained，7.20 放行
        write(os.path.join(d, ".op", "changes", "demo-change", "change.yaml"),
              "name: demo-change\ntype: feature\nphase: plan\n")
        git = subprocess.run(["git", "add", "-A"], cwd=d)
        code, out = run_check(d)
        if code == 0 and "execution_mode 全部在" in out:
            print("[GREEN] GREEN：缺省 constrained 7.20 放行")
        else:
            print("[FAIL] 缺省 constrained 应放行: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 31. WARN：活跃 autonomous 变更应被 7.21 提示（不阻塞）
        write(os.path.join(d, ".op", "changes", "demo-change", "change.yaml"),
              "name: demo-change\ntype: feature\nphase: build\nexecution_mode: autonomous\n")
        git = subprocess.run(["git", "add", "-A"], cwd=d)
        code, out = run_check(d)
        if code == 0 and "活跃自主执行变更" in out and "7.21" in out:
            print("[GREEN] WARN：活跃 autonomous 被 7.21 提示")
        else:
            print("[FAIL] 活跃 autonomous 应被 7.21 提示: exit=%d\n%s" % (code, out[-800:]))
            ok = False

        # 32. GREEN：autonomous 收尾（phase=done）后 7.21 放行
        write(os.path.join(d, ".op", "changes", "demo-change", "change.yaml"),
              "name: demo-change\ntype: feature\nphase: done\nexecution_mode: autonomous\n")
        git = subprocess.run(["git", "add", "-A"], cwd=d)
        code, out = run_check(d)
        if code == 0 and "无活跃自主执行变更" in out:
            print("[GREEN] GREEN：收尾后 7.21 放行")
        else:
            print("[FAIL] 收尾后应放行: exit=%d\n%s" % (code, out[-800:]))
            ok = False
    finally:
        shutil.rmtree(d, ignore_errors=True)

    print("=== content-check 冒烟测试%s ===" % ("全部通过" if ok else "存在失败"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
