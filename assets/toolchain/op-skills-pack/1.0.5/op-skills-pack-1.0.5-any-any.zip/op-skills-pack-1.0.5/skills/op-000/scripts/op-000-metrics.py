#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
op 体系变更度量（op-000 metrics）
==================================
聚合 .op/changes（活跃）+ .op/archive/YYYY/MM/（归档）的 change.yaml，
输出变更统计：总数 / 活跃 / 归档 / 按 type / 按 phase / 周期。

用法：python op-000/scripts/op-000-metrics.py <仓库根> [--md]
  --md  输出 Markdown 表格（写入 docs/metrics.md）
"""
import io
import os
import sys
import re
import json
from datetime import datetime


def load_yaml(path):
    import yaml
    with io.open(path, encoding="utf-8") as f:
        return yaml.safe_load(f)


def scan(root):
    """返回 [ {name,type,phase,status,created,archived,dir} ]"""
    out = []
    opd = os.path.join(root, ".op")
    if not os.path.isdir(opd):
        return out
    # 活跃
    ch = os.path.join(opd, "changes")
    if os.path.isdir(ch):
        for name in os.listdir(ch):
            cy = os.path.join(ch, name, "change.yaml")
            if os.path.isfile(cy):
                d = load_yaml(cy) or {}
                out.append({
                    "name": name, "type": d.get("type", "?"), "phase": d.get("phase", "?"),
                    "status": d.get("status", "active"), "created": d.get("created", ""),
                    "archived": "", "dir": "changes", "demo": bool(d.get("demo", False)),
                })
    # 归档
    arch = os.path.join(opd, "archive")
    if os.path.isdir(arch):
        for y in sorted(os.listdir(arch)):
            yp = os.path.join(arch, y)
            if not os.path.isdir(yp):
                continue
            for m in sorted(os.listdir(yp)):
                mp = os.path.join(yp, m)
                if not os.path.isdir(mp):
                    continue
                for name in os.listdir(mp):
                    cy = os.path.join(mp, name, "change.yaml")
                    if os.path.isfile(cy):
                        d = load_yaml(cy) or {}
                        out.append({
                            "name": name, "type": d.get("type", "?"), "phase": "archive",
                            "status": d.get("status", "archived"), "created": d.get("created", ""),
                            "archived": d.get("archived_at", ""), "dir": f"archive/{y}/{m}",
                            "demo": bool(d.get("demo", False)),
                        })
    return out


def fmt_period(created, archived):
    """变更生命周期天数（created → archived）"""
    if not created or not archived:
        return ""
    try:
        c = datetime.fromisoformat(str(created).replace("Z", "+00:00"))
        a = datetime.fromisoformat(str(archived).replace("Z", "+00:00"))
        return f"{(a - c).days + 1} 天"
    except Exception:
        return ""


def main():
    root = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
    use_md = "--md" in sys.argv
    changes = scan(root)
    active = [c for c in changes if c["dir"] == "changes"]
    archived = [c for c in changes if c["dir"] != "changes"]
    demos = [c for c in changes if c.get("demo")]
    types = {}
    for c in changes:
        types[c["type"]] = types.get(c["type"], 0) + 1

    lines = []
    lines.append(f"# op 体系变更度量（{datetime.now().strftime('%Y-%m-%d %H:%M')}）")
    lines.append("")
    lines.append(f"- 变更总数：{len(changes)}（活跃 {len(active)} / 归档 {len(archived)} / 演练 {len(demos)}）")
    lines.append(f"- 类型分布：{json.dumps(types, ensure_ascii=False)}")
    lines.append("")
    lines.append("| 变更 | type | phase | status | 演练 | 周期 | 位置 |")
    lines.append("|---|---|---|---|---|---|---|")
    for c in sorted(changes, key=lambda x: x["name"]):
        period = fmt_period(c["created"], c["archived"])
        lines.append(f"| {c['name']} | {c['type']} | {c['phase']} | {c['status']} | {'✅' if c.get('demo') else '—'} | {period} | {c['dir']} |")
    # skill 引用频率（正文被引用次数 = 使用热度代理）
    try:
        reg = load_yaml(os.path.join(root, "op-000", "registry.yaml")) or {}
        names = [s.get("name") for s in reg.get("skills", []) if s.get("name")]
    except Exception:
        names = []
    if names:
        ref = {n: 0 for n in names}
        for n in names:
            fp = os.path.join(root, n, "SKILL.md")
            if not os.path.isfile(fp):
                continue
            try:
                body = io.open(fp, encoding="utf-8", errors="replace").read().replace("\r\n", "\n")
            except Exception:
                continue
            body = re.sub(r"^---\n.*?\n---\n", "", body, flags=re.S)
            for c in names:
                if c == n:
                    continue
                if re.search(r"(?<![a-z-])" + re.escape(c) + r"(?![a-z-])", body):
                    ref[c] += 1
        lines.append("")
        lines.append("## skill 引用频率（SKILL.md 正文被引用次数）")
        lines.append("")
        lines.append("| skill | 被引用 |")
        lines.append("|---|---|")
        for n, c in sorted(ref.items(), key=lambda x: -x[1]):
            lines.append(f"| {n} | {c} |")
        report = "\n".join(lines) + "\n"

    if use_md:
        dst = os.path.join(root, "docs", "metrics.md")
        io.open(dst, "w", encoding="utf-8").write(report)
        print(f"已写入 {dst}")
    else:
        print(report)


if __name__ == "__main__":
    main()
