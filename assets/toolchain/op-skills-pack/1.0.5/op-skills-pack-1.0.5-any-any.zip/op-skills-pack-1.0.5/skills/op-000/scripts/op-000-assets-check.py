#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""op-000-assets-check.py — 资产边界声明（assets.yaml）解析与内部校验

规范：skills/op-000/references/isolation-spec.md §1.1
用法：
  python op-000-assets-check.py [仓库根]          # 人类可读报告
  python op-000-assets-check.py [仓库根] --list   # TSV 清单（skill<TAB>path<TAB>entity<TAB>sensitivity），供脚本消费
退出码：0=全部通过 / 1=存在违规 / 2=环境不可用

判定范围（声明内部一致性）：规则 1/2/7/8
挂载点与实体的存在性、junction 状态由 op-000-isolation-check.sh 依据本脚本输出校验。
"""
import os
import sys

# Windows 管道兼容：强制 UTF-8 输出与 LF 行尾
# （否则下游按 GBK 解码、或把 \n 转成 \r\n 导致 TSV 末字段带 \r）
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", newline="\n")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

try:
    import yaml
except ImportError:  # pragma: no cover
    sys.stderr.write("[FAIL] pyyaml 不可用（请安装 pyyaml）\n")
    sys.exit(2)

SENSITIVITY = ("normal", "config", "secret")


def main():
    argv = sys.argv[1:]
    list_mode = "--list" in argv
    args = [a for a in argv if not a.startswith("--")]
    default_root = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", ".."))
    root = args[0] if args else default_root
    skills_dir = os.path.join(root, "skills")
    if not os.path.isdir(skills_dir):
        sys.stderr.write("环境不可用：%s 不存在\n" % skills_dir)
        return 2

    counters = {"ok": 0, "warn": 0, "fail": 0}
    rows = []

    def emit(level, msg):
        counters[level] += 1
        if not list_mode:
            print("  [%s] %s" % (level.upper(), msg))

    declared = {}
    declared_skills = set()

    for entry in sorted(os.listdir(skills_dir)):
        decl_path = os.path.join(skills_dir, entry, "references", "assets.yaml")
        if not os.path.isfile(decl_path):
            continue
        declared_skills.add(entry)
        try:
            with open(decl_path, "r", encoding="utf-8") as fh:
                data = yaml.safe_load(fh) or {}
        except Exception as exc:  # noqa: BLE001
            emit("fail", "%s/references/assets.yaml 不可解析：%s" % (entry, exc))
            continue
        if not isinstance(data, dict):
            emit("fail", "%s/references/assets.yaml 顶层不是映射" % entry)
            continue
        if data.get("skill") != entry:
            emit("fail", "%s 声明的 skill=%r 与目录名不一致" % (entry, data.get("skill")))
        else:
            emit("ok", "%s 声明可解析且 skill 名一致" % entry)

        mounts = data.get("mounts") or []
        if not isinstance(mounts, list):
            emit("fail", "%s.mounts 不是数组" % entry)
            continue
        for item in mounts:
            if not isinstance(item, dict) or not item.get("path"):
                emit("fail", "%s.mounts 存在缺少 path 的条目" % entry)
                continue
            path = item["path"]
            sens = item.get("sensitivity", "normal")
            if sens not in SENSITIVITY:
                emit("fail", "%s/%s sensitivity=%r 非法（应属 %s）" % (entry, path, sens, "/".join(SENSITIVITY)))
                continue
            template = item.get("template")
            if template:
                tmpl_path = os.path.join(skills_dir, entry, template)
                if not os.path.isfile(tmpl_path):
                    emit("fail", "%s/%s template 不存在：%s" % (entry, path, template))
                else:
                    emit("ok", "%s/%s template 存在" % (entry, path))
            declared[(entry, path)] = {
                "entity": item.get("entity") or "",
                "sensitivity": sens,
            }
            rows.append("%s\t%s\t%s\t%s" % (entry, path, item.get("entity") or "", sens))

    if list_mode:
        sys.stdout.write("\n".join(rows) + ("\n" if rows else ""))
        return 1 if counters["fail"] else 0

    print("== 资产边界声明校验（仓库根：%s） ==" % root)
    print("声明覆盖：%d 个 skill / %d 个槽位" % (len(declared_skills), len(declared)))
    print("汇总：PASS %d / WARN %d / FAIL %d" % (counters["ok"], counters["warn"], counters["fail"]))
    return 1 if counters["fail"] else 0


if __name__ == "__main__":
    sys.exit(main())
