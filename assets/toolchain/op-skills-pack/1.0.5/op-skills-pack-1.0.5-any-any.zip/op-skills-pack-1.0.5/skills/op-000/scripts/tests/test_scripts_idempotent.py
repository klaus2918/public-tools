# -*- coding: utf-8 -*-
"""幂等性冒烟测试（第4组自动化测试轮45固化）
核心脚本重复执行应结果一致（exit code + 输出摘要 hash）。
覆盖：content-check / knowledge-health / docgen / metrics。
用法：python -X utf8 test_scripts_idempotent.py <仓库根（默认仓库自身）>
"""
import hashlib
import io
import os
import shutil
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
REPO = ROOT
PY = sys.executable


def run(args, timeout=300):
    # 列表参数 + shell=False：不经 shell 解析，也不依赖 PATH 中存在 `python` 命令
    return subprocess.run(args, shell=False, capture_output=True, text=True,
                          encoding="utf-8", errors="replace", cwd=REPO, timeout=timeout)


def digest(text):
    return hashlib.md5(text.encode("utf-8", errors="replace")).hexdigest()[:12]


def check(name, cmd, runs=2, timeout=300):
    codes, digests = [], []
    for _ in range(runs):
        r = run(cmd, timeout=timeout)
        codes.append(r.returncode)
        digests.append(digest(r.stdout))
    stable = len(set(codes)) == 1 and len(set(digests)) == 1
    mark = "PASS" if stable else "FAIL"
    print("  [%s] %s: exit=%s digest=%s" % (mark, name, set(codes), set(digests)))
    return stable


def main():
    ok = True

    # 1. content-check（输出大，hash 比较）
    ok = check("content-check 幂等",
               [PY, "-X", "utf8", "op-000/scripts/op-000-content-check.py", REPO]) and ok

    # 2. knowledge-health
    ok = check("knowledge-health 幂等",
               [PY, "-X", "utf8", "op-knowledge/scripts/knowledge-health.py", "health"]) and ok

    # 3. metrics：输出首行含时间戳（快照语义，设计如此），比较剔除首行后的内容
    codes, digests = [], []
    for _ in range(2):
        r = run([PY, "-X", "utf8", "op-000/scripts/op-000-metrics.py", REPO])
        codes.append(r.returncode)
        # 剔除首行（时间戳）
        body = "\n".join(r.stdout.splitlines()[1:])
        digests.append(digest(body))
    stable = len(set(codes)) == 1 and len(set(digests)) == 1
    mark = "PASS" if stable else "FAIL"
    print("  [%s] metrics 幂等（剔除时间戳行）: exit=%s digest=%s" % (mark, set(codes), set(digests)))
    ok = ok and stable

    # 4. docgen：同数据渲染 2 次产物一致
    d = tempfile.mkdtemp(prefix="idem_")
    try:
        data_f = os.path.join(d, "data.json")
        with io.open(data_f, "w", encoding="utf-8") as f:
            f.write('{"title": "幂等测试", "items": [{"k": "a"}, {"k": "b"}]}')
        outs = []
        for i in (1, 2):
            out_i = os.path.join(d, "out%d" % i)
            r = run([PY, "-X", "utf8", "op-docgen/scripts/docgen.py", "--skeleton", "user-manual",
                     "--data", data_f, "--out", out_i, "--skip-docx"])
            if r.returncode == 0:
                outs.append(out_i)
        if len(outs) == 2:
            def _h(p):
                with io.open(p, encoding="utf-8", errors="replace") as f:
                    return digest(f.read())
            same = _h(os.path.join(outs[0], "draft.md")) == _h(os.path.join(outs[1], "draft.md"))
            print("  [%s] docgen 同数据渲染产物一致" % ("PASS" if same else "FAIL"))
            ok = ok and same
        else:
            print("  [FAIL] docgen 渲染未成功（%d/2）" % len(outs))
            ok = False
    finally:
        shutil.rmtree(d, ignore_errors=True)

    print("=== 幂等性冒烟测试%s ===" % ("全部通过" if ok else "存在失败"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
