#!/usr/bin/env bash
# op-000-isolation-check.sh — 三层隔离一键自检
#   L1 工作区级：外部版本目录不入库、不参与校验
#   L2 运行资产级：挂载点（skill 内目录）<-> 实体（.basic/evolved/<skill>/<挂载点>）
#   L3 分发级：个人资产与本地实例配置不入库、不随包分发
#
# 规范：skills/op-000/references/isolation-spec.md
# 用法：bash op-000-isolation-check.sh [仓库根]
# 退出码：0 = 全部通过 / 1 = 存在违规 / 2 = 环境不可用
set -uo pipefail

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
ROOT="${1:-$(cd "$SCRIPT_DIR/../../.." && pwd)}"

FAIL=0
WARN=0
OK=0

pass() { OK=$((OK + 1)); printf '  [PASS] %s\n' "$*"; }
warn() { WARN=$((WARN + 1)); printf '  [WARN] %s\n' "$*"; }
fail() { FAIL=$((FAIL + 1)); printf '  [FAIL] %s\n' "$*"; }

if ! git -C "$ROOT" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "环境不可用：$ROOT 不是 git 工作区（本检查依赖 git ls-files / check-ignore）" >&2
  exit 2
fi

echo "== 隔离自检（仓库根：$ROOT） =="

echo "-- L1 工作区级（外部版本目录） --"
found_ext=0
while IFS= read -r d; do
  [ -z "$d" ] && continue
  found_ext=1
  rel=$(basename "$d")
  if git -C "$ROOT" check-ignore -q -- "$rel/"; then
    pass "外部版本目录已忽略：$rel"
  else
    fail "外部版本目录未忽略：$rel（.gitignore 需含 op-skills-pack-*/）"
  fi
done < <(find "$ROOT" -maxdepth 1 -mindepth 1 -type d -name 'op-skills-pack-*' 2>/dev/null | sort)
[ "$found_ext" -eq 0 ] && pass "无外部版本目录"

tracked_ext=$(git -C "$ROOT" ls-files | grep '^op-skills-pack-' | head -n 3 || true)
if [ -n "$tracked_ext" ]; then
  fail "外部版本目录存在被跟踪文件（示例：$(echo "$tracked_ext" | head -n 1)）"
else
  pass "外部版本目录零跟踪"
fi

echo "-- L2 运行资产级（挂载点 / 实体） --"
ENTITY_ROOT=""
for cand in .basic/evolved .claude/evolved; do
  if [ -d "$ROOT/$cand" ]; then ENTITY_ROOT="$cand"; break; fi
done
if [ -z "$ENTITY_ROOT" ]; then
  warn "实体根不存在（.basic/evolved 与 .claude/evolved 均缺失）——按未初始化处理"
  ENTITY_ROOT=".basic/evolved"
else
  pass "实体根：$ENTITY_ROOT"
fi

MOUNTS='browser-agent-bridge/runtime
op-browser/projects
op-browser/tasks
op-design-extract/catalog
op-design-extract/shared
op-done/config
op-html/sites
op-knowledge/config
op-release/config
op-worktree/workspaces'

miss_link=0
miss_entity=0
while IFS= read -r m; do
  [ -z "$m" ] && continue
  skill="${m%%/*}"
  sub="${m#*/}"
  link="$ROOT/skills/$skill/$sub"
  entity="$ROOT/$ENTITY_ROOT/$skill/$sub"
  if [ -L "$link" ]; then
    pass "挂载点已建链：$m"
  elif [ -d "$link" ]; then
    warn "挂载点为实体目录（非 junction）：$m（数据在仓库工作区，建议迁移到实体根后重建）"
  else
    miss_link=$((miss_link + 1))
  fi
  [ -d "$entity" ] || miss_entity=$((miss_entity + 1))
done <<< "$MOUNTS"
[ "$miss_link" -gt 0 ] && warn "$miss_link 个挂载点未创建（运行时数据将落在 skill 目录，已被 .gitignore 覆盖）"
[ "$miss_entity" -gt 0 ] && warn "$miss_entity 个实体目录缺失（可运行 op-000-mount-sync.ps1 创建）"

echo "-- L3 分发级（个人资产 / 本地实例配置） --"
for cand in .basic/evolved .claude/evolved; do
  [ -d "$ROOT/$cand" ] || continue
  n=$(git -C "$ROOT" ls-files -- "$cand" 2>/dev/null | grep -v '\.gitkeep$' | wc -l | tr -d ' ')
  if [ "$n" -gt 0 ]; then
    fail "$cand 下有 $n 个非占位文件被 git 跟踪（个人资产入库风险，应 git rm --cached）"
  else
    pass "$cand 仅占位文件被跟踪（或无跟踪）"
  fi
done
for f in .sensitive-terms .sensitive-terms.warn skills/op-release/config.yaml; do
  if git -C "$ROOT" ls-files --error-unmatch -- "$f" >/dev/null 2>&1; then
    fail "本地实例配置/敏感文件被跟踪：$f"
  else
    pass "未跟踪：$f"
  fi
done

echo ""
echo "汇总：PASS $OK / WARN $WARN / FAIL $FAIL"
if [ "$FAIL" -gt 0 ]; then exit 1; fi
exit 0
