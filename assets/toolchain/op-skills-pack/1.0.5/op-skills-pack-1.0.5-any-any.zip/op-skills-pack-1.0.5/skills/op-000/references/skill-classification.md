# skill 治理分层契约（tier）

> 版本：v1.0 ｜ 2026-09-14 ｜ 归属：op-000 ｜ 上游变更：`.op/changes/op-skills-pack-20260912`（P6）
> 目的：定义 skill 的**治理分层**与按环境启停边界，使体系可按环境裁剪，且**不改变 op 主链路契约**。

---

## 1. 两个正交维度（不可混淆）

| 维度 | 字段 | 取值 | 含义 |
|------|------|------|------|
| 功能分类 | `category`（已有） | `core` / `support` / `foundation` / `generic` | 描述 skill 在体系中的**功能位置** |
| 治理分层 | `tier`（本次新增） | `core` / `core-support` / `pluggable` | 描述 skill 的**启停边界与缺省状态** |

> `category` 表达「它是什么」，`tier` 表达「它能不能被停用、停用后谁受影响」。

---

## 2. 三层定义

| tier | 定义 | 缺省状态 | 可否停用 | 停用后果 |
|------|------|---------|---------|---------|
| `core` | op 主链路或提交路径的必备环节 | 启用 | **禁止** | 链路断裂（建变更 / 出方案 / 执行 / 验收 / 提交 / 体系治理） |
| `core-support` | 主链路按需调用；缺省启用，但**允许降级** | 启用 | 允许（需确认） | 对应能力不可用，主链路须走降级路径（提示 + 跳过，不报错） |
| `pluggable` | 依赖外部运行时、环境专有资产或特定领域 | **按环境启用** | 允许 | 仅该能力不可用；主链路不受影响 |

---

## 3. 判定信号（优先级从高到低）

1. **主链路必经** → `core`（例：`op` / `op-plan` / `op-build` / `op-done` / `op-000` / `safe-git-write`）
2. **降级可行**（缺省时提示而非阻塞） → `core-support`（例：`op-knowledge` 未配置知识库时询问引导）
3. **外部运行时依赖**（Playwright / Chrome / Docker / SSH / CDG / Python 第三方库） → `pluggable`
4. **环境专有资产或领域绑定**（项目 kits、真实部署目标、OA 子域） → `pluggable`

若同时命中：先判 1，再判 2，其后 3/4。

---

## 4. 分层分配（19 个 skill）

| tier | skill | 备注 |
|------|-------|------|
| **core**（6） | `op` · `op-plan` · `op-build` · `op-done` · `op-000` · `safe-git-write` | `safe-git-write` 为提交唯一入口（category=generic） |
| **core-support**（4） | `op-orchestrate` · `op-html` · `op-knowledge` · `op-design-extract` | 主链路按需调用：epic 编排 / 确认材料渲染 / 知识检索沉淀 / 设计资产 |
| **pluggable**（9） | `op-browser` · `browser-agent-bridge` · `java-fs` · `op-worktree` · `op-deploy-prep` · `op-docgen` · `op-release` · `frontend-design` · `operate-prg-project` | 另含子层 `op-design-extract/skills/op-oa-workflow`（随父 skill 的 OA 子域；环境内部材料，不随发布包分发） |

**特殊标注**：

- `java-fs`：**宪法相关性**——宪法要求 `.java` 一律经 java-fs；停用会使该条款无法执行，故停用需用户**显式确认**（脚本须输出该提示）。
- `op-release` / `op-deploy-prep`：环境专有（真实部署目标 / 项目 kits），跨环境分发时天然不适用（缺省即可不启用）。
- `browser-agent-bridge`：`op-browser` 的 Bridge 适配器，二者可独立启停（缺省时 `op-browser` 走 CDP 适配器）。

---

## 5. 启停边界（不改主链路契约）

| 约束 | 说明 |
|------|------|
| core 不可停用 | 启停脚本对 `tier: core` 直接拒绝（退出码 1 + 说明） |
| 停用即降级 | 停用 `core-support` 后：调用点必须**提示并跳过**，不得报错阻断（例：知识库未配置 → 按「消费方接入协议」询问） |
| 路由不变 | `/op` 路由、`change.yaml.phase` 四阶段语义（plan→build→done→archive）与 `tier` 无关 |
| 校验不误报 | 停用的 skill 不参与「孤立 Skill」判定与 `dispatches` 对称性检查（由 `validate.sh` 读取状态文件跳过） |
| 状态不入库 | 启停状态写 `.op/skill-state.yaml`（本地，`.op/` 已 gitignore），不随包分发 |

---

## 6. registry 字段约定

```yaml
  - name: op-browser
    category: foundation      # 功能分类（既有）
    tier: pluggable           # 治理分层（本次新增，必填，白名单校验）
    env_requirements: "playwright + httpx + Pillow；Chrome（bridge 模式需 browser-agent-bridge）"  # 可选，人类可读
```

| 字段 | 必填 | 白名单 | 说明 |
|------|------|--------|------|
| `tier` | 是 | `core` / `core-support` / `pluggable` | 校验：`op-000-validate.sh` 检查 3.6 |
| `env_requirements` | 否 | — | 环境依赖的人类可读描述；`tier: pluggable` 建议填写 |

---

## 7. 与其他机制的关系

- **多端同步**：`multi-end-sync/sync-skills.ps1` 建链时按 `.op/skill-state.yaml` 跳过停用 skill（见启停机制）。
- **校验层**：`validate.sh` 检查 3.6（tier 白名单 + core 不得标记 disabled）与孤立判定联动。
- **打包分发**：分发包按 tier 提供「核心包 / 完整包」两种形态（后续可在 PACKAGING 规则中体现）。
- **修订**：本契约修订须走 op-000 `optimize`（含方案确认门禁）。
