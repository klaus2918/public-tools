# 隔离规范（三层隔离）

> 版本：v1.0 ｜ 更新：2026-09-14 ｜ 归属：op-000
> 上游变更：`.op/changes/op-skills-pack-20260912`（P0）
> 目的：明确「仓库骨架 / 运行资产 / 外部版本 / 分发包」四者的数据边界与判定标准，
> 避免外部版本与运行数据污染校验基线或随包分发。

---

## 1. 三层隔离定义

| 层 | 隔离对象 | 位置约定 | 防护手段 | 判定标准（校验口径） |
|----|---------|---------|---------|-------------------|
| **L1 工作区级** | 外部独立迭代版本（解压目录、外部包） | 仓库根 `op-skills-pack-*/`，或仓库外任意目录 | `.gitignore`（不入库）+ `content-check` 的 `is_external_path()`（不参与扫描）+ `sync-skills.ps1` 白名单排除 | `git status` 不出现外部版本目录；`validate.sh` / `content-check` 全绿不受其影响 |
| **L2 运行资产级** | skill 运行数据（站点 / 任务 / 项目 / 配置 / 工作区 / 快照） | 实体：`.basic/evolved/<skill>/<挂载点>/`；入口：skill 内同名挂载点目录（junction） | skill 代码只使用**相对路径**（不感知实体位置）；`.gitignore` 覆盖运行目录 | 运行数据不进 git（`.gitkeep` 占位除外）；挂载点状态由自检脚本报告 |
| **L3 分发级** | 个人资产与本地实例配置 | 不随包分发 | 打包零跟踪前置校验；本地实例配置防线（`*.local.*`、`skills/op-release/config.yaml`、`.sensitive-terms*`、`skills/*/config/config.yaml`） | 包内零 evolved 资产、零敏感文件；`scan-sensitive.py` 零命中 |

### 原则

1. **外部的归外部**：外部版本只读引用，不入库、不参与校验、不随包分发；需要比对时可直接读取其文件。
2. **运行数据与代码分离**：仓库只存骨架、模板与代码；运行数据落 L2 实体目录。
3. **同层优先**：路径判定由内向外（挂载点 → 实体 → 仓库），禁止跨层引用。
4. **降级可用**：挂载点未创建时，skill 运行时使用 skill 内相对路径（数据落 skill 目录，已被 `.gitignore` 覆盖），该状态视为「合规但非最优」，由自检脚本提示。

---

## 2. 挂载点清单（10 个）

| # | skill | 挂载点 | 实体（重命名后） | 用途 |
|---|-------|--------|-----------------|------|
| 1 | browser-agent-bridge | `runtime/` | `.basic/evolved/browser-agent-bridge/runtime/` | Bridge 运行时数据 |
| 2 | op-browser | `projects/` | `.basic/evolved/op-browser/projects/` | 项目适配资产 |
| 3 | op-browser | `tasks/` | `.basic/evolved/op-browser/tasks/` | 任务与运行记录（含 `runs/`、`runs_index.json`） |
| 4 | op-design-extract | `catalog/` | `.basic/evolved/op-design-extract/catalog/` | 标签索引派生缓存 |
| 5 | op-design-extract | `shared/` | `.basic/evolved/op-design-extract/shared/` | 项目级设计资产 |
| 6 | op-done | `config/` | `.basic/evolved/op-done/config/` | 归档/提交本地配置 |
| 7 | op-html | `sites/` | `.basic/evolved/op-html/sites/` | 确认材料站点产物与 `.last-opened` |
| 8 | op-knowledge | `config/` | `.basic/evolved/op-knowledge/config/` | 知识库连接配置（模板在 `references/knowledge-bases.example.yaml`） |
| 9 | op-release | `config/` | `.basic/evolved/op-release/config/` | 环境实例配置（模板在 `references/config-example.yaml`） |
| 10 | op-worktree | `workspaces/` | `.basic/evolved/op-worktree/workspaces/` | worktree 环境登记 |

> 重命名：`.claude/evolved/` → `.basic/evolved/`（2026-09-14 决策：`.claude/` 为 Claude 客户端自身目录，
> 同层存放运行资产导致识别异常）。迁移完成前，自检脚本兼容两种实体根。

---

## 3. 工具

| 场景 | 命令 | 说明 |
|------|------|------|
| 一键自检（三层） | `bash skills/op-000/scripts/op-000-isolation-check.sh [仓库根]` | 退出码：0 全部通过 / 1 存在违规 / 2 环境不可用 |
| 挂载点状态 | `powershell -NoProfile -File skills/op-000/scripts/op-000-mount-sync.ps1 -Status` | 只读检查 10 个挂载点 |
| 挂载点创建/修复 | `powershell -NoProfile -File skills/op-000/scripts/op-000-mount-sync.ps1` | 幂等：缺失实体目录则创建，缺失挂载点则建 junction；非空实体目录不动 |
| 校验基线 | `bash skills/op-000/scripts/op-000-validate.sh` + `py skills/op-000/scripts/op-000-content-check.py .` | L1 违规会直接体现为校验失败 |

---

## 4. 违规判定与处置

| 现象 | 层级 | 判定 | 处置 |
|------|------|------|------|
| 外部版本目录出现在 `git status` | L1 | 违规 | 补 `.gitignore`（`op-skills-pack-*/`），确认未被跟踪 |
| 外部版本内的坏文件导致 `content-check` 失败 | L1 | 违规 | 确认 `is_external_path()` 生效（顶层目录名前缀匹配） |
| 挂载点缺失 | L2 | 合规但非最优（WARN） | 运行 `op-000-mount-sync.ps1` 建链 |
| 挂载点为实体目录（非 junction） | L2 | 合规但非最优（WARN） | 数据先迁移到实体根，再重建 junction |
| `.basic/evolved/` 下个人资产被 git 跟踪 | L2/L3 | 违规 | `git rm --cached` 解除跟踪，保留文件；补 `.gitignore` |
| 本地实例配置（`config.yaml`/`*.local.*`/`.sensitive-terms`）被跟踪 | L3 | 违规 | 解除跟踪 + 确认 `.gitignore` 防线（`content-check 7.14` 亦会阻断） |
| 包内出现 evolved 资产或敏感词文件 | L3 | 违规 | 打包零跟踪前置校验拦截；见 CHANGELOG v22「evolved 零跟踪前置检查」 |

---

## 5. 与其他机制的关系

- **打包分发**：`build-pack.cmd` 的「包内 evolved 泄漏自检」与本规范 L3 判定标准一致（零跟踪）。
- **多端同步**：`multi-end-sync/sync-skills.ps1` 白名单只认含 `SKILL.md` 的目录，并排除 `.git`/`.op`/`.claude`/`.basic`/`docs`/`废弃`；外部版本目录不参与建链。
- **校验层**：`content-check` 的排除清单（`_exp`、`docs/archive`、`.git`、`.claude`、`.basic`、`node_modules`、`__pycache__`、外部版本目录）即本规范的机读实现。
- **变更管辖**：本规范修订须走 op-000 `optimize`（含方案确认门禁）。
