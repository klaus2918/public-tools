# -*- coding: utf-8 -*-
"""op 体系回归测试入口（第4组自动化测试轮47固化）
一键运行全部测试套件，汇总 PASS/FAIL。
用法：python -X utf8 run_all_tests.py <仓库根（默认仓库自身）>
包含：
  - content-check 冒烟（test_content_check.py）
  - 自主执行守卫（test_autonomous_guard.py，第10组轮119固化）
  - hook 真实触发（test_precommit.py，约 2 分钟）
  - 脚本 exit code（test_scripts_exitcodes.py）
  - 模板渲染（test_template_render.py）
  - 边界输入（test_scripts_edgecases.py）
  - 幂等性（test_scripts_idempotent.py）
  - op-orchestrate 对账/校验（op-orchestrate/scripts/tests/）
  - java-fs validate-text 自测（java-fs/scripts/validate_text_selftest.py）
  - 知识库 health（op-knowledge/scripts/knowledge-health.py health）
"""
import io
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
REPO = ROOT
PY = sys.executable

SUITES = [
    ("content-check 冒烟", "op-000/scripts/tests/test_content_check.py", ".", 300),
    ("自主执行守卫", "op-000/scripts/tests/test_autonomous_guard.py", ".", 120),
    ("脚本 exit code", "op-000/scripts/tests/test_scripts_exitcodes.py", ".", 300),
    ("模板渲染", "op-000/scripts/tests/test_template_render.py", ".", 120),
    ("边界输入", "op-000/scripts/tests/test_scripts_edgecases.py", ".", 180),
    ("幂等性", "op-000/scripts/tests/test_scripts_idempotent.py", ".", 300),
    ("orchestrate 对账", "op-orchestrate/scripts/tests/test_reconcile.py", "op-orchestrate/scripts/tests", 120),
    ("orchestrate 校验", "op-orchestrate/scripts/tests/test_validate.py", "op-orchestrate/scripts/tests", 120),
    ("java-fs selftest", "java-fs/scripts/validate_text_selftest.py", "java-fs/scripts", 120),
    ("java-fs server 安全", "java-fs/scripts/tests/test_server_security.py", "java-fs/scripts", 120),
    ("java-fs 快照安全", "java-fs/scripts/tests/test_snapshot_security.py", "java-fs/scripts", 120),
    ("docx zip 安全", "docx/scripts/tests/test_zip_safe.py", "docx/scripts", 120),
    ("知识库 health", "op-knowledge/scripts/knowledge-health.py", ".", 120),
    ("pre-commit hook", "op-000/scripts/tests/test_precommit.py", ".", 600),
]


def run_suite(name, rel, cwd, timeout):
    args = ["health"] if "health" in rel else ["."]
    cmd = [PY, "-X", "utf8", os.path.join(REPO, rel)] + args
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                           errors="replace", cwd=os.path.join(REPO, cwd), timeout=timeout)
        return r.returncode, r.stdout + r.stderr
    except subprocess.TimeoutExpired:
        return -1, "超时（>%ds）" % timeout
    except Exception as e:
        return -2, str(e)[:200]


def main():
    results = []
    for name, rel, cwd, timeout in SUITES:
        script = os.path.join(REPO, rel)
        workdir = os.path.join(REPO, cwd)
        # 路径缺失守卫：套件脚本或其 cwd 在本仓库不存在时标记 SKIP（不计入失败）
        if not os.path.isfile(script) or not os.path.isdir(workdir):
            print("  [SKIP] %s: 路径缺失（script=%s, cwd=%s）" % (name, rel, cwd))
            results.append((name, None, None))
            continue
        code, out = run_suite(name, rel, cwd, timeout)
        passed = code == 0
        mark = "PASS" if passed else "FAIL"
        results.append((name, passed, code))
        print("  [%s] %s: exit=%s" % (mark, name, code))
        if not passed:
            # 打印失败输出的关键尾部
            tail = "\n".join(out.splitlines()[-8:])
            print("      %s" % tail.replace("\n", "\n      "))

    print("\n=== 回归汇总 ===")
    for name, passed, code in results:
        mark = "SKIP" if passed is None else ("PASS" if passed else "FAIL")
        print("  [%s] %s" % (mark, name))
    n_pass = sum(1 for _, p, _ in results if p)
    n_fail = sum(1 for _, p, _ in results if p is False)
    n_skip = sum(1 for _, p, _ in results if p is None)
    print("通过 %d/%d（跳过 %d）" % (n_pass, len(results), n_skip))
    return 0 if n_fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
