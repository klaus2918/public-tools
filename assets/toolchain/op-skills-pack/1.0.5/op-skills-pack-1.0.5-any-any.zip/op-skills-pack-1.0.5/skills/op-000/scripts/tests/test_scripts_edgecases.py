# -*- coding: utf-8 -*-
"""边界输入冒烟测试（第4组自动化测试轮44固化）
覆盖：空目录/空 registry/坏 YAML/空 SKILL.md/特殊字符数据/空知识库。
用法：python -X utf8 test_scripts_edgecases.py <仓库根（默认仓库自身）>
"""
import io
import os
import shutil
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
REPO = ROOT
PY = sys.executable


def run(args, timeout=180):
    # 列表参数 + shell=False：不经 shell 解析，也不依赖 PATH 中存在 `python` 命令
    return subprocess.run(args, shell=False, capture_output=True, text=True,
                          encoding="utf-8", errors="replace", cwd=REPO, timeout=timeout)


def main():
    ok = True
    d = tempfile.mkdtemp(prefix="edge_")
    try:
        # 1. content-check 空目录：不崩溃，优雅降级 exit 0
        r = run([PY, "-X", "utf8", "op-000/scripts/op-000-content-check.py", d])
        passed = r.returncode == 0
        print("  [%s] content-check 空目录 exit=%d" % ("PASS" if passed else "FAIL", r.returncode))
        ok = ok and passed

        # 2. content-check 空 registry：exit 0
        os.makedirs(os.path.join(d, "op-000"))
        with io.open(os.path.join(d, "op-000", "registry.yaml"), "w", encoding="utf-8") as f:
            f.write("skills: []\n")
        r = run([PY, "-X", "utf8", "op-000/scripts/op-000-content-check.py", d])
        passed = r.returncode == 0
        print("  [%s] content-check 空 registry exit=%d" % ("PASS" if passed else "FAIL", r.returncode))
        ok = ok and passed

        # 3. content-check 坏 registry YAML：exit 1（7.12 兜底检出）
        with io.open(os.path.join(d, "op-000", "registry.yaml"), "w", encoding="utf-8") as f:
            f.write("skills: [unclosed\n")
        r = run([PY, "-X", "utf8", "op-000/scripts/op-000-content-check.py", d])
        passed = r.returncode == 1
        print("  [%s] content-check 坏 registry YAML exit=%d" % ("PASS" if passed else "FAIL", r.returncode))
        ok = ok and passed

        # 4. content-check 空 SKILL.md：不崩溃
        with io.open(os.path.join(d, "op-000", "registry.yaml"), "w", encoding="utf-8") as f:
            f.write("skills: []\n")
        os.makedirs(os.path.join(d, "test-skill"))
        with io.open(os.path.join(d, "test-skill", "SKILL.md"), "w", encoding="utf-8") as f:
            f.write("")
        r = run([PY, "-X", "utf8", "op-000/scripts/op-000-content-check.py", d])
        passed = r.returncode == 0
        print("  [%s] content-check 空 SKILL.md exit=%d" % ("PASS" if passed else "FAIL", r.returncode))
        ok = ok and passed

        # 5. docgen 特殊字符数据（中文/引号/emoji/换行）→ 渲染成功
        special = '{"title": "中文 & 引号 \\" 测试", "desc": "emoji 🎉 换行\\n第二行", "items": [{"k": "值1"}, {"k": "值2"}]}'
        data_f = os.path.join(d, "special.json")
        with io.open(data_f, "w", encoding="utf-8") as f:
            f.write(special)
        out_d = os.path.join(d, "out")
        r = run([PY, "-X", "utf8", "op-docgen/scripts/docgen.py", "--skeleton", "user-manual",
                 "--data", data_f, "--out", out_d, "--skip-docx"])
        passed = r.returncode == 0 and os.path.isfile(os.path.join(out_d, "draft.md"))
        print("  [%s] docgen 特殊字符数据 exit=%d" % ("PASS" if passed else "FAIL", r.returncode))
        ok = ok and passed

        # 6. knowledge-health 空 KB：exit 1（结构缺失语义正确，非崩溃）
        empty_kb = os.path.join(d, "empty_kb")
        os.makedirs(empty_kb)
        r = run([PY, "-X", "utf8", "op-knowledge/scripts/knowledge-health.py", "health", "--kb", empty_kb])
        passed = r.returncode == 1 and "缺失目录" in (r.stdout + r.stderr)
        print("  [%s] knowledge-health 空 KB exit=%d" % ("PASS" if passed else "FAIL", r.returncode))
        ok = ok and passed
    finally:
        shutil.rmtree(d, ignore_errors=True)

    print("=== 边界输入冒烟测试%s ===" % ("全部通过" if ok else "存在失败"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
