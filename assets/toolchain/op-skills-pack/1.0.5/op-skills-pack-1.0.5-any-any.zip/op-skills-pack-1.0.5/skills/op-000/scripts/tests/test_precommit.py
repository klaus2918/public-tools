# -*- coding: utf-8 -*-
"""pre-commit hook 真实触发冒烟测试（第4组自动化测试轮40固化）
场景：空提交放行 / FFFD 拦截 / 探针拦截 / 正常提交放行（自动还原）。
用法：python -X utf8 test_precommit.py <仓库根（默认仓库自身）>
注意：会真实触发 hook（content-check 全量约 1-2 分钟）；所有提交立即撤销，无残留。
"""
import io
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
REPO = ROOT  # op-skills 仓库根


def git(*args):
    return subprocess.run(["git"] + list(args), capture_output=True, text=True,
                          encoding="utf-8", errors="replace", cwd=REPO)


def hook_path():
    r = git("rev-parse", "--git-path", "hooks")
    return r.stdout.strip()


def main():
    if not os.path.isfile(os.path.join(hook_path(), "pre-commit")):
        print("[SKIP] pre-commit hook 未安装（core.hooksPath 或 .git/hooks 无 pre-commit）")
        return 0

    ok = True
    created = []
    try:
        # 1. 空提交放行
        r = git("commit", "--allow-empty", "-m", "test(hook): 空提交")
        if r.returncode == 0:
            print("[PASS] 空提交放行")
            git("reset", "--soft", "HEAD~1")
        else:
            print("[FAIL] 空提交被拦截:\n%s" % (r.stdout + r.stderr)[-500:])
            ok = False

        # 2. FFFD 拦截
        fa = os.path.join(REPO, "_exp", "hook_fffd_test.md")
        with io.open(fa, "w", encoding="utf-8", newline="") as f:
            f.write("# FFFD 测试\n\n坏字符：\ufffd\ufffd\n")
        created.append(fa)
        git("add", "-f", os.path.relpath(fa, REPO))
        r = git("commit", "-m", "test(hook): 应被 FFFD 拦截")
        out = r.stdout + r.stderr
        if r.returncode != 0 and "FFFD" in out:
            print("[PASS] FFFD 被拦截")
        else:
            print("[FAIL] FFFD 未被拦截 (exit=%d)\n%s" % (r.returncode, out[-500:]))
            ok = False
        git("reset")

        # 3. 探针拦截
        fb = os.path.join(REPO, "op-000", "tmp_hook_probe.txt")
        with io.open(fb, "w", encoding="utf-8", newline="") as f:
            f.write("探针测试\n")
        created.append(fb)
        git("add", "op-000/tmp_hook_probe.txt")
        r = git("commit", "-m", "test(hook): 应被探针拦截")
        out = r.stdout + r.stderr
        if r.returncode != 0 and ("探针" in out or "tmp_" in out):
            print("[PASS] 探针被拦截")
        else:
            print("[FAIL] 探针未被拦截 (exit=%d)\n%s" % (r.returncode, out[-500:]))
            ok = False
        git("reset")

        # 4. 正常提交放行
        fc = os.path.join(REPO, "_exp", "hook_normal_test.md")
        with io.open(fc, "w", encoding="utf-8", newline="") as f:
            f.write("# 正常提交测试\n\n无问题内容。\n")
        created.append(fc)
        git("add", "-f", os.path.relpath(fc, REPO))
        r = git("commit", "-m", "test(hook): 正常提交应放行")
        if r.returncode == 0:
            print("[PASS] 正常提交放行")
            git("reset", "--soft", "HEAD~1")
        else:
            print("[FAIL] 正常提交被拦截:\n%s" % (r.stdout + r.stderr)[-500:])
            ok = False
        git("reset")
    finally:
        for f in created:
            if os.path.exists(f):
                try:
                    os.remove(f)
                except OSError:
                    pass
        git("reset")
        r = git("status", "--short")
        print("[cleanup] 工作区状态:", r.stdout.strip() or "(干净)")

    print("=== pre-commit hook 冒烟测试%s ===" % ("全部通过" if ok else "存在失败"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
