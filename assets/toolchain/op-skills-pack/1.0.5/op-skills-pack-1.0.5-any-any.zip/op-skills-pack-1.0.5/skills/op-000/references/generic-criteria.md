# 通用化判定标准（generic-criteria）

> 版本：v1 ｜ 2026-09-21 ｜ 归属：op-000 ｜ 引入变更：`.op/changes/op-system-design/generic-criteria`
> 目的：定义「通用」的判定标准，用于评估 skill/工具能否跨项目复用、是否应做泛化改造。

## 1. 定义

**通用（generic）= 不依赖具体项目。**

与**环境专有（env-specific）正交**：环境专有指依赖外部运行时/特定环境（如 ssh + 远端 Docker、特定 CLI、透明加密客户端），属 tier 维度的治理状态（`pluggable`），**不构成「非通用」**。

| 定级 | 含义 | 处置 |
|------|------|------|
| `generic` | 7 维信号无项目绑定 | 可跨项目直接复用 |
| `env-specific` | 依赖外部运行时/特定环境（合规） | 按环境启用（tier=pluggable） |
| `project-specific` | 存在项目绑定 | 需泛化改造（改名 + 配置化） |

## 2. 判别信号表（7 维，任一命中即项目绑定）

| # | 维度 | 通用（generic） | 项目绑定（project-specific） |
|:-:|------|----------------|------------------------------|
| 1 | 名称 | 中性功能名（如 `op-release`） | 含业务专名（如 `op-demo-k8s`） |
| 2 | 目录/路径 | 无项目名、无项目盘符路径 | 硬编码项目目录/绝对路径 |
| 3 | 端集合 | 配置驱动（任意端名） | 白名单写死（`backend/pc/app`） |
| 4 | 构建命令 | 配置提供（`build_cmd`） | 硬编码（`mvn`/`npm` 写死） |
| 5 | 远端端点 | 配置提供（`remote_script`/`images_dir`） | 绑定特定服务器/脚本名 |
| 6 | 产物/镜像命名 | 模板/配置 | 绑定项目前缀约定 |
| 7 | 业务专名 | 无 | 注释/日志/文档含项目专名 |

## 3. 定级流程

1. 对目标 skill 逐维核对上表（读 SKILL.md、scripts、references）；
2. 任一维命中「项目绑定」→ `project-specific`；
3. 无项目绑定但依赖外部运行时/特定环境 → `env-specific`；
4. 其余 → `generic`。

## 4. 处置路径

- `project-specific` → **泛化改造**：改名（去业务专名）+ 契约配置化（端集合/构建命令/端点/命名），改造由该 skill 自己的变更执行；
- 泛化完成 → 重新定级（预期 `generic` 或 `env-specific`）。

## 5. 定级表（registry 全量 19 skill，2026-09-21 首次定级）

| skill | 定级 | 说明 |
|-------|------|------|
| op / op-plan / op-build / op-done / op-000 / op-orchestrate | generic | 工作流与治理，与项目无关 |
| safe-git-write | generic | Git 写操作治理，与项目无关 |
| op-html / op-design-extract / op-knowledge | generic | 渲染/设计资产/知识管理，与项目无关 |
| op-docgen | generic | 制式文档生成（jinja2/python-docx 为库依赖，非环境专有） |
| frontend-design | generic | 前端设计指导（纯指导） |
| op-browser | env-specific | 依赖 playwright + Chrome（外部运行时） |
| browser-agent-bridge | env-specific | 依赖 Chrome Native Messaging 宿主 |
| java-fs | env-specific | 依赖 CDG 透明加密客户端（机器双态） |
| op-worktree | env-specific | 依赖 git worktree + 多个配套仓库 |
| op-deploy-prep | env-specific | 依赖项目 kits 与目标环境信息 |
| operate-prg-project | env-specific | 依赖 Project Graph 仓库（pnpm CLI）+ ownership helper |
| **op-demo-k8s** | **project-specific** | 业务专名 + 硬编码三端/命令/远端脚本 → **泛化中** |

## 6. 首个实践用例

- **op-demo-k8s → op-release**：改造由既有变更 `op-demo-k8s-rename-generic` 执行（改名 + 契约通用化：端集合/`build_cmd`/`remote_script`/镜像命名可配）；
- 本表登记其目标定级：泛化完成后预期为 `env-specific`（仍依赖 ssh + 远端 Docker，但不再绑定项目）。

## 7. 与其它机制的关系

- **tier 契约**（`skill-classification.md`）：本标准的 `env-specific` 与 `tier: pluggable` 呼应但不相等（pluggable 还含"领域绑定"情形）；定级为人工核对，标准供引用；
- **接入标准路径**（`external-skill-onboarding.md`）：新引入 skill 的 tier 判定步骤建议同步做本定级；
- **修订**：本标准修订须走 op-000 `optimize`（含方案确认门禁）。
