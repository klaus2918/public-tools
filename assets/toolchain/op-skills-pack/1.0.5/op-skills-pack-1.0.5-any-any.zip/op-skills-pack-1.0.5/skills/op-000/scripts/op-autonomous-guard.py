#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""op-autonomous-guard.py — 自主执行守卫（第10组轮113固化）

检测仓库 .op/changes 下是否存在"活跃自主执行变更"
（change.yaml execution_mode == autonomous 且 phase 未收尾 archive/done）。

- exit 1：存在活跃自主变更（pre-commit 用，阻断提交——自主执行产物必须经人工确认）
- exit 0：无活跃自主变更（可正常走 safe-git-write 约束路径提交）

用法：python op-autonomous-guard.py <仓库根>
"""
import io
import os
import sys


def load_yaml(path):
    import yaml
    with io.open(path, encoding="utf-8") as f:
        return yaml.safe_load(f)


def main():
    if len(sys.argv) < 2:
        print("用法：python op-autonomous-guard.py <仓库根>")
        return 2
    root = sys.argv[1]
    changes_dir = os.path.join(root, ".op", "changes")
    active = []
    if os.path.isdir(changes_dir):
        for dp, dns, fns in os.walk(changes_dir):
            for fn in fns:
                if fn != "change.yaml":
                    continue
                fp = os.path.join(dp, fn)
                try:
                    cy = load_yaml(fp)
                except Exception as e:
                    print("⚠️  解析失败（%s）：%s" % (e, os.path.relpath(fp, root)))
                    continue
                if not isinstance(cy, dict):
                    continue
                mode = cy.get("execution_mode")
                phase = cy.get("phase")
                if mode == "autonomous" and phase not in ("archive", "done"):
                    active.append((os.path.relpath(dp, root), str(phase)))
    if active:
        print("❌ 存在活跃自主执行变更，禁止 Git 写操作（提交必须经人工确认走 safe-git-write）：")
        for name, phase in active:
            print("   - %s（phase=%s）" % (name, phase))
        print("   处理方式：自主执行产物交用户人工确认并收尾（phase=done/archive）后重试提交")
        return 1
    print("✅ 无活跃自主执行变更，可正常提交")
    return 0


if __name__ == "__main__":
    sys.exit(main())
