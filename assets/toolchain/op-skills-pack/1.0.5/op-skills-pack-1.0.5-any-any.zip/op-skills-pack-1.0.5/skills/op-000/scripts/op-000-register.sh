#!/usr/bin/env bash
# ==============================================================
# op-000-register.sh — 注册 op-xxx Skill 到 registry.yaml
#
# 用法：
#   ./op-000-register.sh <skill-name>
#   ./op-000-register.sh --check <skill-name>  仅检查不注册
#   ./op-000-register.sh --sync <skill-name>   同步已注册 skill 的字段
#   ./op-000-register.sh --all                 批量注册所有孤立 Skill
# ==============================================================
set -euo pipefail

SKILLS_DIR="$(cd "$(dirname "$0")/.." && pwd)"
REGISTRY="$SKILLS_DIR/registry.yaml"

# 错误处理
die() { echo "❌ $*" >&2; exit 1; }
info() { echo "ℹ️  $*"; }
ok()   { echo "✅ $*"; }
warn() { echo "⚠️  $*" >&2; }

# 获取 Skill 目录路径
get_skill_path() {
  local name="$1"
  # 接受 op-xxx 和 op_xxx 两种目录名
  local dir1="$SKILLS_DIR/../$name"
  local dir2="$SKILLS_DIR/../${name//op-/op_}"
  if [ -d "$dir1" ]; then echo "$dir1"; return 0; fi
  if [ -d "$dir2" ]; then echo "$dir2"; return 0; fi
  return 1
}

# 校验 SKILL.md frontmatter
validate_frontmatter() {
  local skill_path="$1"
  local skill_file="$skill_path/SKILL.md"

  [ -f "$skill_file" ] || die "SKILL.md 不存在: $skill_file"

  # 检查 frontmatter 标记（tr -d '\r' 兼容 CRLF 行尾文件）
  head -1 "$skill_file" | tr -d '\r' | grep -q '^---$' || die "缺少开头的 ---"
  local line2=$(sed -n '2p' "$skill_file")
  echo "$line2" | grep -q '^name:' || die "frontmatter 缺少 name 字段（第2行）"

  # 提取 name（允许任意合法 skill 名称，不再限定 op- 前缀）
  local name_in_file=$(sed -n 's/^name:[[:space:]]*//p' "$skill_file" | head -1)
  echo "$name_in_file" | tr -d '\r' | grep -qE '^[a-z][a-z0-9-]*$' || die "name 必须为合法标识符（小写字母开头，可含数字/连字符），当前: $name_in_file"

  # 检查必需字段
  local required=("description" "status")
  for field in "${required[@]}"; do
    grep -q "^$field:" "$skill_file" || die "frontmatter 缺少 $field 字段"
  done

  # phase_role 白名单校验（蓝图 2R1 任务 6：防拼写错误如 entery 静默入库）
  local pr=$(sed -n '/^phase_role:[[:space:]]*/{s/^phase_role:[[:space:]]*//;p;q}' "$skill_file" | sed 's/^"//;s/"$//')
  if [ -n "$pr" ]; then
    case "$pr" in
      entry|plan|build|done|support|meta|foundation) ;;
      *) die "phase_role 非法：$pr（白名单：entry/plan/build/done/support/meta/foundation）" ;;
    esac
  fi

  echo "$name_in_file"
}

# 注册到 registry.yaml
register_skill() {
  local name="$1"
  local skill_path="$2"
  local skill_file="$skill_path/SKILL.md"

  # 检查是否已注册
  if grep -q "  - name: $name" "$REGISTRY" 2>/dev/null; then
    info "Skill $name 已在 registry.yaml 中"
    return 0
  fi

  # 提取 frontmatter 字段
  local desc=$(sed -n '/^description:[[:space:]]*/{s/^description:[[:space:]]*//;p;q}' "$skill_file" | sed 's/^"//;s/"$//')
  # 转义 description 中的双引号和反斜杠，保证写入后 YAML 合法
  # （注意：不能用 sed 转义——bash 双引号内 \ 会被消费一层导致转义失效；用 bash 参数替换）
  desc=${desc//\\/\\\\}
  desc=${desc//\"/\\\"}
  local status_val=$(sed -n '/^status:[[:space:]]*/{s/^status:[[:space:]]*//;p;q}' "$skill_file" | sed 's/^"//;s/"$//')
  local phase_role=$(sed -n '/^phase_role:[[:space:]]*/{s/^phase_role:[[:space:]]*//;p;q}' "$skill_file" | sed 's/^"//;s/"$//')
  local version=$(sed -n '/^version:[[:space:]]*/{s/^version:[[:space:]]*//;p;q}' "$skill_file" | sed 's/^"//;s/"$//')
  local created=$(sed -n '/^created_at:[[:space:]]*/{s/^created_at:[[:space:]]*//;p;q}' "$skill_file" | sed 's/^"//;s/"$//')
  local updated=$(sed -n '/^updated_at:[[:space:]]*/{s/^updated_at:[[:space:]]*//;p;q}' "$skill_file" | sed 's/^"//;s/"$//')

  # 默认值
  [ -z "$status_val" ] && status_val="active"
  [ -z "$phase_role" ] && phase_role="support"
  [ -z "$version" ] && version="1.0.0"
  [ -z "$created" ] && created="$(date '+%Y-%m-%dT%H:%M:%S+08:00')"
  [ -z "$updated" ] && updated="$created"

  # 在 registry.yaml 末尾添加条目
  cat >> "$REGISTRY" <<EOF

  - name: $name
    description: "$desc"
    status: $status_val
    phase_role: $phase_role
    version: "$version"
    created_at: "$created"
    updated_at: "$updated"
EOF

  # 更新 updated_at 头
  sed -i "s/^updated_at:.*/updated_at: \"$(date '+%Y-%m-%dT%H:%M:%S+08:00')\"/" "$REGISTRY"

  ok "已注册 $name 到 registry.yaml"
}

# 同步已注册 skill 的字段
sync_skill() {
  local name="$1"
  local skill_path="$2"
  local skill_file="$skill_path/SKILL.md"

  grep -q "  - name: $name" "$REGISTRY" || die "Skill $name 尚未注册，请先注册"

  # 提取 frontmatter 字段
  local desc=$(sed -n '/^description:[[:space:]]*/{s/^description:[[:space:]]*//;p;q}' "$skill_file" | sed 's/^"//;s/"$//')
  # 转义 description 中的双引号和反斜杠，保证写入后 YAML 合法（同 register_skill：bash 参数替换）
  desc=${desc//\\/\\\\}
  desc=${desc//\"/\\\"}
  local status_val=$(sed -n '/^status:[[:space:]]*/{s/^status:[[:space:]]*//;p;q}' "$skill_file" | sed 's/^"//;s/"$//')
  local phase_role=$(sed -n '/^phase_role:[[:space:]]*/{s/^phase_role:[[:space:]]*//;p;q}' "$skill_file" | sed 's/^"//;s/"$//')
  local version=$(sed -n '/^version:[[:space:]]*/{s/^version:[[:space:]]*//;p;q}' "$skill_file" | sed 's/^"//;s/"$//')
  local updated=$(sed -n '/^updated_at:[[:space:]]*/{s/^updated_at:[[:space:]]*//;p;q}' "$skill_file" | sed 's/^"//;s/"$//')
  local now
  now=$(date '+%Y-%m-%dT%H:%M:%S+08:00')

  # 默认值
  [ -z "$status_val" ] && status_val="active"
  [ -z "$phase_role" ] && phase_role="support"
  [ -z "$version" ] && version="1.0.0"
  [ -z "$updated" ] && updated="$now"

  # 按字段逐行替换目标条目（用 awk 而非 sed c\：sed c\ 会消费反斜杠，导致 \" 转义失效破坏 YAML）
  # awk -v desc="$desc" 的双引号会再消费一层反斜杠，故先翻倍（\\" -> \\\\"）
  desc_arg=${desc//\\/\\\\}   # -v 双引号传参会消费一层反斜杠，先翻倍
  awk -v name="$name" -v desc="$desc_arg" -v status_v="$status_val" -v prole="$phase_role" -v ver="$version" -v upd="$updated" '
    BEGIN { in_target=0 }
    $0 ~ "^  - name: "name"$" { in_target=1 }
    in_target && /^  - name: / && $0 !~ "^  - name: "name"$" { in_target=0 }
    in_target && /^    description:/ { print "    description: \"" desc "\""; next }
    in_target && /^    status:/ { print "    status: " status_v; next }
    in_target && /^    phase_role:/ { print "    phase_role: " prole; next }
    in_target && /^    version:/ { print "    version: \"" ver "\""; next }
    in_target && /^    updated_at:/ { print "    updated_at: \"" upd "\""; next }
    { print }
  ' "$REGISTRY" > "$REGISTRY.tmp"
  mv "$REGISTRY.tmp" "$REGISTRY"

  # 同步编排契约字段：invoked_by / dispatches / dependencies
  # （嵌套对象，使用 awk 在 frontmatter 块中精确替换并保留 YAML 缩进）
  sync_block() {
    local field="$1"
    awk -v name="$name" -v field="$field" '
      BEGIN { in_target=0; in_block=0; }
      # 命中目标 skill 的条目
      $0 ~ "^  - name: "name"$" { in_target=1; print; next }
      # 在目标条目内，下一个 skill 条目开始 = 结束
      in_target && /^  - name: / && $0 !~ "^  - name: "name"$" { in_target=0 }
      in_target && $0 ~ "^    "field":" { in_block=1; next }
      in_target && in_block {
        # 块结束条件：行不以 "      "（6 空格）开头（说明进入下一个字段）
        if ($0 !~ /^      / && $0 !~ /^$/) { in_block=0 }
        else { next }
      }
      in_target && !in_block && /^    dependencies:/ { in_block=1; next }
      in_target && in_block && $0 ~ /^    [a-z_]+:/ && $0 !~ /^    dependencies:/ {
        in_block=0
      }
      { print }
    ' "$REGISTRY" > "$REGISTRY.tmp"
    mv "$REGISTRY.tmp" "$REGISTRY"
  }

  # 从 SKILL.md frontmatter 抽取目标 block，追加到 registry 条目
  extract_block() {
    local field="$1"
    awk -v field="$field" '
      BEGIN { in_fm=0; in_block=0; lines=0 }
      /^---$/ { in_fm = !in_fm; if (!in_fm) exit; next }
      in_fm && $0 ~ "^"field":" { in_block=1; print "    " $0; lines++; next }
      in_block && lines > 0 {
        if ($0 ~ /^[^ ]/ || $0 ~ /^---$/) { exit }
        if ($0 ~ /^$/) { print ""; next }
        print "    " $0
        lines++
      }
    ' "$skill_file"
  }

  # 追加或更新 invoked_by / dispatches / dependencies 块
  for field in invoked_by dispatches dependencies; do
    block=$(extract_block "$field" || true)
    if [ -n "$block" ]; then
      # 先删 registry 中目标条目里该字段的旧 block
      awk -v name="$name" -v field="$field" '
        BEGIN { in_target=0; in_block=0 }
        $0 ~ "^  - name: "name"$" { in_target=1; print; next }
        in_target && /^  - name: / && $0 !~ "^  - name: "name"$" { in_target=0 }
        in_target && $0 ~ "^    "field":" { in_block=1; next }
        in_target && in_block {
          if ($0 !~ /^      / && $0 !~ /^$/) { in_block=0; print; next }
          next
        }
        in_target && in_block && /^    [a-z_]+:/ && $0 !~ "^    "field":" { in_block=0; print; next }
        { print }
      ' "$REGISTRY" > "$REGISTRY.tmp"
      mv "$REGISTRY.tmp" "$REGISTRY"

      # 在目标条目末尾（下一条 - name: 之前）插入新 block
      awk -v name="$name" -v field="$field" -v block="$block" '
        BEGIN { in_target=0; inserted=0 }
        $0 ~ "^  - name: "name"$" { in_target=1; print; next }
        in_target && !inserted && /^  - name: / && $0 !~ "^  - name: "name"$" {
          # 目标条目结束，先输出新 block 再输出新条目
          print block
          print ""
          print $0
          inserted=1
          in_target=0
          next
        }
        in_target && !inserted && /^---$/ {
          # 目标条目是文件末尾的最后一个
          print block
          print ""
          print "---"
          inserted=1
          in_target=0
          next
        }
        { print }
      ' "$REGISTRY" > "$REGISTRY.tmp"
      mv "$REGISTRY.tmp" "$REGISTRY"
    fi
  done

  # 更新 registry 的 updated_at 头
  sed -i "s/^updated_at:.*/updated_at: \"$now\"/" "$REGISTRY"

  ok "已同步 $name 到 registry.yaml"
}

# ==== 主逻辑 ====
main() {
  local mode="${1:-}"
  local skill_name="${2:-}"

  [ -f "$REGISTRY" ] || die "registry.yaml 不存在: $REGISTRY"

  case "$mode" in
    --check)
      [ -z "$skill_name" ] && die "用法: $0 --check <skill-name>"
      local path
      path=$(get_skill_path "$skill_name") || die "Skill $skill_name 目录不存在"
      validate_frontmatter "$path"
      ok "SKILL.md frontmatter 校验通过"
      ;;
    --sync)
      [ -z "$skill_name" ] && die "用法: $0 --sync <skill-name>"
      local sync_path
      sync_path=$(get_skill_path "$skill_name") || die "Skill $skill_name 目录不存在（已构建？）"
      validate_frontmatter "$sync_path" >/dev/null 2>&1 || die "frontmatter 校验失败"
      sync_skill "$skill_name" "$sync_path"
      ;;
    --all)
      info "批量注册所有孤立 Skill..."
      local orphans=$("$(dirname "$0")/op-000-check-orphans.sh" 2>/dev/null || echo "")
      [ -z "$orphans" ] && ok "没有孤立 Skill 需要注册" && exit 0
      echo "$orphans" | while read -r name; do
        [ -z "$name" ] && continue
        local path
        path=$(get_skill_path "$name") || { warn "目录不存在: $name"; continue; }
        validate_frontmatter "$path" >/dev/null 2>&1 || { warn "frontmatter 不完整: $name"; continue; }
        register_skill "$name" "$path"
      done
      ;;
    *)
      # 直接指定 skill 名进行注册（mode 即为 skill 名）
      [ -z "$mode" ] && die "用法: $0 <skill-name> 或 $0 --all"
      skill_name="$mode"
      local path
      path=$(get_skill_path "$skill_name") || die "Skill $skill_name 目录不存在（已构建？）"
      validate_frontmatter "$path" >/dev/null 2>&1 || die "frontmatter 校验失败"
      register_skill "$skill_name" "$path"
      ;;
  esac

  ok "完成"
}

main "$@"
