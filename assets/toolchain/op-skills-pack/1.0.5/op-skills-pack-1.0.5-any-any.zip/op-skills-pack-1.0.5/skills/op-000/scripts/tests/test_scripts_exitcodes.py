# -*- coding: utf-8 -*-
"""核心脚本 exit code / 错误路径冒烟测试（第4组自动化测试轮41）
验证：无参数/缺参数/无效子命令/不存在路径等错误路径的退出码语义。
用法：python -X utf8 test_scripts_exitcodes.py <仓库根（默认仓库自身）>
"""
import io
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
REPO = ROOT

PY = sys.executable


def run_py(rel, *args, timeout=120):
    return subprocess.run([PY, "-X", "utf8", os.path.join(REPO, rel)] + list(args),
                          capture_output=True, text=True, encoding="utf-8", errors="replace",
                          timeout=timeout)


def main():
    ok = True
    cases = []

    # 1. knowledge-health：缺 cmd → argparse 报错 exit 2
    r = run_py("op-knowledge/scripts/knowledge-health.py")
    cases.append(("health 缺 cmd", r.returncode == 2, r.returncode))
    # 2. knowledge-health：无效 cmd → exit 2
    r = run_py("op-knowledge/scripts/knowledge-health.py", "bogus-cmd")
    cases.append(("health 无效 cmd", r.returncode == 2, r.returncode))
    # 3. knowledge-health：baseline 正常 → exit 0
    r = run_py("op-knowledge/scripts/knowledge-health.py", "baseline")
    cases.append(("health baseline", r.returncode == 0, r.returncode))
    # 4. knowledge-health：health 正常 → exit 0（P1=0）
    r = run_py("op-knowledge/scripts/knowledge-health.py", "health")
    cases.append(("health health", r.returncode == 0, r.returncode))
    # 5. knowledge-health：--kb 不存在路径 → exit 非0（报错路径）
    r = run_py("op-knowledge/scripts/knowledge-health.py", "health", "--kb", r"Z:\no_such_kb_xyz")
    cases.append(("health 坏 --kb", r.returncode != 0, r.returncode))

    # 6. op-docgen：缺 --skeleton → argparse exit 2
    r = run_py("op-docgen/scripts/docgen.py")
    cases.append(("docgen 缺参数", r.returncode == 2, r.returncode))
    # 7. op-docgen：坏骨架 → 非0
    r = run_py("op-docgen/scripts/docgen.py", "--skeleton", "no-such-skeleton",
               "--data", "op-docgen/assets/samples/user-manual/data.json",
               "--out", r"_exp\_r41_out")
    cases.append(("docgen 坏骨架", r.returncode != 0, r.returncode))

    # 8. content-check：无参数 → exit 2（IndexError 或提示）
    r = run_py("op-000/scripts/op-000-content-check.py")
    cases.append(("content-check 无参数", r.returncode != 0, r.returncode))
    # 9. content-check：不存在路径 → exit 1 或 2
    r = run_py("op-000/scripts/op-000-content-check.py", r"Z:\no_such_dir")
    cases.append(("content-check 坏路径", r.returncode != 0, r.returncode))
    # 10. content-check：正常 → exit 0
    r = run_py("op-000/scripts/op-000-content-check.py", REPO, timeout=300)
    cases.append(("content-check 正常", r.returncode == 0, r.returncode))

    # 11. orchestrate-reconcile：缺 parent → argparse exit 2
    r = run_py("op-orchestrate/scripts/orchestrate-reconcile.py")
    cases.append(("reconcile 缺 parent", r.returncode == 2, r.returncode))

    # 12. metrics：正常运行 → exit 0
    r = run_py("op-000/scripts/op-000-metrics.py", REPO)
    cases.append(("metrics 正常", r.returncode == 0, r.returncode))

    for name, passed, code in cases:
        mark = "[PASS]" if passed else "[FAIL]"
        print(f"  {mark} {name}: exit={code}")
        if not passed:
            ok = False

    print("=== 脚本 exit code 冒烟测试%s ===" % ("全部通过" if ok else "存在失败"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
