﻿# op-000-mount-sync.ps1
# 作用：L2 运行资产挂载点（skill 内目录 <-> .basic/evolved 实体）的检查与创建/修复。
# 规范：skills/op-000/references/isolation-spec.md（三层隔离 · L2 运行资产级）
#
# 用法：
#   powershell -NoProfile -File op-000-mount-sync.ps1 -Status     # 只读检查（不修改）
#   powershell -NoProfile -File op-000-mount-sync.ps1             # 创建缺失挂载点（幂等）
#   powershell -NoProfile -File op-000-mount-sync.ps1 -RepoRoot D:\path\to\repo
#
# 退出码：0 = 全部就绪 / 1 = 存在错误（建链失败、指向错误）/ 2 = 存在警告（未建链、实体目录形态）
param(
  [switch]$Status,
  [string]$RepoRoot = ''
)

$ErrorActionPreference = 'Stop'

if (-not $RepoRoot) {
  $RepoRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..\..')).Path
}

# 挂载点清单（与 isolation-spec.md §2 一一对应，10 个）
$Mounts = @(
  @{ Skill = 'browser-agent-bridge'; Mount = 'runtime' },
  @{ Skill = 'op-browser';           Mount = 'projects' },
  @{ Skill = 'op-browser';           Mount = 'tasks' },
  @{ Skill = 'op-design-extract';    Mount = 'catalog' },
  @{ Skill = 'op-design-extract';    Mount = 'shared' },
  @{ Skill = 'op-done';              Mount = 'config' },
  @{ Skill = 'op-html';              Mount = 'sites' },
  @{ Skill = 'op-knowledge';         Mount = 'config' },
  @{ Skill = 'op-release';           Mount = 'config' },
  @{ Skill = 'op-worktree';          Mount = 'workspaces' }
)

# 实体根：优先 .basic/evolved（重命名后），兼容 .claude/evolved（迁移前）
$entityRootName = $null
foreach ($cand in @('.basic\evolved', '.claude\evolved')) {
  if (Test-Path -LiteralPath (Join-Path $RepoRoot $cand)) { $entityRootName = $cand; break }
}
if (-not $entityRootName) { $entityRootName = '.basic\evolved' }
$EntityRoot = Join-Path $RepoRoot $entityRootName

Write-Output "== op-000 挂载点 $(if ($Status) { '检查（-Status）' } else { '同步' }) =="
Write-Output "仓库根   : $RepoRoot"
Write-Output "实体根   : $EntityRoot"
Write-Output ''

$okCount = 0
$warnCount = 0
$errCount = 0

foreach ($m in $Mounts) {
  $skill = $m.Skill
  $mount = $m.Mount
  $entity = Join-Path (Join-Path $EntityRoot $skill) $mount
  $link = Join-Path (Join-Path (Join-Path $RepoRoot 'skills') $skill) $mount
  $label = "$skill/$mount"

  if (-not (Test-Path -LiteralPath (Join-Path $RepoRoot (Join-Path 'skills' $skill)))) {
    Write-Output "  [ERR ] $label : skill 目录不存在（skills/$skill）"
    $errCount++
    continue
  }

  # 实体目录：缺失则创建（-Status 不修改）
  if (-not (Test-Path -LiteralPath $entity)) {
    if ($Status) {
      Write-Output "  [WARN] $label : 实体目录缺失（$entityRootName/$skill/$mount）"
      $warnCount++
      continue
    }
    New-Item -ItemType Directory -Path $entity -Force | Out-Null
    Write-Output "  [INFO] $label : 已创建实体目录 $entityRootName/$skill/$mount"
  }

  $linkExists = Test-Path -LiteralPath $link
  if (-not $linkExists) {
    if ($Status) {
      Write-Output "  [WARN] $label : 挂载点未创建（运行数据将落在 skill 目录）"
      $warnCount++
      continue
    }
    try {
      New-Item -ItemType Junction -Path $link -Target $entity | Out-Null
      Write-Output "  [OK  ] $label : 已创建 junction -> $entityRootName/$skill/$mount"
      $okCount++
    } catch {
      Write-Output "  [ERR ] $label : 建链失败：$($_.Exception.Message)"
      $errCount++
    }
    continue
  }

  # 已存在：判断形态与指向
  $item = Get-Item -LiteralPath $link -Force
  if ($item.LinkType -eq 'Junction') {
    $actual = ($item.Target -join '')
    if ($actual -eq $entity) {
      Write-Output "  [OK  ] $label : junction 指向正确"
      $okCount++
    } else {
      Write-Output "  [ERR ] $label : junction 指向错误（$actual）"
      $errCount++
    }
  } else {
    # 已存在但非 junction：目录为空时可安全替换为 junction（仅 -Status 之外执行）
    $children = @(Get-ChildItem -LiteralPath $link -Force)
    if ($children.Count -eq 0 -and -not $Status) {
      try {
        Remove-Item -LiteralPath $link -Force
        New-Item -ItemType Junction -Path $link -Target $entity | Out-Null
        Write-Output "  [OK  ] $label : 空目录已替换为 junction -> $entityRootName/$skill/$mount"
        $okCount++
      } catch {
        Write-Output "  [ERR ] $label : 空目录替换失败：$($_.Exception.Message)"
        $errCount++
      }
    } else {
      Write-Output "  [WARN] $label : 非 junction（实体目录形态；需人工迁移数据到实体根后重建）"
      $warnCount++
    }
  }
}

Write-Output ''
Write-Output "汇总：OK $okCount / WARN $warnCount / ERR $errCount"

if ($errCount -gt 0) { exit 1 }
if ($warnCount -gt 0) { exit 2 }
exit 0
