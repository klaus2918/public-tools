# -*- coding: utf-8 -*-
"""模板渲染冒烟测试（第4组自动化测试轮43固化）
1. op-docgen：4 骨架渲染（3 空数据 + user-manual 真实数据），校验 draft.md/placeholders.json 产物
2. op-html：templates/ day/night 模板配对完整性
用法：python -X utf8 test_template_render.py <仓库根（默认仓库自身）>
"""
import glob
import io
import os
import shutil
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
REPO = ROOT
PY = sys.executable


def run(args):
    # 列表参数 + shell=False：不经 cmd/shell 解析，也不依赖 PATH 中存在 `python` 命令
    return subprocess.run(args, shell=False, capture_output=True, text=True,
                          encoding="utf-8", errors="replace", cwd=REPO)


def main():
    ok = True

    # ── 1. op-docgen 渲染 ──
    print("=== op-docgen 4 骨架渲染 ===")
    try:
        import jinja2
        have_j2 = True
    except ImportError:
        have_j2 = False
    if not have_j2:
        print("[SKIP] jinja2 不可用，跳过渲染（pip install jinja2）")
    else:
        outdir = tempfile.mkdtemp(prefix="docgen_render_")
        try:
            for sk in ["api-doc", "db-design", "test-report", "user-manual"]:
                if sk == "user-manual":
                    data = os.path.join(REPO, "op-docgen", "assets", "samples", "user-manual", "data.json")
                else:
                    data = os.path.join(outdir, sk + "-data.json")
                    with io.open(data, "w", encoding="utf-8") as f:
                        f.write("{}")
                r = run([PY, "-X", "utf8", "op-docgen/scripts/docgen.py",
                         "--skeleton", sk, "--data", data, "--out", outdir, "--skip-docx"])
                if r.returncode == 0:
                    print("  [PASS] %s 渲染成功" % sk)
                else:
                    print("  [FAIL] %s 渲染失败: %s" % (sk, (r.stdout + r.stderr)[-400:]))
                    ok = False
            # 产物校验
            draft = os.path.join(outdir, "draft.md")
            ph = os.path.join(outdir, "placeholders.json")
            if os.path.isfile(draft) and os.path.isfile(ph):
                print("  [PASS] 产物 draft.md + placeholders.json 生成")
            else:
                print("  [FAIL] 产物缺失: draft=%s placeholders=%s"
                      % (os.path.isfile(draft), os.path.isfile(ph)))
                ok = False
        finally:
            shutil.rmtree(outdir, ignore_errors=True)

    # ── 2. op-html day/night 模板配对 ──
    print("\n=== op-html day/night 模板配对 ===")
    tpl_dir = os.path.join(REPO, "op-html", "templates")
    htmls = sorted(glob.glob(os.path.join(tpl_dir, "*.html")))
    names = {os.path.basename(h) for h in htmls}
    singles = []
    for n in sorted(names):
        if n.endswith("-dark.html"):
            mate = n[:-len("-dark.html")] + ".html"
        elif n.endswith(".html"):
            mate = n[:-len(".html")] + "-dark.html"
        else:
            continue
        if mate not in names:
            singles.append((n, mate))
    if not singles:
        print("  [PASS] %d 个模板全配对（%d 对 day/night）" % (len(htmls), len(htmls) // 2))
    else:
        for n, mate in singles:
            print("  [FAIL] %s 缺配对模板 %s" % (n, mate))
        ok = False

    print("\n=== 模板渲染冒烟测试%s ===" % ("全部通过" if ok else "存在失败"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
