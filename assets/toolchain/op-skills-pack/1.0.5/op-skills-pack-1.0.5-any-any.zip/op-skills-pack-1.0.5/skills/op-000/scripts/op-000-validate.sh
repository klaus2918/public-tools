#!/usr/bin/env bash
# ==============================================================
# op-000-validate.sh — 校验 op 体系一致性
#
# 检查（v3.5.0，本仓库变更 op-skills-pack-20260912 追加 3.5 / 3.6）：
#   fast 模式（默认）：0 YAML 编码健康 / 1 存在性 / 2 完整性+BOM / 3 name 一致性
#                     / 3.5 SKILL.md 行数硬上限（<=300）/ 3.6 tier 治理分层契约
#                     / 3.7 单 skill 合规审计（结构 / 注册 / 隔离 / 依赖）
#                     / 5.2 版本一致性 / 7 内容与引用层（P0-1 A-01）
#   full 模式（--full）：fast + 4 孤立 / 5.1/5.3/5.4 design-extract 详细 / 6 编排钩子
#   8 体系健康度量（演进基线观测，首次运行存档 .op/validate-baseline.json）
# ==============================================================
set -euo pipefail

# Windows 控制台默认 GBK：统一 python 子进程输出编码，避免 ✅/中文输出触发
# UnicodeEncodeError（与各 .py 内的 stdout.reconfigure 形成双保险）。
export PYTHONIOENCODING="${PYTHONIOENCODING:-utf-8}"

SKILLS_DIR="$(cd "$(dirname "$0")/.." && pwd)"
REGISTRY="$SKILLS_DIR/registry.yaml"
PARENT_DIR="$(cd "$SKILLS_DIR/.." && pwd)"
HAS_ERROR=false

error() { echo "❌ $*" >&2; HAS_ERROR=true; }
ok()   { echo "✅ $*"; }
info() { echo "ℹ️  $*"; }

# 模式解析：--fast（默认，秒级）/ --full（全量）
MODE="fast"
case "${1:-}" in
  ""|--fast) MODE="fast" ;;
  --full)    MODE="full" ;;
  *) echo "❌ 未知参数：${1:-}（支持 --fast / --full）" >&2; exit 1 ;;
esac
info "校验模式：$MODE（--full 追加：孤立 Skill / design-extract 详细 / 编排钩子）"

info "op 系列一致性检查"
echo "──────────────────────────────────────"
echo ""

# 检查 0：registry.yaml YAML 可解析性与编码健康（防双重编码污染/U+20AC/U+FFFD 复发）
info "检查 0：registry.yaml YAML 可解析性与编码健康..."

# 探测可用的 python（Windows 上 python3 可能是 Microsoft Store 占位符）
PY_CMD=""
for c in py python3 python; do
  if command -v "$c" >/dev/null 2>&1; then
    if "$c" -c 'import json' >/dev/null 2>&1; then
      PY_CMD="$c"
      break
    fi
  fi
done

if [ -z "$PY_CMD" ]; then
  info "  ⚠️  无可用 python，跳过 YAML 解析/编码检查"
elif ! "$PY_CMD" -c 'import yaml' >/dev/null 2>&1; then
  info "  ⚠️  环境缺少 pyyaml，跳过 YAML 解析检查（仅文件级检查）"
else
  CHECK0_OUTPUT=$("$PY_CMD" - "$REGISTRY" <<'PY' 2>&1
import sys
try:
    import yaml
except ImportError:
    print("NO_YAML_MODULE"); sys.exit(2)
try:
    with open(sys.argv[1], encoding="utf-8") as f:
        data = yaml.safe_load(f)
    if not isinstance(data, dict) or "skills" not in data:
        print("NOT_VALID:缺少 skills 顶层键"); sys.exit(1)
    bad = []
    for s in data["skills"]:
        desc = str(s.get("description", ""))
        if "\u20ac" in desc or "\ufffd" in desc:
            bad.append(str(s.get("name", "?")))
    if bad:
        print(f"POLLUTED:{','.join(bad)}"); sys.exit(1)
    print(f"OK:{len(data['skills'])}")
    sys.exit(0)
except Exception as e:
    print(f"PARSE_ERROR:{type(e).__name__}:{e}")
    sys.exit(1)
PY
)
  CHECK0_RC=$?
  if [ "$CHECK0_RC" -eq 0 ]; then
    ok "  registry.yaml YAML 可解析，无编码污染（$CHECK0_OUTPUT）"
  else
    error "  registry.yaml 异常：$CHECK0_OUTPUT"
  fi
fi

echo ""

# 检查 1/2/3：结构层检查（python 单次实现——git-bash 下 bash 逐条目 fork 外部命令
# 约 250+ 次，是 fast 模式 80s 慢点主因；输出格式与 bash 原版逐字符兼容）
info "检查 1：registry.yaml → SKILL.md 匹配..."
info "检查 2：SKILL.md 完整性（name/description + 无 BOM）..."
info "检查 3：注册表 ↔ SKILL.md name 一致性..."
if [ -n "$PY_CMD" ]; then
  BASIC_OUTPUT=$("$PY_CMD" "$SKILLS_DIR/scripts/op-000-basic-check.py" "$REGISTRY" "$PARENT_DIR" 2>&1) || true
  echo "$BASIC_OUTPUT"
  if echo "$BASIC_OUTPUT" | grep -q '❌'; then
    error "  结构层检查存在 ❌（见上方输出）"
  fi
else
  info "  ⚠️  无可用 python，跳过结构层检查（1/2/3）"
fi

echo ""

orphan_count=0
soft_orphan_count=0

# 检查 3.5：SKILL.md 行数硬上限（<=300 行，v3.4.0 新增）
# 背景：SKILL.md 是 agent 每轮上下文的一等开销，超长即稀释关键规则；细则应下沉 references/。
# 名单：op 系列 + 非 op 支撑 skill（browser-agent-bridge / java-fs / safe-git-write / frontend-design / operate-prg-project）
info "检查 3.5：SKILL.md 行数硬上限（<=300）..."
SKILL_LINE_LIMIT=300
line_violations=0
checked_skills=0
for dir in "$PARENT_DIR"/*; do
  [ -d "$dir" ] || continue
  base=$(basename "$dir")
  case "$base" in
    op-*|op_*|browser-agent-bridge|java-fs|safe-git-write|frontend-design|operate-prg-project) ;;
    *) continue ;;
  esac
  [ -f "$dir/SKILL.md" ] || continue
  checked_skills=$((checked_skills + 1))
  lines=$(wc -l < "$dir/SKILL.md" | tr -d ' ')
  if [ "$lines" -gt "$SKILL_LINE_LIMIT" ]; then
    error "  $base/SKILL.md 行数超限：$lines > $SKILL_LINE_LIMIT（细则请下沉 references/）"
    line_violations=$((line_violations + 1))
  fi
done
[ "$line_violations" -eq 0 ] && ok "  全部 SKILL.md 未超限（检查 $checked_skills 个）"

# 检查 3.6：tier 治理分层契约（P6 新增）
# - tier 白名单：core / core-support / pluggable（缺失或越界 → 阻塞）
# - tier: core 不得出现在 .op/skill-state.yaml 的 disabled 列表（阻塞）
# - tier: pluggable 建议声明 env_requirements（缺省 → 提示）
info "检查 3.6：tier 治理分层契约..."
if [ -n "$PY_CMD" ]; then
  set +e
  T36_OUTPUT=$("$PY_CMD" - "$REGISTRY" "$PARENT_DIR" <<'PY'
import io, os, sys
try:
    import yaml
except ImportError:
    print("WARN|pyyaml 缺失，跳过 tier 校验")
    sys.exit(0)
reg_path, parent = sys.argv[1], sys.argv[2]
try:
    reg = yaml.safe_load(io.open(reg_path, encoding="utf-8-sig"))
except Exception as e:
    print("ERR|registry 解析失败：%s" % e)
    sys.exit(2)
WHITELIST = {"core", "core-support", "pluggable"}
errs, warns = [], []
state_disabled = set()
# 状态文件可能位于 <repo>/.op/（validate.sh 的 PARENT_DIR 为 skills/ 时需上溯一级）
for cand in (os.path.join(parent, ".op", "skill-state.yaml"),
             os.path.join(os.path.dirname(parent), ".op", "skill-state.yaml")):
    if os.path.isfile(cand):
        try:
            st = yaml.safe_load(io.open(cand, encoding="utf-8")) or {}
            for item in (st.get("disabled") or []):
                state_disabled.add(str(item).strip())
        except Exception:
            pass
        break
skills = reg.get("skills", []) or []
for s in skills:
    name, tier = s.get("name"), s.get("tier")
    if tier not in WHITELIST:
        errs.append("%s — tier 缺失或越界（%r）" % (name, tier))
    elif tier == "pluggable" and not s.get("env_requirements"):
        warns.append("%s — pluggable 未声明 env_requirements" % name)
    if tier == "core" and name in state_disabled:
        errs.append("%s — tier: core 不得停用（见 .op/skill-state.yaml）" % name)
for e in errs:
    print("ERR|  " + e)
for w in warns:
    print("WARN|  " + w)
print("OK|  tier 契约校验完成（%d 条目，%d 错误 / %d 提示）" % (len(skills), len(errs), len(warns)))
sys.exit(1 if errs else 0)
PY
)
  T36_RC=$?
  set -e
  echo "$T36_OUTPUT" | sed 's/^ERR|/❌/; s/^WARN|/⚠️ /; s/^OK|/✅ /'
  if [ "$T36_RC" -ne 0 ]; then
    error "  tier 治理分层契约不通过（见上）"
  fi
else
  info "  ⚠️  无可用 python，跳过 tier 校验（3.6）"
fi

# 检查 3.7：单 skill 合规审计（结构 / 注册 / 隔离 / 依赖四维，本变更新增）
# - 结构：SKILL.md 行数 ≤300、frontmatter 完整、无 BOM
# - 注册：registry 条目存在、name/version/tier 一致
# - 隔离：references/assets.yaml 声明与挂载点（挂载点未创建 → WARN，不阻断）
# - 依赖：frontmatter dispatches 目标 skill 存在
info "检查 3.7：单 skill 合规审计（结构 / 注册 / 隔离 / 依赖）..."
AUDIT_SCRIPT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/op-000-skill-audit.py"
if [ -n "$PY_CMD" ] && [ -f "$AUDIT_SCRIPT" ]; then
  set +e
  AUDIT_OUTPUT=$(PYTHONUTF8=1 PYTHONIOENCODING=utf-8 "$PY_CMD" "$AUDIT_SCRIPT" "$(dirname "$PARENT_DIR")" 2>&1)
  AUDIT_RC=$?
  set -e
  echo "$AUDIT_OUTPUT"
  if [ "$AUDIT_RC" -ne 0 ]; then
    error "  单 skill 合规审计不通过（见上）"
  else
    ok "  单 skill 合规审计通过"
  fi
else
  info "  ⚠️  无可用 python 或缺 skill-audit 脚本，跳过单 skill 合规审计（3.7）"
fi

# 检查 4：孤立 Skill（--full 才执行；fast 下跳过以提速）
if [ "$MODE" = "full" ]; then
  info "检查 4：已构建但未注册的孤立 Skill..."
  # reg_names 供孤立判定（结构层 python 化后此处按需重建，仅 full 模式使用）
  declare -A reg_names
  while IFS= read -r line; do
    n=$(echo "$line" | sed 's/  - name: //')
    reg_names["$n"]=1
  done < <(grep '  - name: ' "$REGISTRY" || true)
  for dir in "$PARENT_DIR"/op-* "$PARENT_DIR"/op_*; do
    [ -d "$dir" ] || continue
    [ "$(basename "$dir")" = "op-000" -o "$(basename "$dir")" = "op_000" ] && continue
    [ -f "$dir/SKILL.md" ] || continue
    name_in_file=$(sed -n 's/^name:[[:space:]]*//p' "$dir/SKILL.md" | head -1 | tr -d '"')
    if [ -z "${reg_names[$name_in_file]:-}" ]; then
      # 检查是否含 .op-internal-allow-orphan 标记（软孤立：warn 而非 error）
      if [ -f "$dir/.op-internal-allow-orphan" ]; then
        info "  ⚠️  $name_in_file — 软孤立（含 .op-internal-allow-orphan 标记，不阻断）"
        soft_orphan_count=$((soft_orphan_count + 1))
      else
        error "  $name_in_file — 已构建但未注册"
        orphan_count=$((orphan_count + 1))
      fi
    fi
  done
  [ "$orphan_count" -eq 0 ] && [ "$soft_orphan_count" -eq 0 ] && ok "  无孤立 Skill，注册表与目录一致"
  [ "$soft_orphan_count" -gt 0 ] && info "  软孤立 Skill 数：$soft_orphan_count（warn 级别，不阻断 validate）"
fi

echo ""

# 检查 5：design-extract 相关校验
info "检查 5：design-extract 产物与沉淀路径..."
DESIGN_EXTRACT_FILE="$PARENT_DIR/op-design-extract/SKILL.md"
if [ -f "$DESIGN_EXTRACT_FILE" ]; then
  # 5.1 frontmatter 规范性（--full 才执行；fast 下由检查 2 覆盖核心字段）
  if [ "$MODE" = "full" ]; then
    # 用 awk 在 frontmatter 段（首对 --- 之间）精确提取各字段并校验非空
    fm_block=$(awk 'BEGIN{found=0} /^---$/{found=!found; if(found==0) exit; next} found{print}' "$DESIGN_EXTRACT_FILE")

    fm_field_value() {
      # 在 fm_block 中提取指定字段的值（去掉前缀和引号）
      echo "$fm_block" | awk -v key="$1" '
        BEGIN{FS=": "}
        {
          # 处理"key: value"或"key:"两种形态；忽略 layer-desc 这种含连字符的字段
          idx=index($0, ": ")
          if (idx > 0) {
            k=substr($0, 1, idx-1)
            v=substr($0, idx+2)
          } else {
            k=$0; v=""
          }
          if (k == key) { gsub(/^"|"$/, "", v); print v; exit }
        }'
    }

    # 校验 name 字段存在且非空
    fm_name=$(fm_field_value "name")
    if [ -z "$fm_name" ]; then
      error "  op-design-extract — frontmatter 缺少 name 字段或值为空"
    fi

    # 校验 version 字段存在且非空
    fm_version=$(fm_field_value "version")
    if [ -z "$fm_version" ]; then
      error "  op-design-extract — frontmatter 缺少 version 字段或值为空"
    fi

    # 校验 description 字段存在且非空
    fm_description=$(fm_field_value "description")
    if [ -z "$fm_description" ]; then
      error "  op-design-extract — frontmatter 缺少 description 字段或值为空"
    fi

    if [ -n "$fm_name" ] && [ -n "$fm_version" ] && [ -n "$fm_description" ]; then
      ok "  op-design-extract — frontmatter 核心字段（name/version/description）完整且非空"
    fi

    # 校验 frontmatter 中不含 when_to_invoke 等非标准字段
    if grep -qE '^when_to_invoke:' "$DESIGN_EXTRACT_FILE"; then
      error "  op-design-extract — frontmatter 含非标准字段 when_to_invoke"
    else
      ok "  op-design-extract — frontmatter 无非标准字段 when_to_invoke"
    fi
  fi

  # 5.2 版本一致性：registry.yaml vs SKILL.md（python 单次实现，替代原 awk 逐条目循环——
  # 原实现 24 条目 × 多次 awk 大文件解析是 fast 模式主要耗时）
  version_drift_count=0
  if [ -n "$PY_CMD" ]; then
    # set -e 下命令替换返回非 0 会直接中止整个校验（原缺陷：版本漂移被吞成崩溃）：
    # 临时关闭 -e，改为按 V52_RC 判定漂移条目数。
    set +e
    V52_OUTPUT=$("$PY_CMD" - "$REGISTRY" "$PARENT_DIR" <<'PY'
import io, os, re, sys
reg_path, parent = sys.argv[1], sys.argv[2]
with io.open(reg_path, encoding="utf-8-sig") as f:
    reg_text = f.read()
entries = re.findall(r'^  - name: (\S+)\n(.*?)(?=^  - name: |\Z)', reg_text, re.M | re.S)
drift = 0
for name, seg in entries:
    rm = re.search(r'^    version:["\s]+([^"\s]+)', seg, re.M)
    reg_version = rm.group(1) if rm else None
    md = os.path.join(parent, name, "SKILL.md")
    skill_version = None
    if os.path.isfile(md):
        with io.open(md, encoding="utf-8-sig") as f:
            head = f.read(4096)
        fm = head.split("---", 2)
        if len(fm) >= 2:
            sm = re.search(r'^version:["\s]+([^"\s]+)', fm[1], re.M)
            if sm:
                skill_version = sm.group(1)
    if reg_version is None:
        print("❌   %s — registry.yaml 中缺少 version 字段" % name); drift += 1
    elif skill_version is None:
        print("❌   %s — SKILL.md 的 frontmatter 缺少 version 字段（无法做版本一致性比较）" % name); drift += 1
    elif reg_version == skill_version:
        print("✅   %s — registry.yaml 与 SKILL.md 版本一致（%s）" % (name, skill_version))
    else:
        print("❌   %s — 版本不一致：registry.yaml='%s' ≠ SKILL.md='%s'" % (name, reg_version, skill_version)); drift += 1
if drift == 0:
    print("✅   全部条目 registry ↔ SKILL.md 版本一致")
sys.exit(1 if drift else 0)
PY
)
    V52_RC=$?
    set -e
    echo "$V52_OUTPUT"
    if [ "$V52_RC" -ne 0 ]; then
      version_drift_count=$((version_drift_count + 1))
    fi
  else
    info "  ⚠️  无可用 python，跳过版本一致性检查（5.2）"
  fi

  # 5.3 沉淀路径说明检查（--full 才执行）
  if [ "$MODE" = "full" ]; then
    # 提取 frontmatter 之后的正文（避免被 frontmatter 的 description 命中）
    body_block=$(awk 'BEGIN{fm_count=0} /^---$/{fm_count++; next} fm_count>=2{print}' "$DESIGN_EXTRACT_FILE")

    shared_path_ok=false
    placeholder_ok=false
    shared_line=""
    placeholder_line=""

    # 5.3.1 正文中必须出现 op-design-extract/shared/...这种带 <project-slug> 的完整路径
    if echo "$body_block" | grep -qE 'op-design-extract/shared/<'; then
      shared_path_ok=true
      shared_line=$(echo "$body_block" | grep -nE 'op-design-extract/shared/<' | head -1)
    fi

    # 5.3.2 <project-slug> 占位符必须被明确标注为占位（避免被误读为真实名称）
    if echo "$body_block" | grep -qE '<project-slug>'; then
      placeholder_line=$(echo "$body_block" | grep -nE '<project-slug>' | head -1)
      placeholder_line_num=$(echo "$placeholder_line" | cut -d: -f1)
      # 在占位符行前后 3 行窗口内查找解释性关键词
      placeholder_ctx=$(echo "$body_block" | awk -v ln="$placeholder_line_num" 'NR>=ln-3 && NR<=ln+3 {print}')
      if echo "$placeholder_ctx" | grep -qE '占位|代号|项目|指|<\s*project-slug\s*>|placeholder'; then
        placeholder_ok=true
      fi
    fi

    if [ "$shared_path_ok" = true ] && [ "$placeholder_ok" = true ]; then
      ok "  op-design-extract — 项目级沉淀路径说明正确（含 shared/<project-slug>/ 与占位说明）"
    else
      if [ "$shared_path_ok" = false ]; then
        error "  op-design-extract — 正文未说明项目级沉淀路径 op-design-extract/shared/<project-slug>/"
      fi
      if [ "$placeholder_ok" = false ]; then
        error "  op-design-extract — <project-slug> 占位说明不清晰：需在占位符行 3 行内含「占位/代号/指」等解释性关键词（当前最近行：${placeholder_line:-未找到}）"
      fi
    fi
  fi

  # 5.4 变更级产物格式检查（--full 才执行；扫描所有 .op/changes/*/design-extract/）
  if [ "$MODE" = "full" ]; then
    design_extract_count=0
    design_extract_error=0

    # Python helper：按 plan 验收要点校验 design-contract.json 的字段类型
    # 输出格式：每字段一行，FIELD:STATUS[:detail]
    #   STATUS ∈ ok | missing | type_wrong | parse_error | not_dict | not_exists
    validate_design_contract_json() {
      local f="$1"
      if [ ! -f "$f" ]; then
        echo "ROOT:not_exists"
        return
      fi
      if [ -z "$PY_CMD" ]; then
        # 无 python 可用：保守地跳过 JSON 字段校验，仅依赖文件级白名单（5.4 原有行为）
        echo "ROOT:no_python"
        return
      fi
      "$PY_CMD" - "$f" <<'PY'
import json, sys
path = sys.argv[1]
try:
    with open(path, "r", encoding="utf-8") as fp:
        data = json.load(fp)
except Exception as e:
    print(f"ROOT:parse_error:{type(e).__name__}")
    sys.exit(0)
if not isinstance(data, dict):
    actual = type(data).__name__
    print(f"ROOT:not_dict:{actual}")
    sys.exit(0)

# 期望字段及期望类型集合（plan P004 验收要点）
spec = [
    ("project_slug",      "string"),
    ("has_ui",            "bool"),
    ("design_extracted",  "bool"),
    ("components",        "list_or_object"),
]

for field, expected in spec:
    if field not in data:
        print(f"{field}:missing")
        continue
    val = data[field]
    actual = type(val).__name__
    # JSON 解析后：str/dict/list/int/float/bool/None；JSON 的 True/False 在 Python 中为 bool（class 'bool'）
    if expected == "string":
        ok = isinstance(val, str)
    elif expected == "bool":
        ok = isinstance(val, bool)
    elif expected == "list_or_object":
        ok = isinstance(val, (list, dict))
    else:
        ok = False
    if ok:
        print(f"{field}:ok")
    else:
        print(f"{field}:type_wrong:{actual}")
PY
    }

    for de_dir in "$PARENT_DIR"/.op/changes/*/design-extract; do
      [ -d "$de_dir" ] || continue
      design_extract_count=$((design_extract_count + 1))
      for f in "$de_dir"/*; do
        [ -f "$f" ] || continue
        bn=$(basename "$f")
        if [ "$bn" != "design-contract.json" ] && [ "$bn" != "design-report.md" ] && [ "$bn" != "diff-against-shared.md" ]; then
          error "  变更级产物异常：$f（只允许 design-contract.json / design-report.md / diff-against-shared.md）"
          design_extract_error=$((design_extract_error + 1))
        fi
        # P004：仅对 design-contract.json 做字段类型校验（其它产物只做白名单检查）
        if [ "$bn" = "design-contract.json" ]; then
          validate_output=$(validate_design_contract_json "$f")
          while IFS= read -r line; do
            [ -z "$line" ] && continue
            field=$(echo "$line" | cut -d: -f1)
            status=$(echo "$line" | cut -d: -f2)
            detail=$(echo "$line" | cut -d: -f3-)
            case "$status" in
              ok)
                # 字段 OK，不单独打印（汇总输出在最后一行，避免噪音）
                ;;
              missing)
                error "  design-contract.json 字段缺失：$field（文件：$f）"
                design_extract_error=$((design_extract_error + 1))
                ;;
              type_wrong)
                error "  design-contract.json 字段类型错误：$field 期望 string/bool/list|object，实际=$detail（文件：$f）"
                design_extract_error=$((design_extract_error + 1))
                ;;
              not_dict)
                error "  design-contract.json 根对象不是 JSON object（实际=$detail），无法校验字段（文件：$f）"
                design_extract_error=$((design_extract_error + 1))
                ;;
              parse_error)
                error "  design-contract.json 解析失败：$detail（文件：$f）"
                design_extract_error=$((design_extract_error + 1))
                ;;
              no_python)
                # 环境无 python3，无法做字段层校验，温和提示且不计入错误（白名单已生效）
                info "  ⚠️  环境缺少 python3，跳过 design-contract.json 字段类型校验（仅文件级白名单）：$f"
                ;;
              *)
                error "  design-contract.json 校验内部错误：未知状态 $status（文件：$f）"
                design_extract_error=$((design_extract_error + 1))
                ;;
            esac
          done <<< "$validate_output"
        fi
      done
    done
    if [ "$design_extract_count" -eq 0 ]; then
      info "  未发现变更级 design-extract 产物"
    elif [ "$design_extract_error" -eq 0 ]; then
      ok "  发现 $design_extract_count 个变更级 design-extract 目录，产物格式合规（含 design-contract.json 字段类型校验）"
    fi
  fi
else
  info "  op-design-extract/SKILL.md 不存在，跳过 design-extract 检查"
fi

# 检查 6：op-orchestrate 编排一致性（--full 才执行；epic 变更，op-orchestrate 存在时按需加载）
if [ "$MODE" = "full" ]; then
  if [ -d "$PARENT_DIR/op-orchestrate" ] && [ -f "$PARENT_DIR/op-orchestrate/SKILL.md" ]; then
    if [ -f "$PARENT_DIR/op-orchestrate/scripts/op-orchestrate-validate.sh" ]; then
      if bash "$PARENT_DIR/op-orchestrate/scripts/op-orchestrate-validate.sh" "$PARENT_DIR"; then
        ok "  op-orchestrate — 编排一致性检查通过"
      else
        error "  op-orchestrate — 编排一致性检查失败（见上方输出）"
      fi
    else
      info "  op-orchestrate — 未发现编排校验脚本，跳过编排检查"
    fi
  else
    info "  op-orchestrate/SKILL.md 不存在，跳过编排检查"
  fi
fi

echo ""

# 检查 7：内容与引用层一致性（P0-1 A-01 落地；fast/full 均执行，快检查）
info "检查 7：内容与引用层一致性（SKILL.md 引用 / 资产完整性 / 版本联动 / 索引 / 复用来源）..."
CONTENT_OUTPUT=""
REF_BAD=0
if [ -n "$PY_CMD" ]; then
  CONTENT_OUTPUT=$("$PY_CMD" "$SKILLS_DIR/scripts/op-000-content-check.py" "$PARENT_DIR" 2>&1) || true
  echo "$CONTENT_OUTPUT"
  if echo "$CONTENT_OUTPUT" | grep -q '❌'; then
    error "  内容与引用层检查失败（见上方输出）"
  else
    ok "  内容与引用层检查通过"
  fi
  REF_BAD=$(echo "$CONTENT_OUTPUT" | grep -c "引用不存在" || true)
else
  info "  ⚠️  无可用 python，跳过内容与引用层检查（7）"
fi

echo ""

# 检查 8：体系健康度量（A-08；演进基线观测，首次运行存档）
info "检查 8：体系健康度量..."
REG_COUNT=$(grep -c '  - name: ' "$REGISTRY" || true)
DIGEST_COUNT=$(find "$PARENT_DIR/op-design-extract/catalog/digests" -name '*.md' 2>/dev/null | wc -l | tr -d ' ' || true)
ASSET_COUNT=0
if [ -f "$PARENT_DIR/op-design-extract/catalog/index.json" ]; then
  IDX_WIN=$(cygpath -w "$PARENT_DIR/op-design-extract/catalog/index.json" 2>/dev/null || echo "$PARENT_DIR/op-design-extract/catalog/index.json")
  ASSET_COUNT=$("$PY_CMD" -c "import json,io;d=json.load(io.open(r'$IDX_WIN',encoding='utf-8'));print(sum(1 for t in d.get('tags',[]) if t.get('kind')!='skill'))" 2>/dev/null || echo 0)
fi
VERSION_DRIFT_COUNT=${version_drift_count:-0}
ORPHAN_COUNT=${orphan_count:-0}
if [ "$ASSET_COUNT" -gt 0 ]; then
  DIGEST_PCT=$((DIGEST_COUNT * 100 / ASSET_COUNT))
else
  DIGEST_PCT=0
fi
info "  度量：registry 条目=$REG_COUNT 孤立=$ORPHAN_COUNT 版本漂移=$VERSION_DRIFT_COUNT digest覆盖=${DIGEST_COUNT}/${ASSET_COUNT}(${DIGEST_PCT}%) 引用断裂=$REF_BAD"
# 演进前基线存档（首次运行；.op/ 为运行时数据，不入库）
BASELINE_FILE="$PARENT_DIR/.op/validate-baseline.json"
if [ ! -f "$BASELINE_FILE" ]; then
  mkdir -p "$PARENT_DIR/.op"
  cat > "$BASELINE_FILE" <<EOF
{"recorded_at": "$(date +%Y-%m-%dT%H:%M:%S)", "note": "op 体系演进基线（2R1 度量段首跑，演进前基线以 s1r1 盘点实测为准）", "entries": $REG_COUNT, "orphans": $ORPHAN_COUNT, "version_drift": $VERSION_DRIFT_COUNT, "digest_coverage": "$DIGEST_COUNT/$ASSET_COUNT", "ref_broken": $REF_BAD}
EOF
  info "  首次运行：度量基线已存档 $BASELINE_FILE"
fi

echo ""
echo "──────────────────────────────────────"

if [ "$HAS_ERROR" = true ]; then
  echo "❌ 检查完成，存在问题需要修复（如上）"
  exit 1
else
  echo "✅ 全部检查通过，op 体系一致"
  exit 0
fi
