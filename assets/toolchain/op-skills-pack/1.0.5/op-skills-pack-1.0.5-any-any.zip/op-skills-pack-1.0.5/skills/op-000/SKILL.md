---
name: op-000
category: support
description: op 体系蓝图设计师。管理 op 体系的机制和职能：宪法管理、Skill 生命周期、注册表维护、能力清单、资产边界管理、质量门禁、分发安装。吸收 writing-skills 和 skill-creator。
status: active
phase_role: meta
version: "4.3.0"
updated_at: 2026-09-14
---

# op-000 — op 体系蓝图设计师

## Overview

op-000 是核心 1（蓝图设计师），负责管理 op 体系的机制和职能：

| 职能 | 说明 |
|------|------|
| 宪法管理 | constitution/AGENTS.md 维护 |
| Skill 生命周期 | 创建→注册→校验→优化→演化→废弃（含 junction 处理） |
| 注册表维护 | registry.yaml 作为 skill 清单唯一事实源 |
| 能力清单 | 每个 skill 的核心能力、输入输出、调用关系 |
| 资产边界管理 | skill 内代码/资产分离规划、junction 管理 |
| 质量门禁 | 结构合规基线（SKILL.md 行数上限 ≤300、frontmatter 完整性、文件卫生）、注册一致性（registry ↔ SKILL.md）、单 skill 整体一致性审计（结构 / 注册 / 隔离 / 依赖四维） |
| 分发安装 | 打包提取纯净安装包、安装配置 junction |
| 多端同步 | sync-skills.ps1 + tools.yaml |

---

## When to Use

- Creating a new op-xxx skill (`/op-000 build ...`)
- Optimizing an existing op-xxx skill (`/op-000 optimize ...`)
- Detecting or fixing registry drift (`/op-000 list --orphans`, `/op-000 validate`)
- Registering a built-but-unregistered skill (`/op-000 register ...`)
- Evaluating coverage gaps in the op workflow (`/op-000 evolve ...`)

**Do not use for:**
- Day-to-day project work (use `/op`)
- Writing implementation code for a project change (use `/op-build`)
- Editing project-level files like `op.yaml`, `plan.md`, or `tasks.md` (out of scope)

---

## Quick Reference

| Command | What it does |
|---------|--------------|
| `/op-000 build <name> [description]` | RED-GREEN-REFACTOR: create + test + iterate |
| `/op-000 optimize [target]` | RED-GREEN-REFACTOR: edit + test + validate |
| `/op-000 validate` | Run consistency checks on skills/ and registry.yaml |
| `/op-000 list` | Show registered skills + orphan warnings |
| `/op-000 list --orphans-only` | Output only orphaned skill names |
| `/op-000 register <name>` | Register one skill |
| `/op-000 register --all` | Register all orphaned skills |
| `/op-000 evolve [domain]` | Evaluate coverage gaps and propose next skills |

---

## Core Rules

1. **Scope = registry 全量（op 系列 + 支撑类）。** File operations are limited to `skills/`（op-* 与 registry 收录的支撑类：java-fs / safe-git-write / frontend-design / operate-prg-project / browser-agent-bridge）与 `skills/op-000/registry.yaml`；外部/非核心 skill 引入按 `references/external-skill-onboarding.md` 七步标准路径执行。
2. **Do not touch project files.** Never read or write `op.yaml`, `.op/`, `plan.md`, or `tasks.md`.
3. **TDD cycle is mandatory for build and optimize.** RED (baseline test) → GREEN (write/fix) → REFACTOR (close loopholes).
4. **Validate after every write.** After any edit to a skill or the registry, run `scripts/op-000-validate.sh`.
5. **Confirm before destructive actions.** `build`, `register` (incl. `--all`), and `optimize` require user confirmation.
6. **Use the provided scripts.** Do not hand-roll registry edits or orphan scans.

---

## 工具边界：sync-skills.ps1 vs register.sh（C-13）

op 体系维护涉及两个"同步/注册"入口，职责不同，禁止混用：

| 工具 | 同步方向 | 覆盖范围 | 典型场景 |
|------|----------|----------|----------|
| `op-000/scripts/op-000-register.sh` | SKILL.md frontmatter **↔** `op-000/registry.yaml` | op 体系内部注册表 | 新 skill 注册、版本/依赖字段同步（`--sync`）、孤儿批量注册（`--all`） |
| `op-000/scripts/sync-skills.ps1` | 仓库 skill 目录 **↔** 各工具 skills 目录（claude/codex/jcode/cc-switch/zcode/reasonix Junction + cc-switch 注册表） | 外部工具接入 | 修改 skill 后同步到各端生效；`-Status` 全面校验；`-Register <name>` 接入 cc-switch |

**边界规则**：内部注册（registry.yaml）只经 op-000-register.sh；外部接入（Junction/cc-switch）只经 sync-skills.ps1。两工具互不替代，`register` 一词在不同工具中含义不同（内部表 vs 外部表），使用时按工具名区分。

---

## Subcommands

### build — RED-GREEN-REFACTOR

#### 🔴 RED — Write Failing Test First

1. Parse name into `op-<name>`; validate `^[a-z][a-z0-9-]{1,32}$`.
2. Reject reserved names: `op`, `000`, `registry`, `help`, `init`.
3. Check for existing directory. If it exists, require `--force` and re-confirm.
4. Show proposed scope boundaries and wait for user confirmation.
5. **Write a pressure scenario prompt** that tests what this skill should enforce.
6. **Run one subagent WITHOUT the skill.** Feed the scenario prompt. Document verbatim what the agent does wrong, what rationalizations it uses, what it misses.
7. **Classify the failure type:**
   - **Discipline failure (明知故犯):** Agent knows the rule but finds excuses. → Later GREEN: write prohibitions + red flags.
   - **Shaping failure (不会做):** Agent is willing but output has wrong shape. → Later GREEN: write positive recipe (what the output IS).
   - **If the baseline does NOT show the failure** (agent already does the right thing without the skill), stop — no skill needed.

#### 🟢 GREEN — Write Minimal Skill

8. **Classify the baseline failure** from RED:
   - **明知故犯 (Discipline failure):** Agent knows the rule but rationalizes skipping it under pressure. → Write **Prohibition + rationalization table + red flags** (current default).
   - **不会做 (Shaping failure):** Agent is willing but output has the wrong shape — too verbose, missing sections, wrong structure. → Write a **positive recipe** stating what the output *is* (its parts, in order). Do NOT use prohibitions — they make shaping failures worse than no guidance at all.
9. Write `SKILL.md` that **addresses only the specific failures observed in RED**. Do not add speculative content for hypothetical cases.
   - Structure: Overview → When to Use → Quick Reference → Core Rules → Red Flags → Common Mistakes
   - `description` must be triggering-condition format (not workflow summary)
   - frontmatter 完整：`status` / `phase_role` / `version` / `updated_at`
10. Create `assets/.gitkeep`. Create `references/` and `scripts/` only if needed.
11. **Run the SAME subagent scenario WITH the skill.** Agent should now comply. Document the pass.
12. Run `scripts/op-000-register.sh <name>`.

#### 🔧 REFACTOR — Close Loopholes

13. **Identify any NEW rationalizations** from the GREEN test run. Add explicit counters.
14. **Re-run** to confirm compliance holds.
15. **Verify the form choice was correct.** If the RED failure was shaping (wrong output shape) but you wrote prohibitions, the agent may have gotten worse — rewrite as a positive recipe and re-test. If the failure was discipline but you wrote a recipe, the agent may still find rationalizations — rewrite as prohibitions + red flags.
16. Run `scripts/op-000-validate.sh` for structural consistency.
17. If behavior change is subtle, add a common-mistakes entry for the old rationalization.

**Truth:** If you didn't watch an agent fail without the skill, you don't know if the skill teaches the right thing.

**Micro-testing shortcut:** When full subagent runs are expensive, use single-shot subagent calls (one without, one with) with a focused prompt that tempts the failure. 5+ reps of wording variants in micro-test before committing to full pressure scenarios.

---

### optimize — RED-GREEN-REFACTOR

#### 🔴 RED — Establish Baseline

1. Parse target (skill name, `registry`, or empty for whole-series review).
2. Run `scripts/op-000-validate.sh` to establish structural baseline.
3. **If the change affects agent behavior** (new rules, changed guidance, added constraints):
   a. Write a micro-test prompt: a focused scenario that tempts the old undesirable behavior.
   b. Run it once without the change — document what the agent does wrong.
   c. **If the baseline does NOT exhibit the failure**, the change may not be needed. Ask user to confirm.
4. **方案确认（强制）**：展示改动预览（文件、章节、原因）→ **必须等用户确认后才能进入 GREEN**。未确认就执行 → STOP（确认是放行凭证，不是可跳过的形式步骤）。

#### 🟧 Optional: Visual Review with op-html

当建议 > 3 条，或每条改动都触及多个文件 / 多个 skill 时，建议在 GREEN 之前把「建议分组」用 op-html 渲染成一页「建议卡片」，让用户在浏览器里逐条 approve / reject / modify，而非仅在对话里口头确认。

**好处：**
- 用户可全屏审阅（一次性看全所有建议，不用滚对话）。
- 每条修改意见能以「卡片为单位」沉淀到 op-html 产物，便于下游 op-build 按 P0/P1 分批执行。
- 若某条被 reject，下一轮 op-000 optimize 仍可复用同一份 op-html 产物继续。

输出约定：
- **默认 Markdown**：生成 `confirm.md` 到 `.op/changes/<change-id>/`，用表格/列表展示建议，供对话内确认。
- **仅当用户明确要求 HTML** 时才进入 op-html HTML 流程，产物约定如下：
  - stage: `optimize-review`
  - output_path（HTML 模式）: `op-html/sites/<repo>/<skill>-<version>-<topic>/`
  - data.system: phase / version / red_signal / decisions
  - data.business: 每条建议一张卡片，含 problem / change / impact / rollback / approval

注：这不是强制步骤。当只有 1-2 条口头建议时，仍以对话方式确认即可。

#### 🟢 GREEN — Apply Change

5. Apply edits to SKILL.md files only.
6. **文件写后校验（强制，v3.5.0）**：每个改写的 SKILL.md / registry.yaml / scripts 立即执行 `java-fs validate-text <file>`（或 `validate-text-many` 批量），确保 UTF-8 无 BOM、无 U+FFFD 乱码、无转义残留（`\r\n` 字面量/反引号）；失败 exit 1，禁止进入下一步，修复后重验。
7. Update `registry.yaml` descriptions/versions if needed.
8. **Run the SAME micro-test prompt WITH the change.** Verify the fix works.
9. Run `scripts/op-000-validate.sh`.

#### 🔧 REFACTOR — Verify It Sticks

9. Check for unintended side effects: does the edit break anything else?
10. If the micro-test passed but feels fragile, add a pressure multiplier (time constraint, conflicting goal) and re-run.
11. Write a `Common Mistakes` entry documenting what the old behavior was and why it was wrong.

**When to skip RED (safe shortcuts):**
- Purely cosmetic changes (rewording, reordering, typos) — GREEN + validate only
- Registry sync (version bumps, description alignment) — direct write + validate
- Adding a Red Flag or Common Mistake entry that documents an already-observed failure — add directly

#### 📦 知识沉淀（optimize 完成后）

optimize 完成后，按需调 `op-knowledge` 沉淀本次优化的关键设计：

- 优化主题、改动文件、关键设计决策、版本变更
- 沉淀到知识库（默认库），便于后续复用

> 知识库配置缺失时按 op-knowledge「消费方接入协议」询问用户（引导配置 / 本次跳过），禁止静默跳过。

---

### validate

Run `scripts/op-000-validate.sh` and return its output. Do not summarize away error details.

校验覆盖（与 `op-000-validate.sh` 检查编号一致）：
- **3.1 / 3.3 注册一致性**：registry.yaml 每个条目对应有 SKILL.md；name / version 一致
- **3.2 字段与编码**：SKILL.md 核心字段（name/description）完整，**且不允许带 UTF-8 BOM**（BOM 会导致 jcode 重新扫描时 frontmatter 解析失败、skill 被排除——op 2.5.0 真实故障，2026-08-12 修复）
- **3.4 孤立检测**：无孤立 Skill（软孤立须含 `.op-internal-allow-orphan` 标记）
- **3.5 结构合规基线（行数）**：SKILL.md 行数硬上限 ≤300 行（v3.4.0 起；细则下沉 `references/`）
- **3.6 tier 治理分层**：tier 白名单校验；`tier: core` 不得标记 disabled
- **3.7 单 skill 合规审计（新增）**：结构 / 注册 / 隔离 / 依赖四维矩阵，违规即 FAIL（隔离维度的「挂载点未创建」保持 WARN）
- **文件卫生（v3.5.0 起）**：对全部 op-* SKILL.md 执行 `java-fs validate-text` 批量检查，重点 U+FFFD 乱码与转义残留（`\r\n` 字面量/反引号），任一文件失败即视为 validate 不通过（先修复再回归；宪法刻意 FFFD 示例所在文件按白名单放行）

### list

Run `scripts/op-000-list.sh` (or `--orphans-only` if flag provided).

### register

Run `scripts/op-000-register.sh` with the provided arguments. Validate frontmatter before writing.

### evolve

Read all active op-xxx SKILL.md files and registry.yaml. Report:
- Coverage of plan/build/done/support phases
- Overlapping responsibilities
- Missing or deprecated dependencies
- Version drift between SKILL.md and registry.yaml

No automatic changes. Output a ranked list of proposals and wait for user decision.

---

## Test Scenario Template (for build RED phase)

When writing the pressure scenario for a new skill, structure it as:

```markdown
You are working on [project context]. The user asks you to [specific task the
skill should govern].

IMPORTANT: [pressure multiplier — tight deadline, conflicting instruction,
  sunk cost, tired, etc.]

Respond to the user with what you would do.
```

**Pressure types to cycle through:**
- **Time pressure:** "We need this done in 5 minutes."
- **Sunk cost:** "You already wrote 50 lines of code for this."
- **Authority:** "Your lead told you to skip this step."
- **Exhaustion:** "You've been debugging for 3 hours."
- **Ambiguity:** "The requirements don't mention this."

---

## Red Flags — STOP

| Smell | What to do |
|-------|------------|
| User asks to edit `op.yaml` or `.op/` | Refuse and route to `/op` |
| User asks op-000 to write project code | Refuse and route to `/op-build` |
| Request skips validation | Explain that validate runs automatically after writes |
| Optimize without a target or goal | Ask what specific behavior should change |
| Editing registry.yaml by hand | Stop and use `register` or `validate` instead |
| **Skipping RED phase on build** | RED is mandatory — watching an agent fail without the skill is how you know what to write |
| **optimize 未确认方案就执行** | STOP：展示改动预览后必须等用户确认，未确认就进入 GREEN 属违规 |

---

## Common Mistakes

- **Skipping RED phase.** Without a baseline failure, you don't know if the skill is needed or what to address.
- **Writing speculative content.** Address only observed failures from RED. Extra hypotheticals = dead weight.
- **Wrong form for the failure.** Using prohibitions on a shaping failure (wrong output shape) makes output worse. Using a recipe on a discipline failure (knows better but skips) leaves loopholes open. Classify in RED, choose in GREEN, verify in REFACTOR.
- **One test run without checking.** Single samples lie. Run at least 2-3 reps if the failure is subtle.
- **Editing registry.yaml manually.** Always use `scripts/op-000-register.sh`.
- **Skipping validate after edits.** Every build/optimize/register must end with validation.
- **Skipping confirmation before GREEN.** 必须展示改动预览并等用户确认；未确认就执行属违规。
- **未按标准路径接入外部/非核心 skill。** 见 `references/external-skill-onboarding.md`（七步路径 + 反模式清单）。
- **Writing long essays in SKILL.md.** Keep skills concise: overview, quick ref, rules, mistakes.
- **Forgetting frontmatter.** Every SKILL.md must have `name` and `description` (trigger-condition format only, no workflow summary).

---

## Scripts

Located in `skills/op-000/scripts/`:

- `op-000-validate.sh` — registry ↔ directory consistency, field checks, orphan detection
- `op-000-list.sh` — registered skills table and orphan warnings
- `op-000-check-orphans.sh` — orphan scan (used by other scripts)
- `op-000-isolation-check.sh` — 三层隔离一键自检（L1 工作区级 / L2 运行资产级 / L3 分发级；退出码 0/1/2）
- `op-000-mount-sync.ps1` — L2 运行资产挂载点检查/创建/修复（幂等；`-Status` 只读）
- `op-000-skill-toggle.sh` — skill 启停（治理分层契约驱动：`core` 拒绝停用；状态写 `.op/skill-state.yaml`）
- `op-000-basic-check.py` / `op-000-content-check.py` — 结构层与内容层校验（由 `op-000-validate.sh` 调用）
- `op-000-register.sh` — register one skill, `--all`, or `--check`

---

## Version

| Field | Value |
|-------|-------|
| Skill | op-000 |
| Version | 4.3.0 |
| Updated | 2026-09-14 |
| Key change | v4.3.0: 新增 skill 治理分层契约（`references/skill-classification.md`：core / core-support / pluggable）+ registry `tier` 字段 + `validate.sh` 检查 3.6 + 启停脚本 `op-000-skill-toggle.sh`；v4.2.0: optimize 方案强制确认门禁（未确认不得进入 GREEN）、optimize 后知识沉淀、新增三层隔离规范（`references/isolation-spec.md`）与隔离自检/挂载点脚本；v4.0.0: 体系蓝图与管理边界整理 |
