#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""op-000-sensitive-check.py — 敏感槽位声明校验（L3 分发级，声明驱动）

数据源：
  全局：skills/op-000/references/sensitive-slots.yaml（模式 / 类别 / 处置 / 关联槽位）
  技能级：各 skills/*/references/assets.yaml 的 sensitivity=config|secret 槽位

校验：
  1) 处置含 track_forbidden 的模式 → 不得有匹配文件被 git 跟踪
  2) skill 级敏感槽位的实体 → 必须落在 gitignore 防线内（git check-ignore）

用法：python op-000-sensitive-check.py [仓库根]
退出码：0=通过 / 1=违规 / 2=环境不可用
"""
import fnmatch
import io
import os
import subprocess
import sys

# Windows 管道兼容：强制 UTF-8 + LF
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", newline="\n")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

try:
    import yaml
except ImportError:  # pragma: no cover
    sys.stderr.write("[FAIL] pyyaml 不可用（请安装 pyyaml）\n")
    sys.exit(2)


def git(root, *args):
    return subprocess.run(
        ["git", "-C", root] + list(args),
        capture_output=True, text=True, encoding="utf-8", errors="replace",
    )


def matches(pattern, path):
    """pattern 支持 * 通配与目录前缀（结尾 /）；path 为仓库相对路径（/ 分隔）。"""
    if pattern.endswith("/"):
        prefix = pattern.rstrip("/")
        parts = path.split("/")
        for i in range(len(parts)):
            if fnmatch.fnmatch("/".join(parts[: i + 1]), prefix):
                return True
        return False
    return fnmatch.fnmatch(path, pattern) or fnmatch.fnmatch(os.path.basename(path), pattern)


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    default_root = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", ".."))
    root = args[0] if args else default_root

    slots_path = os.path.join(root, "skills", "op-000", "references", "sensitive-slots.yaml")
    if not os.path.isfile(slots_path):
        sys.stderr.write("环境不可用：%s 不存在\n" % slots_path)
        return 2

    # git 工作区检查
    if git(root, "rev-parse", "--is-inside-work-tree").returncode != 0:
        sys.stderr.write("环境不可用：%s 不是 git 工作区\n" % root)
        return 2

    with io.open(slots_path, encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    slots = data.get("slots") or []

    ls = git(root, "ls-files")
    tracked = [ln for ln in ls.stdout.splitlines() if ln.strip()]

    ok = 0
    fail = 0
    print("== 敏感槽位声明校验（L3，仓库根：%s） ==" % root)

    print("-- 全局敏感模式（sensitive-slots.yaml） --")
    for s in slots:
        if not isinstance(s, dict):
            continue
        pattern = s.get("pattern")
        disp = s.get("disposition", "both")
        if not pattern:
            fail += 1
            print("  [FAIL] 存在缺少 pattern 的条目")
            continue
        if disp in ("track_forbidden", "both"):
            hits = [t for t in tracked if matches(pattern, t)]
            if hits:
                fail += 1
                print("  [FAIL] 敏感模式被跟踪：%s（示例：%s）" % (pattern, hits[0]))
            else:
                ok += 1
                print("  [PASS] 未被跟踪：%s" % pattern)

    print("-- skill 级敏感槽位（assets.yaml sensitivity） --")
    import glob
    for decl_path in sorted(glob.glob(os.path.join(root, "skills", "*", "references", "assets.yaml"))):
        with io.open(decl_path, encoding="utf-8") as fh:
            decl = yaml.safe_load(fh) or {}
        skill = decl.get("skill") or os.path.basename(os.path.dirname(os.path.dirname(decl_path)))
        for m in decl.get("mounts") or []:
            if not isinstance(m, dict):
                continue
            sens = m.get("sensitivity") or "normal"
            if sens == "normal":
                continue
            entity = (m.get("entity") or "").rstrip("/")
            path = m.get("path") or "?"
            if not entity:
                fail += 1
                print("  [FAIL] %s/%s（%s）缺少 entity 声明" % (skill, path, sens))
                continue
            rc = git(root, "check-ignore", "-q", "--", entity).returncode
            if rc == 0:
                ok += 1
                print("  [PASS] 敏感槽位在忽略防线内：%s/%s（%s）" % (skill, path, sens))
            else:
                fail += 1
                print("  [FAIL] 敏感槽位未在忽略防线内：%s/%s（%s）" % (skill, path, sens))

    print("\n汇总：PASS %d / FAIL %d" % (ok, fail))
    return 1 if fail else 0


if __name__ == "__main__":
    sys.exit(main())
