# 外部/非核心 skill 接入标准路径

> 版本：v1 ｜ 2026-09-21 ｜ 归属：op-000 ｜ 引入变更：`.op/changes/op-system-design/external-skill-onboarding`
> 适用：从体系外引入 skill（第三方 / 本机既有），或把既有能力纳入体系管理。
> 验收口径：走完本路径后，`op-000-validate.sh`（含 3.7 四维审计）全绿即接入完成。

---

## 七步路径

### 1. 来源审查（强制，不可跳过）

按 `skills/safe-git-write/references/sensitive-terms.example` 的「外部内容引入禁入清单」**逐类判定**：

- 命中禁入项 → **剔除或占位化**（真实值写入挂载点，不入库）；
- 审查结论随引入变更记录（变更目录或引入记录中留痕）。

### 2. 结构整理

- `SKILL.md`：行数 ≤300、frontmatter 完整（name / description / status / phase_role / version / updated_at）、无 UTF-8 BOM；
- 有运行资产 → 声明 `references/assets.yaml`（schema 见 `isolation-spec.md` §1.1）；
- 环境相关模板命名 `references/*.example.*`（**仅占位值**）。

### 3. tier 判定

按 `references/skill-classification.md` 判定信号：

| 信号 | tier |
|------|------|
| 主链路必经 | `core` |
| 缺省启用、可降级 | `core-support` |
| 外部运行时 / 环境专有 / 特定领域 | `pluggable`（补 `env_requirements`） |

### 4. 注册

```bash
bash skills/op-000/scripts/op-000-register.sh <name>
```

frontmatter ↔ `registry.yaml` 同步入表（含 tier / category / version）。

### 5. 挂载点（有运行资产时）

1. `assets.yaml` 声明槽位（path / entity / purpose / sensitivity / template）；
2. `powershell -NoProfile -File skills/op-000/scripts/op-000-mount-sync.ps1` 建链（幂等）；
3. 敏感槽位（sensitivity=config/secret）在上述声明中标注，L3 校验自动纳入。

### 6. 多端接入（按需）

- 当前机制：`multi-end-sync/tools.yaml` 登记 + `sync-skills.ps1`（按需选择）；
- 环境探测 → 建议 → 选择 → 按需建链的新流程见 `multi-end-sync-redesign` 变更。

### 7. 校验（验收口径）

```bash
bash skills/op-000/scripts/op-000-validate.sh        # 含 3.7 四维审计
py   skills/op-000/scripts/op-000-content-check.py . # 内容层
bash skills/op-000/scripts/op-000-isolation-check.sh # 三层隔离（含敏感槽位）
```

全部全绿 → 接入完成；任一失败 → 按输出修复后重跑。

---

## 引用规则（单一事实源）

| 规则 | 位置 |
|------|------|
| 禁入清单 | `skills/safe-git-write/references/sensitive-terms.example` |
| 三层隔离与资产声明 schema | `skills/op-000/references/isolation-spec.md` |
| tier 治理分层契约 | `skills/op-000/references/skill-classification.md` |
| 敏感槽位声明 | `skills/op-000/references/sensitive-slots.yaml` |
| 四维审计实现 | `skills/op-000/scripts/op-000-skill-audit.py` |

---

## 反模式（禁止）

- 跳过来源审查直接复制外部内容入库；
- 带 BOM / 超 300 行 / frontmatter 缺失的 `SKILL.md`；
- 有运行资产却不声明 `assets.yaml`（挂载点与声明脱节）；
- 把真实环境值写进 `references/` 模板（应占位）；
- 未注册即接入多端（registry 与实际覆盖脱节）。
