#!/usr/bin/env bash
# ==============================================================
# op-000-list.sh — 列出 op 系列 Skill 全景
#
# 输出：注册 Skill 表 + 孤立 Skill 提示
# 用法：
#   ./op-000-list.sh                完整列表 + 孤立提示
#   ./op-000-list.sh --orphans-only 只输出孤立列表
# ==============================================================
set -euo pipefail

SKILLS_DIR="$(cd "$(dirname "$0")/.." && pwd)"
REGISTRY="$SKILLS_DIR/registry.yaml"
PARENT_DIR="$(cd "$SKILLS_DIR/.." && pwd)"

[ -f "$REGISTRY" ] || { echo "❌ registry.yaml 不存在" >&2; exit 1; }

orphans_only="${1:-}"

echo "═══════════════════════════════════════════════"
echo "  op 系列 Skill 注册表"
echo "═══════════════════════════════════════════════"

# 列注册表
printf "  %-24s %-12s %-10s %s\n" "名称" "阶段角色" "版本" "状态"
printf "  %-24s %-12s %-10s %s\n" "───────────────────────" "───────────" "────────" "──────"

# 逐项解析：遇到下一个 name 时输出上一条，不依赖字段出现顺序
entry_name=""; entry_role=""; entry_ver=""; entry_st=""

flush_entry() {
  if [ -n "$entry_name" ]; then
    # 双 entry 职责标识：op=路由器（router）、op-orchestrate=路由目的地（orchestrate），G-23/C-12
    local role_label="$entry_role"
    if [ "$entry_role" = "entry" ] && [ "$entry_name" = "op" ]; then
      role_label="entry/router"
    elif [ "$entry_role" = "entry" ] && [ "$entry_name" = "op-orchestrate" ]; then
      role_label="entry/orchestrate"
    fi
    printf "  %-24s %-12s %-10s %s\n" "$entry_name" "$role_label" "$entry_ver" "$entry_st"
  fi
  entry_name="$1"; entry_role=""; entry_ver=""; entry_st=""
}

in_skills=false
while IFS= read -r line; do
  # 跳过 skills: 之前的元数据
  if [ "$in_skills" = false ]; then
    echo "$line" | grep -q '^skills:' && in_skills=true
    continue
  fi

  if echo "$line" | grep -qE '^  - name:'; then
    # 新条目开始 → 输出上一条（如有）
    new_name=$(echo "$line" | sed 's/^  - name: //')
    flush_entry "$new_name"
  elif echo "$line" | grep -qE '^    phase_role:'; then
    entry_role=$(echo "$line" | sed 's/^    phase_role: //')
  elif echo "$line" | grep -qE '^    version:'; then
    entry_ver=$(echo "$line" | sed 's/^    version: "//;s/"$//')
  elif echo "$line" | grep -qE '^    status:'; then
    entry_st=$(echo "$line" | sed 's/^    status: //')
  fi
done < "$REGISTRY"

# 输出最后一条
flush_entry ""

echo ""

# 检查孤立
echo "── 孤立检测 ────────────────────────────────────"
orphan_found=false
declare -A registered
while IFS= read -r line; do
  n=$(echo "$line" | sed 's/  - name: //')
  registered["$n"]=1
done < <(grep '  - name: op-' "$REGISTRY" || true)

for dir in "$PARENT_DIR"/op-* "$PARENT_DIR"/op_*; do
  [ -d "$dir" ] || continue
  local_name=$(basename "$dir" | sed 's/^op_/op-/')
  [ "$local_name" = "op-000" ] && continue
  [ -f "$dir/SKILL.md" ] || continue
  name_in_file=$(sed -n 's/^name:[[:space:]]*//p' "$dir/SKILL.md" | head -1 | tr -d '"')
  if [ -z "${registered[$name_in_file]:-}" ]; then
    if [ "$orphans_only" = "--orphans-only" ]; then
      echo "$name_in_file"
    else
      echo "  ⚠️  $name_in_file — 已构建但未注册"
    fi
    orphan_found=true
  fi
done

if [ "$orphan_found" = false ] && [ "$orphans_only" != "--orphans-only" ]; then
  echo "  ✅ 无孤立 Skill"
fi

if [ "$orphans_only" != "--orphans-only" ]; then
  echo "═══════════════════════════════════════════════"
fi
