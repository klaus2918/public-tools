# -*- coding: utf-8 -*-
"""自主执行守卫冒烟测试（第10组轮119固化）
RED/GREEN：无变更 exit 0；活跃 autonomous exit 1；收尾（done）exit 0。
用法：python -X utf8 test_autonomous_guard.py <仓库根（默认仓库自身）>
"""
import io
import os
import shutil
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
GUARD = os.path.join(ROOT, "op-000", "scripts", "op-autonomous-guard.py")


def write(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with io.open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(content)


def run_guard(target):
    r = subprocess.run([sys.executable, "-X", "utf8", GUARD, target],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    return r.returncode, (r.stdout + r.stderr)


def main():
    ok = True
    d = tempfile.mkdtemp(prefix="guard_smoke_")
    try:
        # 1. GREEN：空目录（无 .op）→ exit 0
        rc, out = run_guard(d)
        if rc == 0 and "无活跃自主执行变更" in out:
            print("[GREEN] 空目录 exit 0")
        else:
            print("[FAIL] 空目录应 exit 0: rc=%d\n%s" % (rc, out[-400:]))
            ok = False

        # 2. GREEN：无 execution_mode 的 change.yaml（缺省 constrained）→ exit 0
        write(os.path.join(d, ".op", "changes", "c1", "change.yaml"),
              "name: c1\ntype: feature\nphase: plan\n")
        rc, out = run_guard(d)
        if rc == 0 and "无活跃自主执行变更" in out:
            print("[GREEN] 缺省 constrained exit 0")
        else:
            print("[FAIL] 缺省 constrained 应 exit 0: rc=%d\n%s" % (rc, out[-400:]))
            ok = False

        # 3. RED：活跃 autonomous（phase=build）→ exit 1
        write(os.path.join(d, ".op", "changes", "a1", "change.yaml"),
              "name: a1\ntype: feature\nphase: build\nexecution_mode: autonomous\n")
        rc, out = run_guard(d)
        if rc == 1 and "活跃自主执行变更" in out and "a1" in out:
            print("[GREEN] RED：活跃 autonomous 阻断 exit 1")
        else:
            print("[FAIL] 活跃 autonomous 应 exit 1: rc=%d\n%s" % (rc, out[-400:]))
            ok = False

        # 4. GREEN：autonomous 收尾（phase=done）→ exit 0
        write(os.path.join(d, ".op", "changes", "a1", "change.yaml"),
              "name: a1\ntype: feature\nphase: done\nexecution_mode: autonomous\n")
        rc, out = run_guard(d)
        if rc == 0 and "无活跃自主执行变更" in out:
            print("[GREEN] 收尾后 exit 0")
        else:
            print("[FAIL] 收尾后应 exit 0: rc=%d\n%s" % (rc, out[-400:]))
            ok = False

        # 5. GREEN：真实仓库 → exit 0（无活跃 autonomous 变更）
        rc, out = run_guard(ROOT)
        if rc == 0:
            print("[GREEN] 真实仓库 exit 0")
        else:
            print("[FAIL] 真实仓库应 exit 0: rc=%d\n%s" % (rc, out[-400:]))
            ok = False
    finally:
        shutil.rmtree(d, ignore_errors=True)

    print("=== 自主执行守卫冒烟测试%s ===" % ("全部通过" if ok else "存在失败"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
