#!/usr/bin/env bash
# op-000-skill-toggle.sh — skill 启停（治理分层契约：skills/op-000/references/skill-classification.md）
#
# 用法：
#   bash op-000-skill-toggle.sh status                 # 列出各 skill 的 tier 与启用状态
#   bash op-000-skill-toggle.sh disable <name>         # 停用（core 拒绝；java-fs 需 --confirm-constitution）
#   bash op-000-skill-toggle.sh enable  <name>         # 启用
#
# 状态存放：<repo>/.op/skill-state.yaml（本地，不入库、不随包分发）
# 退出码：0 成功 / 1 拒绝或失败 / 2 环境缺失
set -uo pipefail

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
ROOT=$(cd "$SCRIPT_DIR/../../.." && pwd)
REGISTRY="$ROOT/skills/op-000/registry.yaml"
STATE_DIR="$ROOT/.op"
STATE_FILE="$STATE_DIR/skill-state.yaml"

PY_CMD=""
for c in py python3 python; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import yaml' >/dev/null 2>&1; then PY_CMD="$c"; break; fi
done
if [ -z "$PY_CMD" ]; then
  echo "环境不可用：需要可用的 python（含 pyyaml）" >&2
  exit 2
fi

ACTION="${1:-status}"
NAME="${2:-}"
CONFIRM="${3:-}"

# registry → "name|tier"（去 CR，兼容 Windows python 输出）
reg_dump() {
  "$PY_CMD" - "$REGISTRY" <<'PY' | tr -d '\r'
import io, sys
import yaml
reg = yaml.safe_load(io.open(sys.argv[1], encoding="utf-8-sig")) or {}
for s in reg.get("skills", []) or []:
    print("%s|%s" % (s.get("name"), s.get("tier")))
PY
}

# 当前停用列表（去 CR）
state_dump() {
  if [ -f "$STATE_FILE" ]; then
    "$PY_CMD" - "$STATE_FILE" <<'PY' | tr -d '\r'
import io, sys
import yaml
st = yaml.safe_load(io.open(sys.argv[1], encoding="utf-8")) or {}
for n in (st.get("disabled") or []):
    print(str(n).strip())
PY
  fi
}

write_state() {
  local yaml_lines="$1"
  mkdir -p "$STATE_DIR"
  {
    echo "# skill 启停状态（本地，不入库；契约见 skills/op-000/references/skill-classification.md）"
    echo "# 由 op-000-skill-toggle.sh 维护；tier=core 不可停用"
    if [ -n "$yaml_lines" ]; then
      echo "disabled:"
      printf '%s' "$yaml_lines"
    else
      echo "disabled: []"
    fi
  } > "$STATE_FILE"
}

case "$ACTION" in
  status)
    echo "== skill 启停状态（tier / 状态）=="
    DISABLED=$(state_dump)
    while IFS='|' read -r n t; do
      [ -z "$n" ] && continue
      if printf '%s\n' "$DISABLED" | grep -qx "$n"; then s="停用"; else s="启用"; fi
      printf '  %-22s %-14s %s\n' "$n" "$t" "$s"
    done < <(reg_dump)
    echo ""
    echo "状态文件：$STATE_FILE"
    exit 0
    ;;
  enable|disable)
    if [ -z "$NAME" ]; then
      echo "用法：bash op-000-skill-toggle.sh enable|disable <name>" >&2
      exit 1
    fi
    TIER=$(reg_dump | awk -F'|' -v n="$NAME" '$1 == n { print $2 }')
    if [ -z "$TIER" ]; then
      echo "拒绝：registry 中无此 skill「$NAME」（分层见 references/skill-classification.md）" >&2
      exit 1
    fi
    if [ "$ACTION" = "disable" ]; then
      if [ "$TIER" = "core" ]; then
        echo "拒绝：tier=core 的 skill 不可停用（$NAME）" >&2
        exit 1
      fi
      if [ "$NAME" = "java-fs" ] && [ "$CONFIRM" != "--confirm-constitution" ]; then
        echo "提醒：java-fs 与宪法条款相关（.java 一律经 java-fs），停用将使该条款无法执行。" >&2
        echo "      如确认停用，请追加 --confirm-constitution" >&2
        exit 1
      fi
    fi
    # 重算列表：先剔除同名的旧记录，disable 时再追加
    keep=""
    while IFS= read -r n; do
      [ -z "$n" ] && continue
      [ "$n" = "$NAME" ] && continue
      keep="$keep$n"$'\n'
    done < <(state_dump)
    if [ "$ACTION" = "disable" ]; then
      keep="$keep$NAME"$'\n'
    fi
    yaml_lines=""
    while IFS= read -r n; do
      [ -z "$n" ] && continue
      yaml_lines="$yaml_lines  - $n"$'\n'
    done <<< "$keep"
    write_state "$yaml_lines"
    if [ "$ACTION" = "disable" ]; then
      echo "已停用：$NAME（tier=$TIER）"
    else
      echo "已启用：$NAME（tier=$TIER）"
    fi
    echo "提示：多端目录建链需按状态跳过（sync-skills.ps1 集成见任务 39）；校验器（validate 3.6 与孤立判定）已读取本状态，停用不会误报。"
    exit 0
    ;;
  *)
    echo "用法：bash op-000-skill-toggle.sh {status|enable <name>|disable <name> [--confirm-constitution]}" >&2
    exit 1
    ;;
esac
