#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
op 体系基础结构检查（validate 检查 1/2/3 的 python 实现）
=========================================================
蓝图 2R1 任务 1（G-10/A-06）提速落地：git-bash 下 bash 循环逐条目 fork
外部命令（sed/head/grep/[ -d ]）约 250+ 次，是 fast 模式 80s 慢点的主因。
本脚本一次 python 启动完成检查 1/2/3，输出格式与 bash 原版逐字符兼容。

  检查 1：registry.yaml → SKILL.md 匹配（存在性）
  检查 2：SKILL.md 核心字段 + BOM（name/description 必填；BOM 破坏 frontmatter 解析）
  检查 3：注册表 ↔ SKILL.md name 一致性（双向）

用法：python op-000-basic-check.py <registry> <parent_dir>
输出：每行 ✅/❌ 前缀（无标题，标题由 validate.sh 打印）；存在 ❌ 时 exit 1。
"""
import io
import os
import re
import sys

# Windows 控制台默认 GBK：显式把 stdout/stderr 切到 UTF-8，避免 ✅/中文输出触发
# UnicodeEncodeError（与 op-browser/cli.py、safe-git-write/scan-sensitive.py 同约定）
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

REG_PATH, PARENT = sys.argv[1], sys.argv[2]
HAS_ERROR = False


def ok(msg):
    print("  ✅ " + msg)


def err(msg):
    global HAS_ERROR
    HAS_ERROR = True
    print("  ❌ " + msg)


with io.open(REG_PATH, encoding="utf-8-sig") as f:
    reg_text = f.read()
entries = re.findall(r'^  - name: (\S+)\n(.*?)(?=^  - name: |\Z)', reg_text, re.M | re.S)
reg_names = [n for n, _ in entries]

# ---- 检查 1：registry.yaml → SKILL.md 匹配 ----
for name in reg_names:
    dir1 = os.path.join(PARENT, name)
    dir2 = os.path.join(PARENT, name.replace("op-", "op_", 1))
    if os.path.isfile(os.path.join(dir1, "SKILL.md")):
        ok("%s → SKILL.md 存在" % name)
    elif os.path.isfile(os.path.join(dir2, "SKILL.md")):
        ok("%s → SKILL.md 存在（目录名 %s）" % (name, os.path.basename(dir2)))
    else:
        err("%s → SKILL.md 不存在！" % name)

# ---- 检查 2：SKILL.md 完整性（name/description 必填 + 无 BOM） ----
for name in reg_names:
    md = os.path.join(PARENT, name, "SKILL.md")
    if not os.path.isfile(md):
        continue
    with io.open(md, "rb") as f:
        head_bytes = f.read(4096)
    if head_bytes[:3] == b'\xef\xbb\xbf':
        err("%s — SKILL.md 带 BOM（\\xEF\\xBB\\xBF）：jcode 重新扫描时 frontmatter 解析失败，skill 会被排除；请去除前 3 字节（内容不变）" % name)
        continue
    text = head_bytes.decode("utf-8", errors="replace")
    if not re.search(r'(?m)^name:', text):
        err("%s — 缺少 name 字段" % name)
        continue
    if not re.search(r'(?m)^description:', text):
        err("%s — 缺少 description 字段" % name)
        continue
    ok("%s — 核心字段完整（无 BOM）" % name)

# ---- 检查 3：注册表 ↔ SKILL.md name 一致性（双向） ----
fm_names = {}
for name in reg_names:
    md = os.path.join(PARENT, name, "SKILL.md")
    if not os.path.isfile(md):
        continue
    with io.open(md, encoding="utf-8-sig") as f:
        text = f.read(4096)
    m = re.search(r'(?m)^name:[ \t]*"?([^"\n]+?)"?[ \t]*$', text)
    if m:
        fm_names[m.group(1).strip()] = name
# 目录中 op-* 但不在 registry 的（孤立提示，不阻断）
for d in sorted(os.listdir(PARENT)):
    if not (d.startswith("op-") or d.startswith("op_")):
        continue
    md = os.path.join(PARENT, d, "SKILL.md")
    if not os.path.isfile(md):
        continue
    with io.open(md, encoding="utf-8-sig") as f:
        text = f.read(4096)
    m = re.search(r'(?m)^name:[ \t]*"?([^"\n]+?)"?[ \t]*$', text)
    if m and m.group(1).strip() not in reg_names:
        print("  ⚠️  %s — 在注册表中不存在（孤立）" % m.group(1).strip())
# 反向：registry name 在 SKILL.md frontmatter 中能找到
for name in reg_names:
    if name not in fm_names:
        err("%s — 在注册表中但 SKILL.md 找不到" % name)

sys.exit(1 if HAS_ERROR else 0)
