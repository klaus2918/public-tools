#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
op 体系内容与引用层校验（op-000 validate 检查 7 的实现）
=======================================================
蓝图 2R1 任务 3（P0-1 A-01）落地：validate 结构层之外的内容层盲区。

覆盖检查：
  7.1 SKILL.md 正文相对路径引用存在性（references/、scripts/、../）
      排除：代码块、条件性引用（"若存在/如果/如有"等）、外部绝对路径
  7.2 资产完整性计数（catalog/index.json 条数 vs shared/ 实况 vs digests 覆盖率）
  7.3 被调度 skill 版本滞后提示（已知调度边，调度方 updated_at 晚于被调度方）
  7.4 catalog/index.json 过期检测（shared/ 最新资产 mtime vs 索引 updated_at）
  7.5 reuse-sources.yaml 引用路径存在性（generators/checkers 的 source、kits 的 path）

分级语义（蓝图定稿）：存量已知缺口 → ⚠️（不破坏全绿）；引用断裂/资产文件缺失等
确定性错误 → ❌。存在 ❌ 时 exit 1。

用法：python op-000-content-check.py <仓库根>
"""
import io
import json
import os
import re
import sys

# Windows 控制台默认 GBK：显式把 stdout/stderr 切到 UTF-8，避免 ✅/⚠️/中文输出
# 触发 UnicodeEncodeError（与 op-browser/cli.py、safe-git-write/scan-sensitive.py 同约定）
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

ROOT = sys.argv[1]
HAS_ERROR = False

# git ls-files 惰性缓存（轮65 性能优化）：单次 subprocess 复用，
# 避免 7.10/7.14/7.15 各触发一次全量扫描（实测单次约 0.46s）。
_GIT_LS_FILES_CACHE = None


def git_ls_files():
    """返回 git 跟踪文件列表（进程内缓存一次）。git 不可用时返回 []。"""
    global _GIT_LS_FILES_CACHE
    if _GIT_LS_FILES_CACHE is None:
        import subprocess as _sp
        _r = _sp.run(["git", "ls-files"], capture_output=True, text=True,
                     encoding="utf-8", errors="replace", cwd=ROOT)
        _GIT_LS_FILES_CACHE = _r.stdout.splitlines() if _r.returncode == 0 else []
    return _GIT_LS_FILES_CACHE


# 外部版本目录（独立迭代版本解压/放置区）排除规则：
# 这些目录不属于本仓库自身资产（如 op-skills-pack-20260912/），必须排除在
# 7.11/7.12/7.13/7.18/7.19 的扫描范围外——否则外部版本的异构/坏文件会污染
# 本仓库校验基线（P0 隔离落地，2026-09-14，见 .op/changes/op-skills-pack-20260912/）。
EXTERNAL_DIR_PREFIX = "op-skills-pack-"


def is_external_path(path):
    """判断路径是否落在仓库根下的外部版本目录内（按顶层目录名前缀匹配）。"""
    try:
        rel = os.path.relpath(os.path.abspath(path), os.path.abspath(ROOT))
    except ValueError:
        return False
    if rel.startswith(".."):
        return False
    return rel.replace("\\", "/").split("/")[0].startswith(EXTERNAL_DIR_PREFIX)


def ok(msg):
    print("✅ " + msg)


def warn(msg):
    print("⚠️  " + msg)


def err(msg):
    global HAS_ERROR
    HAS_ERROR = True
    print("❌ " + msg)


def load_yaml(path):
    import yaml
    with io.open(path, encoding="utf-8") as f:
        return yaml.safe_load(f)


# ---------------- 7.1 SKILL.md 引用存在性 ----------------
# 条件性/示例性上下文关键词：命中则该行跳过（避免误报）
COND_RE = re.compile(
    r"若存在|若不存在|如果|如有|不存在|存在时|示例|例如|假设|可选|需要时|必要时|如：|如:|"
    r"含 references|含 scripts|包含 references|包含 scripts|"
    r"（含 references|（含 scripts"
)
# 相对引用模式：references/xxx 与 scripts/xxx（文件路径，含子目录），以及 ../ 跨目录引用
REF_RE = re.compile(r"(?:references|scripts)/([A-Za-z0-9._/+-]+)")
UPREF_RE = re.compile(r"\.\./([A-Za-z0-9._/+-]+/[A-Za-z0-9._+-]+)")
# 排除以反引号包裹的行内代码、http(s)://、绝对路径（盘符或 / 开头）
CODE_RE = re.compile(r"`[^`]*`")


def scan_skill_refs(reg_names):
    """扫描 registry 条目 + op-* 目录的 SKILL.md，返回 (检查行数, 断裂清单 [(目录, 行号, 引用)])。"""
    checked_lines = 0
    bad = []
    for entry in sorted(os.listdir(ROOT)):
        sdir = os.path.join(ROOT, entry)
        skill_md = os.path.join(sdir, "SKILL.md")
        if entry.startswith(".") or not (os.path.isdir(sdir) and os.path.isfile(skill_md)):
            continue
        # 扫描范围：op-* 目录 + registry 条目（单一事实源）；其余目录（外部 skill 等）不纳入
        if not entry.startswith("op-") and entry not in reg_names:
            continue
        with io.open(skill_md, encoding="utf-8") as f:
            lines = f.read().splitlines()
        in_code = False
        for ln, line in enumerate(lines, 1):
            s = line.strip()
            if s.startswith("```"):
                in_code = not in_code
                continue
            if in_code or not s:
                continue
            if COND_RE.search(s):
                continue
            # 去掉行内反引号代码再匹配（references/xxx 出现在代码示例中不算引用）
            plain = CODE_RE.sub("", s)
            if not plain:
                continue
            for m in REF_RE.finditer(plain):
                rel = m.group(0).rstrip("/")
                if not rel:
                    continue
                target = os.path.normpath(os.path.join(sdir, rel))
                checked_lines += 1
                if not os.path.exists(target):
                    bad.append((entry, ln, rel))
            for m in UPREF_RE.finditer(plain):
                rel = m.group(0)
                target = os.path.normpath(os.path.join(sdir, rel))
                checked_lines += 1
                if not os.path.exists(target):
                    bad.append((entry, ln, rel))
    return checked_lines, bad


def check_71(reg_names):
    print("  7.1 SKILL.md 正文相对路径引用存在性...")
    checked, bad = scan_skill_refs(reg_names)
    if not bad:
        ok(f"  引用存在性通过（检查 {checked} 处引用，无断裂）")
    else:
        for entry, ln, rel in bad:
            err(f"  {entry}/SKILL.md 第 {ln} 行引用不存在：{rel}")
        warn(f"  引用断裂 {len(bad)} 处（如上）")


# ---------------- 7.2 资产完整性计数 ----------------
def check_72():
    print("  7.2 设计资产完整性计数（index.json / shared / digests）...")
    de_root = os.path.join(ROOT, "op-design-extract")
    idx_path = os.path.join(de_root, "catalog", "index.json")
    if not os.path.isfile(idx_path):
        warn("  catalog/index.json 不存在，跳过资产计数检查（op-design-extract 未初始化）")
        return
    with io.open(idx_path, encoding="utf-8") as f:
        idx = json.load(f)
    assets = [t for t in idx.get("tags", []) if t.get("kind") != "skill"]
    skills = [t for t in idx.get("tags", []) if t.get("kind") == "skill"]
    # 7.2a 资产 files 存在性（确定错误 → ❌）
    missing_files = []
    for t in assets:
        project = t.get("project")
        for rel in t.get("files", []):
            target = os.path.join(de_root, "shared", project or "", rel)
            if not os.path.exists(target):
                missing_files.append((t.get("key"), rel))
    if missing_files:
        for key, rel in missing_files[:10]:
            err(f"  资产 {key} 引用的文件不存在：shared/.../{rel}")
        if len(missing_files) > 10:
            err(f"  ...另有 {len(missing_files) - 10} 处缺失")
    else:
        ok(f"  资产 files 引用全部存在（{sum(len(t.get('files', [])) for t in assets)} 个文件）")
    # 7.2b digests 覆盖率（数量缺口 → ⚠️）
    digests_dir = os.path.join(de_root, "catalog", "digests")
    digest_count = 0
    if os.path.isdir(digests_dir):
        for _, _, files in os.walk(digests_dir):
            digest_count += sum(1 for f in files if f.endswith(".md"))
    if digest_count >= len(assets) and digest_count > 0:
        ok(f"  L1 digest 覆盖率 {digest_count}/{len(assets)}（齐全）")
    else:
        warn(f"  L1 digest 覆盖率 {digest_count}/{len(assets)}，存量缺口（disclose L1 渐进披露能力空转，见 2R3 全量重建）")
    # 7.2c shared/ 实况 vs index 计数（索引缺失资产 → ⚠️；索引过期检测在 7.4）
    shared_dir = os.path.join(de_root, "shared")
    idx_by_project = {}
    for t in assets:
        idx_by_project.setdefault(t.get("project"), set()).add(t.get("key"))
    missing_keys = []
    if os.path.isdir(shared_dir):
        for proj in sorted(os.listdir(shared_dir)):
            tags_file = os.path.join(shared_dir, proj, "tags.yaml")
            if not os.path.isfile(tags_file):
                continue
            try:
                data = load_yaml(tags_file)
            except Exception:
                warn(f"  7.2c {proj}/tags.yaml 解析失败（事实源损坏，资产无法进入索引）")
                continue
            src_keys = {t.get("key") for t in (data or {}).get("tags", []) if t.get("key")}
            idx_keys = idx_by_project.get(proj, set())
            for k in sorted(src_keys - idx_keys):
                missing_keys.append((proj, k))
    if missing_keys:
        for proj, k in missing_keys[:10]:
            warn(f"  7.2c {proj} 资产 {k} 在事实源存在但未进入索引（索引缺失资产）")
        if len(missing_keys) > 10:
            warn(f"  ...另有 {len(missing_keys) - 10} 个缺失")
    else:
        ok(f"  事实源资产全部进入索引（{sum(len(v) for v in idx_by_project.values())} 个）")
    return len(assets)


# ---------------- 7.3 被调度 skill 版本滞后 ----------------
# 已知调度边：调度方(registry updated_at) 晚于被调度方即提示
KNOWN_EDGES = [
    ("op-plan", "op-brainstorming"),
    ("op-plan", "op-html"),
    ("op-build", "op-browser"),
    ("op-build", "op-worktree"),
    ("op-build", "subagent-driven-development"),
    ("op-build", "systematic-debugging"),
]


def check_73(reg):
    print("  7.3 被调度 skill 版本滞后提示...")
    upd = {}
    for s in reg.get("skills", []):
        upd[str(s.get("name", ""))] = str(s.get("updated_at", ""))
    lag = []
    for caller, callee in KNOWN_EDGES:
        a, b = upd.get(caller, ""), upd.get(callee, "")
        if a and b and a > b:
            lag.append((caller, callee, a, b))
    if not lag:
        ok("  已知调度边无版本滞后")
    else:
        for caller, callee, a, b in lag:
            warn(f"  {caller}（{a}）晚于被调度方 {callee}（{b}），衔接契约可能漂移，建议联动核对")


# ---------------- 7.4 catalog/index.json 过期检测 ----------------
def check_74():
    print("  7.4 catalog/index.json 过期检测...")
    de_root = os.path.join(ROOT, "op-design-extract")
    idx_path = os.path.join(de_root, "catalog", "index.json")
    shared_dir = os.path.join(de_root, "shared")
    if not os.path.isfile(idx_path):
        return
    with io.open(idx_path, encoding="utf-8") as f:
        idx = json.load(f)
    idx_time = str(idx.get("updated_at", ""))
    # shared/ 下最新文件的 mtime（本地时间）
    latest_mtime = 0.0
    if os.path.isdir(shared_dir):
        for root, _, files in os.walk(shared_dir):
            # 排除 _contracts/（域无关契约参考层，非设计资产；2R2 新增）
            if os.path.basename(root) == "_contracts":
                continue
            for fn in files:
                p = os.path.join(root, fn)
                try:
                    latest_mtime = max(latest_mtime, os.path.getmtime(p))
                except OSError:
                    pass
    # idx_time 形如 2026-08-05T19:05:25.594944（本地时间）；转 epoch 比较
    import datetime
    try:
        dt = datetime.datetime.strptime(idx_time, "%Y-%m-%dT%H:%M:%S.%f")
        idx_epoch = dt.timestamp()
    except ValueError:
        try:
            dt = datetime.datetime.strptime(idx_time, "%Y-%m-%dT%H:%M:%S")
            idx_epoch = dt.timestamp()
        except ValueError:
            warn(f"  index.json updated_at 无法解析（{idx_time}），跳过过期检测")
            return
    if latest_mtime > idx_epoch + 1:
        warn("  index.json 过期：shared/ 有资产变更晚于索引重建时间，建议运行 tag-index.sh 重建（唯一写者）")
    else:
        ok("  index.json 与 shared/ 资产同步（无过期）")


# ---------------- 7.5 reuse-sources.yaml 引用路径存在性 ----------------
def check_75():
    print("  7.5 op-deploy-prep reuse-sources.yaml 引用路径存在性...")
    rs_path = os.path.join(ROOT, "op-deploy-prep", "references", "reuse-sources.yaml")
    if not os.path.isfile(rs_path):
        warn("  reuse-sources.yaml 不存在，跳过（op-deploy-prep 未初始化）")
        return
    rs = load_yaml(rs_path)
    bad_sources = []
    for g in rs.get("generators", []):
        src = g.get("source", "")
        if src and not os.path.exists(os.path.join(ROOT, src)):
            bad_sources.append((g.get("id"), src))
    for c in rs.get("checkers", []):
        src = c.get("source", "")
        if src and not os.path.exists(os.path.join(ROOT, src)):
            bad_sources.append((c.get("id"), src))
    if bad_sources:
        for gid, src in bad_sources:
            err(f"  {gid} 的 source 不存在：{src}")
    else:
        ok(f"  generators/checkers 的 source 引用全部存在（{len(rs.get('generators', [])) + len(rs.get('checkers', []))} 个）")
    placeholder = 0
    missing_kit = 0
    for k in rs.get("kits", []):
        p = k.get("path", "")
        if not p:
            missing_kit += 1
            continue
        if p.startswith("<") and p.endswith(">"):
            placeholder += 1
        elif not os.path.exists(os.path.join(ROOT, p)):
            missing_kit += 1
    if placeholder:
        warn(f"  kits 有 {placeholder} 条 path 为占位符（<历史材料包路径：...>），复用链第③档暂不可消费（见 2R3 实体化）")
    if missing_kit:
        warn(f"  kits 有 {missing_kit} 条 path 缺失或指向不存在路径")
    if not placeholder and not missing_kit:
        ok("  kits path 全部实体化且存在")


# ---------------- 7.6 phase_role 白名单校验 ----------------
PHASE_ROLE_WHITELIST = {"entry", "plan", "build", "done", "support", "meta", "foundation"}


def check_76(reg):
    print("  7.6 phase_role 白名单校验（registry-integration.md §3.2 建议落地）...")
    if not reg:
        warn("  registry 不可解析，跳过 phase_role 白名单校验")
        return
    bad = []
    for s in reg.get("skills", []):
        pr = s.get("phase_role")
        if pr is None:
            bad.append((s.get("name"), "<缺失>"))
        elif pr not in PHASE_ROLE_WHITELIST:
            bad.append((s.get("name"), pr))
    if not bad:
        ok(f"  全部 {len(reg.get('skills', []))} 条目的 phase_role 在白名单内")
    else:
        for name, pr in bad:
            err(f"  {name} 的 phase_role={pr} 非法（白名单：{sorted(PHASE_ROLE_WHITELIST)}）")


# ---------------- 7.7 tmp/log 残留防线 ----------------
TMP_PATTERNS = ("tmp_", "_tmp", ".tmp")


def check_77():
    """op 体系 skill 目录内临时文件残留（gitignore 已排除跟踪，存在即卫生残留）。
    蓝图 2R3 任务 6（P2-C）：tmp/log 机器防线。"""
    print("  7.7 tmp/log 残留防线（skill 目录内临时文件）...")
    hits = []
    for entry in sorted(os.listdir(ROOT)):
        sdir = os.path.join(ROOT, entry)
        if entry.startswith(".") or not os.path.isdir(sdir):
            continue
        if not (entry.startswith("op-") or entry in ("webapp-testing", "java-fs", "safe-git-write", "systematic-debugging", "subagent-driven-development", "dispatching-parallel-agents", "skill-creator", "writing-skills", "docx", "browser-agent-bridge", "frontend-design", "operate-prg-project")):
            continue
        for root, dirs, files in os.walk(sdir):
            # 跳过 junction 目标（.claude/evolved、.basic/evolved 等运行资产由挂载/git 单独管理，另作校验）
            dirs[:] = [d for d in dirs if not d.startswith(".")]
            for fn in files:
                low = fn.lower()
                if low.startswith(TMP_PATTERNS[0]) or low.startswith(TMP_PATTERNS[1]) or low.endswith(TMP_PATTERNS[2]):
                    hits.append(os.path.join(root, fn))
    if hits:
        warn(f"  发现 {len(hits)} 个临时文件残留（应清理；gitignore 已防误入库）：")
        for h in hits:
            warn(f"    {h}")
    else:
        ok("  无临时文件残留")


# ---------------- 7.8 调度关系对称性（dispatches ↔ depended_by/invoked_by） ----------------
def check_78(reg):
    """检查 registry 调度关系对称性：dispatches 的目标 skill 应声明对应的
    depended_by 或 invoked_by 反向引用，保证关系图可双向遍历（协同性优化阶段3）。
    约定：invoked_by 表示入口路由强绑定（op → plan/build/done）；dispatches 的
    被动视图用 depended_by 表示（如 op-build → op-browser 对应 op-browser depended_by op-build）。
    仅警告不阻塞（对称性是质量属性，缺失不影响运行）。"""
    print("  7.8 调度关系对称性（dispatches ↔ depended_by/invoked_by）...")
    names = {str(s.get("name", "")) for s in reg.get("skills", [])}
    by_name = {str(s.get("name", "")): s for s in reg.get("skills", [])}
    missing = []
    for name, s in by_name.items():
        for callee in s.get("dispatches", []):
            if callee not in names:
                missing.append((name, callee, "目标不在 registry"))
                continue
            tgt = by_name[callee]
            rev = tgt.get("depended_by", []) + tgt.get("invoked_by", [])
            if not any((isinstance(r, dict) and r.get("skill") == name) or r == name for r in rev):
                missing.append((name, callee, f"{callee} 缺 depended_by/invoked_by 反向声明"))
    if missing:
        warn(f"  发现 {len(missing)} 条不对称调度边（建议补反向声明，不阻塞）：")
        for caller, callee, why in missing:
            warn(f"    {caller} --dispatches--> {callee}：{why}")
    else:
        ok("  全部 dispatches 边均有关联反向声明（depended_by/invoked_by）")


# ---------------- 7.9 category 分层与 registry/frontmatter 一致性（v3 新增） ----------------
CATEGORY_WHITELIST = {"core", "support", "foundation", "generic"}


def _yaml_text(text):
    import yaml
    try:
        return yaml.safe_load(text)
    except Exception:
        return None


def check_79(reg):
    """7.9 category 资产分层校验（v3）：全部 skill 必须声明 category 且在白名单内；
    SKILL.md frontmatter 与 registry 的 category/version/status/phase_role/dispatches 必须一致
    （单一事实源 = SKILL.md frontmatter；registry 是派生的关系图）。"""
    print("  7.9 category 分层与 registry/frontmatter 一致性（v3）...")
    if not reg:
        warn("  registry 不可解析，跳过 7.9")
        return
    bad = []
    for s in reg.get("skills", []):
        name = s.get("name")
        cat = s.get("category")
        if cat is None:
            bad.append((name, "registry 缺 category"))
        elif cat not in CATEGORY_WHITELIST:
            bad.append((name, f"registry category={cat} 非法（白名单：{sorted(CATEGORY_WHITELIST)}）"))
        fm_path = os.path.join(ROOT, name, "SKILL.md")
        if os.path.isfile(fm_path):
            try:
                with io.open(fm_path, encoding="utf-8-sig") as f:
                    txt = f.read().replace("\r\n", "\n")
                m = re.match(r"^---\n(.*?)\n---", txt, re.S)
                if not m:
                    bad.append((name, "frontmatter 缺失"))
                    continue
                fm = _yaml_text(m.group(1))
                if fm is None:
                    bad.append((name, "frontmatter 解析失败"))
                    continue
                if fm.get("category") != cat:
                    bad.append((name, f"category 不一致：registry={cat} frontmatter={fm.get('category')}"))
                if str(fm.get("version")) != str(s.get("version")):
                    bad.append((name, f"version 不一致：registry={s.get('version')} frontmatter={fm.get('version')}"))
                if fm.get("status") != s.get("status"):
                    bad.append((name, f"status 不一致：registry={s.get('status')} frontmatter={fm.get('status')}"))
                if fm.get("phase_role") != s.get("phase_role"):
                    bad.append((name, f"phase_role 不一致：registry={s.get('phase_role')} frontmatter={fm.get('phase_role')}"))
                rd = set(s.get("dispatches") or [])
                fd = set(fm.get("dispatches") or [])
                if rd != fd:
                    bad.append((name, f"dispatches 不一致：reg={sorted(rd)} fm={sorted(fd)}"))
            except Exception as e:
                bad.append((name, f"frontmatter 读取/解析异常：{str(e)[:50]}"))
    if bad:
        for name, why in bad:
            err(f"  {name}：{why}")
    else:
        ok(f"  全部 {len(reg.get('skills', []))} 条目的 category 分层与 frontmatter 一致")


# ---------------- 7.10 探针脚本跟踪防线（v3 新增） ----------------
PROBE_PREFIXES = ("_verify_", "_analyze_", "_tmp", "tmp_", "_m3_")
PROBE_SUFFIXES = (".out", ".lock")


def check_710(reg):
    """7.10 探针/过程产物跟踪防线：git 跟踪的 _verify_/_analyze_/tmp_ 开头文件
    或 .out/.lock 过程产物应解除跟踪（探针只存在于工作区，不入库、不入包）。
    白名单豁免：op-html/templates/_*.html（命名约定）、__init__.py（合法 Python 包）。"""
    print("  7.10 探针脚本跟踪防线（v3）...")
    tracked = git_ls_files()
    hits = [f for f in tracked
            if f.rsplit("/", 1)[-1].startswith(PROBE_PREFIXES)
            or f.rsplit("/", 1)[-1].endswith(PROBE_SUFFIXES)]
    whitelist = [h for h in hits
                 if "op-html/templates/" in h or h.endswith("__init__.py")]
    real = [h for h in hits if h not in whitelist]
    if real:
        for h in real:
            warn(f"  探针/过程产物被 git 跟踪：{h}（应 git rm --cached 解除）")
        warn(f"  共 {len(real)} 个探针被跟踪，建议解除跟踪（不影响工作区文件）")
    else:
        ok(f"  无探针/过程产物被跟踪（{len(whitelist)} 个白名单命名约定豁免）")


def check_711(_reg=None):
    """7.11 脚本语法健康（第4组自动化测试固化）：对仓库内脚本做源码级语法校验。
    - .py：compile() 确定性校验（无外部依赖，必须通过）
    - .js：node 单进程批量（vm.Script 编译，轮65 优化：102 文件 43s→0.5s）
    - .ps1：PowerShell 解析器（ThreadPool 并行，轮65 优化）
    - .cmd/.bat：括号配对
    - .sh：bash -n（ThreadPool 并行，轮65 优化）
    排除：_exp/、docs/archive/、.git/、.claude/、.basic/、node_modules/、__pycache__/"""
    print("  7.11 脚本语法健康（第4组固化）...")
    import json as _json
    import subprocess
    from concurrent.futures import ThreadPoolExecutor

    skip_parts = ("_exp", os.sep + "docs" + os.sep + "archive", os.sep + ".git",
                  os.sep + ".claude", os.sep + ".basic",
                  os.sep + "node_modules", os.sep + "__pycache__")
    py_bad = js_bad = ps_bad = sh_bad = cmd_bad = 0
    py_ok = js_ok = ps_ok = sh_ok = cmd_ok = 0

    # 探测外部工具（一次）：固定路径 + PATH（shutil.which）
    import shutil

    def _tool(paths, name, exclude=None):
        for p in paths:
            if os.path.isfile(p):
                return p
        w = shutil.which(name)
        if w and exclude and os.path.normcase(os.path.abspath(w)).startswith(os.path.normcase(exclude)):
            return None
        return w

    node = _tool([r"C:\Program Files\nodejs\node.exe", "/usr/bin/node", "/usr/local/bin/node"], "node")
    # bash 排除 WSL 存根（System32\bash.exe 无 WSL 时报错）
    bash = _tool([r"C:\Program Files\Git\bin\bash.exe", r"C:\Program Files (x86)\Git\bin\bash.exe",
                  "/bin/bash", "/usr/bin/bash", "/usr/local/bin/bash"], "bash",
                 exclude=r"C:\Windows\System32")

    # 收集文件（跳过不可读），js/sh/ps1 延后批量执行
    js_files, sh_files, ps_files, cmd_files = [], [], [], []

    for dp, dns, fns in os.walk(ROOT):
        if any(s in dp for s in skip_parts) or is_external_path(dp):
            continue
        for fn in fns:
            fp = os.path.join(dp, fn)
            ext = fn.rsplit(".", 1)[-1].lower() if "." in fn else ""
            try:
                src = io.open(fp, encoding="utf-8", errors="replace").read()
            except Exception:
                continue
            if ext == "py":
                try:
                    compile(src, fp, "exec")
                    py_ok += 1
                except SyntaxError as e:
                    py_bad += 1
                    err(f"  脚本语法错误：{os.path.relpath(fp, ROOT)}（L{e.lineno}: {e.msg}）")
            elif ext == "js":
                js_files.append(fp)
            elif ext == "ps1":
                ps_files.append(fp)
            elif ext in ("cmd", "bat"):
                if src.count("(") == src.count(")"):
                    cmd_ok += 1
                else:
                    cmd_bad += 1
                    err(f"  CMD 括号不配对：{os.path.relpath(fp, ROOT)}")
            elif ext == "sh":
                sh_files.append(fp)

    # ---- js 批量：node 单进程 vm.Script 编译（一次 spawn，全部文件）----
    if js_files:
        if node:
            js_script = (
                "const fs=require('fs');const vm=require('vm');"
                "const files=JSON.parse(fs.readFileSync(0,'utf-8'));let bad=[];"
                "for(const fp of files){try{new vm.Script(fs.readFileSync(fp,'utf-8'),{filename:fp});}"
                "catch(e){bad.push({f:fp,m:e.message.split('\\n')[0]});}}"
                "console.log(JSON.stringify({t:files.length,b:bad}));"
                "process.exit(bad.length?1:0);"
            )
            try:
                r = subprocess.run([node, "-e", js_script], input=_json.dumps([os.path.abspath(f) for f in js_files]),
                                   capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120)
                out = r.stdout.strip()
                res = _json.loads(out) if out else {"t": len(js_files), "b": []}
                js_ok = res["t"] - len(res["b"])
                js_bad = len(res["b"])
                for b in res["b"]:
                    err(f"  JS 语法错误：{os.path.relpath(b['f'], ROOT)}（{b['m'][:100]}）")
            except Exception as e:
                warn(f"  node 批量检查失败（{e}），js 语法检查跳过")
        else:
            warn("  node 不可用，js 语法检查跳过")
    else:
        js_ok = js_bad = 0

    # ---- sh/ps1 并行：ThreadPool 逐文件 spawn ----
    def _check_sh(fp):
        r = subprocess.run([bash, "-n", fp], capture_output=True, text=True, encoding="utf-8", errors="replace")
        return r.returncode, fp, (r.stderr or r.stdout).strip()[:100]

    def _check_ps(fp):
        cmd = ["powershell", "-NoProfile", "-Command",
               "[void][System.Management.Automation.Language.Parser]::ParseFile('" +
               fp.replace("'", "''") + "',[ref]$null,[ref]$e); if($e.Count){$e|%%{$_};exit 1}else{exit 0}"]
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
        return r.returncode, fp, ""

    workers = 16
    if sh_files and bash:
        try:
            with ThreadPoolExecutor(max_workers=workers) as ex:
                for rc, fp, msg in ex.map(_check_sh, sh_files):
                    if rc == 0:
                        sh_ok += 1
                    else:
                        sh_bad += 1
                        err(f"  Shell 语法错误：{os.path.relpath(fp, ROOT)}（{msg}）")
        except Exception as e:
            warn(f"  sh 并行检查失败（{e}），sh 语法检查跳过")
    elif sh_files:
        warn("  bash 不可用，sh 语法检查跳过")

    if ps_files:
        try:
            with ThreadPoolExecutor(max_workers=workers) as ex:
                for rc, fp, _ in ex.map(_check_ps, ps_files):
                    if rc == 0:
                        ps_ok += 1
                    else:
                        ps_bad += 1
                        err(f"  PowerShell 语法错误：{os.path.relpath(fp, ROOT)}")
        except Exception as e:
            warn(f"  ps1 并行检查失败（{e}），ps1 语法检查跳过")

    summary = f"py {py_ok}/{py_ok + py_bad}"
    if node:
        summary += f" | js {js_ok}/{js_ok + js_bad}"
    else:
        warn("  node 不可用，js 语法检查跳过")
    summary += f" | ps1 {ps_ok}/{ps_ok + ps_bad}"
    if bash:
        summary += f" | sh {sh_ok}/{sh_ok + sh_bad}"
    else:
        warn("  bash 不可用，sh 语法检查跳过")
    summary += f" | cmd {cmd_ok}/{cmd_ok + cmd_bad}"
    print(f"  ✓ 脚本语法健康：{summary}")


def check_712(_reg=None):
    """7.12 结构化文件解析健康（第4组轮42固化）：json/yaml/xml 全量解析校验。
    json.loads / yaml.safe_load / ElementTree.parse 确定性校验（外部依赖仅 PyYAML）。
    豁免（历史/展示文档例外）：
      docs/plan/*.json —— 历史 AutoPlan 生成物（存档区，progress logs 仅引用存在性）
    排除：外部版本目录（顶层目录名以 op-skills-pack- 开头）不参与扫描，见 is_external_path()。"""
    print("  7.12 结构化文件解析健康（第4组固化）...")
    import glob
    import json as _json
    import yaml as _yaml

    skip_parts = ("_exp", os.sep + "docs" + os.sep + "archive", os.sep + ".git",
                  os.sep + ".claude", os.sep + ".basic",
                  os.sep + "node_modules", os.sep + "__pycache__")
    # 豁免规则：路径子串匹配
    exempt_substr = (os.path.join("docs", "plan") + os.sep,)

    def _exempt(fp):
        rel = os.path.normpath(os.path.relpath(fp, ROOT)).replace("\\", "/")
        return any(s.replace("\\", "/") in rel for s in exempt_substr)

    n_json = n_yaml = n_xml = 0
    n_bad = 0

    def _fail(rel, why):
        nonlocal n_bad
        n_bad += 1
        err(f"  结构化解析失败：{rel}（{why[:90]}）")

    for pat, kind in (("**/*.json", "json"), ("**/*.y*ml", "yaml"), ("**/*.xml", "xml")):
        for fp in glob.glob(os.path.join(ROOT, pat), recursive=True):
            if any(s in fp for s in skip_parts) or is_external_path(fp):
                continue
            if _exempt(fp):
                continue
            try:
                src = io.open(fp, encoding="utf-8", errors="strict").read()
            except Exception as e:
                _fail(os.path.relpath(fp, ROOT), f"非 UTF-8 读取失败：{e}")
                continue
            try:
                if kind == "json":
                    _json.loads(src)
                    n_json += 1
                elif kind == "yaml":
                    _yaml.safe_load(src)
                    n_yaml += 1
                else:
                    import xml.etree.ElementTree as ET2
                    ET2.fromstring(src)
                    n_xml += 1
            except Exception as e:
                _fail(os.path.relpath(fp, ROOT), str(e))

    print(f"  ✓ 结构化解析健康：json {n_json} | yaml {n_yaml} | xml {n_xml}（豁免 {len(exempt_substr)} 类例外）")


# ---------------- 主流程 ----------------
def check_715(_reg=None):
    """7.15 网络传输卫生（第5组轮59固化）：脚本中非本机明文 http:// 端点必须为零。
    豁免：127.0.0.1/localhost/[::1] 本机服务、XML 命名空间标识符（schemas./www.w3.org/www.omg.org）、
    注释/文档示例（行首 # 或含 example/示例）。证书校验绕过（verify=False）同样阻塞。"""
    print("  7.15 网络传输卫生（第5组固化）...")
    import glob as _glob
    import re as _re

    skip_parts = ("_exp/", "/docs/", "/.git/", "/.claude/", "/.basic/",
                  "/node_modules/", "/__pycache__/", "/tests/")
    exts = (".py", ".js", ".ts", ".sh", ".ps1", ".cmd")
    http_re = _re.compile(r'https?://([^\s"\'\\]+)')
    local_ok = ("127.0.0.1", "localhost", "[::1]", "0.0.0.0")
    ns_ok = ("schemas.", "www.w3.org", "www.omg.org", "purl.org",
             "xml.apache.org", "openoffice.org")

    n_hits = 0
    # 仅扫描 git 跟踪文件（未跟踪的探针/临时文件由 7.10/gitignore 防线处理）
    tracked_files = git_ls_files()
    for rel_fp in tracked_files:
        if not rel_fp.endswith(exts):
            continue
        if any(s in rel_fp for s in skip_parts):
            continue
        fp = os.path.join(ROOT, rel_fp)
        if not os.path.isfile(fp):
            continue
        if os.path.basename(fp) == "op-000-content-check.py":
            continue  # 检查器自身（docstring/正则含关键字，豁免）
        try:
            src = io.open(fp, encoding="utf-8", errors="replace").read()
        except Exception:
            continue
        for i, l in enumerate(src.splitlines(), 1):
            s = l.strip()
            if not s or s.startswith(("#", "//", "rem ", "REM ")):
                continue
            for m in http_re.finditer(l):
                url = m.group(0)
                host = m.group(1).split("/")[0].split(":")[0].strip("[]").lower()
                if not host or host.startswith(("$", "{", "%")) or host in local_ok or any(
                        n in host for n in ns_ok):
                    continue
                if url.startswith("http://"):
                    if any(k in l for k in ("example", "示例", "例如", "placeholder")):
                        continue
                    err(f"  明文 http 端点：{os.path.relpath(fp, ROOT)}:{i} {url[:80]}")
                    n_hits += 1
            if _re.search(r"verify\s*=\s*False|_create_unverified_context|CERT_NONE", l):
                err(f"  证书校验绕过：{os.path.relpath(fp, ROOT)}:{i} {s[:80]}")
                n_hits += 1
    if not n_hits:
        ok("  脚本零明文外传 http、零证书校验绕过")


def check_716(_reg=None):
    """7.16 体积与规模健康（第6组轮71固化）：git 跟踪超大文件与打包产物防线。
    - 被跟踪文件 >=5MB：阻塞（❌，仓库膨胀风险）
    - 被跟踪文件 >=2MB：警告（⚠️，观察）
    - 被跟踪打包产物 zip：警告（构建产物可再生成，建议解除跟踪）
    豁免：docs/archive/package/*.zip（历史归档完整性，v10 污染包标记勿用）。
    git 不可用时跳过。"""
    print("  7.16 体积与规模健康（第6组固化）...")
    import os as _os
    tracked = git_ls_files()
    if not tracked:
        warn("  git 不可用（非仓库目录），7.16 跳过")
        return
    big_blocks = []
    big_warns = []
    zip_warns = []
    for rel_fp in tracked:
        fp = _os.path.join(ROOT, rel_fp)
        try:
            sz = _os.path.getsize(fp)
        except OSError:
            continue
        if sz >= 5 * 1048576:
            big_blocks.append((sz, rel_fp))
        elif sz >= 2 * 1048576:
            big_warns.append((sz, rel_fp))
        if rel_fp.lower().endswith(".zip") and "docs/archive/package/" not in rel_fp:
            zip_warns.append((sz, rel_fp))
    for sz, f in big_blocks:
        err(f"  超大跟踪文件（%.1f MB）：%s（应解除跟踪或移出 git，仓库膨胀风险）" % (sz / 1048576, f))
    for sz, f in big_warns:
        warn(f"  大跟踪文件（%.1f MB）：%s" % (sz / 1048576, f))
    for sz, f in zip_warns:
        warn(f"  打包产物被跟踪（%.1f MB）：%s（可再生成，建议 git rm --cached）" % (sz / 1048576, f))
    if not (big_blocks or big_warns or zip_warns):
        ok("  无超大/大跟踪文件、无打包产物入库")



def check_717(_reg=None):
    """7.17 可维护性健康（第7组轮83固化）：
    - frontmatter version 与 registry version 不一致：阻塞（❌，版本漂移，改 SKILL 忘改 registry 或反之）
    - 活跃文档（非 archive）markdown 相对链接断裂：警告（⚠️，文档引用失效，误导开发者）
    豁免：docs/archive/（历史冻结区，断裂记录不修）。"""
    print("  7.17 可维护性健康（第7组固化）...")
    import re as _re
    n_err = n_warn = 0
    # 1. 版本一致性：顶层 SKILL.md frontmatter version vs registry 同名条目
    reg_path = os.path.join(ROOT, "op-000", "registry.yaml")
    reg_versions = {}
    if os.path.isfile(reg_path):
        try:
            reg = load_yaml(reg_path)
            for s_ in reg.get("skills", []):
                reg_versions[str(s_.get("name", ""))] = str(s_.get("version", ""))
        except Exception as e:
            warn("  registry.yaml 解析失败（%s），版本一致性跳过" % e)
    for d in sorted(os.listdir(ROOT)):
        smd = os.path.join(ROOT, d, "SKILL.md")
        if not (os.path.isdir(os.path.join(ROOT, d)) and os.path.isfile(smd)):
            continue
        src = io.open(smd, encoding="utf-8", errors="replace").read()
        m = _re.search(r'^version:\s*["\']?([\w.]+)["\']?', src, re.M)
        fm = m.group(1) if m else None
        rg = reg_versions.get(d)
        if rg is not None and fm != rg:
            err("  版本不一致：%s frontmatter=%s registry=%s" % (d, fm, rg))
            n_err += 1
    # 2. 活跃文档 markdown 相对链接完整性（跳过 archive 冻结区）
    docs_root = os.path.join(ROOT, "docs")
    if os.path.isdir(docs_root):
        for dirpath, dirs, files in os.walk(docs_root):
            dirs[:] = [x for x in dirs if x not in ("archive", ".git", "node_modules")]
            if os.sep + "archive" in dirpath:
                continue
            for fn in files:
                if not fn.endswith(".md"):
                    continue
                fp = os.path.join(dirpath, fn)
                try:
                    src = io.open(fp, encoding="utf-8", errors="replace").read()
                except Exception:
                    continue
                for m in _re.finditer(r"\[[^\]]*\]\(([^)]+)\)", src):
                    t = m.group(1).strip()
                    if t.startswith(("http://", "https://", "#", "mailto:")) or "${" in t or "<" in t:
                        continue
                    tp = t.split("#", 1)[0].split("?", 1)[0]
                    if not tp:
                        continue
                    full = os.path.normpath(os.path.join(dirpath, tp))
                    if not os.path.exists(full):
                        warn("  活跃文档断裂链接：%s -> %s" % (os.path.relpath(fp, ROOT), t))
                        n_warn += 1
    if not n_err and not n_warn:
        ok("  版本一致、活跃文档链接完整")



def check_718(_reg=None):
    """7.18 健壮性健康（第8组轮95固化）：
    - 裸 open()（非 with 且文件无 close 配对）：警告（⚠️，句柄泄露风险）
    - errors=ignore 解码：警告（⚠️，静默丢弃字符）
    豁免：文件内有 .close() 调用（显式资源管理，如 task_store 锁句柄）。"""
    print("  7.18 健壮性健康（第8组固化）...")
    import ast as _ast
    n_warn = 0
    for dirpath, dirs, files in os.walk(ROOT):
        dirs[:] = [x for x in dirs
                   if x not in ("_exp", ".git", ".claude", ".basic", "node_modules",
                                "__pycache__", "tests", "tmp", "docs", "archive")
                   and not x.startswith(EXTERNAL_DIR_PREFIX)]
        if os.sep + "docs" in dirpath or os.sep + "archive" in dirpath:
            continue
        for fn in files:
            if not fn.endswith(".py"):
                continue
            fp = os.path.join(dirpath, fn)
            # 跳过检查器自身（7.18 检测模式字符串会匹配本文件）
            if os.path.abspath(fp) == os.path.abspath(__file__):
                continue
            try:
                src = io.open(fp, encoding="utf-8", errors="replace").read()
                tree = _ast.parse(src)
            except Exception:
                continue
            with_opens = set()
            has_close = ".close()" in src
            for node in _ast.walk(tree):
                if isinstance(node, _ast.With):
                    for item in node.items:
                        e = item.context_expr
                        if isinstance(e, _ast.Call) and getattr(e.func, "id", "") == "open":
                            with_opens.add(e.lineno)
                if isinstance(node, _ast.Call):
                    f = node.func
                    if isinstance(f, _ast.Attribute) and f.attr == "close":
                        has_close = True
            for node in _ast.walk(tree):
                if isinstance(node, _ast.Call) and getattr(node.func, "id", "") == "open":
                    if node.lineno not in with_opens and not has_close:
                        warn("  裸 open（非 with 且无 close）：%s:%d"
                             % (os.path.relpath(fp, ROOT), node.lineno))
                        n_warn += 1
            if 'errors="ignore"' in src or "errors='ignore'" in src:
                warn("  errors=ignore 解码（静默丢弃）：%s" % os.path.relpath(fp, ROOT))
                n_warn += 1
    if not n_warn:
        ok("  无裸 open 泄露、零 errors=ignore")


def check_719(_reg=None):
    """7.19 生态集成健康（第9组轮106固化）：
    - 生态集成基线文档完整性：docs/system/02-历史报告/ 下 op-体系生态集成基线-*.md
      须存在且章节数 >= 9（第9组轮97起每轮一章，治理产物退化即阻塞 ❌）
    - 退出码约定漂移：.py 中 exit/sys.exit 数字字面量超出 {0,1,2,3} 约定
      （0 成功/1 失败/2 告警或依赖缺失/3 特定错误类别）→ 警告 ⚠️
    - 跨 skill 依赖完整性：SKILL.md frontmatter dependencies 的 skill 引用
      必须存在于 registry 或仓库目录（依赖断裂会误导调度 → 阻塞 ❌）
    豁免：docs/archive/（历史冻结区不扫描）。"""
    print("  7.19 生态集成健康（第9组固化）...")
    import glob as _glob
    n_err = n_warn = 0
    # 1. 生态集成基线文档完整性（docs/ 目录不存在视为未初始化仓库，跳过不阻塞）
    base_dir = os.path.join(ROOT, "docs", "system", "02-历史报告")
    if not os.path.isdir(base_dir):
        warn("  docs/system/02-历史报告 目录不存在（未初始化/空仓库），7.19a 跳过")
    else:
        bl_files = _glob.glob(os.path.join(base_dir, "op-体系生态集成基线-*.md"))
        if not bl_files:
            err("  生态集成基线文档缺失（docs/system/02-历史报告/op-体系生态集成基线-*.md）")
            n_err += 1
        else:
            latest = max(bl_files, key=os.path.getmtime)
            src = io.open(latest, encoding="utf-8", errors="replace").read()
            chaps = len(re.findall(r"^## ", src, re.M))
            if chaps < 9:
                err("  生态集成基线文档章节不足：%s 仅 %d 章（应 >= 9）"
                    % (os.path.basename(latest), chaps))
                n_err += 1
            else:
                ok("  生态集成基线文档完整（%s，%d 章）" % (os.path.basename(latest), chaps))
    # 2. 退出码约定漂移
    for dirpath, dirs, files in os.walk(ROOT):
        dirs[:] = [x for x in dirs
                   if x not in ("_exp", ".git", ".claude", ".basic", "node_modules",
                                "__pycache__", "tests", "tmp", "docs", "archive")
                   and not x.startswith(EXTERNAL_DIR_PREFIX)]
        if os.sep + "docs" in dirpath or os.sep + "archive" in dirpath:
            continue
        for fn in files:
            if not fn.endswith(".py"):
                continue
            fp = os.path.join(dirpath, fn)
            if os.path.abspath(fp) == os.path.abspath(__file__):
                continue
            try:
                src = io.open(fp, encoding="utf-8", errors="replace").read()
            except Exception:
                continue
            for m in re.finditer(r"(?:sys\.exit|exit)\((\d+)\)", src):
                code = int(m.group(1))
                if code > 3:
                    warn("  退出码超出约定 {0,1,2,3}：%s:%d -> exit(%d)"
                         % (os.path.relpath(fp, ROOT), src[:m.start()].count("\n") + 1, code))
                    n_warn += 1
    if not n_warn:
        ok("  退出码字面量全部在约定 {0,1,2,3} 内")
    # 3. 跨 skill 依赖完整性（frontmatter dependencies 的 skill 引用）
    exist_dirs = set(os.listdir(ROOT))
    reg_deps = set()
    for s_ in (_reg or {}).get("skills", []):
        reg_deps.add(str(s_.get("name", "")))
    dep_bad = []
    for d in sorted(os.listdir(ROOT)):
        smd = os.path.join(ROOT, d, "SKILL.md")
        if not (os.path.isdir(os.path.join(ROOT, d)) and os.path.isfile(smd)):
            continue
        try:
            src = io.open(smd, encoding="utf-8", errors="replace").read()
        except Exception:
            continue
        # 仅 frontmatter（首个 --- 到下一个 ---）内的 dependencies 块
        fm = src.split("---", 2)
        if len(fm) < 3:
            continue
        fm_body = fm[1]
        for m in re.finditer(r"skill:\s*['\"]?([A-Za-z0-9_-]+)['\"]?", fm_body):
            ref = m.group(1)
            if ref not in exist_dirs and ref not in reg_deps:
                dep_bad.append((d, ref))
    if dep_bad:
        for d, ref in dep_bad:
            err("  跨 skill 依赖断裂：%s frontmatter 依赖不存在 %s" % (d, ref))
            n_err += 1
    else:
        ok("  跨 skill 依赖引用全部存在（frontmatter dependencies 完整）")


def check_720(_reg=None):
    """7.20 执行模式契约（第10组轮111固化）：
    - .op/changes 与 .op/archive 下所有 change.yaml 的 execution_mode 字段
      必须在白名单 {constrained, autonomous} 内；缺省视为 constrained（合法）。
      非法值 → 阻塞 ❌（声明了不存在的执行模式会破坏模式路由）。
    - autonomous 模式变更应已具备人工确认前提：change.yaml 存在
      execution_mode: autonomous 时提示检查 .op/ 评估记录（⚠️ 提示，非阻塞）。"""
    print("  7.20 执行模式契约（第10组固化）...")
    import glob as _glob
    MODE_WHITELIST = {"constrained", "autonomous"}
    n_err = n_warn = 0
    scanned = 0
    for pat in ("change.yaml", "*/change.yaml"):
        for fp in _glob.glob(os.path.join(ROOT, ".op", "changes", pat)):
            scanned += 1
            try:
                cy = load_yaml(fp)
            except Exception as e:
                warn("  change.yaml 解析失败（%s）：%s" % (e, os.path.relpath(fp, ROOT)))
                n_warn += 1
                continue
            if not isinstance(cy, dict):
                continue
            mode = cy.get("execution_mode")
            if mode is None:
                continue
            if mode not in MODE_WHITELIST:
                err("  execution_mode 非法：%s = %s（白名单：%s）"
                    % (os.path.relpath(fp, ROOT), mode, sorted(MODE_WHITELIST)))
                n_err += 1
            elif mode == "autonomous":
                n_warn += 1  # 提示：需配套评估记录与人工确认
    for pat in ("*.yaml",):
        for fp in _glob.glob(os.path.join(ROOT, ".op", "archive", "**", pat), recursive=True):
            if not fp.endswith("change.yaml"):
                continue
            scanned += 1
            try:
                cy = load_yaml(fp)
            except Exception:
                continue
            if not isinstance(cy, dict):
                continue
            mode = cy.get("execution_mode")
            if mode is not None and mode not in MODE_WHITELIST:
                err("  归档 change.yaml execution_mode 非法：%s = %s"
                    % (os.path.relpath(fp, ROOT), mode))
                n_err += 1
    if scanned == 0:
        warn("  无 change.yaml 可查（.op/changes 未初始化），7.20 跳过")
    elif not n_err:
        ok("  execution_mode 全部在 {constrained, autonomous} 内（扫描 %d 个 change.yaml）" % scanned)


def check_721(_reg=None):
    """7.21 自主执行活跃检测（第10组轮113固化）：
    - .op/changes 下存在 execution_mode == autonomous 且 phase 未收尾
      （archive/done 之外）的活跃自主变更 → 提示 ⚠️（不阻塞 content-check，
      自主执行内部验证可用；但提交由 pre-commit 守卫阻断）。
    - 与 op-autonomous-guard.py 逻辑一致，级别降为提示。"""
    print("  7.21 自主执行活跃检测（第10组固化）...")
    import glob as _glob
    n_warn = 0
    for fp in _glob.glob(os.path.join(ROOT, ".op", "changes", "**", "change.yaml"), recursive=True):
        try:
            cy = load_yaml(fp)
        except Exception:
            continue
        if not isinstance(cy, dict):
            continue
        mode = cy.get("execution_mode")
        phase = cy.get("phase")
        if mode == "autonomous" and phase not in ("archive", "done"):
            warn("  活跃自主执行变更：%s（phase=%s）——产物需人工确认并收尾，提交被 pre-commit 守卫阻断"
                 % (os.path.relpath(os.path.dirname(fp), ROOT), phase))
            n_warn += 1
    if not n_warn:
        ok("  无活跃自主执行变更")


def check_714(_reg=None):
    """7.14 敏感文件跟踪防线（第5组轮53固化）：git 跟踪的敏感扩展名/文件名必须为零。
    防护面：密钥/证书（.pem/.key/.p12/.pfx/.jks/.keystore/.htpasswd）、
    私钥（id_rsa/id_ed25519）、凭据（.env 类、*.secret、password/passwd 文件）。
    命中任一即阻塞（防误入库）。"""
    print("  7.14 敏感文件跟踪防线（第5组固化）...")
    tracked = git_ls_files()
    if not tracked:
        warn("  git 不可用（非仓库目录），7.14 跳过")
        return

    import re as _re
    # 敏感模式：扩展名 / 私钥前缀 / 凭据文件名
    sens_re = _re.compile(
        r"\.(pem|key|p12|pfx|jks|keystore|htpasswd|secret|pkcs12)$|"
        r"(^|/)(id_rsa|id_ed25519|id_dsa|id_ecdsa)(\.pub)?$|"
        r"(^|/)(\.env|\.env\.local|\.env\.prod|\.env\.dev)$|"
        r"(^|/)(password|passwd|credentials?|secrets?)(\.|$)",
        _re.IGNORECASE)
    hits = [f for f in tracked if sens_re.search(f)]
    if hits:
        for h in hits:
            err(f"  敏感文件被跟踪：{h}（密钥/凭据类，应立即 git rm --cached 并确认未泄露）")
    else:
        ok("  无敏感文件被 git 跟踪（0 个密钥/凭据命中）")


def check_713(_reg=None):
    """7.13 依赖声明健康（第5组轮50固化）：有第三方 Python 导入的顶层目录必须声明依赖。
    声明来源（任一命中即可）：SKILL.md frontmatter dependencies 字段、SKILL.md 正文 Dependencies/依赖 段、
    目录内 requirements.txt、根级 requirements.txt（非 skill 顶层目录兜底）。
    豁免：docs/（分发说明与历史归档，由根 requirements.txt 注释声明）、.claude、node_modules。
    """
    print("  7.13 依赖声明健康（第5组固化）...")
    import glob as _glob

    # glob 收集（非 git 仓库场景同样生效；排除 _exp/.git/.claude/node_modules/docs/__pycache__）
    skip_parts = ("_exp", os.sep + "docs", os.sep + ".git", os.sep + ".claude", os.sep + ".basic",
                  os.sep + "node_modules", os.sep + "__pycache__")
    pys = []
    for fp in _glob.glob(os.path.join(ROOT, "**", "*.py"), recursive=True):
        if any(s in fp for s in skip_parts) or is_external_path(fp):
            continue
        pys.append(os.path.relpath(fp, ROOT).replace("\\", "/"))

    try:
        stdlib = set(getattr(sys, "stdlib_module_names", ()))
    except Exception:
        stdlib = set()
    # 常见第三方包名 -> requirements 声明名（大小写/别名归一）
    NAME_MAP = {"pil": "Pillow", "yaml": "PyYAML", "docx": "python-docx",
                "jinja2": "jinja2", "defusedxml": "defusedxml", "lxml": "lxml",
                "httpx": "httpx", "playwright": "playwright"}

    # 按顶层目录分组
    groups = {}
    for p in pys:
        top = p.split("/", 1)[0]
        groups.setdefault(top, []).append(p)

    root_txt = ""
    if os.path.isfile(os.path.join(ROOT, "requirements.txt")):
        root_txt = io.open(os.path.join(ROOT, "requirements.txt"), encoding="utf-8").read().lower()

    n_groups = n_ok = 0
    for top in sorted(groups):
        files = groups[top]
        sdir = os.path.join(ROOT, top)
        is_skill = os.path.isfile(os.path.join(sdir, "SKILL.md"))

        # 收集本组 import 的模块名
        imported = set()
        for p in files:
            src = io.open(os.path.join(ROOT, p), encoding="utf-8", errors="replace").read()
            for m in re.finditer(r"^(?:from|import)\s+([a-zA-Z_][a-zA-Z0-9_]*)", src, re.M):
                imported.add(m.group(1).lower())

        # 本地模块：组内存在同名 .py / 包目录
        # 本地模块：组内任一脚本同目录存在同名 .py / 包目录（覆盖子目录包如 office/helpers、tests/test_reconcile）
        dirs = set(os.path.dirname(os.path.join(ROOT, p)) for p in files)
        local = set()
        for mod in imported:
            # 同目录同名文件/包，或模块名 == 某目录 basename（包自引用，如 src/op_browser）
            if any(os.path.isfile(os.path.join(d, mod + ".py")) or os.path.isdir(os.path.join(d, mod))
                   or os.path.basename(d) == mod for d in dirs):
                local.add(mod)
        third = sorted(imported - stdlib - local)
        if not third:
            continue
        n_groups += 1

        # 声明文本：SKILL.md 全文 + 目录 requirements.txt + 根 requirements.txt
        decl = root_txt
        if is_skill:
            smd = os.path.join(sdir, "SKILL.md")
            if os.path.isfile(smd):
                decl += io.open(smd, encoding="utf-8").read().lower()
        local_req = os.path.join(sdir, "requirements.txt")
        if os.path.isfile(local_req):
            decl += io.open(local_req, encoding="utf-8").read().lower()

        missing = [m for m in third if NAME_MAP.get(m, m).lower() not in decl]
        if missing:
            err(f"  依赖声明缺失：{top} 使用第三方模块 {missing}，但 SKILL.md/requirements.txt 未声明")
        else:
            n_ok += 1

    # 追加：根 requirements.txt 非注释包行应有最低版本约束（防已知漏洞版本，轮55）
    if root_txt:
        bad_req = []
        for ln in root_txt.splitlines():
            s = ln.strip()
            if not s or s.startswith("#"):
                continue
            if ">=" not in s and "==" not in s:
                bad_req.append(s)
        if bad_req:
            warn(f"  requirements.txt 缺少版本约束（建议 >=最低版本）：{bad_req}")
        else:
            ok("  requirements.txt 全部包行含最低版本约束")

    print(f"  ✓ 依赖声明健康：{n_ok}/{n_groups} 组（含第三方依赖）已声明；docs/ 由根 requirements.txt 注释声明")


def check_722(_reg=None):
    """7.22 evolved 资产入库边界（本次变更固化，隔离 L2/L3）：
    .basic/evolved（迁移前 .claude/evolved）下不得有任何被 git 跟踪的文件——
    运行资产属本机数据，零跟踪才能保证分发包不泄漏个人资产。
    实现：以 git 仓库根为准查询（content-check 可能以 skills/ 为 ROOT 运行）。"""
    print("  7.22 evolved 资产入库边界（隔离 L2/L3）...")
    import subprocess as _sp

    try:
        _r = _sp.run(["git", "rev-parse", "--show-toplevel"], cwd=ROOT,
                     capture_output=True, text=True, encoding="utf-8", errors="replace")
        top = _r.stdout.strip() if _r.returncode == 0 else ""
    except Exception:
        top = ""
    if not top:
        warn("  非 git 仓库（或 git 不可用），跳过 evolved 零跟踪检查")
        return

    hits = []
    for sub in (".basic/evolved", ".claude/evolved"):
        _r = _sp.run(["git", "ls-files", "--", sub], cwd=top,
                     capture_output=True, text=True, encoding="utf-8", errors="replace")
        if _r.returncode == 0 and _r.stdout.strip():
            hits.extend([ln for ln in _r.stdout.splitlines() if ln.strip()])
    if hits:
        err("  evolved 资产被 git 跟踪：%d 个（示例：%s）——应 git rm --cached 解除跟踪并确认 .gitignore 覆盖"
            % (len(hits), hits[0]))
    else:
        ok("  evolved 运行资产零跟踪（隔离 L2/L3 边界成立）")


# ---------------- 主流程 ----------------
def main():
    reg_path = os.path.join(ROOT, "op-000", "registry.yaml")
    reg = None
    reg_names = set()
    if os.path.isfile(reg_path):
        with io.open(reg_path, encoding="utf-8-sig") as f:
            try:
                reg = load_yaml(reg_path)
                reg_names = {str(s.get("name", "")) for s in reg.get("skills", [])}
            except Exception as e:
                warn(f"  registry.yaml 解析失败（{e}），跳过 7.3")
    check_71(reg_names)
    check_72()
    if reg:
        check_73(reg)
        check_76(reg)
        check_78(reg)
        check_79(reg)
        check_710(reg)
    check_74()
    check_75()
    check_77()
    check_711()
    check_712()
    check_713()
    check_714()
    check_715()
    check_716()
    check_717()
    check_718()
    check_719(reg)
    check_720()
    check_721()
    check_722()
    if HAS_ERROR:
        print("检查 7：存在 ❌ 错误（见上）")
        sys.exit(1)
    print("检查 7：内容与引用层检查通过")
    sys.exit(0)


if __name__ == "__main__":
    main()
