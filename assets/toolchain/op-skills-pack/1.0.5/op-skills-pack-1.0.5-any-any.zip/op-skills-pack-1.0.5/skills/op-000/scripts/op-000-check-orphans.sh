#!/usr/bin/env bash
# ==============================================================
# op-000-check-orphans.sh — 检查已构建但未注册的孤立 Skill
#
# 扫描 skills/ 下所有 op-xxx 或 op_xxx 目录与 registry.yaml 对比
# 输出：孤立 Skill 列表（每行一个 name），无输出 = 无孤立
# ==============================================================
set -euo pipefail

SKILLS_DIR="$(cd "$(dirname "$0")/.." && pwd)"
REGISTRY="$SKILLS_DIR/registry.yaml"
PARENT_DIR="$(cd "$SKILLS_DIR/.." && pwd)"

[ -f "$REGISTRY" ] || { echo "❌ registry.yaml 不存在" >&2; exit 1; }

# 提取已注册的 name 列表
declare -A registered
while IFS= read -r line; do
  name=$(echo "$line" | sed 's/  - name: //')
  registered["$name"]=1
done < <(grep '  - name: op-' "$REGISTRY" || true)

found_orphan=false

# 扫描 skills/ 目录
for dir in "$PARENT_DIR"/op-* "$PARENT_DIR"/op_*; do
  [ -d "$dir" ] || continue
  local_name=$(basename "$dir" | sed 's/^op_/op-/')

  # 跳过自身
  [ "$local_name" = "op-000" ] && continue

  # 检查 SKILL.md
  [ -f "$dir/SKILL.md" ] || continue

  # 提取 frontmatter name
  name_in_file=$(sed -n 's/^name:[[:space:]]*//p' "$dir/SKILL.md" | head -1 | tr -d '"')

  # 检查是否在注册表中
  if [ -z "${registered[$name_in_file]:-}" ]; then
    echo "$name_in_file"
    found_orphan=true
  fi
done

if [ "$found_orphan" = false ]; then
  exit 0
fi
