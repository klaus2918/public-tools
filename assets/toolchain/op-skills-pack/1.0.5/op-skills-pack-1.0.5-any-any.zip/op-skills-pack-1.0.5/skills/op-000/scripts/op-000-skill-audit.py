#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""op-000-skill-audit.py — 单 skill 合规审计（op-000-validate.sh 检查 3.7）

对 registry 内每个 skill 汇总四维合规并输出矩阵：
  结构：SKILL.md 存在、行数 ≤300、frontmatter 含 name/description、无 UTF-8 BOM
  注册：registry.yaml 有条目；name / version / tier 与 frontmatter 一致
  隔离：references/assets.yaml 声明（skill 名一致、挂载点存在）；无声明但属带槽位 skill → WARN
  依赖：frontmatter dispatches 指向的 skill 目录存在

用法：
  python op-000-skill-audit.py [仓库根]          # 人类可读矩阵
  python op-000-skill-audit.py [仓库根] --json   # 机器可读
退出码：0=全部通过 / 1=存在违规 / 2=环境不可用
"""
import io
import json
import os
import sys

# Windows 管道兼容：强制 UTF-8 + LF
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", newline="\n")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

try:
    import yaml
except ImportError:  # pragma: no cover
    sys.stderr.write("[FAIL] pyyaml 不可用（请安装 pyyaml）\n")
    sys.exit(2)

LINE_LIMIT = 300
TIERS = ("core", "core-support", "pluggable")

# 带资产槽位的 skill（无 assets.yaml 声明时给 WARN，提示补声明）
MOUNT_SKILLS = {
    "browser-agent-bridge", "op-browser", "op-design-extract", "op-done",
    "op-html", "op-knowledge", "op-demo-k8s", "op-worktree",
}


def read_frontmatter(path):
    """返回 (frontmatter 或 None, 行数, 是否有 BOM)。"""
    with open(path, "rb") as fh:
        raw = fh.read()
    has_bom = raw.startswith(b"\xef\xbb\xbf")
    text = raw.decode("utf-8-sig", errors="replace")
    lines = text.splitlines()
    fm = None
    if lines and lines[0].strip() == "---":
        for i in range(1, len(lines)):
            if lines[i].strip() == "---":
                try:
                    fm = yaml.safe_load("\n".join(lines[1:i])) or {}
                except Exception:  # noqa: BLE001
                    fm = None
                break
    return fm, len(lines), has_bom


def load_yaml(path):
    try:
        with io.open(path, encoding="utf-8") as fh:
            return yaml.safe_load(fh)
    except Exception:  # noqa: BLE001
        return None


def audit_skill(root, name, reg_entry):
    """返回 (结构, 注册, 隔离, 依赖, 备注列表)。每维取值 ok/warn/fail/na。"""
    sdir = os.path.join(root, "skills", name)
    notes = []

    # ── 结构 ──
    skill_md = os.path.join(sdir, "SKILL.md")
    fm, nlines, has_bom = read_frontmatter(skill_md)
    struct = "ok"
    if fm is None:
        struct = "fail"
        notes.append("frontmatter 缺失或不可解析")
    else:
        if not fm.get("name") or not fm.get("description"):
            struct = "fail"
            notes.append("frontmatter 缺 name/description")
        if nlines > LINE_LIMIT:
            struct = "fail"
            notes.append("SKILL.md 行数 %d > %d" % (nlines, LINE_LIMIT))
        if has_bom:
            struct = "fail"
            notes.append("SKILL.md 含 UTF-8 BOM")

    # ── 注册 ──
    reg = "ok"
    if not reg_entry:
        reg = "fail"
        notes.append("registry.yaml 无条目")
    else:
        if reg_entry.get("name") != name:
            reg = "fail"
            notes.append("registry.name 与目录名不一致")
        if fm and fm.get("version") and reg_entry.get("version") != fm.get("version"):
            reg = "fail"
            notes.append("registry.version %s != frontmatter.version %s"
                         % (reg_entry.get("version"), fm.get("version")))
        tier = reg_entry.get("tier")
        if tier is None:
            reg = "fail"
            notes.append("registry 缺 tier 字段")
        elif tier not in TIERS:
            reg = "fail"
            notes.append("registry.tier=%s 非白名单" % tier)

    # ── 隔离 ──
    isolation = "na"
    decl_path = os.path.join(sdir, "references", "assets.yaml")
    if os.path.isfile(decl_path):
        decl = load_yaml(decl_path) or {}
        if decl.get("skill") != name:
            isolation = "fail"
            notes.append("assets.yaml 的 skill 字段与目录名不一致")
        else:
            isolation = "ok"
            for m in (decl.get("mounts") or []):
                p = (m or {}).get("path")
                if not p:
                    isolation = "fail"
                    notes.append("assets.yaml 存在缺 path 的条目")
                    continue
                if not os.path.exists(os.path.join(sdir, p)):
                    isolation = "warn"
                    notes.append("挂载点未创建：%s（可 mount-sync 创建）" % p)
    elif name in MOUNT_SKILLS:
        isolation = "warn"
        notes.append("该 skill 有资产槽位但缺 references/assets.yaml 声明")

    # ── 依赖 ──
    deps = "na"
    if fm:
        targets = fm.get("dispatches") or []
        if isinstance(targets, list) and targets:
            deps = "ok"
            for t in targets:
                if not os.path.isdir(os.path.join(root, "skills", str(t))):
                    deps = "fail"
                    notes.append("dispatches 目标不存在：%s" % t)

    return struct, reg, isolation, deps, notes


def main():
    argv = sys.argv[1:]
    as_json = "--json" in argv
    args = [a for a in argv if not a.startswith("--")]
    default_root = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", ".."))
    root = args[0] if args else default_root

    skills_dir = os.path.join(root, "skills")
    registry_path = os.path.join(skills_dir, "op-000", "registry.yaml")
    if not os.path.isdir(skills_dir):
        sys.stderr.write("环境不可用：%s 不存在\n" % skills_dir)
        return 2
    registry = load_yaml(registry_path) or {}
    reg_map = {}
    for e in (registry.get("skills") or []):
        if isinstance(e, dict) and e.get("name"):
            reg_map[e["name"]] = e
    if not reg_map:
        sys.stderr.write("环境不可用：registry.yaml 未解析出条目（%s）\n" % registry_path)
        return 2

    names = sorted(reg_map.keys())
    rows = []
    counts = {"ok": 0, "warn": 0, "fail": 0}

    for name in names:
        if not os.path.isdir(os.path.join(skills_dir, name)):
            rows.append({"skill": name, "structure": "fail", "registry": "ok",
                         "isolation": "na", "deps": "na", "notes": ["skill 目录不存在"]})
            counts["fail"] += 1
            continue
        struct, reg, isolation, deps, notes = audit_skill(root, name, reg_map.get(name))
        levels = [struct, reg, isolation, deps]
        verdict = "fail" if "fail" in levels else ("warn" if "warn" in levels else "ok")
        counts[verdict] += 1
        rows.append({"skill": name, "structure": struct, "registry": reg,
                     "isolation": isolation, "deps": deps, "notes": notes})

    if as_json:
        print(json.dumps({"root": root, "skills": rows, "counts": counts}, ensure_ascii=False, indent=2))
        return 1 if counts["fail"] else 0

    print("== 单 skill 合规审计（仓库根：%s） ==" % root)
    print("skill | 结构 | 注册 | 隔离 | 依赖")
    print("------|------|------|------|------")
    for r in rows:
        print("%s | %s | %s | %s | %s" % (r["skill"], r["structure"], r["registry"], r["isolation"], r["deps"]))
    flagged = [r for r in rows if r["notes"]]
    if flagged:
        print("\n备注：")
        for r in flagged:
            for n in r["notes"]:
                print("  - [%s] %s" % (r["skill"], n))
    print("\n汇总：skill %d ｜ 通过 %d / 告警 %d / 违规 %d"
          % (len(rows), counts["ok"], counts["warn"], counts["fail"]))
    return 1 if counts["fail"] else 0


if __name__ == "__main__":
    sys.exit(main())
