# tasks.md 完整字段定义

> 来源：op-plan v4.0.0 设计文档

---

## YAML Frontmatter 格式

```yaml
---
tasks:
  - id: 1
    title: "任务标题"
    status: pending
    priority: high
    depends: []
    verify: "auto|manual|skip"
    end: ["pc|app|backend"]
    design_tags: []
    design_contract: ""
    usage_step: []
---
```

---

## 字段定义

| 字段 | 类型 | 取值范围 | 必填 | 说明 |
|------|------|----------|------|------|
| `id` | int | 正整数 | 是 | 任务唯一标识 |
| `title` | string | — | 是 | 任务标题 |
| `status` | enum | `pending` \| `in_progress` \| `done` \| `skipped` | 是 | 任务状态 |
| `priority` | enum | `high` \| `medium` \| `low` | 否 | 优先级 |
| `depends` | int[] | task ID 列表；`[]` = 根任务 | 否 | 依赖关系，非空时走 DAG |
| `verify` | enum | `auto` \| `manual` \| `skip` | 是 | 验证方式 |
| `verify-browser` | enum | `optional` \| `required` \| (omitted) | 否 | 浏览器验证需求 |
| `verify-e2e` | enum | `demo` \| (omitted) | 否 | 业务 E2E 路由 |
| `end` | string[] | `["pc", "app", "backend", "verify", ...]` | 否 | 跨端标记 |
| `design-contract` | string | `<project-slug>` | 否 | 设计契约引用 |
| `design-tags` | string[] | 标签列表 | 否 | 设计资产标签 |
| `usage-step` | int[] | 使用过程步骤编号 | 否 | 引用 plan.md「使用故事」 |

---

## verify-browser 触发条件

plan 阶段判定，命中任一信号即标 `required`；否则标 `optional` 或省略：

| 信号 | 示例 |
|------|------|
| 核心交易路径 | 支付/下单/审批流转等主链路 |
| 高风险变更 | 数据迁移、批量更新、权限模型变更 |
| 有外部依赖的端到端场景 | 跨系统对接、第三方 API/SDK 集成 |
| 登录态敏感操作 | 登录/登出、会话管理、权限校验页面 |

---

## DAG 依赖规则

| depends value | Meaning |
|---------------|---------|
| `[]` or omitted | Root task — execute immediately |
| `[1, 2]` | Wait until tasks #1 and #2 complete |
| Cycle detected (A→B→C→A) | Reject — cycle must be resolved in plan |

---

## 示例

```yaml
---
tasks:
  - id: 1
    title: "实现用户登录接口"
    status: pending
    priority: high
    type: backend
    verify: auto
    end: ["backend"]
    depends: []

  - id: 2
    title: "实现登录页面UI"
    status: pending
    priority: high
    type: frontend
    verify: auto
    verify-browser: required
    end: ["pc"]
    usage-step: [1]
    depends: []

  - id: 3
    title: "联调登录接口+页面"
    status: pending
    priority: medium
    type: test
    verify: auto
    verify-browser: optional
    depends: [1, 2]
---
```
