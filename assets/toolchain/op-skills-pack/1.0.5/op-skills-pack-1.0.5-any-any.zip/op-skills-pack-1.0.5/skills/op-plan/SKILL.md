---
name: op-plan
category: core
status: active
phase_role: plan
description: 将模糊需求转化为可执行方案和任务清单。按类型决定产出粒度，G1-G4 内嵌为核心步骤。
version: "4.6.0"
updated_at: 2026-09-14
dispatches:
  - op-design-extract
  - op-html
---

# op-plan — 方案阶段 Skill

## Overview

将模糊想法转化为可执行的方案和任务，产物写入 `.op/changes/<name>/`。不写实现代码。

---

## Quick Reference

| Command | Action |
|---------|--------|
| `/op-plan [<change>]` | 启动或恢复方案流程 |
| `/op-plan status [<change>]` | 查看方案进度 |

---

## Core Flow

### 1. 类型分层产出

| Type | 产出 | 说明 |
|------|------|------|
| hotfix | 无文档 | 直改 |
| tweak | 一句话方案 | 简单记录 |
| feature | plan.md + tasks.md | 方案 + 任务 |
| complex | + brainstorm-summary.md | 深度方案探索（内部分支） |

### 1.1b 专家组（复杂变更前置门禁）

触发条件（任一命中即组建专家组，产出 `.op/changes/<name>/expert-review.md`，模板见 `references/expert-review-template.md`）：

- `type=complex` 或 `epic`
- `execution_mode: autonomous`
- 跨 skill 依赖面（改动涉及 ≥2 个 skill 的契约）
- 边界模糊 / 多解（存在 ≥2 条合理路线）

**门禁**：`autonomous` + `complex` 组合为前置门禁——未产出 `expert-review.md` 不得进入 §8 方案确认。
评估内容：风险 / 一致性 / 边界 / 假设 / 结论五段，交付前按模板复核清单逐项确认。

### 1.2 执行模式声明（change.yaml 契约）

`change.yaml` 应声明 `execution_mode`（白名单 `constrained` / `autonomous`；缺省视为 `constrained`）：

| 模式 | 行为契约 |
|------|---------|
| `constrained`（默认） | 现有强制阻断流程；关键步骤等用户确认 |
| `autonomous` | 无确认开发闭环，但**硬禁 Git 写操作**；交付前逐项自检 `references/autonomous-delivery-checklist.md` |

校验：`content-check 7.20`（非法值阻塞）/ `7.21`（活跃自主执行提示）。

### 2. 按需调用（可选）

| 支撑 skill | 调用时机 | 说明 |
|-----------|---------|------|
| op-design-extract | 有 UI/DB/架构设计时 | assess 查询设计资产 |
| op-knowledge | 非 hotfix 时 | search 检索已有知识 |
| op-html | 方案确认时 | 生成确认材料（默认 MD） |

### 3. G1 需求追问（feature/complex）

设计树追问，边界澄清：
- 追问需求完整性
- 澄清边界和约束
- 识别隐含需求

**强制清单（6 问，缺一不得进入 §5 G3）**：

| # | 问题 | 落点（plan.md） |
|:-:|------|----------------|
| 1 | 目标与成功标准（可观测） | 方案概述 |
| 2 | 边界与「不做项」 | 关键决策 |
| 3 | 反例 / 失败场景 | 关键决策 |
| 4 | 验收口径（谁验、怎么验） | 验收标准 |
| 5 | 影响面（模块 / 契约 / 数据） | 关键决策 |
| 6 | 回滚方式 | 风险与回滚 |

- 本轮无法取得答复的项：**在「阻塞项」显式登记并标注「未答」**，不得默认取值后继续；
- 与 §1.1b 专家组的分工：**专家组建言**（跨模块风险）、**本清单取证**（需求本身），两者皆为前置门禁、不合并；
- 清单细则与填写示例 → [references/alignment-checklist.md](references/alignment-checklist.md)

### 4. G2 域语言约束

识别术语，统一，写入 plan.md 术语表：
- 识别业务术语
- 统一同义词
- 写入 plan.md「术语表」章节

### 5. G3 验证策略追问

确定验证方式和标准：
- 反问提供 3 档选项：接口冒烟 | 浏览器自动化（经 op-browser，物料落 evolved） | 人工验证
- 选择结果写入 plan.md「验证策略」章节
- 至少一条任务的 verify 字段落地；选浏览器自动化档时同步声明 `browser_verification` 与 `browser_screenshot_read`

### 6. 出方案

**plan.md 约定章节**：

```markdown
# 方案：<标题>

## 使用故事
## 方案概述
## 关键决策
## 阻塞项
## 术语表（G2）
## 验证策略（G3）
## 方案自检（G4）
```

**tasks.md 格式**：

```yaml
---
tasks:
  - id: 1
    title: "任务标题"
    status: pending
    priority: high
    depends: []
    verify: "auto|manual|skip"
    end: ["pc|app|backend"]
    design_tags: []
    design_contract: ""
    usage_step: []
---
```

> 完整字段定义见 references/tasks-format.md

**tasks.md 生成后强制校验（6 项，任一不通过则回改）**：

| # | 校验项 | 通过标准 |
|---|--------|---------|
| 1 | 格式 | 统一 YAML frontmatter（废弃 Markdown checkbox）；字段名与 `tasks-format.md` 一致 |
| 2 | id 递增 | id 为正整数、严格递增、无重复 |
| 3 | depends 无环 | 依赖图为 DAG：无自依赖、无环 |
| 4 | verify 必填 | 每个 task 均含 `verify`（auto/manual/skip） |
| 5 | 与 plan 一致 | 任务集合覆盖 plan.md 全部交付项，且无超范围任务 |
| 6 | 规模 | feature ≤ 10 项；complex ≤ 20 项；超出则拆分或简化 |

### 7. G4 方案自检（pause 前自动执行）

Agent 自动执行清单检查，结果写入 plan.md「方案自检」章节：

1. **假设清单**：方案中是否包含未被显式声明的假设？
2. **遗漏场景**：是否存在未提及但有合理性的边界情况？
3. **前后矛盾**：方案内部是否有自相矛盾的表述？
4. **术语一致性**：方案中是否使用了不同的词描述同一概念？
5. **外部依赖**：方案是否依赖于未确认的外部系统/接口？
6. **回退路径**：如果方案失败，是否有回退策略？

**不阻塞 pause**：自检结果写入方案供人审阅时参考。

### 8. 方案确认暂停（Mandatory Pause）

1. **先问查看方式**（至少给出以下选项，用户可指定任意方式）：
   1. 打开文件（plan.md / tasks.md 直接打开 / 打开目录）
   2. 摘要展示（对话中展示方案要点与任务清单）
   3. HTML 渲染打开（op-html；默认仍先产出 Markdown）
   4. 用户指定任意方式
2. 方案产出后**强制暂停**，等待用户确认（hotfix/tweak 口头确认即可）
3. **确认留痕**：用户确认后，在 `plan.md` frontmatter 写入：

   ```yaml
   confirmed: true
   confirmed_at: "<ISO 时间戳>"
   ```

   - `confirmed` **只能由用户确认后设置**；agent 禁止自行写入（op-build §0 启动守卫据此放行）
   - 未确认时保持 `confirmed: false`（或缺省）；禁止以「需求明确 / 改动很小」为由跳过确认
4. 确认后：`change.yaml.phase = build`

### 9. 执行约束 YAML（plan.md 顶部）

```yaml
---
execution:
  allow_commit: false          # 默认禁止
  allow_push: false            # 始终禁止
  use_worktree: false          # 默认不使用
  browser_verification: none   # none | optional | required
  browser_screenshot_read: false  # false=浏览器验证用文本/DOM 断言；true=允许截图对比与读图确认
  parallel_mode: serial        # serial | dag
  knowledge_search: true       # 默认启用
  design_extract: auto         # auto | off
---
```

方案确认时由用户决定各项约束，确认后不可单方面修改。

### 10. complex 路径（内部分支）

complex 变更走内部分支：
- 一次一问，2-3 方案对比
- 分段审批
- 产出 brainstorm-summary.md

---

## Red Flags — STOP

| Smell | Action |
|-------|--------|
| User starts writing code during plan | Remind: plan phase, implementation blocked |
| Feature expands beyond current scope | Suggest splitting into a separate change |
| 20+ tasks in the breakdown | Recommend splitting or simplifying |
| agent 自行写入 `confirmed: true` | STOP：确认凭证只能由用户设置（op-build §0 会拦截） |
| 确认前未询问查看方式 | STOP：先问查看方式（4 选项），再请用户确认 |

---

## Common Mistakes

- **Skipping the confirmation pause.** Every plan must pause for explicit user approval.
- **Writing to root directory.** All outputs go to `.op/changes/<name>/`.
- **归档时往 index.json 写 archived 摘要。** index.json 只保留进行态（archived 不写；如已有 archived 条目须清除），归档查询走 `.op/archive/` 目录扫描。
- **跳过查看方式询问。** 确认前必须先问「如何查看方案」（打开文件/摘要/HTML/用户指定）。
- **agent 自行标记 confirmed。** 确认凭证是用户放行凭证，不是 agent 可自判的标记。

---

## Version

| Field | Value |
|-------|-------|
| Skill | op-plan |
| Version | 4.6.0 |
| Updated | 2026-09-14 |
| Key change | v4.6.0: G1 强制对齐追问清单（6 问，缺一不得进入 G3）、新增 references/alignment-checklist.md（来源：grill-me 参考改写）；v4.5.0: tasks.md 生成后强制 6 项校验（格式/id/depends/verify/一致性/规模）；v4.4.0: 统一 YAML frontmatter 为唯一格式（废弃 Markdown checkbox）、执行约束新增 `browser_screenshot_read`；v4.3.0: 确认环节先问查看方式（打开文件/摘要/HTML/用户指定）；v4.2.0: 补回 §1.1b 专家组与 §1.2 execution_mode 契约（修复模板悬空引用）；v4.1.0: 确认关口留痕（plan.md frontmatter `confirmed`，作为 op-build 放行凭证） |
| References | `references/tasks-format.md`（字段定义）· `references/tasks-template.md`（骨架）· `references/plan-template.md`（方案骨架）· `references/pause-behavior.md`（暂停语义）· `references/output-levels.md`（产出粒度）· `references/expert-review-template.md`（专家组）· `references/autonomous-delivery-checklist.md`（自主执行交付自检） |
