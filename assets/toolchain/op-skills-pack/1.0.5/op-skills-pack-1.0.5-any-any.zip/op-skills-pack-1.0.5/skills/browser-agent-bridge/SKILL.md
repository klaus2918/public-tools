---
name: browser-agent-bridge
category: foundation
status: active
phase_role: foundation
version: "2.0.0"
updated_at: 2026-08-20
description: Chrome Native Messaging 桥接。为 op-browser 提供 Bridge 适配器支持。
---

# Browser Agent Bridge

Chrome Native Messaging 桥接，为 op-browser 的 Bridge 适配器提供底层支持。

```text
Agent -> 127.0.0.1:8765 /rpc or /ws -> native/host.py -> Chrome extension -> Chrome APIs/CDP
```

---

## Quick Start

1. 用户打开扩展侧边栏，点击 Start Bridge
2. 检查健康状态：`curl -sS http://127.0.0.1:8765/health`
3. 调用 JSON-RPC：`POST http://127.0.0.1:8765/rpc`

---

## 核心命令

| 命令 | 说明 |
|------|------|
| `POST /rpc` | 单次 JSON-RPC 调用 |
| `ws://127.0.0.1:8765/ws` | 长连接会话 |
| `/health` | 健康检查 |
| `session.start` | 启动新会话 |
| `tabs.list` | 列出标签页 |

---

## 客户端脚本

| 脚本 | 说明 |
|------|------|
| `scripts/browser_bridge_client.py` | Python 客户端 |
| `scripts/rpc.sh` | Bash RPC 辅助 |
| `scripts/ws-rpc.js` | WebSocket 辅助 |

---

## 认证

当 `/health` 报告 `authRequired: true` 时，需设置 `BROWSER_AGENT_BRIDGE_TOKEN` 环境变量。

---

## 分发状态

本仓库只含运行时客户端。扩展源码、原生主机、安装器需从上游仓库获取。

---

## Version

| Field | Value |
|-------|-------|
| Skill | browser-agent-bridge |
| Version | 2.0.0 |
| Updated | 2026-08-20 |
| References | protocol.md |
