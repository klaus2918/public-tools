@echo off
REM java_fs.cmd - Java encrypted file proxy (unified edition, cmd wrapper)
REM Usage: java_fs.cmd read <path>
REM        java_fs.cmd read-b64 <path>
REM        java_fs.cmd write <path> <content>
REM        java_fs.cmd write-b64 <path> <b64file>
REM        java_fs.cmd snapshot <path>
REM        java_fs.cmd restore <path> <snapdir>
REM        java_fs.cmd diff-confirm <path> <snapdir>
REM        java_fs.cmd write-confirm <path> <b64file>
REM        java_fs.cmd cleanup-snapshots [hours]
REM        java_fs.cmd validate-java <path> [level]
REM        java_fs.cmd start|stop|status
REM Prefer java_fs.ps1 when content contains tricky characters.
setlocal
set "SCRIPT_DIR=%~dp0"
if "%1"=="read" (
  if "%2"=="" goto usage
  powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%java_fs.ps1" read "%2"
  exit /b %errorlevel%
)
if "%1"=="read-b64" (
  if "%2"=="" goto usage
  powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%java_fs.ps1" read-b64 "%2"
  exit /b %errorlevel%
)
if "%1"=="write" (
  if "%2"=="" goto usage
  if not "%3"=="" (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%java_fs.ps1" write "%2" "%3"
  ) else (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%java_fs.ps1" write "%2"
  )
  exit /b %errorlevel%
)
if "%1"=="write-b64" (
  if "%2"=="" goto usage
  if "%3"=="" goto usage
  powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%java_fs.ps1" write-b64 "%2" "%3"
  exit /b %errorlevel%
)
if "%1"=="snapshot" (
  if "%2"=="" goto usage
  powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%java_fs.ps1" snapshot "%2"
  exit /b %errorlevel%
)
if "%1"=="restore" (
  if "%2"=="" goto usage
  if "%3"=="" goto usage
  powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%java_fs.ps1" restore "%2" "%3"
  exit /b %errorlevel%
)
if "%1"=="diff-confirm" (
  if "%2"=="" goto usage
  if "%3"=="" goto usage
  powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%java_fs.ps1" diff-confirm "%2" "%3"
  exit /b %errorlevel%
)
if "%1"=="write-confirm" (
  if "%2"=="" goto usage
  if "%3"=="" goto usage
  powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%java_fs.ps1" write-confirm "%2" "%3"
  exit /b %errorlevel%
)
if "%1"=="cleanup-snapshots" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%java_fs.ps1" cleanup-snapshots %2
  exit /b %errorlevel%
)
if "%1"=="validate-java" (
  if "%2"=="" goto usage
  powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%java_fs.ps1" validate-java "%2" %3
  exit /b %errorlevel%
)
if "%1"=="start" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%java_fs.ps1" start
  exit /b %errorlevel%
)
if "%1"=="stop" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%java_fs.ps1" stop
  exit /b %errorlevel%
)
if "%1"=="status" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%java_fs.ps1" status
  exit /b %errorlevel%
)
if "%1"=="env" (
  if "%2"=="-force" (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%java_fs.ps1" env -force
  ) else (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%java_fs.ps1" env
  )
  exit /b %errorlevel%
)
if "%1"=="mode" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%java_fs.ps1" mode
  exit /b %errorlevel%
)
:usage
echo usage: java_fs.cmd read^|read-b64^|write^|write-b64^|snapshot^|restore^|diff-confirm^|write-confirm^|cleanup-snapshots^|validate-java^|env^|mode^|start^|stop^|status ...
exit /b 1
