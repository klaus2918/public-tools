#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
validate_text_selftest.py - Self-test sample set for java-fs validate-text
========================================================================
Phase-1 (op-write-verify): "damage must be detected, normal must pass".

Samples are constructed with \\u escapes (ASCII-only source) so this file
stays ASCII-only per java_fs_io.py design rule 3. A temp dir is created,
samples are written to disk, then `_validate_text_impl` is invoked in-process
plus one end-to-end subprocess smoke (ps1 wrapper -> python chain).

Exit codes: 0 all pass, 1 any failure.
"""
import io
import os
import re
import subprocess
import sys
import tempfile

# Ensure java_fs_io is importable when run standalone
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import java_fs_io as jf  # noqa: E402

# Each sample: (name, filename, content, expect) where expect in {'ERROR','OK'}
# Content uses \\uXXXX escapes only (see _u); other backslashes stay literal.
def _u(s):
    """Decode only \\uXXXX escapes to real chars (source stays ASCII).

    NB: do NOT use .decode('unicode_escape') - it maps UTF-8 bytes as
    Latin-1 (corrupts CJK) and interprets literal \\r\\n as real control
    chars. Regex-substitute only \\uXXXX; all other backslash sequences
    stay literal (they are file content, e.g. the \\r\\n trigger case).
    """
    return re.sub(r'\\u([0-9a-fA-F]{4})',
                  lambda m: chr(int(m.group(1), 16)), s)


# --- damage set (must ERROR) ---
DAMAGE = [
    ('xml_escape_residue', 'd1.xml', '<?xml version="1.0"?>\n<select>SELECT x FROM t WHERE x=\\r\\n1</select>\n', 'ERROR'),   # trigger case
    ('xml_backtick_run', 'd2.xml', '<?xml version="1.0"?>\n<select>SELECT `r`n FROM t</select>\n', 'ERROR'),               # PS backtick pair
    ('xml_unclosed_tag', 'd3.xml', '<?xml version="1.0"?>\n<select><where> x=1 </select>\n', 'ERROR'),                     # ET structure
    ('xml_bad_resultmap_child', 'd4.xml', '<?xml version="1.0"?>\n<resultMap id="m" type="T"><select>x</select></resultMap>\n', 'ERROR'),  # MyBatis model
    ('fffd_mojibake', 'd5.txt', 'hello \\uFFFD world\n', 'ERROR'),          # U+FFFD
    ('bom_file', 'd6.txt', '\ufeffok\n', 'ERROR'),                          # UTF-8 BOM
    ('json_truncated', 'd7.json', '{"a": 1,\n"b": 2\n', 'ERROR'),           # truncated JSON
    ('js_syntax_error', 'd8.js', 'function ( {\n', 'ERROR'),                 # JS syntax
    ('yaml_bad_indent', 'd9.yaml', 'a:\n  b: 1\n c: 2\n', 'ERROR'),          # YAML indent
    ('json_bad_escape', 'd10.json', '{"msg": "bad \\q escape"}\n', 'ERROR'),  # json.loads catches \q
]

# --- normal set (must be OK/exit 0; WARN allowed) ---
NORMAL = [
    ('xml_mybatis_full', 'n1.xml', '<?xml version="1.0"?>\n<select id="q">SELECT `order` FROM `user` WHERE id=1</select>\n', 'OK'),  # MySQL backtick
    ('xml_win_path', 'n2.xml', '<?xml version="1.0"?>\n<property value="C:\\\\new\\\\file"/>\n', 'OK'),  # Windows path (backslash before n)
    ('json_valid_escape', 'n3.json', '{"msg": "a\\r\\nb"}\n', 'OK'),          # valid JSON \r\n escape (WARN allowed)
    ('js_cjs', 'n4.js', 'const a = 1;\nmodule.exports = a;\n', 'OK'),
    ('js_esm', 'n5.js', 'import x from "mod";\nexport default x;\n', 'OK'),  # ESM (double-mode)
    ('ts_string_braces', 'n6.ts', 'const s = "{ ";\nlet n = 1;\n', 'OK'),     # string braces (strip)
    ('vue_valid', 'n7.vue', '<template><div>hi</div></template>\n<script>export default {}</script>\n<style>p{}</style>\n', 'OK'),
    ('yaml_valid', 'n8.yaml', 'a: 1\nb:\n  c: 2\n', 'OK'),
    ('md_valid', 'n9.md', '# Title\n\ntext here\n', 'OK'),
    ('cjk_normal', 'n10.txt', '\u4f60\u597d\uff0c\u4e16\u754c\n', 'OK'),        # Chinese, no qmark
    ('qmark_edge', 'n11.txt', 'ni hao? hao? hao?\n', 'OK'),                    # ASCII ? edge (not CJK-adjacent)
    ('ps1_bom_ok', 'n12.ps1', '\ufeff# \u4e2d\u6587\u6ce8\u91ca PS 5.1 \u5fc5\u987b\u5e26 BOM\nWrite-Output "ok"\n', 'OK'),  # .ps1 BOM = required (WARN allowed)
]


def run_impl(name, filename, content, expect):
    """Write sample to temp dir and validate in-process."""
    p = os.path.join(_TMP, filename)
    with io.open(p, 'w', encoding='utf-8', newline='') as f:
        f.write(content)
    errors, warnings = jf._validate_text_impl(p)
    if expect == 'ERROR':
        return len(errors) > 0, 'errors=%r' % errors[:2]
    return len(errors) == 0, 'errors=%r warnings=%r' % (errors[:2], warnings[:2])


def main():
    global _TMP
    _TMP = tempfile.mkdtemp(prefix='javafs_selftest_')
    print('java-fs validate-text self-test')
    print('tmp:', _TMP)

    total = passed = 0
    fails = []
    for name, fn, content, expect in DAMAGE:
        total += 1
        ok, extra = run_impl(name, fn, _u(content), expect)
        if ok:
            passed += 1
            print('  PASS [%s] %s' % ('ERR', name))
        else:
            fails.append(name)
            print('  FAIL [%s] %s : %s' % ('ERR', name, extra))
    for name, fn, content, expect in NORMAL:
        total += 1
        ok, extra = run_impl(name, fn, _u(content), expect)
        if ok:
            passed += 1
            print('  PASS [%s] %s' % ('OK ', name))
        else:
            fails.append(name)
            print('  FAIL [%s] %s : %s' % ('OK ', name, extra))

    # end-to-end smoke: one damage + one normal via subprocess (ps1 chain)
    smoke_d = os.path.join(_TMP, 'd1.xml')
    r = subprocess.run([sys.executable, os.path.join(_HERE, 'java_fs_io.py'),
                        'validate-text', smoke_d],
                       capture_output=True, text=True)
    total += 1
    if r.returncode != 0:
        passed += 1
        print('  PASS [E2E] damage -> exit 1')
    else:
        fails.append('e2e_damage')
        print('  FAIL [E2E] damage expected exit 1, got %d' % r.returncode)

    smoke_n = os.path.join(_TMP, 'n3.json')
    r = subprocess.run([sys.executable, os.path.join(_HERE, 'java_fs_io.py'),
                        'validate-text', smoke_n],
                       capture_output=True, text=True)
    total += 1
    if r.returncode == 0:
        passed += 1
        print('  PASS [E2E] normal -> exit 0')
    else:
        fails.append('e2e_normal')
        print('  FAIL [E2E] normal expected exit 0, got %d' % r.returncode)

    print()
    print('selftest: %d/%d passed' % (passed, total))
    if fails:
        print('FAILED:', ', '.join(fails))
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
