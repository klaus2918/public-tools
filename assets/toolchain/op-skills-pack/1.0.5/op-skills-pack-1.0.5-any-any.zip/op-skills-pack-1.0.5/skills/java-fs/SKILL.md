---
name: java-fs
category: foundation
status: active
phase_role: foundation
version: "2.0.0"
updated_at: 2026-08-20
description: Java 加密文件全局读写工具。本机所有 .java 文件的读取、写入、编辑必须经本 skill 完成（透明加密环境）。
---

# java-fs — Java 加密文件全局读写工具

## 强制规则 (MANDATORY)

> **所有 `.java` 文件的读取、写入、编辑，必须通过本 skill 完成。**
> 严禁直接用 read / write / edit / apply_patch 工具操作 .java 文件。

原因：本机安装亿赛通 Cobra DocGuard（CDG）透明加密客户端，`.java` 写入即加密落盘。
`python.exe` 在 CDG 解密白名单中，可透明解密读取、正确加密写入。

---

## 机器模式（encrypted / plain）

CDG 透明加密是**机器级全局属性（两态）**：

| 命令 | 说明 |
|------|------|
| `java_fs env [-force]` | 探测本机是否 CDG 加密并写入 `~/.java_fs_mode` |
| `java_fs mode` | 打印当前模式 |

- **`encrypted`**：读写经 `python.exe` 中转
- **`plain`**：读写走 .NET 原生 IO（不经 python）

---

## 核心命令

| 命令 | 说明 |
|------|------|
| `read <路径>` | 读取 .java 文件 |
| `write <路径> <内容>` | 写入 .java 文件（短内容） |
| `write-b64 <路径>` | 写入 .java 文件（base64 通道，推荐） |
| `validate-java <路径>` | 校验 .java 文件 |
| `validate-text <路径>` | 校验文本文件（UTF-8/BOM/U+FFFD） |
| `snapshot <路径>` | 写前快照 |
| `restore <路径>` | 恢复快照 |

---

## 脚本入口

| 脚本 | 说明 |
|------|------|
| `java_fs.ps1` | Windows PowerShell 主入口 |
| `java_fs.cmd` | cmd 封装 |
| `java_fs.sh` | bash 入口 |
| `java_fs_io.py` | 字节级 IO helper |

---

## 安装位置

各工具通过各自原生的 skills 目录发现本 skill（Junction 指向仓库）：

| 工具 | 路径 |
|------|------|
| codex | `%USERPROFILE%\.codex\skills\java-fs\` |
| jcode | `%USERPROFILE%\.jcode\skills\java-fs\` |

---

## Version

| Field | Value |
|-------|-------|
| Skill | java-fs |
| Version | 2.0.0 |
| Updated | 2026-08-20 |
