#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
java_fs_server.py - Java 加密文件读写代理服务（统一版）
=============================================
利用 python.exe 被亿赛通/CDG 透明加密客户端白名单授权的特性，
提供高速文件读写。三端（codex / jcode / reasonix）共用此实现。

用法:
  python java_fs_server.py              # 启动（前台）
  python java_fs_server.py --stop       # 停止

API:
  GET  /read?path=<path>     读取文件返回明文
  POST /write?path=<path>    写入文件（body=内容）
  GET  /health               健康检查
  POST /shutdown             停止服务
"""
import json
import os
import secrets
import signal
import sys
import threading
import urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from socketserver import ThreadingMixIn

HOST = '127.0.0.1'
# 统一状态文件（与 PowerShell / bash 入口共用同一端口文件）
PORT_FILE = Path.home() / '.java_fs_port'
PID_FILE = Path.home() / '.java_fs_pid'
TOKEN_FILE = Path.home() / '.java_fs_token'
# Origin 白名单（浏览器同源/文件页）；无 Origin 头（curl / Invoke-WebRequest 等 CLI）直接放行
ORIGIN_ALLOWED_PREFIXES = ('file://', 'null',
                           'http://127.0.0.1', 'http://localhost',
                           'http://[::1]', 'https://127.0.0.1', 'https://localhost')


# --- 文件核心（python 白名单自动加解密）---

def read_file(path: str) -> bytes:
    with open(path, 'rb') as f:
        return f.read()


def write_file(path: str, content: bytes):
    abspath = os.path.abspath(path)
    os.makedirs(os.path.dirname(abspath), exist_ok=True)
    with open(abspath, 'wb') as f:
        f.write(content)


# --- HTTP ---

class Handler(BaseHTTPRequestHandler):
    """请求处理器"""

    def _origin_allowed(self) -> bool:
        """浏览器跨源防护：带 Origin 头且非白名单的请求一律拒绝。
        无 Origin 头（curl / Invoke-WebRequest 等 CLI 工具）不受影响。"""
        origin = self.headers.get('Origin', '')
        if not origin:
            return True
        return any(origin.startswith(prefix) for prefix in ORIGIN_ALLOWED_PREFIXES)

    def _require_origin(self) -> bool:
        if self._origin_allowed():
            return True
        self._json(403, {"error": "origin not allowed"})
        return False

    def _check_shutdown_token(self, params) -> bool:
        """/shutdown 需携带 TOKEN_FILE 中记录的一次性令牌。"""
        want = ''
        if TOKEN_FILE.exists():
            want = TOKEN_FILE.read_text().strip()
        got = params.get('token', [None])[0] or self.headers.get('X-Token', '')
        if want and secrets.compare_digest(want, got):
            return True
        self._json(403, {"error": "invalid shutdown token"})
        return False

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)
        route = parsed.path.rstrip('/')

        if route == '/health':
            return self._json(200, {"status": "ok"})

        if route == '/read':
            if not self._require_origin():
                return
            file_path = params.get('path', [None])[0]
            if not file_path:
                return self._json(400, {"error": "missing path"})
            try:
                data = read_file(file_path)
                self.send_response(200)
                self.send_header('Content-Type', 'text/plain; charset=utf-8')
                self.send_header('Content-Length', str(len(data)))
                self.send_header('Connection', 'close')
                self.end_headers()
                self.wfile.write(data)
            except FileNotFoundError:
                self._json(404, {"error": "not found"})
            except Exception:
                self._json(500, {"error": "read failed"})
            return

        self._json(404, {"error": "not found"})

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)
        route = parsed.path.rstrip('/')

        if route == '/shutdown':
            if not self._require_origin():
                return
            if not self._check_shutdown_token(params):
                return
            self._json(200, {"status": "shutting down"})
            threading.Thread(target=self.server.shutdown, daemon=True).start()
            return

        if route == '/write':
            if not self._require_origin():
                return
            file_path = params.get('path', [None])[0]
            if not file_path:
                return self._json(400, {"error": "missing path"})
            try:
                length = int(self.headers.get('Content-Length', 0))
                content = self.rfile.read(length)
                write_file(file_path, content)
                self._json(200, {"status": "written", "bytes": len(content)})
            except Exception:
                self._json(500, {"error": "write failed"})
            return

        self._json(404, {"error": "not found"})

    def _json(self, status: int, data: dict):
        body = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Connection', 'close')
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        pass


class PoolServer(ThreadingMixIn, HTTPServer):
    allow_reuse_address = True
    daemon_threads = True


# --- 服务管理 ---

class Manager:
    def __init__(self, host=HOST, port=0):
        self.host = host
        self.port = port
        self._server = None
        self._thread = None

    def start(self) -> int:
        self._server = PoolServer((self.host, self.port), Handler)
        self.port = self._server.server_address[1]
        PORT_FILE.write_text(str(self.port))
        PID_FILE.write_text(str(os.getpid()))
        TOKEN_FILE.write_text(secrets.token_hex(16))
        try:
            os.chmod(TOKEN_FILE, 0o600)
        except OSError:
            pass
        self._thread = threading.Thread(
            target=self._server.serve_forever, daemon=True)
        self._thread.start()
        return self.port

    def stop(self):
        if self._server:
            self._server.shutdown()
        PORT_FILE.unlink(missing_ok=True)
        PID_FILE.unlink(missing_ok=True)
        TOKEN_FILE.unlink(missing_ok=True)

    @staticmethod
    def detect() -> int:
        if PORT_FILE.exists():
            try:
                port = int(PORT_FILE.read_text().strip())
                import urllib.request
                r = urllib.request.urlopen(
                    f'http://{HOST}:{port}/health', timeout=2)
                if r.status == 200:
                    r.close()
                    return port
            except Exception:
                pass
            PORT_FILE.unlink(missing_ok=True)
        return 0

    @staticmethod
    def stop_existing() -> bool:
        stopped = False
        if PID_FILE.exists():
            try:
                pid = int(PID_FILE.read_text().strip())
                os.kill(pid, signal.SIGTERM)
                stopped = True
            except (OSError, ValueError):
                pass
            PID_FILE.unlink(missing_ok=True)
        if not stopped and PORT_FILE.exists():
            try:
                port = int(PORT_FILE.read_text().strip())
                token = TOKEN_FILE.read_text().strip() if TOKEN_FILE.exists() else ''
                import urllib.request
                req = urllib.request.Request(
                    f'http://{HOST}:{port}/shutdown?token={urllib.parse.quote(token)}',
                    method='POST')
                urllib.request.urlopen(req, timeout=3)
                stopped = True
            except Exception:
                pass
        PORT_FILE.unlink(missing_ok=True)
        TOKEN_FILE.unlink(missing_ok=True)
        return stopped


# --- CLI ---

def main():
    if len(sys.argv) > 1:
        if sys.argv[1] == '--stop':
            Manager.stop_existing()
            print('stopped')
            return
        if sys.argv[1] in ('--help', '-h'):
            print('Usage: python java_fs_server.py [--stop]')
            return

    existing = Manager.detect()
    if existing:
        print(f'already running: http://{HOST}:{existing}')
        return

    mgr = Manager()
    port = mgr.start()
    print(f'started: http://{HOST}:{port} pid={os.getpid()}')

    try:
        threading.Event().wait()
    except KeyboardInterrupt:
        mgr.stop()


if __name__ == '__main__':
    main()