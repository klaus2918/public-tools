#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
java_fs_io.py - CDG-whitelisted byte-level IO helper for java-fs
================================================================
Single purpose: read/write files through python.exe, which is on the
Cobra DocGuard (CDG) transparent-encryption whitelist. python writes
.java files encrypted-correctly on disk; other processes (agent Node,
javac/java) would produce/read ciphertext.

Design rules (lessons learned, see java-fs SKILL.md):
  1. Paths are passed via sys.argv (Windows wide-char command line is
     Unicode-safe). NEVER embed paths into `python -c "..."` code
     strings - backslashes get mangled (escapes) and quotes break.
  2. Content is transported as BASE64 (ASCII-only) via a temp file,
     not as command-line args (length limit ~32767) and not via
     PowerShell/cmd pipelines (PS 5.1 encodes stdin as ASCII/ANSI,
     corrupting CJK into '?').
  3. THIS FILE MUST STAY ASCII-ONLY (comments in English). PS 5.1
     parses .ps1 without BOM as ANSI/GBK, and mixed encodings across
     the toolchain corrupt logic. The same discipline applies here.

Operations (v1.1.0):
  read-b64        <path>                       print base64
  write-b64       <path> <b64file>             decode file, write, verify
  verify          <path> <b64file>             compare on-disk bytes vs base64
  snapshot        <path> [snap-dir]            back up original (b64 + meta)
  restore         <path> <snap-dir>            restore from snapshot, verify
  diff-confirm    <path> <snap-dir> [outfile]  unified diff + corruption report
  write-confirm   <path> <b64file> [outfile]   snapshot -> write -> diff -> report
  cleanup-snapshots <base-dir> [max-hours]     remove stale snapshots
  validate-java   <path> [level]               basic|syntax|compile check
  env             [-force]                     detect CDG encryption, save
                                               mode to ~/.java_fs_mode, print it
  mode                                         print current mode (detect if
                                               not yet saved)

Exit codes: 0 ok, 1 error (message on stderr).
"""
import base64
import difflib
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import time

MODE_FILE = os.path.join(os.path.expanduser('~'), '.java_fs_mode')


def detect_cdg_encrypted() -> bool:
    """Detect whether this machine has CDG transparent encryption active.

    Machine-level global property (2 states: encrypted / plain), checked at
    install time and cached in ~/.java_fs_mode. Detection channels:
      1. Windows registry keys (EsafeNet / Cobra / WOW6432Node)
      2. running processes (esafenet / cobra / docguard / dlp)
      3. write-probe: a .java file must carry an 'E-SafeNet' header
    Any channel hit => encrypted. All miss => plain.
    """
    if os.name != 'nt':
        return False  # CDG is a Windows DLP client; non-Windows is plain
    # 1. registry
    try:
        import winreg
        for hive, sub in [
            (winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\EsafeNet'),
            (winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\WOW6432Node\EsafeNet'),
            (winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Cobra'),
        ]:
            try:
                with winreg.OpenKey(hive, sub):
                    return True
            except OSError:
                continue
    except ImportError:
        pass
    # 2. processes
    try:
        out = subprocess.run(['tasklist'], capture_output=True, text=True,
                             timeout=10).stdout.lower()
        for k in ('esafenet', 'cobra', 'docguard', 'dlp'):
            if k in out:
                return True
    except Exception:
        pass
    # 3. write-probe header
    try:
        probe = os.path.join(tempfile.gettempdir(), '_jf_cdg_probe.java')
        with open(probe, 'wb') as f:
            f.write(b'public class Probe {}\n')
        with open(probe, 'rb') as f:
            head = f.read(16)
        os.remove(probe)
        if b'E-SafeNet' in head:
            return True
    except OSError:
        pass
    return False


def read_mode() -> str:
    """Read cached mode file; detect and save if absent."""
    if os.path.isfile(MODE_FILE):
        try:
            with open(MODE_FILE, 'r', encoding='ascii') as f:
                mode = f.read().strip().lower()
            if mode in ('encrypted', 'plain'):
                return mode
        except OSError:
            pass
    mode = 'encrypted' if detect_cdg_encrypted() else 'plain'
    save_mode(mode)
    return mode


def save_mode(mode: str) -> None:
    """Persist mode to ~/.java_fs_mode (machine-global, install-time fact)."""
    mode = 'encrypted' if mode == 'encrypted' else 'plain'
    with open(MODE_FILE, 'w', encoding='ascii') as f:
        f.write(mode + '\n')

SNAP_BASE = os.path.join(tempfile.gettempdir(), 'java-fs-snapshots')
DIFF_BASE = os.path.join(tempfile.gettempdir(), 'java-fs-diff')
VERIFY_TMP = os.path.join(tempfile.gettempdir(), 'javafs_verify')

# --- CJK ranges (subset covering common Chinese) ---
_CJK_RANGES = (
    (0x4E00, 0x9FFF),    # CJK Unified Ideographs
    (0x3400, 0x4DBF),    # CJK Extension A
    (0x20000, 0x2A6DF),  # Extension B
    (0xF900, 0xFAFF),    # Compatibility Ideographs
    (0x3000, 0x303F),    # CJK Symbols and Punctuation
    (0xFF00, 0xFFEF),    # Fullwidth Forms
)


def _is_cjk(ch: str) -> bool:
    if not ch:
        return False
    o = ord(ch)
    return any(lo <= o <= hi for lo, hi in _CJK_RANGES)


def _cjk_ratio(text: str) -> float:
    if not text:
        return 0.0
    n = sum(1 for ch in text if _is_cjk(ch))
    return n / len(text)


def _sha256_hex(text: str) -> str:
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


# ============================ corruption checks ============================

def detect_fffd(text: str) -> dict:
    """U+FFFD replacement character => content was damaged in transit."""
    count = text.count('\uFFFD')
    if count == 0:
        return {'passed': True, 'count': 0, 'severity': 'PASS'}
    positions = [i + 1 for i, line in enumerate(text.splitlines(), 0)
                 if '\uFFFD' in line]
    return {'passed': False, 'count': count, 'positions': positions,
            'severity': 'CRITICAL'}


def detect_suspicious_qmark(text: str, threshold: int = 3) -> dict:
    """CJK chars replaced by '?' when PS 5.1 pipelines mangled encoding."""
    suspicious = 0
    positions = []
    for i, line in enumerate(text.splitlines(), 1):
        for j, ch in enumerate(line):
            if ch != '?':
                continue
            prev_ch = line[j - 1] if j > 0 else ''
            next_ch = line[j + 1] if j < len(line) - 1 else ''
            if _is_cjk(prev_ch) or _is_cjk(next_ch):
                suspicious += 1
                positions.append({'line': i, 'col': j + 1,
                                  'context': line[max(0, j - 5):j + 6]})
    if suspicious > threshold:
        return {'passed': False, 'suspicious_count': suspicious,
                'positions': positions, 'severity': 'HIGH'}
    if suspicious > 0:
        return {'passed': True, 'suspicious_count': suspicious,
                'positions': positions, 'severity': 'LOW'}
    return {'passed': True, 'suspicious_count': 0, 'positions': [],
            'severity': 'PASS'}


def detect_bom_issues(new_text: str, original_text: str) -> dict:
    """UTF-8 BOM is not required and javac rejects a leading BOM."""
    issues = []
    if new_text.startswith('\uFEFF'):
        issues.append('new content starts with BOM (javac may reject it)')
    if original_text.startswith('\uFEFF') and not new_text.startswith('\uFEFF'):
        issues.append('original had BOM, new content lost it (encoding switch?)')
    if not original_text.startswith('\uFEFF') and new_text.startswith('\uFEFF'):
        issues.append('BOM added where original had none')
    return {'passed': not issues, 'issues': issues,
            'severity': 'MEDIUM' if issues else 'PASS'}


def detect_cjk_ratio_drop(original_text: str, new_text: str) -> dict:
    """A sharp drop in CJK ratio suggests Chinese comments got corrupted."""
    orig_ratio = _cjk_ratio(original_text)
    new_ratio = _cjk_ratio(new_text)
    if orig_ratio < 0.01 or orig_ratio <= 0:
        return {'passed': True, 'original_ratio': orig_ratio,
                'new_ratio': new_ratio, 'ratio_change': 0.0, 'severity': 'PASS'}
    ratio_change = (orig_ratio - new_ratio) / orig_ratio
    if ratio_change > 0.5:
        return {'passed': False, 'original_ratio': orig_ratio,
                'new_ratio': new_ratio, 'ratio_change': ratio_change,
                'severity': 'HIGH'}
    if ratio_change > 0.2:
        return {'passed': True, 'original_ratio': orig_ratio,
                'new_ratio': new_ratio, 'ratio_change': ratio_change,
                'severity': 'MEDIUM'}
    return {'passed': True, 'original_ratio': orig_ratio,
            'new_ratio': new_ratio, 'ratio_change': ratio_change,
            'severity': 'PASS'}


def check_corruption(original_text: str, new_text: str) -> dict:
    """Combined corruption report."""
    checks = {
        'fffd': detect_fffd(new_text),
        'suspicious_qmark': detect_suspicious_qmark(new_text),
        'bom': detect_bom_issues(new_text, original_text),
        'cjk_ratio': detect_cjk_ratio_drop(original_text, new_text),
    }
    order = ['PASS', 'LOW', 'MEDIUM', 'HIGH', 'CRITICAL']
    max_sev = max((c['severity'] for c in checks.values()),
                  key=lambda s: order.index(s))
    all_passed = all(c['passed'] for c in checks.values())

    parts = []
    if not checks['fffd']['passed']:
        parts.append('FFFD count=%d (fatal)' % checks['fffd']['count'])
    if not checks['suspicious_qmark']['passed']:
        parts.append('suspicious qmark=%d' %
                     checks['suspicious_qmark']['suspicious_count'])
    if not checks['bom']['passed']:
        parts.append('BOM: ' + '; '.join(checks['bom']['issues']))
    if not checks['cjk_ratio']['passed']:
        parts.append('CJK ratio drop: %.1f%% -> %.1f%%' % (
            checks['cjk_ratio']['original_ratio'] * 100,
            checks['cjk_ratio']['new_ratio'] * 100))
    summary = ('corruption check PASS' if all_passed
               else 'corruption WARN: ' + '; '.join(parts))
    return {'passed': all_passed, 'overall_severity': max_sev,
            'checks': checks, 'summary': summary}


# ============================ core IO (unchanged) ============================

def read_bytes(path: str) -> bytes:
    with open(path, 'rb') as f:
        return f.read()


def read_b64(path: str) -> str:
    return base64.b64encode(read_bytes(path)).decode('ascii')


def write_b64(path: str, b64file: str) -> int:
    with open(b64file, 'r', encoding='ascii') as f:
        b64 = f.read().strip()
    data = base64.b64decode(b64)
    abspath = os.path.abspath(path)
    os.makedirs(os.path.dirname(abspath), exist_ok=True)
    with open(abspath, 'wb') as f:
        f.write(data)
    return len(data)


def verify(path: str, b64file: str) -> bool:
    with open(b64file, 'r', encoding='ascii') as f:
        b64 = f.read().strip()
    expected = base64.b64decode(b64)
    return read_bytes(path) == expected


# ============================ snapshot / restore ============================

def _decode_text(data: bytes) -> str:
    try:
        return data.decode('utf-8-sig')
    except UnicodeDecodeError:
        return data.decode('utf-8', errors='replace')


def snapshot(path: str, snap_dir: str = None) -> str:
    """Back up original bytes as original.b64 + metadata.json."""
    data = read_bytes(path)
    if not snap_dir:
        snap_dir = os.path.join(SNAP_BASE, _sha256_hex(os.path.abspath(path)))
    os.makedirs(snap_dir, exist_ok=True)
    with open(os.path.join(snap_dir, 'original.b64'), 'w', encoding='ascii') as f:
        f.write(base64.b64encode(data).decode('ascii'))
    text = _decode_text(data)
    meta = {
        'original_path': os.path.abspath(path),
        'snapshot_time': time.strftime('%Y-%m-%dT%H:%M:%S%z'),
        'file_size': len(data),
        'cjk_ratio': round(_cjk_ratio(text), 4),
        'file_hash_sha256': hashlib.sha256(data).hexdigest(),
    }
    with open(os.path.join(snap_dir, 'metadata.json'), 'w',
              encoding='utf-8') as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)
    return snap_dir


def restore(path: str, snap_dir: str) -> int:
    """Restore original.b64 from snapshot, write back, verify bytes.

    轮57 加固：先按 metadata.json 的 file_hash_sha256 校验快照完整性（fail-closed，
    快照损坏/被篡改时拒绝恢复，绝不写坏数据）；写回后再逐字节比对。"""
    b64_path = os.path.join(snap_dir, 'original.b64')
    with open(b64_path, 'r', encoding='ascii') as f:
        b64 = f.read().strip()
    data = base64.b64decode(b64)

    # 快照完整性校验（metadata 存在时必须匹配）
    meta_path = os.path.join(snap_dir, 'metadata.json')
    if os.path.isfile(meta_path):
        try:
            with open(meta_path, 'r', encoding='utf-8') as f:
                meta = json.load(f)
            expected = meta.get('file_hash_sha256')
            if expected:
                actual = hashlib.sha256(data).hexdigest()
                if actual != expected:
                    raise IOError(
                        'snapshot corrupted: sha256 mismatch (expected %s..., got %s...), '
                        'refusing to restore' % (expected[:12], actual[:12]))
        except (ValueError, json.JSONDecodeError):
            raise IOError('snapshot corrupted: metadata.json unreadable, refusing to restore')

    abspath = os.path.abspath(path)
    os.makedirs(os.path.dirname(abspath), exist_ok=True)
    with open(abspath, 'wb') as f:
        f.write(data)
    if read_bytes(abspath) != data:
        raise IOError('restore verify failed')
    return len(data)


def cleanup_snapshots(base_dir: str = None, max_hours: int = 24) -> tuple:
    """Remove snapshot dirs older than max_hours. Returns (removed, kept)."""
    base_dir = base_dir or SNAP_BASE
    if not os.path.isdir(base_dir):
        return (0, 0)
    if max_hours < 0:
        max_hours = 24  # 防御负值：退化为默认 24h，绝不删除全部
    cutoff = time.time() - max_hours * 3600
    removed = kept = 0
    for name in os.listdir(base_dir):
        d = os.path.join(base_dir, name)
        if not os.path.isdir(d):
            continue
        try:
            mtime = os.path.getmtime(d)
        except OSError:
            mtime = 0
        if mtime < cutoff:
            import shutil
            shutil.rmtree(d, ignore_errors=True)
            removed += 1
        else:
            kept += 1
    return (removed, kept)


# ============================ diff / confirm ============================

def _diff_lines(original_text: str, new_text: str, filepath: str,
                context: int = 3) -> str:
    orig_lines = original_text.splitlines(keepends=True)
    new_lines = new_text.splitlines(keepends=True)
    diff = difflib.unified_diff(
        orig_lines, new_lines,
        fromfile=filepath + ' (original)',
        tofile=filepath + ' (modified)',
        lineterm='', n=context)
    return ''.join(diff)


def _stat_lines(original_text: str, new_text: str) -> dict:
    sm = difflib.SequenceMatcher(None, original_text.splitlines(),
                                 new_text.splitlines(), autojunk=False)
    added = removed = 0
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == 'insert':
            added += (j2 - j1)
        elif tag == 'delete':
            removed += (i2 - i1)
        elif tag == 'replace':
            added += (j2 - j1)
            removed += (i2 - i1)
    return {'added': added, 'removed': removed}


def diff_confirm(path: str, snap_dir: str, outfile: str = None) -> str:
    """Compare current file vs snapshot; write diff + corruption report."""
    b64_path = os.path.join(snap_dir, 'original.b64')
    with open(b64_path, 'r', encoding='ascii') as f:
        original_text = _decode_text(base64.b64decode(f.read().strip()))
    new_text = _decode_text(read_bytes(path))

    context = int(os.environ.get('JAVA_FS_DIFF_CONTEXT', '3'))
    diff = _diff_lines(original_text, new_text, path, context)
    stat = _stat_lines(original_text, new_text)
    report = check_corruption(original_text, new_text)

    max_lines = int(os.environ.get('JAVA_FS_DIFF_MAX_LINES', '5000'))
    diff_body = diff
    truncated = False
    if len(diff.splitlines()) > max_lines:
        diff_body = '\n'.join(diff.splitlines()[:max_lines]) + \
            '\n... (truncated, %d total lines)' % len(diff.splitlines())
        truncated = True

    header = [
        '===== java-fs diff-confirm =====',
        'file: %s' % os.path.abspath(path),
        'snapshot: %s' % os.path.abspath(snap_dir),
        'stat: +%d -%d' % (stat['added'], stat['removed']),
        'corruption: %s' % report['summary'],
        'severity: %s' % report['overall_severity'],
        'truncated: %s' % str(truncated),
        '================================',
        '',
    ]
    body = '\n'.join(header) + diff_body + '\n'

    if not outfile:
        name = os.path.basename(path) + '.diff'
        outfile = os.path.join(DIFF_BASE, name)
    os.makedirs(os.path.dirname(outfile), exist_ok=True)
    with open(outfile, 'w', encoding='utf-8') as f:
        f.write(body)

    if report['overall_severity'] in ('CRITICAL',):
        print('CRITICAL: corruption detected (%s), see %s'
              % (report['summary'], outfile))
        return 'CRITICAL'
    if report['overall_severity'] in ('HIGH', 'MEDIUM'):
        print('WARN: %s, see %s' % (report['summary'], outfile))
        return 'WARN'
    print('OK: diff written to %s (corruption PASS)' % outfile)
    return 'OK'


def write_confirm(path: str, b64file: str, outfile: str = None) -> int:
    """One-shot safe write: snapshot -> write-b64 -> diff-confirm."""
    snap_dir = snapshot(path)
    print('OK: snapshot saved at %s' % snap_dir)
    n = write_b64(path, b64file)
    if not verify(path, b64file):
        print('ERROR: write-back verify failed', file=sys.stderr)
        return 1
    print('written %d verified' % n)
    diff_confirm(path, snap_dir, outfile)
    return 0


# ============================ validation ============================

def _basic_syntax_check(text: str) -> list:
    """Regex-level checks: bracket balance, UTF-8 sanity."""
    errors = []
    stack = []
    pairs = {'(': ')', '{': '}', '[': ']'}
    for i, line in enumerate(text.splitlines(), 1):
        for ch in line:
            if ch in pairs:
                stack.append((ch, i))
            elif ch in ')}]':
                if not stack:
                    errors.append('Line %d: extra closing %s' % (i, ch))
                else:
                    open_ch, _ = stack.pop()
                    if pairs[open_ch] != ch:
                        errors.append('Line %d: bracket mismatch %s vs %s'
                                      % (i, open_ch, ch))
    for ch, line in stack:
        errors.append('Line %d: unclosed bracket %s' % (line, ch))
    try:
        text.encode('utf-8')
    except UnicodeEncodeError:
        errors.append('illegal UTF-8 characters present')
    return errors


def _syntax_check(text: str) -> list:
    """Full parse via javalang when available; fallback to basic."""
    try:
        import javalang
    except ImportError:
        return _basic_syntax_check(text)
    try:
        javalang.parse.parse(text)
        return []
    except javalang.parser.JavaSyntaxError as e:
        return ['syntax error: %s' % e]
    except javalang.tokenizer.LexerError as e:
        return ['lexer error: %s' % e]


def _compile_check(path: str, text: str, classpath: str = '') -> list:
    """javac on a decrypted temp copy (javac is NOT CDG-whitelisted, so we
    must hand it plaintext under %TEMP%, outside project dirs)."""
    javac = None
    for cand in ('javac', 'javac.exe'):
        try:
            if subprocess.call([cand, '-version'],
                               stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL) == 0:
                javac = cand
                break
        except OSError:
            continue
    if not javac:
        return ['javac not found on PATH (skip compile level)']
    # Keep package-relative path so javac resolves package declarations.
    rel = os.path.basename(os.path.abspath(path))
    m = re.search(r'^\s*package\s+([\w.]+)\s*;', text, re.MULTILINE)
    if m:
        rel = os.path.join(*(m.group(1).split('.') + [rel]))
    tmp_java = os.path.join(VERIFY_TMP, rel)
    os.makedirs(os.path.dirname(tmp_java), exist_ok=True)
    with open(tmp_java, 'w', encoding='utf-8', newline='') as f:
        f.write(text)
    out_dir = os.path.join(VERIFY_TMP, 'classes')
    os.makedirs(out_dir, exist_ok=True)
    cmd = [javac, '-d', out_dir]
    if classpath:
        cmd += ['-cp', classpath]
    cmd.append(tmp_java)
    proc = subprocess.run(cmd, capture_output=True, text=True)
    errs = proc.stderr.strip().splitlines()
    # Non-fatal when the file depends on missing project classes.
    relevant = [l for l in errs
                if 'error:' in l and os.path.basename(tmp_java) in l]
    return relevant or errs[:5]


def validate_java(path: str, level: str = None) -> int:
    """level: off | basic (default) | syntax | compile. Prints result."""
    if level is None:
        level = os.environ.get('JAVAFS_VERIFY_LEVEL', 'basic')
    if level == 'off':
        print('OK: validation disabled (JAVAFS_VERIFY_LEVEL=off)')
        return 0
    text = _decode_text(read_bytes(path))
    if level == 'compile':
        errors = _compile_check(path, text, os.environ.get('JAVAFS_CP', ''))
    elif level == 'syntax':
        errors = _syntax_check(text)
    else:
        errors = _basic_syntax_check(text)
    if errors:
        print('ERROR: validation failed (%s):' % level, file=sys.stderr)
        for e in errors[:20]:
            print('  - %s' % e, file=sys.stderr)
        return 1
    print('OK: validation passed (%s)' % level)
    return 0


# ============================ 通用文本文件校验（vue/js/ts/xml/json/yaml/md 等） ============================

def _check_brackets(text: str) -> list:
    """Bracket pairing on code with strings/comments stripped (best-effort).

    Strips line/block comments and string literals (single/double/backtick)
    before counting so string content cannot skew pairing (e.g. const s = "{ ").
    Single pass, non-recursive; only reports when still unbalanced.
    """
    s = re.sub(r'//[^\n]*', '', text)
    s = re.sub(r'/\*.*?\*/', '', s, flags=re.S)
    s = re.sub(r'<!--.*?-->', '', s, flags=re.S)
    s = re.sub(r"'(?:[^'\\]|\\.)*'", "''", s)
    s = re.sub(r'"(?:[^"\\]|\\.)*"', '""', s)
    s = re.sub(r'`(?:[^`]|``)*`', '``', s)
    counts = {'(': 0, ')': 0, '[': 0, ']': 0, '{': 0, '}': 0}
    for ch in s:
        if ch in counts:
            counts[ch] += 1
    errors = []
    for open_ch, close_ch in [('(', ')'), ('[', ']'), ('{', '}')]:
        if counts[open_ch] != counts[close_ch]:
            errors.append('bracket mismatch: %s=%d %s=%d'
                          % (open_ch, counts[open_ch], close_ch, counts[close_ch]))
    return errors


def _check_vue_tags(text: str) -> list:
    """Vue 单文件组件标签配对检查（template/script/style 开闭数量一致）。"""
    import re
    errors = []
    for tag in ('template', 'script', 'style'):
        opens = len(re.findall(r'<%s[\s>]' % tag, text))
        closes = len(re.findall(r'</%s>' % tag, text))
        if opens != closes:
            errors.append('Vue <%s> 标签不配对: 开 %d 闭 %d' % (tag, opens, closes))
    return errors


def _check_mybatis_xml(text: str) -> tuple:
    """MyBatis Mapper XML heuristic (DTD content model not checked by ET).

    resultMap children restricted to the allowed set; backticks are handled
    by _check_escape_residue (paired=ERROR, single=WARN for MySQL compat).
    Returns (errors, warnings).
    """
    errors = []
    warnings = []
    body = re.sub(r'<!--.*?-->', '', text, flags=re.S)
    allowed = {'constructor', 'id', 'result', 'association', 'collection', 'discriminator'}
    for m in re.finditer(r'<resultMap\b[^>]*>(.*?)</resultMap>', body, re.S):
        inner = m.group(1)
        for tag in re.findall(r'<([a-zA-Z_][\w.-]*)\b', inner):
            if tag not in allowed:
                errors.append('resultMap illegal child <%s> (MyBatis content model)' % tag)
    return errors, warnings


_ESCAPE_RESIDUE_RE = re.compile(r'\\[rnt"\'\\]')
_BACKTICK_PAIR_RE = re.compile(r'`[rnt"\']`')


def _check_escape_residue(text: str, ext: str) -> tuple:
    """Detect escape residue: backslash escapes (Python/JS style) or PS
    backtick pairs inside file content - both are shell-writing accidents
    when the target format has no such escape system (e.g. XML).

    - Backslash escape `\\[rnt"'\\]`:
      .xml -> ERROR (trigger case: WHERE x=\\r\\n1), unless a Windows drive
      path (`C:\\new`) is present in the file, then WARN (path context);
      other text formats -> WARN (syntactically legal, but suspicious).
    - Backtick pair `` `[rnt"']` `` (2+ consecutive, PS style):
      .xml -> ERROR; other formats -> WARN.
      A single backtick is a valid MySQL identifier quote -> NOT flagged
      (except as part of a pair above).
    Returns (errors, warnings).
    """
    errors = []
    warnings = []
    has_win_path = re.search(r'[A-Za-z]:\\', text) is not None
    for m in _ESCAPE_RESIDUE_RE.finditer(text):
        seq = m.group(0)
        line = text.count('\n', 0, m.start()) + 1
        ctx = text[max(0, m.start() - 20):m.end() + 10].replace('\n', ' ')
        if ext == '.xml' and not has_win_path:
            errors.append('XML escape residue %r (literal backslash, line %d): %s'
                          % (seq, line, ctx))
        else:
            warnings.append('escape residue %r (WARN, verify intended, line %d): %s'
                            % (seq, line, ctx))
    for m in _BACKTICK_PAIR_RE.finditer(text):
        seq = m.group(0)
        line = text.count('\n', 0, m.start()) + 1
        if ext == '.xml':
            errors.append('XML backtick pair %r (PS escape residue, line %d)'
                          % (seq, line))
        else:
            warnings.append('backtick pair %r (WARN, PS escape residue?, line %d)'
                            % (seq, line))
    return errors, warnings


def _check_js(path: str, errors: list, warnings: list) -> None:
    """JS syntax check with dual-mode (CJS/ESM) and graceful degradation.

    node --check defaults to CommonJS; a top-level `import` fails there.
    On "Cannot use import statement" we retry as a module via stdin.
    If node is missing: WARN + pass (matches SKILL.md), unless
    JAVAFS_VERIFY_JS=strict restores fail-closed.
    """
    import subprocess
    try:
        r = subprocess.run(['node', '--check', path],
                           capture_output=True, text=True, timeout=30)
    except FileNotFoundError:
        if os.environ.get('JAVAFS_VERIFY_JS') == 'strict':
            errors.append('node unavailable and JAVAFS_VERIFY_JS=strict (fail-closed)')
        else:
            warnings.append('node unavailable, JS syntax check skipped (WARN; '
                            'JAVAFS_VERIFY_JS=strict to fail-closed)')
        return
    if r.returncode == 0:
        return
    stderr = (r.stderr or '')
    if 'Cannot use import statement outside a module' in stderr:
        # ESM: retry as module via stdin
        try:
            with open(path, encoding='utf-8') as f:
                src = f.read()
            r2 = subprocess.run(['node', '--input-type=module', '--check', '-'],
                                input=src, capture_output=True, text=True, timeout=30)
            if r2.returncode == 0:
                return
            errors.append('JS ESM syntax error: %s'
                          % (r2.stderr or r2.stdout).strip()[:300])
        except Exception as e:  # noqa: BLE001
            errors.append('JS module check error: %r' % e)
        return
    errors.append('JS syntax error: %s' % stderr.strip()[:300])


def _validate_text_impl(path: str) -> tuple:
    """Validate one text file. Returns (errors, warnings)."""
    errors = []
    warnings = []
    try:
        data = read_bytes(path)
    except Exception as e:
        return ['read failed: %s' % e], []
    try:
        text = _decode_text(data)
    except Exception as e:
        return ['not UTF-8 decodable: %s' % e], []
    fffd = detect_fffd(text)
    if fffd['count'] > 0:
        errors.append('U+FFFD x%d (encoding corruption, forbidden)' % fffd['count'])
    ext = os.path.splitext(path)[1].lower()
    if data.startswith(b'\xef\xbb\xbf'):
        if ext == '.ps1':
            # PS 5.1 解析无 BOM 的 .ps1 按 ANSI/GBK，中文必乱码；BOM 是必需而非损坏（宪法明文）
            warnings.append('UTF-8 BOM present (required by PS 5.1 for .ps1, allowed)')
        else:
            errors.append('UTF-8 BOM present (no-BOM convention)')
    qm = detect_suspicious_qmark(text)
    if qm['severity'] == 'HIGH':
        warnings.append('suspicious qmark x%d (PS pipeline mojibake?)'
                        % qm['suspicious_count'])
    try:
        if ext == '.xml':
            import xml.etree.ElementTree as ET
            ET.fromstring(text)
            e, w = _check_mybatis_xml(text)
            errors.extend(e)
            warnings.extend(w)
            e, w = _check_escape_residue(text, ext)
            errors.extend(e)
            warnings.extend(w)
        elif ext == '.json':
            import json as _json
            _json.loads(text)
            e, w = _check_escape_residue(text, ext)
            errors.extend(e)
            warnings.extend(w)
        elif ext == '.js':
            _check_js(path, errors, warnings)
            e, w = _check_escape_residue(text, ext)
            errors.extend(e)
            warnings.extend(w)
        elif ext in ('.ts', '.vue'):
            errors.extend(_check_brackets(text))
            if ext == '.vue':
                errors.extend(_check_vue_tags(text))
        elif ext in ('.yaml', '.yml'):
            try:
                import yaml
                yaml.safe_load(text)
            except ImportError:
                warnings.append('pyyaml unavailable, YAML structural check skipped')
    except Exception as e:
        errors.append('%s parse error: %s' % (ext.upper().lstrip('.'), e))
    return errors, warnings


def validate_text(path: str) -> int:
    """Validate one text file (non-.java: vue/js/ts/xml/json/yaml/md/etc).

    Phase-1 (op-write-verify) WARN/ERROR grading:
      ERROR  -> exit 1 (blocking): UTF-8 fail, U+FFFD, BOM, structural parse
               failure, XML escape residue / backtick pair (PS accident)
      WARN   -> exit 0 (non-blocking): escape residue elsewhere, qmark,
               node/pyyaml unavailable, MySQL-style single backtick
    Errors and warnings are printed to stderr; OK to stdout.
    """
    errors, warnings = _validate_text_impl(path)
    for w in warnings[:10]:
        print('WARN: %s (%s)' % (w, path), file=sys.stderr)
    if errors:
        print('ERROR: validation failed (%s):' % path, file=sys.stderr)
        for e in errors[:20]:
            print('  - %s' % e, file=sys.stderr)
        return 1
    print('OK: validation passed (%s)' % path)
    return 0


# Directory-scan blacklist (build artifacts / third-party code)
_SCAN_SKIP_DIRS = {
    '.git', '.jcode', '.codex', 'node_modules', '__pycache__', 'target',
    'dist', 'build', '.venv', 'venv', '.idea', '.vscode', '.op',
}
_SCAN_EXTS = {
    '.xml', '.json', '.js', '.ts', '.vue', '.yaml', '.yml', '.md',
    '.ps1', '.html', '.properties', '.txt', '.css',
}


def _expand_validate_targets(args: list) -> list:
    """Expand CLI args to file list. File args pass through; directory args
    are recursively scanned (extension whitelist + dir blacklist)."""
    files = []
    for a in args:
        if os.path.isdir(a):
            for root, dirs, names in os.walk(a):
                dirs[:] = [d for d in dirs if d not in _SCAN_SKIP_DIRS]
                for n in names:
                    if os.path.splitext(n)[1].lower() in _SCAN_EXTS:
                        files.append(os.path.join(root, n))
        else:
            files.append(a)
    return files


def validate_text_many(args: list) -> int:
    """Batch validate-text: multiple files or directories (recursive scan).
    exit 0 all pass; 1 any ERROR (details per file on stderr)."""
    files = _expand_validate_targets(args)
    if not files:
        print('OK: no files to validate')
        return 0
    fail = 0
    warn = 0
    passed = 0
    for f in files:
        errors, warnings = _validate_text_impl(f)
        rel = f
        if warnings:
            warn += 1
            for w in warnings[:5]:
                print('WARN: %s (%s)' % (w, rel), file=sys.stderr)
        if errors:
            fail += 1
            print('FAIL: %s' % rel, file=sys.stderr)
            for e in errors[:20]:
                print('  - %s' % e, file=sys.stderr)
        else:
            passed += 1
            print('PASS: %s' % rel)
    print('summary: %d pass / %d fail / %d warn' % (passed, fail, warn))
    return 1 if fail else 0


# ============================ main ============================

def main() -> int:
    args = sys.argv[1:]
    if not args:
        print(__doc__, file=sys.stderr)
        return 1
    op = args[0]
    try:
        if op == 'read-b64' and len(args) >= 2:
            print(read_b64(args[1]))
            return 0
        if op == 'write-b64' and len(args) >= 3:
            n = write_b64(args[1], args[2])
            ok = verify(args[1], args[2])
            if not ok:
                print('ERROR: write-back verify failed', file=sys.stderr)
                return 1
            print('written %d verified' % n)
            return 0
        if op == 'verify' and len(args) >= 3:
            ok = verify(args[1], args[2])
            print('verify %s' % ('OK' if ok else 'MISMATCH'))
            return 0 if ok else 1
        if op == 'snapshot' and len(args) >= 2:
            d = snapshot(args[1], args[2] if len(args) >= 3 else None)
            print('OK: snapshot saved at %s' % d)
            return 0
        if op == 'restore' and len(args) >= 3:
            n = restore(args[1], args[2])
            print('OK: restored %d bytes' % n)
            return 0
        if op == 'diff-confirm' and len(args) >= 3:
            diff_confirm(args[1], args[2], args[3] if len(args) >= 4 else None)
            return 0
        if op == 'write-confirm' and len(args) >= 3:
            return write_confirm(args[1], args[2],
                                 args[3] if len(args) >= 4 else None)
        if op == 'cleanup-snapshots':
            base = args[1] if len(args) >= 2 else None
            hours = int(args[2]) if len(args) >= 3 else 24
            removed, kept = cleanup_snapshots(base, hours)
            print('OK: removed %d stale snapshot(s), kept %d' % (removed, kept))
            return 0
        if op == 'validate-java' and len(args) >= 2:
            return validate_java(args[1], args[2] if len(args) >= 3 else None)
        if op == 'validate-text' and len(args) >= 2:
            return validate_text_many(args[1:])
        if op == 'env':
            if len(args) >= 2 and args[1] == '-force':
                mode = 'encrypted' if detect_cdg_encrypted() else 'plain'
                save_mode(mode)
            else:
                mode = read_mode()
            print(mode)
            return 0
        if op == 'mode':
            print(read_mode())
            return 0
        if op == 'selftest-text':
            import validate_text_selftest as _st
            return _st.main()
    except FileNotFoundError as e:
        print('ERROR: %s' % e, file=sys.stderr)
        return 1
    except Exception as e:
        print('ERROR: %s' % e, file=sys.stderr)
        return 1
    print('usage: java_fs_io.py '
          'read-b64|write-b64|verify|snapshot|restore|diff-confirm|'
          'write-confirm|cleanup-snapshots|validate-java|validate-text|'
          'env|mode ...',
          file=sys.stderr)
    return 1


if __name__ == '__main__':
    sys.exit(main())
