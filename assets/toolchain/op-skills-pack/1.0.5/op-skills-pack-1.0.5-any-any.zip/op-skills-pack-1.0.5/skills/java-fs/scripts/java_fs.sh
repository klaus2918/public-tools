#!/usr/bin/env bash
# java_fs - Java encrypted file proxy tool (unified edition)
# Usage:
#   java_fs read <path>              plaintext to stdout
#   java_fs read-b64 <path>          base64 single line to stdout (byte-exact)
#   java_fs write <path> <content>   write content (argv; ASCII-safe only)
#   java_fs write <path> < b64file   read base64 from stdin file (byte-exact)
#   java_fs write-b64 <path> <file>  write from base64 file (byte-exact, preferred)
#   java_fs snapshot <path>          back up original bytes to %TEMP% snapshots
#   java_fs restore <path> <snapdir> restore from snapshot
#   java_fs diff-confirm <path> <snapdir>  diff + corruption report
#   java_fs write-confirm <path> <b64file> snapshot -> write -> diff report
#   java_fs cleanup-snapshots [hours]      remove stale snapshots (24h)
#   java_fs validate-java <path> [level]   basic|syntax|compile check
#   java_fs start|stop|status
# Shared server state: ~/.java_fs_port (same as the PowerShell entry)
# NOTE: this file must stay ASCII-only (toolchain parses without UTF-8 BOM).

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
IO_PY="$SCRIPT_DIR/java_fs_io.py"
SERVER_SCRIPT="$SCRIPT_DIR/java_fs_server.py"
PORT_FILE="$HOME/.java_fs_port"

# --- python interpreter detection ---
# `python` is frequently absent from PATH on Windows (only `py` launcher exists).
# Probe py/python3/python once; fail loudly instead of "command not found".
PY=""
for c in py python3 python; do
  if command -v "$c" >/dev/null 2>&1; then
    if "$c" -c 'import sys' >/dev/null 2>&1; then
      PY="$c"
      break
    fi
  fi
done
if [ -z "$PY" ]; then
  echo "ERROR: no python interpreter found (tried py/python3/python)" >&2
  exit 2
fi

# --- direct python calls (no server needed) ---
_direct_read_b64() {
    local path="$1"
    "$PY" "$IO_PY" read-b64 "$path"
}

_direct_write_b64() {
    local path="$1"
    local b64file="$2"
    "$PY" "$IO_PY" write-b64 "$path" "$b64file"
}

# --- ensure server running, return port ---
_ensure_server() {
    local port=0
    if [ -f "$PORT_FILE" ]; then
        port=$(cat "$PORT_FILE" 2>/dev/null || echo 0)
        if [ "$port" -gt 0 ] 2>/dev/null; then
            if curl -sf "http://127.0.0.1:$port/health" >/dev/null 2>&1; then
                echo "$port"
                return 0
            fi
        fi
        rm -f "$PORT_FILE"
    fi
    "$PY" "$SERVER_SCRIPT" > /dev/null 2>&1 &
    local wait=0
    while [ $wait -lt 8 ]; do
        sleep 1
        if [ -f "$PORT_FILE" ]; then
            port=$(cat "$PORT_FILE")
            break
        fi
        wait=$((wait + 1))
    done
    if [ "$port" -eq 0 ]; then
        echo "0"
        return 1
    fi
    echo "$port"
    return 0
}

# --- file ops (prefer server, fallback to direct python) ---
_read_file_b64() {
    local path="$1"
    if [ ! -f "$path" ]; then
        echo "ERROR: not found: $path" >&2
        return 1
    fi
    local port
    port=$(_ensure_server) || {
        _direct_read_b64 "$path"
        return $?
    }
    if [ "$port" = "0" ]; then
        _direct_read_b64 "$path"
        return $?
    fi
    # URL-encode path for query param (spaces/CJK)
    local enc
    enc=$("$PY" -c "import urllib.parse,sys; print(urllib.parse.quote(sys.argv[1], safe=''))" "$path")
    curl -sf "http://127.0.0.1:$port/read?path=$enc" | "$PY" -c "import sys,base64; print(base64.b64encode(sys.stdin.buffer.read()).decode('ascii'))" || {
        _direct_read_b64 "$path"
    }
}

_write_file_b64() {
    local path="$1"
    local b64file="$2"
    if [ ! -f "$b64file" ]; then
        echo "ERROR: b64 file not found: $b64file" >&2
        return 1
    fi
    local port
    port=$(_ensure_server) || {
        _direct_write_b64 "$path" "$b64file"
        return $?
    }
    if [ "$port" = "0" ]; then
        _direct_write_b64 "$path" "$b64file"
        return $?
    fi
    local enc
    enc=$("$PY" -c "import urllib.parse,sys; print(urllib.parse.quote(sys.argv[1], safe=''))" "$path")
    "$PY" -c "import sys,base64; sys.stdout.buffer.write(base64.b64decode(sys.stdin.read().strip()))" < "$b64file" | \
        curl -sf -X POST "http://127.0.0.1:$port/write?path=$enc" --data-binary @- || {
        _direct_write_b64 "$path" "$b64file"
    }
}

# --- server management ---
_start_server() {
    "$PY" "$SERVER_SCRIPT" > /dev/null 2>&1 &
    local wait=0
    while [ $wait -lt 8 ]; do
        sleep 1
        if [ -f "$PORT_FILE" ]; then
            local port
            port=$(cat "$PORT_FILE")
            echo "server started: http://127.0.0.1:$port"
            return 0
        fi
        wait=$((wait + 1))
    done
    echo "ERROR: start failed" >&2
    return 1
}

_stop_server() {
    "$PY" "$SERVER_SCRIPT" --stop 2>/dev/null || true
    rm -f "$PORT_FILE" 2>/dev/null || true
}

_server_status() {
    if [ ! -f "$PORT_FILE" ]; then
        echo "status: not running"
        return 1
    fi
    local port
    port=$(cat "$PORT_FILE" 2>/dev/null || echo 0)
    if [ "$port" -gt 0 ] 2>/dev/null; then
        if curl -sf "http://127.0.0.1:$port/health" >/dev/null 2>&1; then
            echo "status: running http://127.0.0.1:$port"
            return 0
        fi
    fi
    echo "status: stale port file"
    rm -f "$PORT_FILE"
    return 1
}

# --- main ---
case "${1:-help}" in
    read|cat)
        if [ $# -lt 2 ]; then echo "usage: java_fs read <path>" >&2; exit 1; fi
        _b64=$(_read_file_b64 "$2")
        "$PY" -c "import sys,base64; sys.stdout.buffer.write(base64.b64decode(sys.argv[1]))" "$_b64"
        ;;
    read-b64)
        if [ $# -lt 2 ]; then echo "usage: java_fs read-b64 <path>" >&2; exit 1; fi
        _read_file_b64 "$2"
        ;;
    write)
        if [ $# -lt 2 ]; then echo "usage: java_fs write <path> <content>|<b64file>" >&2; exit 1; fi
        if [ $# -ge 3 ]; then
            # argv content: base64 it, then write via b64 channel
            tmpb64=$(mktemp)
            printf '%s' "$3" | base64 -w0 > "$tmpb64"
            _write_file_b64 "$2" "$tmpb64"
            rm -f "$tmpb64"
        else
            # stdin is a base64 file (byte-exact); do not use $(cat) (strips trailing newline)
            tmpb64=$(mktemp)
            cat > "$tmpb64"
            _write_file_b64 "$2" "$tmpb64"
            rm -f "$tmpb64"
        fi
        ;;
    write-b64)
        if [ $# -lt 3 ]; then echo "usage: java_fs write-b64 <path> <b64file>" >&2; exit 1; fi
        _write_file_b64 "$2" "$3"
        ;;
    snapshot)
        if [ $# -lt 2 ]; then echo "usage: java_fs snapshot <path>" >&2; exit 1; fi
        "$PY" "$IO_PY" snapshot "$2"
        ;;
    restore)
        if [ $# -lt 3 ]; then echo "usage: java_fs restore <path> <snapdir>" >&2; exit 1; fi
        "$PY" "$IO_PY" restore "$2" "$3"
        ;;
    diff-confirm)
        if [ $# -lt 3 ]; then echo "usage: java_fs diff-confirm <path> <snapdir>" >&2; exit 1; fi
        "$PY" "$IO_PY" diff-confirm "$2" "$3"
        ;;
    write-confirm)
        if [ $# -lt 3 ]; then echo "usage: java_fs write-confirm <path> <b64file>" >&2; exit 1; fi
        "$PY" "$IO_PY" write-confirm "$2" "$3"
        ;;
    cleanup-snapshots)
        if [ $# -ge 2 ]; then "$PY" "$IO_PY" cleanup-snapshots "$2"; else "$PY" "$IO_PY" cleanup-snapshots; fi
        ;;
    validate-java)
        if [ $# -lt 2 ]; then echo "usage: java_fs validate-java <path> [level]" >&2; exit 1; fi
        if [ $# -ge 3 ]; then "$PY" "$IO_PY" validate-java "$2" "$3"; else "$PY" "$IO_PY" validate-java "$2"; fi
        ;;
    env)
        "$PY" "$IO_PY" env ${2:--force} 2>/dev/null || "$PY" "$IO_PY" env -force
        ;;
    mode)
        "$PY" "$IO_PY" mode
        ;;
    start)
        _start_server
        ;;
    stop)
        _stop_server
        ;;
    status)
        _server_status || true
        ;;
    help|--help|-h)
        echo "java_fs - Java encrypted file proxy tool"
        echo ""
        echo "usage:"
        echo "  java_fs read <path>              read java file plaintext"
        echo "  java_fs read-b64 <path>          read java file as base64 (byte-exact)"
        echo "  java_fs write <path> <content>   write content (ASCII-safe)"
        echo "  java_fs write <path> < b64file   write from base64 stdin (byte-exact)"
        echo "  java_fs write-b64 <path> <file>  write from base64 file (byte-exact, preferred)"
        echo "  java_fs snapshot <path>           back up original bytes"
        echo "  java_fs restore <path> <snapdir>  restore from snapshot"
        echo "  java_fs diff-confirm <path> <snapdir>  diff + corruption report"
        echo "  java_fs write-confirm <path> <b64file> snapshot -> write -> diff report"
        echo "  java_fs cleanup-snapshots [hours] remove stale snapshots"
        echo "  java_fs validate-java <path> [level] basic|syntax|compile check"
        echo "  java_fs env [-force]           probe + cache machine mode (encrypted|plain)"
        echo "  java_fs mode                     print machine mode"
        echo "  java_fs start|stop|status        manage proxy server"
        ;;
    *)
        echo "unknown: $1" >&2
        echo "usage: java_fs read|read-b64|write|write-b64|snapshot|restore|diff-confirm|write-confirm|cleanup-snapshots|validate-java|start|stop|status" >&2
        exit 1
        ;;
esac
