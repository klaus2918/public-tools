# -*- coding: utf-8 -*-
"""java_fs_server.py 安全加固冒烟（第5组轮51固化）
覆盖：Origin 跨源防护（恶意 403 / 白名单放行 / 无 Origin 放行）、
shutdown token 认证（无/错/对）、错误脱敏（404 不泄露路径）。
用法：python -X utf8 test_server_security.py
"""
import io
import os
import pathlib
import shutil
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import java_fs_server as S

ok = True


def check(name, cond, detail=''):
    global ok
    print(('[GREEN] ' if cond else '[FAIL] ') + name + ('' if cond else ' | ' + detail))
    if not cond:
        ok = False


def req(base, url, method='GET', headers=None, data=None):
    r = urllib.request.Request(url, method=method, headers=headers or {}, data=data)
    try:
        resp = urllib.request.urlopen(r, timeout=5)
        return resp.status, resp.read().decode('utf-8', 'replace')
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode('utf-8', 'replace')


def main():
    tmp = tempfile.mkdtemp(prefix='jfs_sec_')
    old_home = os.environ.get('HOME')
    os.environ['HOME'] = tmp
    S.PORT_FILE = pathlib.Path(tmp) / '.java_fs_port'
    S.PID_FILE = pathlib.Path(tmp) / '.java_fs_pid'
    S.TOKEN_FILE = pathlib.Path(tmp) / '.java_fs_token'
    try:
        mgr = S.Manager()
        port = mgr.start()
        base = 'http://%s:%d' % (S.HOST, port)
        token = S.TOKEN_FILE.read_text().strip()
        check('token 文件已创建（32 hex）', bool(token) and len(token) == 32)

        f = os.path.join(tmp, 'Hello.java')
        io.open(f, 'w', encoding='utf-8').write('public class Hello {}\n')
        enc = urllib.parse.quote(f)

        st, body = req(base, '%s/read?path=%s' % (base, enc))
        check('无 Origin read 200', st == 200 and 'public class Hello' in body, '%d %s' % (st, body[:60]))

        st, body = req(base, '%s/read?path=%s' % (base, enc),
                       headers={'Origin': 'https://evil.example.com'})
        check('恶意 Origin read 403', st == 403, '%d %s' % (st, body[:60]))

        st, body = req(base, '%s/read?path=%s' % (base, enc),
                       headers={'Origin': 'http://127.0.0.1:9999'})
        check('白名单 Origin read 200', st == 200, '%d %s' % (st, body[:60]))

        st, body = req(base, '%s/write?path=%s' % (base, enc), method='POST',
                       headers={'Origin': 'https://evil.example.com'}, data=b'x')
        check('恶意 Origin write 403', st == 403, '%d %s' % (st, body[:60]))

        st, body = req(base, '%s/shutdown' % base, method='POST')
        check('shutdown 无 token 403', st == 403, '%d %s' % (st, body[:60]))

        st, body = req(base, '%s/shutdown?token=bad' % base, method='POST')
        check('shutdown 错 token 403', st == 403, '%d %s' % (st, body[:60]))

        st, body = req(base, '%s/read?path=%s' % (base, urllib.parse.quote(os.path.join(tmp, 'nope.java'))))
        check('缺失文件 read 404', st == 404, '%d %s' % (st, body[:60]))

        st, body = req(base, '%s/shutdown?token=%s' % (base, token), method='POST')
        check('shutdown 带 token 200', st == 200, '%d %s' % (st, body[:60]))
    finally:
        os.environ['HOME'] = old_home if old_home else ''
        shutil.rmtree(tmp, ignore_errors=True)

    print('=== java-fs server 安全冒烟%s ===' % ('全部通过' if ok else '存在失败'))
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
