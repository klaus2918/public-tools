#region Header
<#
.SYNOPSIS
  java_fs - Java encrypted file proxy (unified edition)

.DESCRIPTION
  Reads and writes .java files that are transparently encrypted by the
  EsafeNet/CDG DLP client. python.exe is whitelisted by CDG, so it can
  decrypt on read and encrypt correctly on write.

  Transport channels (pick by content):
    read   <path>                plaintext UTF-8 to stdout (may add \r\r\n
                                 on PS 5.1 capture; normalize \r\r\n -> \n
                                 if you post-process the output)
    read-b64 <path>              base64 (ASCII single line) to stdout,
                                 decode to get exact bytes (no line-ending
                                 mangling). Preferred for byte-exact reads.
    write  <path> <content>      content as arg (ASCII only, short)
    write  <path>                content from stdin (plain text channel,
                                 CJK may become '?' on PS 5.1 pipelines)
    write-b64 <path> <b64file>   content from a base64 file (ASCII),
                                 byte-exact, CJK-safe, large-file safe.
                                 Preferred for any non-ASCII content.
    snapshot <path>              back up original bytes (original.b64 + meta)
                                 to %TEMP%\java-fs-snapshots\<hash>
    restore <path> <snapdir>     restore file from a snapshot, then verify
    diff-confirm <path> <snapdir> compare current vs snapshot: write unified
                                 diff + corruption report to %TEMP%\java-fs-diff
    write-confirm <path> <b64file> one-shot safe write: snapshot -> write-b64
                                 -> diff-confirm report
    cleanup-snapshots [hours]    remove snapshots older than N hours (24)
    validate-java <path> [level] basic|syntax|compile syntax/compile check
                                 (level default from JAVAFS_VERIFY_LEVEL)
    start | stop | status        optional long-running proxy server

  One-shot python calls are byte-exact and encoding-safe. Paths are
  passed to python via argv (wide-char safe), NOT embedded in -c code.

.EXAMPLE
  powershell -NoProfile -ExecutionPolicy Bypass -File java_fs.ps1 read F:\path\File.java
  powershell -NoProfile -ExecutionPolicy Bypass -File java_fs.ps1 write F:\path\File.java "public class A {}"
  powershell -NoProfile -ExecutionPolicy Bypass -File java_fs.ps1 write-b64 F:\path\File.java D:\tmp\content.b64
#>
#endregion

param(
  [Parameter(Mandatory = $true, Position = 0)]
  [ValidateSet('read','read-b64','write','write-b64','snapshot','restore',
               'diff-confirm','write-confirm','cleanup-snapshots',
               'validate-java','validate-text','env','mode',
               'start','stop','status','help')]
  [string]$Op,

  [Parameter(Position = 1)]
  [string]$Path,

  [Parameter(Position = 2)]
  [string]$Content
)

$ErrorActionPreference = 'Stop'
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ioPy      = Join-Path $scriptDir 'java_fs_io.py'
$serverPy  = Join-Path $scriptDir 'java_fs_server.py'
$portFile  = Join-Path $env:USERPROFILE '.java_fs_port'
$modeFile  = Join-Path $env:USERPROFILE '.java_fs_mode'

# --- machine mode: encrypted (CDG) vs plain (native IO) ---
# CDG transparent encryption is a machine-level global property. Mode is
# probed once at install time and cached in ~/.java_fs_mode (2 states).
# Plain mode reads/writes .java through native .NET IO (no python hop);
# encrypted mode goes through python.exe (CDG whitelist).
# Find a usable python: py launcher first (windows), then python3, then python.
# `python` is often missing from PATH on Windows; callers must not hardcode it.
function Find-PyCmd {
  foreach ($c in @('py', 'python3', 'python')) {
    $src = (Get-Command $c -ErrorAction SilentlyContinue).Source
    if (-not $src) { continue }
    try {
      & $src -c 'import sys' 2>$null | Out-Null
      if ($LASTEXITCODE -eq 0) { return $src }
    } catch { }
  }
  return $null
}

function Get-JavaFsMode {
  if (Test-Path -LiteralPath $modeFile) {
    try {
      $m = ([IO.File]::ReadAllText($modeFile, [Text.Encoding]::ASCII)).Trim()
      if ($m -eq 'encrypted' -or $m -eq 'plain') { return $m }
    } catch { }
  }
  # Fallback probe via python; conservative default 'encrypted' (legacy).
  $py = Find-PyCmd
  if ($py) {
    $m = (& $py $ioPy mode 2>$null | Select-Object -First 1)
    if ($m -eq 'encrypted' -or $m -eq 'plain') { return $m }
  }
  return 'encrypted'
}
$script:jfMode = Get-JavaFsMode

function Get-Python {
  $py = Find-PyCmd
  if (-not $py) { Write-Error 'python not found (tried py/python3/python). java-fs requires a python interpreter (CDG whitelist).' -ErrorAction Stop; exit 1 }
  return $py
}

# --- legacy plaintext read (byte-exact via base64 -> string; no \r\r\n on PS5.1) ---
function Read-JavaFile([string]$path) {
  if (-not (Test-Path -LiteralPath $path)) { Write-Error ("not found: $path") -ErrorAction Stop; exit 1 }
  if ($script:jfMode -eq 'plain') {
    return [IO.File]::ReadAllText($path, [Text.Encoding]::UTF8)
  }
  $py = Get-Python
  $b64 = & $py $ioPy read-b64 $path
  if ($LASTEXITCODE -ne 0) { Write-Error ("python read failed (exit $LASTEXITCODE)") -ErrorAction Stop; exit 1 }
  $bytes = [Convert]::FromBase64String(($b64 -join '').Trim())
  [Text.Encoding]::UTF8.GetString($bytes)
}

# --- byte-exact read: base64 single line ---
function Read-JavaFileB64([string]$path) {
  if (-not (Test-Path -LiteralPath $path)) { Write-Error ("not found: $path") -ErrorAction Stop; exit 1 }
  if ($script:jfMode -eq 'plain') {
    return [Convert]::ToBase64String([IO.File]::ReadAllBytes($path))
  }
  $py = Get-Python
  & $py $ioPy read-b64 $path
  if ($LASTEXITCODE -ne 0) { Write-Error ("python read failed (exit $LASTEXITCODE)") -ErrorAction Stop; exit 1 }
}

# --- legacy write: content arg or stdin (plain text; CJK unsafe via PS pipeline) ---
function Write-JavaFile([string]$path, [string]$content) {
  $bytes = [Text.Encoding]::UTF8.GetBytes($content)
  $b64 = [Convert]::ToBase64String($bytes)
  $b64File = Join-Path $env:TEMP ("jf_write_" + [IO.Path]::GetRandomFileName() + ".b64")
  try {
    [IO.File]::WriteAllText($b64File, $b64, [Text.Encoding]::ASCII)
    Write-JavaFileB64 $path $b64File
  } finally {
    Remove-Item $b64File -Force -ErrorAction SilentlyContinue
  }
}

# --- byte-exact write: base64 file (CJK-safe, large-file safe, verifies) ---
function Write-JavaFileB64([string]$path, [string]$b64File) {
  if (-not (Test-Path -LiteralPath $b64File)) { Write-Error ("b64 file not found: $b64File") -ErrorAction Stop; exit 1 }
  if ($script:jfMode -eq 'plain') {
    $b64 = ([IO.File]::ReadAllText($b64File, [Text.Encoding]::ASCII)).Trim()
    $bytes = [Convert]::FromBase64String($b64)
    $dir = Split-Path -Parent $path
    if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    [IO.File]::WriteAllBytes($path, $bytes)
    return
  }
  $py = Get-Python
  & $py $ioPy write-b64 $path $b64File
  if ($LASTEXITCODE -ne 0) { Write-Error ("python write failed (exit $LASTEXITCODE)") -ErrorAction Stop; exit 1 }
}

function Get-ServerPort {
  # returns active server port, or 0 if none
  if (Test-Path $portFile) {
    $p = [int](Get-Content $portFile -Raw).Trim()
    try {
      $r = Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:$p/health" -TimeoutSec 2 -ErrorAction Stop
      if ($r.StatusCode -eq 200) { return $p }
    } catch { }
    Remove-Item $portFile -Force -ErrorAction SilentlyContinue
  }
  return 0
}

switch ($Op) {
  'read' {
    if (-not $Path) { Write-Error 'usage: java_fs.ps1 read <path>'; exit 1 }
    Read-JavaFile $Path
  }
  'read-b64' {
    if (-not $Path) { Write-Error 'usage: java_fs.ps1 read-b64 <path>'; exit 1 }
    Read-JavaFileB64 $Path
  }
  'write' {
    if (-not $Path) { Write-Error 'usage: java_fs.ps1 write <path> [content]'; exit 1 }
    if (-not $PSBoundParameters.ContainsKey('Content')) {
      $Content = [Console]::In.ReadToEnd()
    }
    Write-JavaFile $Path $Content
  }
  'write-b64' {
    if (-not $Path -or -not $Content) { Write-Error 'usage: java_fs.ps1 write-b64 <path> <b64file>'; exit 1 }
    Write-JavaFileB64 $Path $Content
  }
  'snapshot' {
    if (-not $Path) { Write-Error 'usage: java_fs.ps1 snapshot <path>'; exit 1 }
    $py = Get-Python
    & $py $ioPy snapshot $Path
    if ($LASTEXITCODE -ne 0) { Write-Error ("python snapshot failed (exit $LASTEXITCODE)") -ErrorAction Stop; exit 1 }
  }
  'restore' {
    if (-not $Path -or -not $Content) { Write-Error 'usage: java_fs.ps1 restore <path> <snapdir>'; exit 1 }
    $py = Get-Python
    & $py $ioPy restore $Path $Content
    if ($LASTEXITCODE -ne 0) { Write-Error ("python restore failed (exit $LASTEXITCODE)") -ErrorAction Stop; exit 1 }
  }
  'diff-confirm' {
    if (-not $Path -or -not $Content) { Write-Error 'usage: java_fs.ps1 diff-confirm <path> <snapdir> [outfile]'; exit 1 }
    $py = Get-Python
    & $py $ioPy diff-confirm $Path $Content
    if ($LASTEXITCODE -ne 0) { Write-Error ("python diff-confirm failed (exit $LASTEXITCODE)") -ErrorAction Stop; exit 1 }
  }
  'write-confirm' {
    if (-not $Path -or -not $Content) { Write-Error 'usage: java_fs.ps1 write-confirm <path> <b64file> [outfile]'; exit 1 }
    $py = Get-Python
    & $py $ioPy write-confirm $Path $Content
    if ($LASTEXITCODE -ne 0) { Write-Error ("python write-confirm failed (exit $LASTEXITCODE)") -ErrorAction Stop; exit 1 }
  }
  'cleanup-snapshots' {
    $py = Get-Python
    if ($Path) { & $py $ioPy cleanup-snapshots $Path } else { & $py $ioPy cleanup-snapshots }
    if ($LASTEXITCODE -ne 0) { Write-Error ("python cleanup failed (exit $LASTEXITCODE)") -ErrorAction Stop; exit 1 }
  }
  'validate-java' {
    if (-not $Path) { Write-Error 'usage: java_fs.ps1 validate-java <path> [level]'; exit 1 }
    $py = Get-Python
    if ($Content) { & $py $ioPy validate-java $Path $Content } else { & $py $ioPy validate-java $Path }
    if ($LASTEXITCODE -ne 0) { Write-Error ("python validate-java failed (exit $LASTEXITCODE)") -ErrorAction Stop; exit 1 }
  }
    'validate-text' {
        if (-not $Path) { Write-Error 'usage: java_fs.ps1 validate-text <path>'; exit 1 }
        $py = Get-Python
        & $py $ioPy validate-text $Path
        if ($LASTEXITCODE -ne 0) { Write-Error ("python validate-text failed (exit $LASTEXITCODE)") -ErrorAction Stop; exit 1 }
  }
  'env' {
    $py = Get-Python
    if ($Path -eq '-force') { & $py $ioPy env -force } else { & $py $ioPy env }
    if ($LASTEXITCODE -ne 0) { Write-Error ("python env probe failed (exit $LASTEXITCODE)") -ErrorAction Stop; exit 1 }
  }
  'mode' {
    # Native read of the cached mode file (no python dependency).
    if (Test-Path -LiteralPath $modeFile) {
      try {
        $m = ([IO.File]::ReadAllText($modeFile, [Text.Encoding]::ASCII)).Trim()
        if ($m -eq 'encrypted' -or $m -eq 'plain') { Write-Output $m; break }
      } catch { }
    }
    $py = Get-Python
    & $py $ioPy mode
    if ($LASTEXITCODE -ne 0) { Write-Error ("python mode failed (exit $LASTEXITCODE)") -ErrorAction Stop; exit 1 }
  }
  'start' {
    $py = Get-Python
    $p = Get-ServerPort
    if ($p -gt 0) { Write-Output "server already running: http://127.0.0.1:$p"; break }
    Start-Process -FilePath $py -ArgumentList $serverPy -WindowStyle Hidden | Out-Null
    $p = 0
    for ($i = 0; $i -lt 10; $i++) {
      Start-Sleep -Milliseconds 1000
      $p = Get-ServerPort
      if ($p -gt 0) { break }
    }
    if ($p -gt 0) { Write-Output "server started: http://127.0.0.1:$p" } else { Write-Error 'server start failed (10s timeout)'; exit 1 }
  }
  'stop' {
    $py = Get-Python
    & $py "$serverPy" --stop 2>$null | Out-Null
    Write-Output 'server stopped'
  }
  'status' {
    $p = Get-ServerPort
    if ($p -gt 0) { Write-Output "status: running http://127.0.0.1:$p" } else { Write-Output 'status: not running' }
  }
  'help' {
    Write-Output 'java_fs.ps1 - Java encrypted file proxy (unified edition)'
    Write-Output '  read  <path>              read .java plaintext (byte-exact via base64, no \r\r\n)'
    Write-Output '  read-b64 <path>           read as base64 single line (byte-exact, preferred)'
    Write-Output '  write <path> [content]    write (content arg ASCII-safe; stdin CJK-unsafe)'
    Write-Output '  write-b64 <path> <file>   write from base64 file (byte-exact, CJK-safe, preferred)'
    Write-Output '  snapshot <path>           back up original bytes (original.b64 + meta)'
    Write-Output '  restore <path> <snapdir>  restore from snapshot, verify'
    Write-Output '  diff-confirm <path> <snapdir>  diff + corruption report vs snapshot'
    Write-Output '  write-confirm <path> <b64file> snapshot -> write-b64 -> diff report (recommended)'
    Write-Output '  cleanup-snapshots [hours] remove stale snapshots (default 24h)'
    Write-Output '  validate-java <path> [level] basic|syntax|compile check (JAVAFS_VERIFY_LEVEL)
  validate-text <path>  generic text check (vue/js/ts/xml/json/yaml/md)'
    Write-Output '  env [-force]             probe + cache machine mode (encrypted|plain)'
    Write-Output '  mode                      print machine mode (cached or probe)'
    Write-Output '  start | stop | status     manage optional proxy server'
  }
}
