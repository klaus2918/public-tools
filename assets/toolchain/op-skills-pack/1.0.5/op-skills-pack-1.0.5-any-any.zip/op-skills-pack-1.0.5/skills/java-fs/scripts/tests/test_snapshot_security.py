# -*- coding: utf-8 -*-
"""restore 快照完整性冒烟（第5组轮57 固化）
覆盖：正常快照恢复 OK、快照损坏（sha256 失配）拒绝恢复、metadata 损坏拒绝恢复、
cleanup 负值边界防御。
用法：python -X utf8 test_snapshot_security.py
"""
import io
import json
import os
import shutil
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import java_fs_io as J

ok = True


def check(name, cond, detail=''):
    global ok
    print(('[GREEN] ' if cond else '[FAIL] ') + name + ('' if cond else ' | ' + detail))
    if not cond:
        ok = False


def main():
    d = tempfile.mkdtemp(prefix='snap_sec_')
    try:
        target = os.path.join(d, 'Test.java')
        original = b'public class Test {}\n'
        io.open(target, 'wb').write(original)

        # 1. 正常 snapshot + restore
        snap = J.snapshot(target)
        check('snapshot 生成 metadata', os.path.isfile(os.path.join(snap, 'metadata.json')))
        io.open(target, 'wb').write(b'public class Changed {}\n')
        n = J.restore(target, snap)
        check('正常 restore 恢复', n == len(original) and io.open(target, 'rb').read() == original)

        # 2. 快照 b64 被篡改 -> 拒绝恢复（fail-closed）
        io.open(target, 'wb').write(b'public class Changed2 {}\n')
        tampered = os.path.join(snap, 'original.b64')
        with io.open(tampered, 'r', encoding='ascii') as f:
            b64 = f.read().strip()
        b64 = b64[:-2] + ('AA' if not b64.endswith('AA') else 'BB')  # 篡改尾部
        io.open(tampered, 'w', encoding='ascii').write(b64)
        try:
            J.restore(target, snap)
            check('篡改快照拒绝恢复', False, '未抛异常')
        except IOError as e:
            check('篡改快照拒绝恢复', 'sha256 mismatch' in str(e), str(e)[:80])
        # 目标未被写坏
        check('目标保持未污染', io.open(target, 'rb').read() == b'public class Changed2 {}\n')

        # 3. metadata 损坏 -> 拒绝恢复
        io.open(os.path.join(snap, 'metadata.json'), 'w', encoding='utf-8').write('{broken json')
        try:
            J.restore(target, snap)
            check('metadata 损坏拒绝恢复', False, '未抛异常')
        except IOError as e:
            check('metadata 损坏拒绝恢复', 'metadata' in str(e), str(e)[:80])

        # 4. cleanup 负值边界（不删除全部）
        kept, removed = J.cleanup_snapshots(os.path.join(d, 'no-such-base'), -5)
        check('cleanup 负值防御', kept == 0 and removed == 0)
    finally:
        shutil.rmtree(d, ignore_errors=True)

    print('=== snapshot 安全冒烟%s ===' % ('全部通过' if ok else '存在失败'))
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
