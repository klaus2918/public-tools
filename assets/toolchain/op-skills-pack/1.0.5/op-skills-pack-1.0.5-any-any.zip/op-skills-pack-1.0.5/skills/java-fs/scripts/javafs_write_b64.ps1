param(
  [Parameter(Mandatory=$true)][string]$B64File,
  [Parameter(Mandatory=$true)][string]$Path
)
# =====================================================================
# javafs_write_b64.ps1 - backward-compatible alias for write-b64
# =====================================================================
# Delegates to java_fs.ps1 write-b64 (byte-exact base64 channel).
# Kept for callers that already reference this script by name.
# ASCII-only file: PS 5.1 parses .ps1 without BOM as ANSI/GBK.
# =====================================================================
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
& (Join-Path $scriptDir 'java_fs.ps1') write-b64 $Path $B64File
exit $LASTEXITCODE
