#!/usr/bin/env python3
"""
op-docgen 文档渲染引擎。

支持：
- 模板选择（assets/skeletons/*.md.j2）
- 数据填充（JSON 数据注入 Jinja2 上下文）
- Markdown 初稿生成
- DOCX 产物渲染（基于 python-docx）
- 占位符清单输出

使用示例：
    python op-docgen/scripts/docgen.py \
        --skeleton user-manual \
        --skin readable \
        --data op-docgen/assets/samples/user-manual/data.json \
        --out /tmp/op-docgen-user-manual
"""

import argparse
import base64
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


# 模块内常量：关键路径
SKILL_DIR = Path(__file__).resolve().parent.parent
ASSETS_DIR = SKILL_DIR / "assets"
SKELETONS_DIR = ASSETS_DIR / "skeletons"
STYLES_DIR = SKILL_DIR / "styles"
DEFAULT_STYLE_PATH = STYLES_DIR / "default.json"
SKINS_DIR = STYLES_DIR / "skins"

# 占位符正则：匹配 [待补充：...]、[待确认：...]、[示例：...]
PLACEHOLDER_RE = re.compile(
    r"(\[待补充：[^\]]*\]|\[待确认：[^\]]*\]|\[示例：[^\]]*\])"
)

# 图片行正则：匹配 ![图注](路径)，图片是「可替换变量」，缺图不阻塞初稿
IMG_LINE_RE = re.compile(r"^!\[(?P<alt>[^\]]*)\]\((?P<path>[^)]*)\)\s*$")

# 图片采集要求行正则：匹配 > 图 1 采集要求：… 或 > 图 3-1 采集要求：…
CAPTION_LINE_RE = re.compile(
    r"^>\s*图\s*(?P<fig>\d+(?:-\d+)?)\s*采集要求[:：]\s*(?P<note>.*)$"
)

# 列表行正则：有序步骤与无序要点
ORDERED_LINE_RE = re.compile(r"^(?P<num>\d+)\.\s+(?P<body>.+)$")
BULLET_LINE_RE = re.compile(r"^[-*]\s+(?P<body>.+)$")


def is_table_separator(row: str) -> bool:
    """判断 Markdown 表格分隔行，例如 | --- | :---: |。"""
    cells = [cell.strip() for cell in row.strip().strip("|").split("|")]
    meaningful = [cell for cell in cells if cell]
    if not meaningful:
        return False
    return all(re.fullmatch(r":?-{2,}:?", cell) for cell in meaningful)


def mark_paragraph_as_caption(document: Any, paragraph: Any) -> None:
    """为图注类段落套用 Caption 样式：字体仍由 run 级设置决定，
    同时避免被 validate.py 的正文样式检查误判（该检查跳过带样式的段落）。"""
    try:
        paragraph.style = document.styles["Caption"]
    except Exception:
        pass


# ── 版式能力：段落底纹／边框、单元格底纹、表格边框、页脚页码、封面、图位框 ──

# 行内富文本标记：**加粗** 与 ![图注](路径)（内联按钮图等）
INLINE_TOKEN_RE = re.compile(r"(\*\*[^*]+\*\*|!\[[^\]]*\]\([^)]*\)|「[^」]*」)")


def add_paragraph_shading(paragraph: Any, fill: str) -> None:
    """给段落加底纹（提示块背景）。"""
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    pPr = paragraph._p.get_or_add_pPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill.lstrip("#"))
    pPr.append(shd)


def add_paragraph_left_border(paragraph: Any, color: str, width_pt: float) -> None:
    """给段落加左侧竖条（提示块强调线）。"""
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    pPr = paragraph._p.get_or_add_pPr()
    bdr = OxmlElement("w:pBdr")
    left = OxmlElement("w:left")
    left.set(qn("w:val"), "single")
    left.set(qn("w:sz"), str(max(2, int(round(width_pt * 8)))))
    left.set(qn("w:space"), "6")
    left.set(qn("w:color"), color.lstrip("#"))
    bdr.append(left)
    pPr.append(bdr)


def set_cell_shading(cell: Any, fill: str) -> None:
    """给表格单元格加底纹（表头、图位框）。"""
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill.lstrip("#"))
    tcPr.append(shd)


def set_table_borders(table: Any, color: str = "#BFBFBF", width_pt: float = 0.5, style: str = "single") -> None:
    """设置表格边框颜色与线宽（覆盖 Table Grid 的默认黑粗线）。"""
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    tblPr = table._tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), style)
        el.set(qn("w:sz"), str(max(2, int(round(width_pt * 8)))))
        el.set(qn("w:space"), "0")
        el.set(qn("w:color"), color.lstrip("#"))
        borders.append(el)
    tblPr.append(borders)


def add_footer_page_number(document: Any, style: dict) -> None:
    """页脚居中页码（PAGE 域）。"""
    if not style.get("metadata", {}).get("footer_page_number", True):
        return
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    section = document.sections[0]
    footer = section.footer
    paragraph = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = paragraph.add_run()
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    run._r.append(begin)
    run._r.append(instr)
    run._r.append(end)
    run.font.size = pt_to_emu(9)


def render_cover(document: Any, style: dict, title: str, meta_lines: list[str]) -> None:
    """封面页：大标题 + 分隔线 + 元信息（居中）。"""
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    font_cfg = style.get("font", {})
    heading_cfg = style.get("heading", {}).get("level_1", {})
    body_size = font_cfg.get("default_size_pt", 10.5)

    for _ in range(5):
        document.add_paragraph()

    p = document.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(title)
    set_run_font(
        run,
        font_cfg.get("heading_font_family", "宋体"),
        font_cfg.get("heading_ascii_family", font_cfg.get("default_ascii_family")),
        heading_cfg.get("font_size_pt", 16) + 8,
        True,
    )
    p.paragraph_format.space_after = pt_to_emu(18)

    line_p = document.add_paragraph()
    line_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    line_run = line_p.add_run("—" * 18)
    line_run.font.size = pt_to_emu(body_size)
    line_p.paragraph_format.space_after = pt_to_emu(24)

    for line in meta_lines:
        mp = document.add_paragraph()
        mp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = mp.add_run(line)
        set_run_font(
            run,
            font_cfg.get("default_family", "宋体"),
            font_cfg.get("default_ascii_family"),
            body_size + 1,
            False,
        )
        mp.paragraph_format.space_after = pt_to_emu(8)


def add_image_placeholder_box(document: Any, style: dict, caption: str, rel_path: str) -> None:
    """图位框：浅灰底纹 + 细边框的占位区域，代替「一行大字」。

    图片是待补入的可替换数据；此处明确标出图号、图注与文件路径，
    人工补图后重新渲染即自动替换为真实图片。
    """
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Cm, RGBColor

    img_cfg = style.get("image", {})
    caption_size = img_cfg.get("caption_font_size_pt", 9)

    table = document.add_table(rows=1, cols=1)
    set_table_borders(table, "#C7CDD6", 0.75, "dashed")
    row = table.rows[0]
    try:
        row.height = Cm(3.2)
    except Exception:
        pass
    cell = row.cells[0]
    set_cell_shading(cell, "#F7F9FC")

    p = cell.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = pt_to_emu(16)
    p.paragraph_format.space_after = pt_to_emu(2)

    icon_run = p.add_run("［图位］")
    apply_font(icon_run, style, caption_size + 1, bold=True)
    icon_run.font.color.rgb = RGBColor(0x64, 0x74, 0x8B)

    cap_run = p.add_run(caption or "未命名插图")
    apply_font(cap_run, style, caption_size + 1, bold=True)
    cap_run.font.color.rgb = RGBColor(0x33, 0x41, 0x55)

    path_p = cell.add_paragraph()
    path_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    path_p.paragraph_format.space_after = pt_to_emu(16)
    path_run = path_p.add_run(f"待补入：{rel_path or '未指定路径'}")
    apply_font(path_run, style, caption_size)
    path_run.font.color.rgb = RGBColor(0x8A, 0x94, 0xA6)


DEFAULT_IMAGE_RATIO = 0.62  # 占位图默认高宽比（常见整屏截图约 16:10）


def make_placeholder_image(path: Any, caption: str, width_mm: float, height_mm: float) -> bool:
    """生成与最终图片同尺寸的占位图。

    人工补图时只需用真实截图覆盖同名文件，再重新渲染即可：
    不需要删除正文里的任何行、也不需要调整图片样式。
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:
        # 无 Pillow 时回退为 1×1 空图，Word 会按目标尺寸拉伸显示
        path.write_bytes(base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M/wHwAE/wH/c8lL4wAAAABJRU5ErkJggg=="))
        return True

    scale = 4  # ≈100dpi
    w = max(int(width_mm * scale), 100)
    h = max(int(height_mm * scale), 100)
    img = Image.new("RGB", (w, h), "#FFFFFF")
    draw = ImageDraw.Draw(img)
    draw.rectangle([0, 0, w - 1, h - 1], outline="#DCE0E6", width=2)
    # 图片位标记：极浅对角斜线（不用灰底大色块，避免抢占正文视觉）
    step = max(18, int(min(w, h) * 0.06))
    for k in range(-h, w + h, step):
        draw.line([(k, 0), (k + h, h)], fill="#F3F5F8", width=1)
        draw.line([(k, h), (k + h, 0)], fill="#F3F5F8", width=1)

    font = None
    size = max(12, int(h * 0.035))
    for candidate in (r"C:\Windows\Fonts\msyh.ttc", r"C:\Windows\Fonts\simsun.ttc"):
        if Path(candidate).exists():
            try:
                font = ImageFont.truetype(candidate, size)
                break
            except Exception:
                font = None
    if font is None:
        font = ImageFont.load_default()

    texts = [caption or "图片位", "待补截图"]
    line_h = size + 6
    y = (h - line_h * len(texts)) // 2
    for idx, text in enumerate(texts):
        try:
            tw = draw.textlength(text, font=font)
        except Exception:
            tw = len(text) * size * 0.6
        draw.text(((w - tw) / 2, y), text, fill="#95A0B0" if idx else "#6B7686", font=font)
        y += line_h
    img.save(str(path))
    return True


def render_inline_text(
    document: Any,
    paragraph: Any,
    text: str,
    style: dict,
    size_pt: float,
    base_dir: Any,
    placeholders: set | None = None,
) -> None:
    """渲染行内富文本：**加粗** 与 ![按钮图/小图](路径)。

    内联图片多为按钮或图标示意，属句子组成部分：文件缺失时输出「按钮图：xx」
    文字标记占位，保证整句仍可读（不会出现「点击，」这类缺宾语）。
    """
    from docx.shared import Mm, RGBColor

    for part in INLINE_TOKEN_RE.split(text):
        if not part:
            continue
        if part.startswith("**") and part.endswith("**") and len(part) > 4:
            run = paragraph.add_run(part[2:-2])
            apply_font(run, style, size_pt, bold=True)
        elif part.startswith("「") and part.endswith("」"):
            # 约定：按钮名／菜单名用「」包裹 → 加粗 + 强调色（皮肤 emphasis.color）
            run = paragraph.add_run(part)
            apply_font(run, style, size_pt, bold=True)
            em_color = style.get("emphasis", {}).get("color")
            if em_color:
                from docx.shared import RGBColor

                run.font.color.rgb = RGBColor.from_string(em_color.lstrip("#").upper())
        elif part.startswith("!["):
            m = IMG_LINE_RE.match(part)
            if not m:
                continue
            alt = m.group("alt").strip()
            rel = m.group("path").strip()
            img_path = Path(rel)
            if rel and not img_path.is_absolute() and base_dir is not None:
                img_path = Path(base_dir) / rel
            inline_h_mm = style.get("image", {}).get("inline_height_mm", 5.5)
            if rel and not rel.startswith("["):
                source = img_path
                if not img_path.is_file():
                    ph_path = img_path.parent / "_placeholder" / img_path.name
                    if (
                        make_placeholder_image(ph_path, alt, inline_h_mm * 3.2, inline_h_mm)
                        and placeholders is not None
                    ):
                        placeholders.add(str(img_path.resolve()))
                    source = ph_path
                if source.is_file():
                    try:
                        run = paragraph.add_run()
                        run.add_picture(str(source), height=Mm(inline_h_mm))
                        continue
                    except Exception:
                        pass
            run = paragraph.add_run(f"〔{alt or '图'}〕")
            apply_font(run, style, size_pt)
            run.font.color.rgb = RGBColor(0x8A, 0x94, 0xA6)
        else:
            run = paragraph.add_run(part)
            apply_font(run, style, size_pt)


def load_json(path: Path) -> dict:
    """读取 JSON 文件。"""
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def merge_style(default: dict, override: dict) -> dict:
    """深度合并两个字典，override 覆盖 default。"""
    result = {}
    for key in set(default.keys()) | set(override.keys()):
        if key in override and key in default:
            if isinstance(default[key], dict) and isinstance(override[key], dict):
                result[key] = merge_style(default[key], override[key])
            else:
                result[key] = override[key]
        elif key in override:
            result[key] = override[key]
        else:
            result[key] = default[key]
    return result


def load_style(skin_name: str | None) -> dict:
    """加载默认样式，并按需合并指定皮肤。"""
    style = load_json(DEFAULT_STYLE_PATH)
    if skin_name:
        skin_path = SKINS_DIR / f"{skin_name}.json"
        if not skin_path.exists():
            raise FileNotFoundError(f"皮肤不存在: {skin_path}")
        skin = load_json(skin_path)
        style = merge_style(style, skin)
    return style


def extract_placeholders(text: str) -> list[dict]:
    """从文本中提取占位符，返回包含类型、标签、原始文本的字典列表。"""
    placeholders = []
    for match in PLACEHOLDER_RE.finditer(text):
        raw = match.group(1)
        # 解析占位符类型与标签内容
        if raw.startswith("[待补充："):
            kind = "missing"
        elif raw.startswith("[待确认："):
            kind = "confirm"
        elif raw.startswith("[示例："):
            kind = "example"
        else:
            kind = "unknown"
        label = raw[raw.find("：") + 1 : -1]
        placeholders.append(
            {
                "kind": kind,
                "label": label,
                "raw": raw,
            }
        )
    return placeholders


def extract_images(markdown_text: str, base_dir: Path | None = None) -> list[dict]:
    """提取图片引用，生成图片清单：图注、路径、是否已就位、采集要求。

    图片是「可替换变量」：缺图不阻塞初稿，清单供人工按图号补图。
    """
    items: list[dict] = []
    lines = markdown_text.splitlines()
    block_lines = {i for i, line in enumerate(lines) if IMG_LINE_RE.match(line.strip())}
    for idx, line in enumerate(lines):
        for m in re.finditer(r"!\[(?P<alt>[^\]]*)\]\((?P<path>[^)]*)\)", line):
            alt = m.group("alt").strip()
            rel = m.group("path").strip()
            is_block = idx in block_lines
            requirement = ""
            if is_block:
                for follow in lines[idx + 1 : idx + 3]:
                    mc = CAPTION_LINE_RE.match(follow.strip())
                    if mc:
                        requirement = mc.group("note").strip()
                        break
            path = Path(rel)
            if base_dir is not None and rel and not path.is_absolute():
                path = base_dir / rel
            exists = bool(rel) and not rel.startswith("[") and path.is_file()
            # 图片分类：按钮/图标类属句子组成部分，整屏截图属版面图
            if alt.startswith("按钮") or alt.startswith("图标"):
                kind = "button"
            elif alt.startswith("流程"):
                kind = "flow"
            else:
                kind = "screenshot"
            items.append(
                {
                    "kind": kind,
                    "placement": "block" if is_block else "inline",
                    "caption": alt,
                    "path": rel,
                    "exists": exists,
                    "requirement": requirement,
                }
            )
    return items


def coerce_param(value: str) -> Any:
    """--param 取值转换：优先按 JSON 解析（数字/布尔/数组），失败则按字符串。"""
    try:
        return json.loads(value)
    except (json.JSONDecodeError, TypeError):
        return value


def render_markdown(skeleton_name: str, data: dict) -> str:
    """使用 Jinja2 渲染 Markdown 初稿。"""
    try:
        from jinja2 import Environment, FileSystemLoader
    except ImportError as exc:
        raise ImportError(
            "渲染骨架需要 jinja2，请安装：pip install jinja2"
        ) from exc

    env = Environment(
        loader=FileSystemLoader(str(SKELETONS_DIR)),
        autoescape=False,  # Markdown 渲染不转义 HTML；select_autoescape 参数因 jinja2 版本而异（3.1.6 仅 default_for_string/default）
    )
    template = env.get_template(f"{skeleton_name}.md.j2")
    return template.render(**data)


def pt_to_emu(pt: float) -> int:
    """磅值转 EMU（Office 长度单位）。"""
    return int(pt * 12700)


def mm_to_emu(mm: float) -> int:
    """毫米转 EMU（1mm = 36000 EMU；914400/25.4）。3R2 实战修复：原 *360000 放大 10 倍致页边距 254mm。"""
    return int(mm * 36000)


def ensure_docx_imports() -> Any:
    """确保 python-docx 可用并返回 docx 模块。"""
    try:
        import docx
    except ImportError as exc:
        raise ImportError(
            "渲染 DOCX 需要 python-docx，请安装：pip install python-docx"
        ) from exc
    return docx


def apply_page_setup(section, style: dict) -> None:
    """将样式配置中的页面设置应用到 DOCX section。"""
    page = style.get("page", {})
    section.page_width = mm_to_emu(page.get("width_mm", 210))
    section.page_height = mm_to_emu(page.get("height_mm", 297))
    section.top_margin = mm_to_emu(page.get("margin_top_mm", 25.4))
    section.bottom_margin = mm_to_emu(page.get("margin_bottom_mm", 25.4))
    section.left_margin = mm_to_emu(page.get("margin_left_mm", 31.7))
    section.right_margin = mm_to_emu(page.get("margin_right_mm", 31.7))
    section.header_distance = mm_to_emu(page.get("header_distance_mm", 15))
    section.footer_distance = mm_to_emu(page.get("footer_distance_mm", 15))


def set_run_font(
    run: Any,
    family: str,
    ascii_family: str | None = None,
    size_pt: float | None = None,
    bold: bool = False,
    color: str | None = None,
) -> None:
    """设置 run 的字体、字号、加粗与颜色。

    注意两点：
    1. python-docx 的 run.font.name 只写西文字体（w:ascii / w:hAnsi），中文必须显式写入
       w:rFonts/@w:eastAsia，否则中文字形会落回 Word 默认字体（表现为「设了宋体没生效」）。
    2. add_heading 会套用内置 Heading 样式（默认蓝色），必须显式覆盖颜色，否则标题不是黑的。
    """
    from docx.oxml.ns import qn

    run.font.name = ascii_family or family
    if size_pt is not None:
        run.font.size = pt_to_emu(size_pt)
    run.bold = bold
    if color:
        from docx.shared import RGBColor

        run.font.color.rgb = RGBColor.from_string(color.lstrip("#").upper())

    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.get_or_add_rFonts()
    rFonts.set(qn("w:eastAsia"), family)
    if ascii_family:
        rFonts.set(qn("w:ascii"), ascii_family)
        rFonts.set(qn("w:hAnsi"), ascii_family)


def apply_font(run, style: dict, size_pt: float | None = None, bold: bool = False) -> None:
    """应用正文样式到 run（含中文字体）。"""
    font_config = style.get("font", {})
    set_run_font(
        run,
        font_config.get("default_family", "宋体"),
        font_config.get("default_ascii_family"),
        size_pt if size_pt is not None else font_config.get("default_size_pt", 10.5),
        bold,
    )


MANUAL_STYLES = {
    "ManualTitle": {"size": 22, "bold": False, "align": "center", "before": 0, "after": 18, "outline": 0},
    "ManualH1": {"size": 22, "bold": True, "align": "left", "before": 18, "after": 6, "outline": 1},
    "ManualH2": {"size": 16, "bold": True, "align": "left", "before": 12, "after": 4, "outline": 2},
    "ManualBody": {"size": 14, "bold": False, "align": "left", "before": 0, "after": 6, "indent_chars": 2},
    "ManualCaption": {"size": 10.5, "bold": False, "align": "center", "before": 6, "after": 12},
}


def ensure_styles(document: Any, style: dict) -> None:
    """定义文档级命名样式（中文字体 + 大纲级别 + 字符单位缩进）。

    参考 minimax-docx 规范修正三处专业做法：
    1. 格式应由命名样式承载，而不是只写 run 级直接格式——否则 Word 样式面板与导航窗格都不认；
    2. 标题样式必须带 w:outlineLvl（H1→0、H2→1），否则 TOC 与导航失效；
    3. 中文首行缩进用 w:firstLineChars（字符单位，随字号缩放），而非固定 DXA。
    同时写入 DocDefaults 的 w:eastAsia 中文字体，避免中文字形落回 Word 默认字体。
    """
    from docx.enum.style import WD_STYLE_TYPE
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Pt

    font_cfg = style.get("font", {})
    east = font_cfg.get("default_family", "宋体")
    ascii_font = font_cfg.get("default_ascii_family", "Times New Roman")
    line_spacing = font_cfg.get("line_spacing", 1.5)
    align_map = {
        "center": WD_ALIGN_PARAGRAPH.CENTER,
        "left": WD_ALIGN_PARAGRAPH.LEFT,
        "justify": WD_ALIGN_PARAGRAPH.JUSTIFY,
    }

    styles_el = document.styles.element
    if styles_el.find(qn("w:docDefaults")) is None:
        doc_defaults = OxmlElement("w:docDefaults")
        rpr_default = OxmlElement("w:rPrDefault")
        rpr = OxmlElement("w:rPr")
        rfonts = OxmlElement("w:rFonts")
        rfonts.set(qn("w:ascii"), ascii_font)
        rfonts.set(qn("w:hAnsi"), ascii_font)
        rfonts.set(qn("w:eastAsia"), east)
        rpr.append(rfonts)
        lang = OxmlElement("w:lang")
        lang.set(qn("w:val"), "en-US")
        lang.set(qn("w:eastAsia"), "zh-CN")
        rpr.append(lang)
        rpr_default.append(rpr)
        doc_defaults.append(rpr_default)
        styles_el.insert(0, doc_defaults)

    for name, cfg in MANUAL_STYLES.items():
        try:
            st = document.styles[name]
        except KeyError:
            st = document.styles.add_style(name, WD_STYLE_TYPE.PARAGRAPH)
            st.base_style = document.styles["Normal"]
        st.font.name = ascii_font
        st.font.size = Pt(cfg["size"])
        st.font.bold = cfg["bold"]

        rPr = st.element.get_or_add_rPr()
        rFonts = rPr.get_or_add_rFonts()
        rFonts.set(qn("w:ascii"), ascii_font)
        rFonts.set(qn("w:hAnsi"), ascii_font)
        rFonts.set(qn("w:eastAsia"), east)

        pf = st.paragraph_format
        pf.alignment = align_map.get(cfg.get("align", "left"), WD_ALIGN_PARAGRAPH.LEFT)
        pf.space_before = Pt(cfg.get("before", 0))
        pf.space_after = Pt(cfg.get("after", 0))
        pf.line_spacing = line_spacing

        pPr = st.element.get_or_add_pPr()
        if cfg.get("indent_chars"):
            ind = pPr.get_or_add_ind()
            ind.set(qn("w:firstLineChars"), str(cfg["indent_chars"] * 100))
            ind.set(qn("w:firstLine"), str(int(cfg["size"] * 20 * cfg["indent_chars"])))
        if cfg.get("outline") is not None:
            ol = OxmlElement("w:outlineLvl")
            ol.set(qn("w:val"), str(cfg["outline"]))
            pPr.insert_element_before(ol, "w:rPr", "w:sectPr", "w:pPrChange")


def render_docx(markdown_text: str, style: dict, output_path: Path) -> set[str]:
    """将 Markdown 文本渲染为 DOCX；返回本次自动生成的占位图路径集合。"""
    docx = ensure_docx_imports()
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    placeholder_paths: set[str] = set()
    document = docx.Document()
    ensure_styles(document, style)
    apply_page_setup(document.sections[0], style)
    add_footer_page_number(document, style)

    font_config = style.get("font", {})
    default_size = font_config.get("default_size_pt", 10.5)
    line_spacing = font_config.get("line_spacing", 1.5)
    paragraph_spacing = font_config.get("paragraph_spacing_after_pt", 6)
    paragraph_cfg = style.get("paragraph", {})
    indent_chars = paragraph_cfg.get("first_line_indent_chars", 2)
    justify = paragraph_cfg.get("align", "justify") == "justify"
    bullet_char = paragraph_cfg.get("list_bullet", "•")
    table_cfg = style.get("table", {})

    heading_cfg = style.get("heading", {})

    # 逐行解析 Markdown 简易结构
    lines = markdown_text.splitlines()

    # 封面：首个一级标题 + 紧随的引用块（直到第一个二级标题）
    cover_end = 0
    if lines and lines[0].strip().startswith("# "):
        scan = 1
        while scan < len(lines) and not lines[scan].strip().startswith("## "):
            scan += 1
        cover_end = scan
    if cover_end > 1 and style.get("metadata", {}).get("title_page", True):
        cover_meta = [
            line.strip()[2:] for line in lines[1:cover_end] if line.strip().startswith("> ")
        ]
        render_cover(document, style, lines[0].strip()[2:].strip(), cover_meta)
        document.add_page_break()
        i = cover_end
    else:
        i = 0

    # ===== 目录页：封面之后、正文之前（皮肤可用 metadata.toc 关闭）=====
    if style.get("metadata", {}).get("toc", True):
        insert_toc_at_end(document)
        document.add_page_break()
    in_code_block = False
    code_buffer: list[str] = []
    code_fence = ""

    while i < len(lines):
        line = lines[i]

        # 代码块边界
        if line.strip().startswith("```"):
            if in_code_block:
                # 结束代码块，输出缓冲内容
                code_text = "\n".join(code_buffer)
                p = document.add_paragraph()
                run = p.add_run(code_text)
                code_style = style.get("code", {})
                run.font.name = code_style.get("font_family", "Consolas")
                run.font.size = pt_to_emu(code_style.get("font_size_pt", 9))
                p.paragraph_format.space_after = pt_to_emu(paragraph_spacing)
                p.paragraph_format.line_spacing = line_spacing
                # 代码块背景色通过底纹实现（简化处理，仅设置段落边框）
                code_buffer = []
                in_code_block = False
            else:
                in_code_block = True
                code_fence = line.strip()
            i += 1
            continue

        if in_code_block:
            code_buffer.append(line)
            i += 1
            continue

        stripped = line.strip()

        # 图片行：![图 N-M 图注](路径)。有图则插图并生成图注；无图输出醒目占位块（缺图不阻塞初稿）
        m_img = IMG_LINE_RE.match(stripped)
        if m_img:
            alt = m_img.group("alt").strip()
            rel = m_img.group("path").strip()
            img_cfg = style.get("image", {})
            caption_size = img_cfg.get("caption_font_size_pt", 9)
            page = style.get("page", {})
            usable_mm = (
                page.get("width_mm", 210)
                - page.get("margin_left_mm", 31.7)
                - page.get("margin_right_mm", 31.7)
            )
            # alt 可带尺寸指令：![图·手机端截图|w=52|r=1.95](images/xx.png)
            width_mm = usable_mm * img_cfg.get("max_width_percent", 100) / 100.0
            ratio = float(img_cfg.get("default_ratio", DEFAULT_IMAGE_RATIO))
            m_w = re.search(r"\|\s*w=([\d.]+)", alt)
            m_r = re.search(r"\|\s*r=([\d.]+)", alt)
            if m_w:
                width_mm = float(m_w.group(1))
            if m_r:
                ratio = float(m_r.group(1))
            alt = re.sub(r"\|\s*[wr]=[\d.]+", "", alt).strip()
            height_mm = width_mm * ratio

            real_path = Path(rel)
            if rel and not real_path.is_absolute():
                real_path = output_path.parent / rel
            source_path = real_path
            inserted = False
            if rel and not rel.startswith("["):
                # 真图放 images/ 下；无真图时用 images/_placeholder/ 下的同尺寸占位图渲染。
                # 补图 = 把截图按文件名放进 images/ 后重新渲染，不需要改数据、不需要调样式。
                if not real_path.is_file():
                    ph_path = real_path.parent / "_placeholder" / real_path.name
                    if make_placeholder_image(ph_path, alt, width_mm, height_mm):
                        placeholder_paths.add(str(real_path.resolve()))
                    source_path = ph_path
                if source_path.is_file():
                    try:
                        from docx.shared import Mm

                        document.add_picture(str(source_path), width=Mm(width_mm))
                        document.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
                        inserted = True
                    except Exception:
                        inserted = False
            if not inserted:
                add_image_placeholder_box(document, style, alt, rel)
            prefix = img_cfg.get("caption_prefix", "图")
            caption_text = alt if alt.startswith(prefix) else f"{prefix} {alt}".strip()
            if caption_text:
                cap_p = document.add_paragraph(style="ManualCaption")
                cap_run = cap_p.add_run(caption_text)
                apply_font(cap_run, style, caption_size)
            i += 1
            continue

        # 标题
        if stripped.startswith("# "):
            cfg = heading_cfg.get("level_1", {})
            p = document.add_paragraph(stripped[2:], style="ManualTitle")
            apply_paragraph_style(p, cfg, style)
            set_outline_level(p, 0)
            i += 1
            continue
        if stripped.startswith("## "):
            cfg = heading_cfg.get("level_2", {})
            p = document.add_paragraph(stripped[3:], style="ManualH1")
            apply_paragraph_style(p, cfg, style)
            set_outline_level(p, 1)
            i += 1
            continue
        if stripped.startswith("### "):
            cfg = heading_cfg.get("level_3", {})
            p = document.add_paragraph(stripped[4:], style="ManualH2")
            apply_paragraph_style(p, cfg, style)
            set_outline_level(p, 2)
            i += 1
            continue

        # 引用块（提示块）
        if stripped.startswith("> "):
            callout_text = stripped[2:]

            # 图片采集要求行：只写入 images.json 与补图清单，不进正文，
            # 避免补图后还要回头删除正文里的提示行
            m_cap = CAPTION_LINE_RE.match(stripped)
            if m_cap:
                i += 1
                continue

            callout_type = "note"
            if stripped.startswith("> **说明**"):
                callout_type = "note"
            elif stripped.startswith("> **注意**"):
                callout_type = "warning"
            elif stripped.startswith("> **禁止**"):
                callout_type = "error"
            callout_cfg = style.get("callout", {}).get(callout_type, style.get("callout", {}).get("note", {}))
            p = document.add_paragraph()
            # 提示块：标签加粗 + 底纹 + 左侧强调线（> **说明**：正文）
            m_label = re.match(r"^\*\*(?P<label>[^*]+)\*\*[:：]?\s*(?P<rest>.*)$", callout_text)
            label = m_label.group("label") if m_label else callout_cfg.get("label", "")
            rest = m_label.group("rest") if m_label else callout_text
            if label:
                label_run = p.add_run(f"{label}：")
                apply_font(label_run, style, default_size, bold=True)
            if rest:
                body_run = p.add_run(rest)
                apply_font(body_run, style, default_size)
            if callout_cfg.get("background_color"):
                add_paragraph_shading(p, callout_cfg["background_color"])
            if callout_cfg.get("left_border_color"):
                add_paragraph_left_border(
                    p, callout_cfg["left_border_color"], callout_cfg.get("left_border_width_pt", 4)
                )
            p.paragraph_format.left_indent = pt_to_emu(6)
            p.paragraph_format.space_before = pt_to_emu(4)
            p.paragraph_format.space_after = pt_to_emu(paragraph_spacing)
            p.paragraph_format.line_spacing = line_spacing
            i += 1
            continue

        # 统一表格检测：先收集连续管道行，再判断是否含分隔行
        if stripped.startswith("|") and stripped.endswith("|"):
            # 回溯到表格第一行（允许表格行之间夹空行）
            back = i - 1
            while back >= 0:
                s_back = lines[back].strip()
                if (s_back.startswith("|") and s_back.endswith("|")) or not s_back:
                    back -= 1
                else:
                    break
            table_start = back + 1
            # 向前收集所有表格行（跳过空行，遇到非表格非空行停止）
            scan = table_start
            while scan < len(lines):
                s = lines[scan].strip()
                if s.startswith("|") and s.endswith("|"):
                    scan += 1
                elif not s:
                    scan += 1
                else:
                    break
            table_lines = [
                lines[j]
                for j in range(table_start, scan)
                if lines[j].strip().startswith("|") and lines[j].strip().endswith("|")
            ]

            # 含分隔行 → 跳过分隔行，其余为表头+数据
            separator_indices = [
                idx for idx, row in enumerate(table_lines) if is_table_separator(row)
            ]
            if separator_indices:
                data_rows = [row for idx, row in enumerate(table_lines) if idx not in separator_indices]
            elif len(table_lines) >= 2:
                # 无分隔行 → 按列数一致性判定
                col_counts = [len(parse_table_row(r)) for r in table_lines]
                if len(set(col_counts)) != 1:
                    i += 1
                    continue
                data_rows = table_lines
            else:
                i += 1
                continue

            if data_rows:
                rows = [parse_table_row(row) for row in data_rows]
                tbl = document.add_table(rows=len(rows), cols=max(len(r) for r in rows))
                tbl.style = "Table Grid"
                set_table_borders(
                    tbl,
                    table_cfg.get("border_color", "#BFBFBF"),
                    table_cfg.get("border_width_pt", 0.5),
                    table_cfg.get("border_style", "single"),
                )
                for ri, row_cells in enumerate(rows):
                    row = tbl.rows[ri]
                    for ci, cell_text in enumerate(row_cells):
                        if ci >= len(row.cells):
                            break
                        cell = row.cells[ci]
                        cell.text = ""
                        cp = cell.paragraphs[0]
                        cp.paragraph_format.space_before = pt_to_emu(2)
                        cp.paragraph_format.space_after = pt_to_emu(2)
                        cp.paragraph_format.line_spacing = 1.15
                        render_inline_text(
                            document,
                            cp,
                            cell_text,
                            style,
                            table_cfg.get("font_size_pt", default_size),
                            output_path.parent,
                            placeholders=placeholder_paths,
                        )
                        if ri == 0 and table_cfg.get("header_fill"):
                            set_cell_shading(cell, table_cfg["header_fill"])
                        if ri == 0 and table_cfg.get("header_bold"):
                            for run in cp.runs:
                                run.bold = True
            i = scan
            continue

        # 有序列表（操作步骤）：悬挂缩进，序号与正文对齐，便于快速扫读
        m_ord = ORDERED_LINE_RE.match(stripped)
        if m_ord:
            p = document.add_paragraph()
            render_inline_text(
                document,
                p,
                f"{m_ord.group('num')}. {m_ord.group('body')}",
                style,
                default_size,
                output_path.parent,
                placeholder_paths,
            )
            p.paragraph_format.left_indent = pt_to_emu(12)
            p.paragraph_format.space_after = pt_to_emu(paragraph_spacing)
            p.paragraph_format.line_spacing = line_spacing
            i += 1
            continue

        # 无序列表（结果/限制等要点）
        m_bul = BULLET_LINE_RE.match(stripped)
        if m_bul:
            p = document.add_paragraph()
            render_inline_text(
                document,
                p,
                f"{bullet_char} {m_bul.group('body')}",
                style,
                default_size,
                output_path.parent,
                placeholder_paths,
            )
            p.paragraph_format.left_indent = pt_to_emu(12)
            p.paragraph_format.space_after = pt_to_emu(paragraph_spacing)
            p.paragraph_format.line_spacing = line_spacing
            i += 1
            continue

        # 普通段落（支持 **加粗** 与行内小图）；缩进/行距/间距由 ManualBody 样式承载
        if stripped:
            p = document.add_paragraph(style="ManualBody")
            render_inline_text(document, p, stripped, style, default_size, output_path.parent, placeholder_paths)
        else:
            # 空行不创建段落，保持紧凑
            pass

        i += 1

    output_path.parent.mkdir(parents=True, exist_ok=True)
    document.save(str(output_path))
    return placeholder_paths


def apply_paragraph_style(paragraph, cfg: dict, style: dict) -> None:
    """应用标题样式配置。"""
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    font_config = style.get("font", {})
    heading_font = font_config.get("heading_font_family", font_config.get("default_family", "宋体"))
    heading_ascii = font_config.get("heading_ascii_family", font_config.get("default_ascii_family"))
    size_pt = cfg.get("font_size_pt", 10.5)
    align = cfg.get("align", "left")

    heading_color = cfg.get("color", "#000000")
    for run in paragraph.runs:
        set_run_font(run, heading_font, heading_ascii, size_pt, cfg.get("bold", True), heading_color)
    paragraph.alignment = {
        "center": WD_ALIGN_PARAGRAPH.CENTER,
        "right": WD_ALIGN_PARAGRAPH.RIGHT,
        "justify": WD_ALIGN_PARAGRAPH.JUSTIFY,
    }.get(align, WD_ALIGN_PARAGRAPH.LEFT)
    paragraph.paragraph_format.space_before = pt_to_emu(cfg.get("space_before_pt", 6))
    paragraph.paragraph_format.space_after = pt_to_emu(cfg.get("space_after_pt", 6))
    paragraph.paragraph_format.line_spacing = font_config.get("line_spacing", 1.5)


def set_outline_level(paragraph, level: int) -> None:
    """注入 Word 大纲级别，使标题可被目录识别（0=一级, 1=二级, 2=三级）。"""
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    pPr = paragraph._p.get_or_add_pPr()
    outline = OxmlElement("w:outlineLvl")
    outline.set(qn("w:val"), str(level))
    pPr.append(outline)


def insert_toc_at_end(document) -> None:
    """在文档 body 末尾追加自动目录域（适合在 Markdown 解析前调用，使目录出现在正文最前面）。"""
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    toc_p = OxmlElement("w:p")

    # PAGE 域
    r1 = OxmlElement("w:r")
    fld1 = OxmlElement("w:fldChar")
    fld1.set(qn("w:fldCharType"), "begin")
    r1.append(fld1)
    toc_p.append(r1)

    r2 = OxmlElement("w:r")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "
    r2.append(instr)
    toc_p.append(r2)

    r3 = OxmlElement("w:r")
    fld2 = OxmlElement("w:fldChar")
    fld2.set(qn("w:fldCharType"), "end")
    r3.append(fld2)
    toc_p.append(r3)

    # TOC 域
    r4 = OxmlElement("w:r")
    fld3 = OxmlElement("w:fldChar")
    fld3.set(qn("w:fldCharType"), "begin")
    r4.append(fld3)
    toc_p.append(r4)

    r5 = OxmlElement("w:r")
    instr2 = OxmlElement("w:instrText")
    instr2.set(qn("xml:space"), "preserve")
    instr2.text = ' TOC \\o "1-3" \\h \\z \\u '
    r5.append(instr2)
    toc_p.append(r5)

    r6 = OxmlElement("w:r")
    fld4 = OxmlElement("w:fldChar")
    fld4.set(qn("w:fldCharType"), "separate")
    r6.append(fld4)
    toc_p.append(r6)

    # 占位文本
    r7 = OxmlElement("w:r")
    r8 = OxmlElement("w:r")
    t = OxmlElement("w:t")
    t.text = "请右键此处→更新域→更新整个目录"
    r8.append(t)
    toc_p.append(r8)

    r9 = OxmlElement("w:r")
    fld5 = OxmlElement("w:fldChar")
    fld5.set(qn("w:fldCharType"), "end")
    r9.append(fld5)
    toc_p.append(r9)

    document.element.body.append(toc_p)


def parse_table_row(line: str) -> list[str]:
    """解析 Markdown 表格行，返回单元格文本列表。"""
    cells = line.strip().strip("|").split("|")
    return [cell.strip() for cell in cells]


def main() -> int:
    parser = argparse.ArgumentParser(description="op-docgen 文档渲染引擎")
    parser.add_argument("--skeleton", required=True, help="骨架名称，例如 api-doc")
    parser.add_argument("--skin", default=None, help="皮肤名称，例如 readable/official")
    parser.add_argument("--data", required=True, help="数据 JSON 文件路径")
    parser.add_argument("--out", required=True, help="输出目录")
    parser.add_argument(
        "--skip-docx",
        action="store_true",
        help="仅生成 Markdown 初稿与占位符清单，跳过 DOCX 渲染",
    )
    parser.add_argument(
        "--param",
        action="append",
        default=[],
        metavar="KEY=VALUE",
        help=(
            "覆盖数据文件顶层字段，可重复。用于同一份数据生成不同角色分册，"
            "例：--param role_key=admin --param role_label=管理端"
        ),
    )
    parser.add_argument(
        "--doc-name",
        default=None,
        help="输出 DOCX 文件名（默认 output.docx）：把角色区分放在文件名上，而不是文档标题里",
    )
    args = parser.parse_args()

    skeleton_path = SKELETONS_DIR / f"{args.skeleton}.md.j2"
    if not skeleton_path.exists():
        print(f"错误：骨架不存在 {skeleton_path}", file=sys.stderr)
        return 1

    data_path = Path(args.data)
    if not data_path.exists():
        print(f"错误：数据文件不存在 {data_path}", file=sys.stderr)
        return 1

    data = load_json(data_path)
    overrides: dict = {}
    for item in args.param:
        if "=" not in item:
            print(f"错误：--param 需要 KEY=VALUE 格式：{item}", file=sys.stderr)
            return 1
        key, value = item.split("=", 1)
        overrides[key.strip()] = coerce_param(value.strip())

    # variants：同一份数据内为不同角色定义差异字段（role_key 取自 --param 或数据文件）
    role_key = overrides.get("role_key", data.get("role_key"))
    variants = data.get("variants")
    if role_key and isinstance(variants, dict) and role_key in variants:
        for key, value in variants[role_key].items():
            data[key] = value

    # --param 覆盖优先于 variants
    data.update(overrides)
    # 注入全局辅助变量
    data.setdefault("generated_at", datetime.now(timezone.utc).isoformat())

    style = load_style(args.skin)

    markdown_text = render_markdown(args.skeleton, data)
    placeholders = extract_placeholders(markdown_text)
    placeholder_summary = {
        "total": len(placeholders),
        "by_kind": {},
        "items": placeholders,
    }
    for p in placeholders:
        placeholder_summary["by_kind"][p["kind"]] = (
            placeholder_summary["by_kind"].get(p["kind"], 0) + 1
        )

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    draft_path = out_dir / "draft.md"
    draft_path.write_text(markdown_text, encoding="utf-8")

    placeholders_path = out_dir / "placeholders.json"
    placeholders_path.write_text(
        json.dumps(placeholder_summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    # 图片清单：标记哪些仍是自动生成的占位图（用真实截图覆盖同名文件即可替换）
    docx_path = out_dir / (args.doc_name or "output.docx")
    placeholder_paths: set[str] = set()
    if not args.skip_docx:
        placeholder_paths = render_docx(markdown_text, style, docx_path)

    images = extract_images(markdown_text, out_dir)
    for img in images:
        target = Path(img["path"])
        if not target.is_absolute():
            target = out_dir / img["path"]
        img["placeholder"] = str(target.resolve()) in placeholder_paths
    images_summary = {
        "total": len(images),
        "pending": sum(1 for img in images if img.get("placeholder")),
        "items": images,
    }
    images_path = out_dir / "images.json"
    images_path.write_text(
        json.dumps(images_summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    # 待核对按钮清单：正文保持干净可读，需要与系统核对的按钮名集中成清单
    buttons = data.get("buttons") or []
    buttons_path = out_dir / "buttons.json"
    buttons_path.write_text(
        json.dumps({"total": len(buttons), "items": buttons}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    # 落盘生效皮肤配置快照，供 validate.py 以真实皮肤作预期校验
    # （3R2 实战修复：此前未写 .style.json，validate 回退默认页边距致 left/right 误报）
    style_path = out_dir / ".style.json"
    style_path.write_text(
        json.dumps(style, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print(f"Markdown 初稿：{draft_path}")
    print(f"占位符清单：{placeholders_path}")
    print(f"图片清单：{images_path}（待补 {images_summary['pending']} 张）")
    print(f"待核对按钮清单：{buttons_path}（{len(buttons)} 项）")
    if not args.skip_docx:
        print(f"DOCX 产物：{docx_path}")
    print(f"占位符统计：{placeholder_summary['by_kind']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
