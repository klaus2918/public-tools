# user-manual 骨架产物说明

本文件说明 `user-manual` 骨架的渲染产物、复现命令与校验要点。数据源为 `data.json`（角色化示例：军休老年大学学员端 / 管理端），结构说明见 `input.md` 与 `references/manual-writing-spec.md`。

## 1. 渲染前置

| 依赖 | 用途 | 最低版本 | 安装命令 |
|---|---|---|---|
| python-docx | DOCX 产物渲染 | 1.2.0 | `pip install python-docx` |
| jinja2 | Markdown 初稿渲染 | 3.x | `pip install jinja2` |

环境验证（2026-09-16）：本机两者**均可用**，端到端渲染通过（此前记录的「jinja2 未安装」已失效）。

## 2. 复现命令：同一份数据出两册

```powershell
# 学员册（data.json 默认 role_key=user）
python op-docgen/scripts/docgen.py --skeleton user-manual --skin readable `
  --data op-docgen/assets/samples/user-manual/data.json --out <out-user>

# 管理册（同一份数据：variants.admin 提供角色差异字段）
python op-docgen/scripts/docgen.py --skeleton user-manual --skin readable `
  --data op-docgen/assets/samples/user-manual/data.json `
  --param role_key=admin --out <out-admin>

python op-docgen/scripts/validate.py <out-user>
```

册内条目归属由 `features[].roles`、`menu_overview[].roles`、`faqs[].roles` 决定，未标记 `roles` 的默认进 `user` 册；角色专属的封面字段（`role_label` / `scope` / `out_of_scope` / 快速上手）写在数据文件的 `variants.<role_key>` 中，渲染时自动套用。

## 3. 产物清单

| 文件 | 说明 |
|---|---|
| `draft.md` | Markdown 初稿（四章制：三步上手 / 我能用的功能 / 操作说明 / 遇到问题） |
| `placeholders.json` | 占位符清单（missing / confirm / example 分类统计） |
| `images.json` | 图片清单：`total` / `pending` / `items[]`（caption、path、exists、requirement） |
| `.style.json` | 生效皮肤快照，供 `validate.py` 对比页边距等样式 |
| `output.docx` | DOCX 成品 |

实测（2026-09-16）：学员册 8 张待补图（7 个学员功能 + 1 张入口图）、管理册 6 张待补图（5 个管理功能 + 1 张入口图），角色过滤生效。

## 4. output.docx 预期内容结构

| 区块 | 说明 |
|---|---|
| 自动目录 | 文档末尾注入 TOC 域（`TOC \o "1-3"`），Word 中右键目录→更新域后显示 |
| 元信息 | 首部引用块：适用角色 / 本册覆盖 / 不在本册 / 版本与日期 |
| 标题 | 仅三级以内；四级标题在手册中不允许（validate 告警） |
| 步骤列表 | 有序列表渲染为无首行缩进段落并保留序号，便于扫读 |
| 要点列表 | `- 结果：` / `- 限制：` 渲染为「• 文本」段落 |
| 图片 | 图片文件存在时插入并生成居中图注；不存在时输出 `【待补图｜图 3-1 …｜images/…】` 占位块 |
| 采集要求 | `> 图 N-M 采集要求：…` 渲染为居中 9pt 提示行（Caption 样式），补图后整行删除 |
| 表格 | 菜单总览、常见问题、术语表渲染为 Table Grid 表格 |
| 提示块 | `> **说明**：…` 渲染为「说明：」加粗标签 + 正文 |
| 页面 | A4，页边距与字体按皮肤 page / font 配置（readable：适中页边距、宋体五号、1.5 倍行距） |

## 5. 校验要点

`validate.py` 输出四类检查：

1. 占位符统计（missing / confirm / example）；
2. 图片引用检查：不存在的路径逐条列出，不阻塞生成；
3. DOCX 样式检查：正文字号、行距、页边距与皮肤配置对比；
4. 用户手册专项（首行为 `# …操作手册` 时启用）：角色声明缺失、章节数超预算、四级标题、缺宾语写法、「第 N 步」编号重复或倒退、单功能步骤超出 7 步、图片缺图注、待补图数量。

负面样例自测（2026-09-16）：`_extract/neg-case/draft.md`（缺角色声明、四级标题、4 处缺宾语、8 步功能、第二步重复、无图注图片）→ 6 类问题全部检出，验证检查项有效。
