#!/usr/bin/env python3
"""
op-docgen 产物校验脚本。

校验项：
- 扫描 Markdown 与 DOCX 中的占位符并分类统计
- 检查 Markdown 中图片引用是否存在
- 检查 DOCX 段落样式、字体、行距、页边距是否符合皮肤配置
- 用户手册专项质量检查（角色声明、章节与层级、缺宾语写法、步骤预算、第 N 步编号、图片图注与待补状态）
- 输出校验报告，不阻塞初稿生成

使用示例：
    python op-docgen/scripts/validate.py /tmp/op-docgen-api
"""

import argparse
import json
import re
import sys
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET


# 占位符正则，与 docgen.py 保持一致
PLACEHOLDER_RE = re.compile(
    r"(\[待补充：[^\]]*\]|\[待确认：[^\]]*\]|\[示例：[^\]]*\])"
)

# XML 命名空间
DOCX_NAMESPACES = {
    "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
}


def load_json(path: Path) -> dict:
    """读取 JSON 文件。"""
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def extract_placeholders(text: str) -> list[dict]:
    """从文本中提取占位符。"""
    placeholders = []
    for match in PLACEHOLDER_RE.finditer(text):
        raw = match.group(1)
        if raw.startswith("[待补充："):
            kind = "missing"
        elif raw.startswith("[待确认："):
            kind = "confirm"
        elif raw.startswith("[示例："):
            kind = "example"
        else:
            kind = "unknown"
        label = raw[raw.find("：") + 1 : -1]
        placeholders.append(
            {
                "kind": kind,
                "label": label,
                "raw": raw,
            }
        )
    return placeholders


# 用户手册专项检查正则
MANUAL_TITLE_RE = re.compile(r"^#\s.*操作手册")
ROLE_DECL_RE = re.compile(r"适用|面向|本手册介绍")
HEADING_LEVEL4_RE = re.compile(r"^####\s")
FEATURE_HEADING_RE = re.compile(r"^###\s")
ORDERED_ITEM_RE = re.compile(r"^\d+\.\s")
STEP_WORD_RE = re.compile(r"第([一二三四五六七八九十]+)步")
CLICK_EMPTY_RE = re.compile(r"点击[，。；]|点击按钮|点击该按钮")
IMG_LINE_RE = re.compile(r"^!\[(?P<alt>[^\]]*)\]")
CAPTION_LINE_RE = re.compile(r"^>\s*图\s*\d+(?:-\d+)?\s*采集要求")
CN_NUM = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9, "十": 10}

# 用户手册结构预算（见 references/manual-writing-spec.md）
MANUAL_CHAPTER_BUDGET = 7  # 与原手册结构一致（使用网络/浏览器/登录/业务章节/技术支持）
MANUAL_STEPS_BUDGET = 7


def check_manual_quality(markdown_text: str) -> dict:
    """用户手册专项质量检查（warn 级，不阻塞生成）。

    检查：角色分层声明、章节数与层级、缺宾语写法、单功能步骤预算、
    「第 N 步」编号重复与倒退、图片图注与待补状态。
    """
    lines = markdown_text.splitlines()
    issues: list[dict] = []

    def add(code: str, message: str) -> None:
        issues.append({"level": "warning", "code": code, "message": message})

    title = next((line.strip() for line in lines if line.strip()), "")
    if not MANUAL_TITLE_RE.match(title):
        return {"applicable": False, "issues": [], "issue_count": 0, "pending_image_count": 0}

    head = "\n".join(lines[:15])
    if not ROLE_DECL_RE.search(head):
        add("role-missing", "开头未说明适用对象：读者无法判断本册面向哪一类角色")

    chapters = [
        line
        for line in lines
        if line.startswith("## ") and not line.lstrip("# ").strip().startswith("附录")
    ]
    if len(chapters) > MANUAL_CHAPTER_BUDGET:
        add(
            "chapter-count",
            f"章节数 {len(chapters)} 超过 {MANUAL_CHAPTER_BUDGET} 个：建议按角色或主题拆分分册",
        )
    for idx, line in enumerate(lines, 1):
        if HEADING_LEVEL4_RE.match(line.strip()):
            add("heading-depth", f"第 {idx} 行出现四级标题：章节层级应不超过 3 级")
            break

    empty_clicks = [line.strip() for line in lines if CLICK_EMPTY_RE.search(line)]
    if empty_clicks:
        add(
            "click-no-object",
            f"出现 {len(empty_clicks)} 处缺宾语操作（如「点击，」「点击按钮」）："
            f"按钮名须以文字写出，示例：{empty_clicks[0][:40]}",
        )

    feature = None
    step_count = 0
    for line in lines + ["### __END__"]:
        s = line.strip()
        if FEATURE_HEADING_RE.match(s):
            if feature and step_count > MANUAL_STEPS_BUDGET:
                add(
                    "steps-over-budget",
                    f"功能「{feature}」含 {step_count} 步，超过 {MANUAL_STEPS_BUDGET} 步预算",
                )
            feature = s.lstrip("# ").strip()
            step_count = 0
        elif feature and ORDERED_ITEM_RE.match(s):
            step_count += 1

    step_numbers = [
        CN_NUM[m.group(1)]
        for line in lines
        for m in [STEP_WORD_RE.search(line)]
        if m and m.group(1) in CN_NUM
    ]
    duplicates = sorted({n for n in step_numbers if step_numbers.count(n) > 1})
    if duplicates:
        add("step-number-duplicate", f"「第 N 步」编号重复：{duplicates}")
    if step_numbers != sorted(step_numbers):
        add("step-number-order", "「第 N 步」编号顺序倒退：请检查步骤编号")

    pending_images = 0
    for idx, line in enumerate(lines):
        m = IMG_LINE_RE.match(line.strip())
        if not m:
            continue
        alt = m.group("alt").strip()
        if not alt.startswith("图"):
            add("image-caption", f"第 {idx + 1} 行图片缺少「图 N-M 图注」形式的图注")
        if any(
            CAPTION_LINE_RE.match(lines[j].strip())
            for j in range(idx + 1, min(idx + 4, len(lines)))
        ):
            pending_images += 1
    if pending_images:
        add(
            "image-pending",
            f"{pending_images} 张图片处于待补状态（已登记采集要求）：交付前补齐并删除采集要求行",
        )

    return {
        "applicable": True,
        "issues": issues,
        "issue_count": len(issues),
        "pending_image_count": pending_images,
    }


def find_image_references(text: str) -> list[str]:
    """查找 Markdown 中 ![alt](path) 或 HTML img src 引用的本地图片路径。"""
    refs: list[str] = []
    # Markdown 图片语法
    for match in re.finditer(r"!\[[^\]]*\]\(([^)]+)\)", text):
        refs.append(match.group(1))
    # HTML img 标签
    for match in re.finditer(r'<img[^>]+src=["\']([^"\']+)["\']', text):
        refs.append(match.group(1))
    return refs


def check_image_exists(markdown_text: str, base_dir: Path) -> list[dict]:
    """检查 Markdown 中引用的图片文件是否实际存在。"""
    results = []
    for ref in find_image_references(markdown_text):
        # 忽略网络图片
        if ref.startswith(("http://", "https://", "data:")):
            continue
        path = base_dir / ref
        results.append(
            {
                "ref": ref,
                "exists": path.exists(),
                "resolved": str(path),
            }
        )
    return results


def load_docx_xml(docx_path: Path) -> dict[str, ET.Element]:
    """从 docx 中读取关键 XML 文件。"""
    xml_files: dict[str, ET.Element] = {}
    if not docx_path.exists():
        return xml_files
    with zipfile.ZipFile(docx_path, "r") as zf:
        for name in ["word/document.xml", "word/styles.xml"]:
            if name in zf.namelist():
                with zf.open(name) as f:
                    xml_files[name] = ET.parse(f).getroot()
    return xml_files


def get_run_font_size_pt(run: ET.Element) -> float | None:
    """从 w:rPr 中提取字号（pt）。"""
    rpr = run.find("w:rPr", DOCX_NAMESPACES)
    if rpr is None:
        return None
    sz = rpr.find("w:sz", DOCX_NAMESPACES)
    if sz is not None:
        half_pt = sz.get(f"{{{DOCX_NAMESPACES['w']}}}val")
        if half_pt is not None:
            try:
                return int(half_pt) / 2.0
            except ValueError:
                return None
    return None


def get_paragraph_property(p: ET.Element, prop_name: str) -> str | None:
    """获取段落属性值。"""
    ppr = p.find("w:pPr", DOCX_NAMESPACES)
    if ppr is None:
        return None
    prop = ppr.find(prop_name, DOCX_NAMESPACES)
    if prop is None:
        return None
    return prop.get(f"{{{DOCX_NAMESPACES['w']}}}val")


def check_docx_style(docx_path: Path, style: dict) -> list[dict]:
    """校验 DOCX 段落样式是否符合皮肤配置。"""
    issues: list[dict] = []
    if not docx_path.exists():
        issues.append(
            {
                "level": "warning",
                "message": f"DOCX 产物不存在: {docx_path}",
            }
        )
        return issues

    xml_files = load_docx_xml(docx_path)
    if "word/document.xml" not in xml_files:
        issues.append(
            {
                "level": "error",
                "message": "DOCX 中未找到 word/document.xml",
            }
        )
        return issues

    font_config = style.get("font", {})
    expected_size = font_config.get("default_size_pt", 10.5)
    expected_line_spacing = font_config.get("line_spacing", 1.5)

    page = style.get("page", {})
    # python-docx 默认单位转换检查

    root = xml_files["word/document.xml"]
    body = root.find("w:body", DOCX_NAMESPACES)
    if body is None:
        issues.append(
            {
                "level": "error",
                "message": "未找到 DOCX body 节点",
            }
        )
        return issues

    for p in body.findall("w:p", DOCX_NAMESPACES):
        pstyle = get_paragraph_property(p, "w:pStyle")
        # 正文段落检查默认字号
        if pstyle is None:
            for run in p.findall("w:r", DOCX_NAMESPACES):
                size = get_run_font_size_pt(run)
                if size is not None and abs(size - expected_size) > 0.5:
                    issues.append(
                        {
                            "level": "warning",
                            "message": f"正文字号 {size} pt 与预期 {expected_size} pt 不符",
                        }
                    )

        # 行距检查
        spacing = p.find("w:pPr/w:spacing", DOCX_NAMESPACES)
        if spacing is not None:
            line_val = spacing.get(f"{{{DOCX_NAMESPACES['w']}}}line")
            line_rule = spacing.get(f"{{{DOCX_NAMESPACES['w']}}}lineRule")
            if line_val is not None and line_rule == "auto":
                # auto 行距值为 240 的倍数
                actual = int(line_val) / 240.0
                if abs(actual - expected_line_spacing) > 0.05:
                    issues.append(
                        {
                            "level": "warning",
                            "message": f"段落行距 {actual} 与预期 {expected_line_spacing} 不符",
                        }
                    )

    # 校验 sectPr 中的页边距
    sect_pr = body.find("w:sectPr", DOCX_NAMESPACES)
    if sect_pr is not None:
        pg_mar = sect_pr.find("w:pgMar", DOCX_NAMESPACES)
        if pg_mar is not None:
            margin_map = {
                "top": page.get("margin_top_mm", 25.4),
                "bottom": page.get("margin_bottom_mm", 25.4),
                "left": page.get("margin_left_mm", 31.7),
                "right": page.get("margin_right_mm", 31.7),
            }
            for attr, expected_mm in margin_map.items():
                val = pg_mar.get(f"{{{DOCX_NAMESPACES['w']}}}{attr}")
                if val is not None:
                    actual_mm = int(val) / 1440.0 * 25.4
                    if abs(actual_mm - expected_mm) > 2.0:
                        issues.append(
                            {
                                "level": "warning",
                                "message": f"页边距 {attr} {actual_mm:.1f} mm 与预期 {expected_mm} mm 偏差过大",
                            }
                        )

    return issues


def validate_output_dir(out_dir: Path) -> dict:
    """校验输出目录中的产物并返回报告。"""
    report: dict = {
        "target": str(out_dir),
        "valid": True,
        "markdown": {},
        "docx": {},
        "summary": {},
    }

    draft_path = out_dir / "draft.md"
    docx_path = out_dir / "output.docx"
    if not docx_path.exists():
        # 兼容自定义文件名（--doc-name）
        candidates = sorted(out_dir.glob("*.docx"))
        if candidates:
            docx_path = candidates[0]
    placeholders_path = out_dir / "placeholders.json"
    style_path = out_dir / ".style.json"

    # Markdown 校验
    if draft_path.exists():
        markdown_text = draft_path.read_text(encoding="utf-8")
        placeholders = extract_placeholders(markdown_text)
        images = check_image_exists(markdown_text, out_dir)
        missing_images = [img for img in images if not img["exists"]]
        report["markdown"] = {
            "exists": True,
            "placeholder_count": len(placeholders),
            "placeholders_by_kind": {},
            "image_refs": len(images),
            "missing_images": len(missing_images),
            "missing_image_list": missing_images,
        }
        for p in placeholders:
            kind = p["kind"]
            report["markdown"]["placeholders_by_kind"][kind] = (
                report["markdown"]["placeholders_by_kind"].get(kind, 0) + 1
            )
    else:
        report["markdown"] = {"exists": False}
        report["valid"] = False

    # 用户手册专项质量检查（warn 级，不阻塞生成）
    if draft_path.exists():
        manual = check_manual_quality(draft_path.read_text(encoding="utf-8"))
    else:
        manual = {"applicable": False, "issues": [], "issue_count": 0, "pending_image_count": 0}

    # 以 images.json 的 placeholder 标记为准（缺图时 docgen 会生成同尺寸占位图）
    images_path = out_dir / "images.json"
    if manual.get("applicable") and images_path.exists():
        try:
            images_data = load_json(images_path)
            pending = sum(1 for item in images_data.get("items", []) if item.get("placeholder"))
            manual["pending_image_count"] = pending
            manual["issues"] = [
                issue for issue in manual.get("issues", []) if issue.get("code") != "image-pending"
            ]
            if pending:
                manual["issues"].append(
                    {
                        "level": "warning",
                        "code": "image-pending",
                        "message": (
                            f"{pending} 张图片仍为占位图：用真实截图覆盖 images/ 下的同名文件后重新渲染即可，"
                            "无需修改数据或正文"
                        ),
                    }
                )
            manual["issue_count"] = len(manual["issues"])
        except Exception:
            pass
    report["manual"] = manual

    # 读取占位符清单（如果存在）
    if placeholders_path.exists():
        try:
            saved_placeholders = load_json(placeholders_path)
            report["markdown"]["saved_placeholder_summary"] = saved_placeholders.get(
                "by_kind", {}
            )
        except json.JSONDecodeError:
            report["markdown"]["saved_placeholder_summary"] = None

    # 读取皮肤配置（如果 docgen 输出时保存了）
    style = {}
    if style_path.exists():
        style = load_json(style_path)

    # DOCX 校验
    if docx_path.exists():
        style = style or {}
        issues = check_docx_style(docx_path, style)
        report["docx"] = {
            "exists": True,
            "size_bytes": docx_path.stat().st_size,
            "style_issues": issues,
            "style_issue_count": len(issues),
        }
        if any(i["level"] == "error" for i in issues):
            report["valid"] = False
    else:
        report["docx"] = {"exists": False}

    # 总览
    report["summary"] = {
        "placeholder_total": report["markdown"].get("placeholder_count", 0),
        "missing_image_total": report["markdown"].get("missing_images", 0),
        "docx_style_issue_total": report["docx"].get("style_issue_count", 0),
        "manual_issue_total": report["manual"].get("issue_count", 0),
        "pending_image_total": report["manual"].get("pending_image_count", 0),
    }

    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="op-docgen 产物校验脚本")
    parser.add_argument("out_dir", help="docgen.py 的输出目录")
    parser.add_argument(
        "--json",
        action="store_true",
        help="以 JSON 格式输出校验报告",
    )
    args = parser.parse_args()

    out_dir = Path(args.out_dir)
    if not out_dir.exists():
        print(f"错误：输出目录不存在 {out_dir}", file=sys.stderr)
        return 1

    report = validate_output_dir(out_dir)

    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print("=" * 50)
        print("op-docgen 产物校验报告")
        print("=" * 50)
        print(f"校验目标：{report['target']}")
        print(f"Markdown 初稿：{'存在' if report['markdown'].get('exists') else '缺失'}")
        print(f"占位符总数：{report['summary']['placeholder_total']}")
        for kind, count in report["markdown"].get("placeholders_by_kind", {}).items():
            print(f"  - {kind}: {count}")
        print(f"图片引用数：{report['markdown'].get('image_refs', 0)}")
        print(f"缺失图片数：{report['summary']['missing_image_total']}")
        if report["markdown"].get("missing_image_list"):
            for img in report["markdown"]["missing_image_list"]:
                print(f"  - 缺失：{img['ref']}（预期路径：{img['resolved']}）")
        print(f"DOCX 产物：{'存在' if report['docx'].get('exists') else '缺失'}")
        print(f"样式检查问题数：{report['summary']['docx_style_issue_total']}")
        if report.get("manual", {}).get("applicable"):
            print(f"手册质量检查问题数：{report['summary']['manual_issue_total']}")
            for issue in report["manual"]["issues"]:
                print(f"  - [{issue['level']}] {issue['message']}")
        for issue in report["docx"].get("style_issues", []):
            print(f"  - [{issue['level']}] {issue['message']}")
        print("=" * 50)
        print(f"校验结论：{'通过' if report['valid'] else '需关注'}")

    # 校验不阻塞：无论是否通过都返回 0
    return 0


if __name__ == "__main__":
    sys.exit(main())
