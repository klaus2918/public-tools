---
name: op-docgen
category: support
description: 制式文档生成。从 Markdown/Jinja2 骨架批量生成 API 文档、数据库设计、用户手册、测试报告等制式 DOCX；用户手册支持按职能角色分册、图片占位与图片清单。吸收 docx skill（单份临时 docx 手工操作）。
status: active
phase_role: support
version: "2.3.0"
updated_at: 2026-09-16
---

# op-docgen — 制式文档生成器

## Overview

读取 Markdown + Jinja2 骨架模板，结合数据与样式皮肤，生成 Markdown 初稿与 DOCX 产物，并提供占位符清单与产物校验报告。

---

## When to Use

- 需要一次性生成接口文档（API Doc）
- 需要输出数据库设计文档（DB Design）
- 需要编写用户操作手册（User Manual）
- 需要产出测试报告（Test Report）
- 需要统一团队文档格式、字体、段落、提示块样式
- op-build / op-done 阶段需要随代码交付配套文档

**Do not use for:**
- 临时性、无需复用的单份文档（直接用 docx skill）
- 高度个性化排版、超出皮肤定义范围的设计
- 在线协作文档或 Wiki 内容
- 确认材料 / 归档门户静态页（默认 Markdown，显式要求才 HTML——归 op-html skill）

---

## 边界声明（与 op-html 划界）

| 维度 | op-docgen | op-html |
|------|-----------|---------|
| 定位 | 制式 DOCX 文档（骨架+皮肤+渲染引擎，批量） | 确认材料/归档门户静态页（默认 Markdown，显式要求才 HTML） |
| 产物 | draft.md + output.docx + placeholders.json | 确认文件（默认 .md）/ 静态 HTML 页面 |
| 触发 | 批量生成 API 文档、DB 设计、用户手册、测试报告等制式 DOCX | op 工作流决策暂停点（plan 确认、done 归档门户） |
| 复用 | assets/skeletons + styles 皮肤（渲染引擎 docgen.py） | templates/ 骨架（复制填充） |

**双向边界**（与 docx↔op-docgen 声明风格一致）：
- **op-docgen 不做**：确认材料 / 归档门户静态页（默认 Markdown，归 op-html）；单份临时 docx 手工操作（归 docx skill）。
- **op-html 不做**：制式 DOCX 文档的批量生成（骨架+皮肤+渲染引擎，归 op-docgen）。

## Quick Reference

| Step | Description |
|------|-------------|
| 选骨架 | `assets/skeletons/` 下选择对应类型 |
| 备数据 | 按骨架所需字段准备 JSON 数据 |
| 选皮肤 | `styles/default.json` + `styles/skins/<skin>.json` |
| 参考示例 | `assets/samples/user-manual/`（输入 md + DOCX 产物占位说明） |
| 渲染 | `python op-docgen/scripts/docgen.py --skeleton <name> --skin <skin> --data <json> --out <dir>` |
| 角色分册 | 同一份数据出多册：数据内用 `variants` 定义角色差异字段，渲染时只加 `--param role_key=admin`；临时覆盖用 `--param KEY=VALUE` |
| 补图 | 按 `<out-dir>/images.json` 的待补清单补图（含行内按钮图），补完删除对应「图 N-M 采集要求」行 |
| 核对按钮 | 按 `<out-dir>/buttons.json` 逐条对照系统实际界面核对按钮名 |
| 校验 | `python op-docgen/scripts/validate.py <out-dir>`（含用户手册专项质量检查） |
| 补充 | 按占位符清单人工填补后重新渲染 |

### 骨架选择决策矩阵

| 场景 | 骨架 | 产物 |
|---|---|---|
| 接口服务说明 | `api-doc` | API 文档 |
| 数据模型说明 | `db-design` | 数据库设计文档 |
| 终端用户操作说明 | `user-manual` | 用户手册（**一册一角色**） |
| 测试执行与结果汇总 | `test-report` | 测试报告 |

**用户手册分册规则**：按「业务模块 × 职能角色」出册——管理员册讲配置/维护/审核，用户册讲办理/查看/提交。

- 数据主体为 `sections[].features[].blocks[]`：章节（`##`）→ 子节/操作（`###`）→ 叙述块（每块 `text` ＋ 可选 `image` / `image_caption`，图紧跟该段落）；章节与子节均可带 `roles`，未标记的默认进 `user` 册。
- 手册末尾输出 `contacts[]`（技术支持）；**不输出封面页、目录、表格、常见问题与跨册引用**。
- 正文为段落叙述（首行缩进 2 字符），图注写作「图·xxx」；行内按钮图嵌在句中（`点击![按钮：发送](images/btn/发送.png)按钮`）。
- 数据内 `variants.<role_key>` 定义该角色专属字段（`title` / `role_label` / `intro`），渲染时自动套用；角色区分也可只体现在输出文件名（`--doc-name`），不必写进文档标题。
- 渲染：`--param role_key=<角色>`；临时覆盖任意顶层字段用 `--param KEY=VALUE`（优先级高于 variants）。
- 版式：操作手册使用 `--skin manual`；写作要求见 `references/manual-writing-spec.md`。

---

## Directory Layout

```
op-docgen/
├── SKILL.md                        # 本文件
├── assets/
│   ├── .gitkeep
│   ├── skeletons/                  # Markdown + Jinja2 骨架
│   │   ├── api-doc.md.j2
│   │   ├── db-design.md.j2
│   │   ├── user-manual.md.j2
│   │   └── test-report.md.j2
│   └── samples/                    # 示例数据
│       └── user-manual/            # user-manual 骨架示例
│           ├── input.md            # 示例输入 Markdown（骨架同构）
│           └── rendered-docx.md    # DOCX 产物占位说明（结构+复现命令）
├── scripts/
│   ├── .gitkeep
│   ├── docgen.py                   # 渲染引擎
│   └── validate.py                 # 产物校验
├── references/
│   ├── .gitkeep
│   ├── style-guide.md              # 制式文档写作规范
│   ├── manual-writing-spec.md      # 用户手册编写规范（角色分层／结构预算／步骤句式／图片契约）
│   └── placeholder-rules.md        # 占位符使用规则（含图片占位与图片清单）
└── styles/
    ├── .gitkeep
    ├── default.json                # 默认样式
    └── skins/
        ├── official.json           # 公文格式 GB/T 9704-2012
        └── readable.json           # 舒适阅读 A4 皮肤
```

---

## 渲染链路前置

op-docgen 渲染链路依赖两个 Python 库（docgen.py 在依赖缺失时抛出带安装命令的 ImportError，**不自动安装**）：

| 依赖 | 用途 | 最低版本 | 安装命令 |
|---|---|---|---|
| python-docx | DOCX 产物渲染（docgen.py 第 4 步） | 1.2.0 | `pip install python-docx` |
| jinja2 | Markdown 初稿渲染（docgen.py 第 3 步） | 3.x | `pip install jinja2` |

**降级路径**：渲染失败时按以下顺序处理，不自动安装依赖：

1. 确认依赖：`python -c "import docx, jinja2"`，无输出即依赖就绪。
2. 缺依赖时按报错提示执行 `pip install python-docx` / `pip install jinja2`，然后重试渲染。
3. 仍失败时检查皮肤与数据文件路径是否正确（报错信息含具体路径）。
4. 依赖缺失时 DOCX 渲染不可用，可先用 `--skip-docx` 仅生成 Markdown 初稿与占位符清单（仍需 jinja2）。

**环境验证记录（2026-09-16）**：本机 python-docx 与 jinja2 **均已可用**，`user-manual` 骨架端到端渲染（draft.md + output.docx + placeholders.json + images.json）验证通过。2026-08-14 记录的「jinja2 未安装」已失效（见 `assets/samples/user-manual/rendered-docx.md`）。

---

## Rendering Pipeline

渲染引擎按以下顺序执行：

1. **模板选择**：根据 `--skeleton` 读取 `assets/skeletons/<name>.md.j2`。
2. **数据填充**：将 `--data` JSON 注入模板上下文；缺失字段保留占位符。
3. **Markdown 生成**：输出 `<out-dir>/draft.md`、`placeholders.json`、`images.json`（图片清单：类型／位置／图注／路径／状态／采集要求）与 `buttons.json`（待与系统核对的按钮清单）。
4. **DOCX 渲染**：按皮肤配置生成——封面页（首个一级标题及其后的引用块）→ 目录页 → 正文；标题黑体分级、正文首行缩进按皮肤；表格带表头底纹；提示块带底纹与左侧强调线；版面图有图则插图并加图注，缺图输出浅灰虚线**图位框**；行内按钮图按小图内联、缺图输出 `〔按钮：xx〕` 标记；页脚居中页码。

---

## Placeholder Mechanism

骨架中所有缺失信息使用统一占位符：

| 占位符 | 语义 | 处理要求 |
|---|---|---|
| `[待补充：xxx]` | 必须补充的关键信息 | 人工补充后替换为实际内容 |
| `[待确认：xxx]` | 需要人工确认的内容 | 确认后替换或删除 |
| `[示例：xxx]` | 示例性占位内容 | 替换为真实数据或删除 |

占位符不阻塞初稿生成；`validate.py` 会分类统计并输出报告。

**图片不进正文占位符，图位是真正的图片对象**：版面图写作 `![图 N 图注](images/NN-名称.png)`，行内按钮图直接嵌在句中（`点击![按钮：新建申请](images/btn/新建申请.png)新建申请`）。

- 渲染时若 `images/NN-名称.png` 不存在，工具会自动生成**同尺寸占位图片**（放在 `images/_placeholder/`）并按最终位置、最终大小、图注插入文档；正文里**不出现任何"待补"文字**。
- **补图 = 把真实截图按同名放进 `images/` 后重新渲染**：不需要改数据、不需要删正文里的提示行、不需要调图片大小／对齐／图注。
- `images.json` 中 `placeholder: true` 表示该图位仍用占位图（即还差几张图一目了然）；采集要求写在数据字段 `image_note`，进入清单，不进正文。
- 行内按钮图同理：`images/btn/xx.png` 不存在时先放占位小图，补图时同名替换即可。

规则细节见 `references/placeholder-rules.md` 第 9 章。

**按钮名不进正文占位符**：正文写业务实名（如「点击『发送』按钮」），需要与系统实际界面对照核对的按钮集中登记在数据文件的 `buttons[]`，渲染输出 `buttons.json` 供逐条核对——正文保持干净可读。

---

## Skin Model

样式采用「默认 + 皮肤覆盖」两层模型：

- `styles/default.json`：字体、段落、页边距、图片边框、提示块等基础样式。
- `styles/skins/<skin>.json`：在默认基础上覆盖，形成具体文档风格。
- 皮肤层只覆盖差异字段，不重复定义全部样式。

### 内置皮肤

| 皮肤 | 适用场景 |
|---|---|
| `official` | 公文、红头文件，遵循 GB/T 9704-2012 格式 |
| `readable` | 技术文档、报告，A4 适中页边距、宋体五号、1.5 倍行距，含封面页与自动目录 |
| `manual` | **操作手册（贴近原样例版式）**：正文四号宋体、1.5 倍行距、首行缩进 2 字符；标题 22pt / 16pt 加粗；图注五号居中；无封面页、无目录、无彩色提示块 |

> `manual` 的字号与层级基准取自实战原手册的 XML 实测值，改版式前先用 `tools/analyze_format.py` 一类脚本量化原件，避免凭感觉调样式。

---

## Common Mistakes

- **在骨架中硬编码皮肤格式**：骨架只负责结构，样式由皮肤配置控制。
- **遗漏占位符清单**：渲染时必须输出 `placeholders.json` 供校验使用。
- **直接修改输出 DOCX 而不回灌骨架**：后续二次渲染会覆盖修改，应先在数据或骨架中补齐。
- **忽略校验报告**：校验报告不阻塞生成，但必须在人工补充阶段参考。
- **把管理员与普通用户合成一册**：关注点不同（管理功能 vs 使用功能），应按 `references/manual-writing-spec.md` 分册，用 `--param role_key` 分别渲染。
- **用截图代替按钮名**：步骤文字必须自洽，禁止「点击，」「点击按钮」这类缺宾语写法；截图只作辅助。
- **把图片路径写成占位符**：图片统一走 `images.json` 清单，不写 `[待补充：截图路径]`。
- **手册写成大而全**：结构沿用原手册（章节 → 子节 → 段落叙述 ＋ 图跟随），章节 ≤7、正文每段 1～2 句；产品背景、运行环境表格、术语表、变更记录、跨册引用不进用户册。
- **只设 `run.font.name` 就以为中文字体生效**：python-docx 该属性只写西文字体（`w:ascii` / `w:hAnsi`），中文必须显式写 `w:rFonts/@w:eastAsia`，否则中文字形落回 Word 默认字体（表现为「设了宋体却不生效」）。用 `set_run_font()` 统一处理。
- **用 `add_heading` 后不覆盖颜色**：内置 Heading 样式默认是蓝色标题，必须显式设黑色（`set_run_font(..., color="#000000")`），否则标题颜色与原件不符。

---

## Version

| Field | Value |
|---|---|
| Skill | op-docgen |
| Version | 2.3.0 |
| Updated | 2026-09-16 |
| Key change | v2.3.0: 新增 `manual` 皮肤（对齐原手册 XML 实测基准：正文四号宋体、1.5 倍行距、首行缩进 2 字符；标题 22pt／16pt 加粗；图注五号居中；可关闭封面页与目录）；`user-manual` 骨架改为 `sections[].features[]` 朴素结构（标题 → 一行说明 → 使用准备 → 章节／操作／步骤／图／提示 → 常见问题），去掉封面、目录、表格与跨册引用；v2.2.0: 版式与图片模型升级——落地皮肤声明的排版能力（封面页、目录页位置修正、表头底纹、提示块底纹与左侧强调线、正文首行缩进与两端对齐、页脚页码）；图片分「版面图（缺图输出图位框）」与「行内按钮图（内联小图／`〔按钮：xx〕` 标记）」两类；新增 `buttons.json` 待核对按钮清单（正文不再出现 `[待确认：…]`）；`images.json` 增加 `kind`／`placement`；v2.1.0: 一册一角色（`roles` 过滤 + `variants` 角色差异字段 + `--param role_key`）、四章制骨架、`validate.py` 手册专项质量检查、修复表格分隔行与表内空行解析；v2.0.0: 渲染链路前置小节与示例；v1.0.1: 与 op-html 的边界声明 |
