# -*- coding: utf-8 -*-
"""op-orchestrate-validate.sh 冒烟测试（RED/GREEN）
复用 _test_reconcile 夹具：一致状态应通过；构造错误应被检出。
"""
import io
import os
import shutil
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import test_reconcile as F

# bash 解释器探测：优先 PATH（which 命中），退回常见安装路径
# （原硬编码 C:\Program Files\Git\bin\bash.exe 在 bash 装于其他盘位时导致 FileNotFoundError）
BASH = shutil.which("bash") or r"C:\Program Files\Git\bin\bash.exe"
VALIDATE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "op-orchestrate-validate.sh")
WS = F.WS
PARENT_DIR = F.PARENT_DIR


def write(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with io.open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(content)


def run_validate():
    # env 复用 test_reconcile.UTF8_ENV：Windows 上 python/子脚本输出默认 GBK，需强制 UTF-8
    r = subprocess.run([BASH, VALIDATE, WS], capture_output=True, text=True,
                       encoding="utf-8", errors="replace", env=F.UTF8_ENV)
    return r.returncode, r.stdout + r.stderr


def main():
    F.setup()
    ok = True

    # 1. GREEN：先对账校正，validate 应通过（exit 0）
    from test_reconcile import run
    r = run([F.PARENT, "--workspace", WS])
    assert "已回写" in (r.stdout + r.stderr), r.stdout + r.stderr
    code, out = run_validate()
    print(out)
    assert code == 0, "一致状态 validate 应通过，exit=%d" % code
    print("[GREEN] 一致状态 validate 通过")

    # 2. RED：子变更 type=hotfix 应被检出
    write(os.path.join(PARENT_DIR, "child-c", "change.yaml"),
          F.CHILD_C.replace("type: complex", "type: hotfix"))
    code, out = run_validate()
    assert code == 1, "hotfix 子变更应报错"
    assert "type=hotfix 非法" in out, "未检出 type 非法: %s" % out
    print("[GREEN] RED：type=hotfix 被检出")

    # 3. RED：依赖环应被检出（child-a -> child-b -> child-a）
    write(os.path.join(PARENT_DIR, "child-a", "change.yaml"),
          F.CHILD_A.replace("depends_on: []", "depends_on: [child-b]"))
    code, out = run_validate()
    assert code == 1, "依赖环应报错"
    assert "依赖存在环" in out, "未检出环: %s" % out
    print("[GREEN] RED：依赖环被检出")

    # 4. RED：父 phase=done 但子变更未全 archived 应被检出
    write(os.path.join(PARENT_DIR, "child-a", "change.yaml"),
          F.CHILD_A.replace("depends_on: []", "depends_on: [child-b]").replace("phase: build", "phase: plan"))
    write(os.path.join(PARENT_DIR, "change.yaml"),
          F.EPIC_CHANGE.replace("phase: build", "phase: done"))
    code, out = run_validate()
    assert code == 1, "父 done 未全归档应报错"
    assert "父 phase=done 但存在未 archived" in out, "未检出父 phase 冲突: %s" % out
    print("[GREEN] RED：父 phase=done 冲突被检出")

    print("=== validate 冒烟测试全部通过 ===")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
