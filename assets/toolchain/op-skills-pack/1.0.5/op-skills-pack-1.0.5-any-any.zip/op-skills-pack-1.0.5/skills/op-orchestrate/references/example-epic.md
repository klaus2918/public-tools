# 完整示例：示例政务服务平台多端重构（epic 编排全流程走查）

> 依据：`docs/design/op-orchestrate-design-contract.md` §4/§5（v0.1 草案）+ `references/orchestration-schema.md`（A2 数据结构规范）
> 本示例为虚构演示，业务需求、文件名、时间戳均为构造数据，用于展示 op-orchestrate 的完整工作流：父变更拆分 → 子变更独立闭环 → 门槛逐项通过 → 依赖检查 → 阻塞与恢复 → 整体归档。
> 数据结构与契约 §4/§5 严格一致：父变更 `type: epic` + `orchestration` 配置；子变更 `parent/depends_on/milestone` 扩展字段；orchestration.yaml 为唯一进度事实源。

---

## 1. 业务背景与拆分

### 1.1 需求描述

**示例政务服务平台多端重构**：现有系统为单体 PC 应用，无法支撑移动端服务。目标是将"服务对象服务办理"重构为 后端 + PC 前端 + APP 前端 三端架构，并完成数据库改造与端到端联调验证。

涉及模块：
- 数据库：新增服务申请、资格核验、材料附件等 8 张表，改造 3 张存量表
- 后端：基础框架（统一响应/异常/日志/鉴权）、统一认证网关、服务申请与资格核验接口
- PC 前端：服务办理页面（申请、草稿、撤回、进度查询）
- APP 前端：移动端服务办理页面（复用后端接口）
- 联调：双端全流程 E2E（登录 → 申请 → 核验 → 办结）

按分解规则（内聚、可独立验证、单子变更任务量可控）拆分为 3 个子变更：

| 子变更 | 名称 | 类型 | 里程碑 | 依赖 | 范围 |
|--------|------|------|--------|------|------|
| child-a | demo-base-capability（基础能力） | complex | M1 基础能力 | 无 | 数据库 schema + 后端基础框架 + 统一认证网关 + 基础数据服务 |
| child-b | demo-service-functions（业务功能） | complex | M1 基础能力 | [child-a] | 服务申请/资格核验接口 + PC/APP 服务办理页面 |
| child-c | demo-integration-verify（联调验证） | feature | M2 联调验证 | [child-a, child-b] | 双端端到端 E2E + 多端一致性验收 |

依赖 DAG：`child-a → child-b → child-c`（child-c 同时依赖 child-a、child-b）。

### 1.2 里程碑计划

| 里程碑 | 名称 | 子变更 |
|--------|------|--------|
| M1 | 基础能力 | child-a, child-b |
| M2 | 联调验证 | child-c |

---

## 2. 父变更 change.yaml

位置：`.op/changes/demo-multi-end-refactor/change.yaml`

```yaml
name: demo-multi-end-refactor
title: 示例政务服务平台多端重构
type: epic
phase: plan
created: 2026-08-11
status: active
description: 编排父变更：拆分基础能力（child-a）、业务功能（child-b）、联调验证（child-c）三个子变更，全部归档后整体收尾。父变更本身不编码，只负责编排。
keywords: [服务对象, 多端重构, 事项办理]
summary: 后端 + PC 前端 + APP 前端三端架构重构，含数据库改造与端到端联调
has_ui: true
has_db: true
has_arch: true
orchestration:
  enabled: true
  milestone_plan:
    - id: M1
      name: 基础能力
      children: [child-a, child-b]
    - id: M2
      name: 联调验证
      children: [child-c]
```

> 说明：父变更 `type: epic` 且 `orchestration.enabled: true`，`/op` 入口据此路由到 op-orchestrate 编排视图，不进入普通 plan/build。

---

## 3. 子变更清单（3 个）

每个子变更是标准 op 变更，独立走 plan → build → done 全生命周期。子变更 change.yaml 与契约 §4.2 一致（含 `parent` / `depends_on` / `milestone` 扩展字段），编排状态（status/phase/gates）**不写入**子变更 change.yaml，只存在于 orchestration.yaml（见 A2 规范 §7.2）。

### 3.1 child-a：基础能力

#### 3.1.1 change.yaml

位置：`.op/changes/demo-multi-end-refactor/child-a/change.yaml`

```yaml
name: child-a
title: 基础能力：数据库 schema + 后端基础框架 + 统一认证
parent: demo-multi-end-refactor
type: complex
phase: plan
created: 2026-08-11
status: active
description: 示例政务服务平台多端重构的基础能力子变更：数据库改造、后端基础框架、统一认证网关、基础数据服务（编排子变更）
has_ui: false
has_db: true
has_arch: true
depends_on: []
milestone: M1
build:
  done_count: 0
  total_count: 0
```

#### 3.1.2 plan.md 摘要

```markdown
# 方案：基础能力（child-a）

## 背景
- 存量单体 PC 应用无法支撑多端架构；数据库表结构未规范化，认证逻辑分散在业务代码
- 本子变更交付三端共用的地基：schema、后端框架、统一认证，供 child-b 业务功能直接消费

## 方案说明
- 数据库：新增 8 张表（service_apply 服务申请、qualification_check 资格核验、material_file 材料附件等），改造 3 张存量表（统一主键/审计字段），迁移脚本可重复执行
- 后端基础框架：统一响应体、全局异常、请求日志、鉴权过滤器（基于 token 白名单）
- 统一认证网关：PC/APP 双端登录签发 token、会话管理、接口鉴权中间件
- 基础数据服务：地区/机构/字典三级缓存接口，供双端页面下拉数据源

## 影响范围
- 新增：`db/migrations/V1__demo_multi_end.sql`、`backend/src/main/java/.../framework/*`、`backend/src/main/java/.../auth/*`、`backend/src/main/java/.../base/*`
- 修改：`backend/pom.xml`（新增依赖）、`db/init.sql`

## 风险与权衡
- 认证方案：统一网关 vs 各端独立认证 → 选统一网关，避免双端会话不一致；风险：网关成为单点，用 token 缓存 + 熔断缓解

## 使用故事
- 使用场景：三端登录与基础数据获取（后端内部能力，触发方 = PC/APP 页面）
- 使用角色：后端开发（消费框架/网关）、PC/APP 前端（消费登录与数据接口）
- 使用过程：
  1. 【PC/APP】用户输入账号密码登录，网关校验并签发 token
  2. 【PC/APP】页面加载基础数据（地区/机构/字典），走缓存接口
- 验收标准：登录接口冒烟通过；8 表迁移在测试库可重复执行；基础数据接口返回缓存命中

## 验收标准
- 功能：统一认证双端登录签发/校验/过期；基础数据三接口返回正确
- 非功能：迁移脚本可重复执行（幂等）；接口 95% 场景 200ms 内响应
```

#### 3.1.3 tasks.md 摘要（5 个 task，每个含 verify 方式）

```markdown
# 任务列表：基础能力（child-a）

总任务数：5

- [ ] #1 数据库 schema 迁移脚本（8 新增表 + 3 存量表改造）
  type: database
  verify: auto
  depends: []
  end: ["backend"]
  verify 方式：测试库执行迁移脚本无报错；information_schema 校验 8 表/外键/索引齐全；重复执行幂等（第二次无变更输出）

- [ ] #2 后端基础框架（统一响应体/全局异常/请求日志/鉴权过滤器）
  type: backend
  verify: auto
  depends: []
  end: ["backend"]
  verify 方式：单元测试（统一响应体序列化、异常映射、日志格式）；启动应用后 curl 未认证请求返回 401

- [ ] #3 统一认证网关（双端登录签发 token、会话管理、鉴权中间件）
  type: backend
  verify: auto
  verify-browser: optional
  end: ["backend"]
  verify 方式：接口测试（登录成功签发 token、错误密码 401、token 过期 401）；浏览器手测登录页签发 token 成功（op-browser 可选验证）

- [ ] #4 基础数据服务（地区/机构/字典三级缓存接口）
  type: backend
  verify: auto
  end: ["backend"]
  verify 方式：curl 冒烟三个接口返回正确 JSON；二次请求命中缓存（日志/响应头验证）

- [ ] #5 基础能力集成测试集（认证 + 基础数据全链路）
  type: test
  verify: auto
  depends: [2, 3, 4]
  end: ["verify"]
  verify 方式：集成测试套件全绿（JUnit + Testcontainers 测试库）；覆盖登录→数据接口调用链路
```

### 3.2 child-b：业务功能

#### 3.2.1 change.yaml

位置：`.op/changes/demo-multi-end-refactor/child-b/change.yaml`

```yaml
name: child-b
title: 业务功能：服务申请/资格核验 + PC/APP 服务办理页面
parent: demo-multi-end-refactor
type: complex
phase: plan
created: 2026-08-11
status: active
description: 示例政务服务平台多端重构的业务功能子变更：服务申请与资格核验接口、PC 与 APP 服务办理页面、双端联调（编排子变更，依赖 child-a 基础能力）
has_ui: true
has_db: false
has_arch: false
depends_on: [child-a]
milestone: M1
build:
  done_count: 0
  total_count: 0
```

#### 3.2.2 plan.md 摘要

```markdown
# 方案：业务功能（child-b）

## 背景
- 基础能力（child-a）交付后，本子变更实现业务主体：服务申请全流程与资格核验规则，覆盖 PC/APP 双端

## 方案说明
- 服务申请接口：申请提交/草稿/撤回/进度查询（复用 child-a 认证与基础数据）
- 资格核验规则引擎：按服务对象身份类别路由核验规则（A 类 / B 类 / C 类），支持扩展
- PC 端服务办理页面：申请表单、材料上传、进度列表
- APP 端服务办理页面：移动端适配表单 + 拍照上传
- 双端联调：接口 + 页面全流程打通

## 影响范围
- 新增：`backend/src/main/java/.../service/*`（申请/核验）、`pc-frontend/src/pages/service/*`、`app-frontend/src/pages/service/*`
- 修改：`pc-frontend/src/router/*`、`app-frontend/src/router/*`、`backend/src/main/resources/*`

## 风险与权衡
- 核验规则集中引擎 vs 散落业务代码 → 选引擎，规则变更不动接口；风险：规则组合爆炸，用规则表 + 优先级排序缓解

## 使用故事
- 使用场景：服务对象通过 PC 或 APP 在线申请服务事项，系统自动核验资格
- 使用角色：服务对象（申请人）、窗口工作人员（核验/办结）
- 使用过程：
  1. 【PC】服务对象登录系统，进入服务办理页，填写申请表单并上传材料
  2. 【PC】提交申请，系统进行资格核验并反馈核验结果
  3. 【APP】服务对象用手机打开 APP，进入申请页，拍照上传材料并提交
  4. 【APP】查看申请进度与核验结果
- 验收标准：双端均可完成申请提交与核验反馈；核验规则按身份类别正确路由

## 验收标准
- 功能：申请提交/草稿/撤回/进度查询四接口正确；PC/APP 表单可完整提交；核验规则按身份类别路由
- 非功能：双端页面在 1280×720（PC）与 375×812（APP）分辨率可用；接口错误有友好提示
```

#### 3.2.3 tasks.md 摘要（6 个 task，每个含 verify 方式）

```markdown
# 任务列表：业务功能（child-b）

总任务数：6

- [ ] #1 服务申请后端接口（提交/草稿/撤回/进度查询）
  type: backend
  verify: auto
  depends: []
  end: ["backend"]
  verify 方式：接口测试四接口全通过（含参数校验、未登录 401、权限不足 403）；单元测试覆盖状态流转（草稿→已提交→已办结）

- [ ] #2 资格核验规则引擎
  type: backend
  verify: auto
  depends: [1]
  end: ["backend"]
  verify 方式：规则单测覆盖三类身份（A 类 / B 类 / C 类）各 ≥3 个边界用例；非法身份返回明确错误

- [ ] #3 PC 端服务办理页面（表单/材料上传/进度列表）
  type: frontend
  verify: auto
  verify-browser: required
  end: ["pc"]
  usage-step: [1, 2]
  verify 方式：单元测试（表单校验）；op-browser SmartBrowser.run 端到端回放：登录→填写→上传→提交→核验结果展示（必须通过，否则阻塞本子变更 G2）

- [ ] #4 APP 端服务办理页面（移动表单/拍照上传/进度查询）
  type: frontend
  verify: auto
  verify-browser: required
  end: ["app"]
  usage-step: [3, 4]
  verify 方式：单元测试（移动布局/表单校验）；op-browser SmartBrowser.run（移动视口）回放：登录→拍照上传→提交→进度查询

- [ ] #5 双端联调（接口 + 页面全流程）
  type: test
  verify: auto
  verify-browser: optional
  depends: [1, 2, 3, 4]
  end: ["verify"]
  verify 方式：联调测试集全绿（PC/APP 各跑一遍 登录→申请→核验→查询 全链路）；核对接口日志无 5xx

- [ ] #6 接口文档与示例数据
  type: docs
  verify: manual
  depends: [5]
  end: ["backend"]
  verify 方式：人工评审接口文档与示例数据完整（字段、枚举、错误码、示例 JSON）
```

### 3.3 child-c：联调验证

#### 3.3.1 change.yaml

位置：`.op/changes/demo-multi-end-refactor/child-c/change.yaml`

```yaml
name: child-c
title: 联调验证：双端端到端 E2E + 多端一致性验收
parent: demo-multi-end-refactor
type: feature
phase: plan
created: 2026-08-11
status: active
description: 示例政务服务平台多端重构的联调验证子变更：端到端用例设计、PC/APP 全流程 E2E、多端一致性验收报告（编排子变更，依赖 child-a 与 child-b）
has_ui: true
has_db: false
has_arch: false
depends_on: [child-a, child-b]
milestone: M2
build:
  done_count: 0
  total_count: 0
```

#### 3.3.2 plan.md 摘要

```markdown
# 方案：联调验证（child-c）

## 背景
- child-a/child-b 交付后，需要在真实业务场景下验证三端整体一致性：同一账号双端登录、申请数据双端可见、核验结果双端一致

## 方案说明
- 端到端用例设计：覆盖 登录→申请→核验→办结 主链路 + 异常分支（材料缺失、核验不通过）
- PC 端全流程 E2E：op-browser 业务域（demo）回放真实业务场景
- APP 端全流程 E2E：移动视口回放
- 多端一致性验收：同一申请在 PC 提交后 APP 可见且状态一致；产出验收报告并闭环缺陷

## 影响范围
- 新增：`e2e/cases/*.yaml`（用例）、`e2e/reports/consistency-report.md`（验收报告）
- 无业务源码改动（如发现缺陷回退给对应子变更修复）

## 风险与权衡
- 联调中发现缺陷时修复归属：按模块回退 child-a/child-b 修复，child-c 只做验证不做修复（范围锁定）

## 使用故事
- 使用场景：重构完成后多端一致性验收（触发方 = 测试/验收人员）
- 使用角色：测试工程师（执行 E2E）、项目经理（审阅验收报告）
- 使用过程：
  1. 【PC】测试工程师登录系统，提交一条服务申请
  2. 【APP】同一账号登录，确认申请数据与状态与 PC 一致
  3. 【PC】窗口工作人员核验并办结
  4. 【APP】确认办结状态同步
- 验收标准：PC/APP 双端全流程 E2E 通过；一致性验收报告交付

## 验收标准
- 功能：主链路与异常分支用例全部通过；双端数据一致
- 非功能：E2E 可重复执行（确定性回放）；验收报告含缺陷清单与闭环状态
```

#### 3.3.3 tasks.md 摘要（4 个 task，每个含 verify 方式）

```markdown
# 任务列表：联调验证（child-c）

总任务数：4

- [ ] #1 端到端用例设计（主链路 + 异常分支）
  type: test
  verify: manual
  depends: []
  end: ["verify"]
  verify 方式：用例评审会议通过（主链路 登录→申请→核验→办结；异常分支 材料缺失/核验不通过/会话过期）；用例覆盖 checklist 人工勾选

- [ ] #2 PC 端全流程 E2E
  type: test
  verify: auto
  verify-browser: required
  verify-e2e: demo
  depends: [1]
  end: ["pc", "verify"]
  verify 方式：op-browser SmartBrowser.run(project="demo-project") 回放 PC 场景全部通过（必须通过，否则阻塞本子变更 G2）

- [ ] #3 APP 端全流程 E2E
  type: test
  verify: auto
  verify-browser: required
  verify-e2e: demo
  depends: [1]
  end: ["app", "verify"]
  verify 方式：op-browser SmartBrowser.run(project="demo-project") 回放移动视口场景全部通过（必须通过）

- [ ] #4 多端一致性验收报告 + 缺陷闭环
  type: docs
  verify: manual
  depends: [2, 3]
  end: ["verify"]
  verify 方式：验收报告评审通过；缺陷清单逐项标记闭环状态（已修复并复验 / 遗留已确认），无 open 阻塞缺陷
```

---

## 4. orchestration.yaml 状态快照

位置：`.op/changes/demo-multi-end-refactor/orchestration.yaml`

### 4.1 初始态（父变更 plan 确认后，2026-08-11T09:00:00+08:00）

全部子变更 pending、phase=plan、三道门槛全 false；里程碑全 pending。

```yaml
parent: demo-multi-end-refactor
updated_at: "2026-08-11T09:00:00+08:00"
milestones:
  - id: M1
    name: 基础能力
    status: pending
  - id: M2
    name: 联调验证
    status: pending
children:
  - name: child-a
    title: 基础能力：数据库 schema + 后端基础框架 + 统一认证
    type: complex
    milestone: M1
    depends_on: []
    status: pending
    phase: plan
    gates:
      plan_confirmed: false
      build_verified: false
      archived: false
    verified_at: null
  - name: child-b
    title: 业务功能：服务申请/资格核验 + PC/APP 服务办理页面
    type: complex
    milestone: M1
    depends_on: [child-a]
    status: pending
    phase: plan
    gates:
      plan_confirmed: false
      build_verified: false
      archived: false
    verified_at: null
  - name: child-c
    title: 联调验证：双端端到端 E2E + 多端一致性验收
    type: feature
    milestone: M2
    depends_on: [child-a, child-b]
    status: pending
    phase: plan
    gates:
      plan_confirmed: false
      build_verified: false
      archived: false
    verified_at: null
```

### 4.2 中间态（2026-08-12T17:30:00+08:00，child-b 验证失败 3 次被阻塞）

状态说明：
- child-a：三道门槛全过（G1 08-11 11:00、G2 08-11 18:00、G3 08-12 10:00），已 archived
- child-b：G1 已过（plan→build），build 阶段 task #3 连续 3 次验证失败 → blocked（验证失败暂停，阻塞 M1）
- child-c：依赖 child-a、child-b，child-b 未 archived → pending（不可启动）
- M1：child-b blocked → blocked；M2：child-c 未启动 → pending

```yaml
parent: demo-multi-end-refactor
updated_at: "2026-08-12T17:30:00+08:00"
milestones:
  - id: M1
    name: 基础能力
    status: blocked
  - id: M2
    name: 联调验证
    status: pending
children:
  - name: child-a
    title: 基础能力：数据库 schema + 后端基础框架 + 统一认证
    type: complex
    milestone: M1
    depends_on: []
    status: archived
    phase: archive
    gates:
      plan_confirmed: true
      build_verified: true
      archived: true
    verified_at: "2026-08-12T10:00:00+08:00"
  - name: child-b
    title: 业务功能：服务申请/资格核验 + PC/APP 服务办理页面
    type: complex
    milestone: M1
    depends_on: [child-a]
    status: blocked
    phase: build
    gates:
      plan_confirmed: true
      build_verified: false
      archived: false
    verified_at: null
  - name: child-c
    title: 联调验证：双端端到端 E2E + 多端一致性验收
    type: feature
    milestone: M2
    depends_on: [child-a, child-b]
    status: pending
    phase: plan
    gates:
      plan_confirmed: false
      build_verified: false
      archived: false
    verified_at: null
```

### 4.3 最终态（父变更归档完成，2026-08-14T16:30:00+08:00）

全部子变更 archived、三道门槛全 true；M1/M2 done；父变更 phase → archive。

```yaml
parent: demo-multi-end-refactor
updated_at: "2026-08-14T16:30:00+08:00"
milestones:
  - id: M1
    name: 基础能力
    status: done
  - id: M2
    name: 联调验证
    status: done
children:
  - name: child-a
    title: 基础能力：数据库 schema + 后端基础框架 + 统一认证
    type: complex
    milestone: M1
    depends_on: []
    status: archived
    phase: archive
    gates:
      plan_confirmed: true
      build_verified: true
      archived: true
    verified_at: "2026-08-12T10:00:00+08:00"
  - name: child-b
    title: 业务功能：服务申请/资格核验 + PC/APP 服务办理页面
    type: complex
    milestone: M1
    depends_on: [child-a]
    status: archived
    phase: archive
    gates:
      plan_confirmed: true
      build_verified: true
      archived: true
    verified_at: "2026-08-13T16:00:00+08:00"
  - name: child-c
    title: 联调验证：双端端到端 E2E + 多端一致性验收
    type: feature
    milestone: M2
    depends_on: [child-a, child-b]
    status: archived
    phase: archive
    gates:
      plan_confirmed: true
      build_verified: true
      archived: true
    verified_at: "2026-08-14T16:00:00+08:00"
```

---

## 5. 全流程走查

> 约定：每次操作后给出 orchestration.yaml 的**关键变化**（变化行 + 新的 `updated_at`），完整快照见 §4；看板输出格式以 A4 `dashboard-spec.md` 为准，此处用简表示意。

### 步骤 1：`/op <parent>` 进入编排视图

命令：`/op demo-multi-end-refactor`

路由判定：`change.yaml.type == epic` 且 `orchestration.enabled: true` → 进入 op-orchestrate 编排视图（而非普通 plan/build）。父变更 phase=plan → 进入拆分流程（阶段一）。

编排视图（看板，父变更 plan 阶段）：

```
父变更：demo-multi-end-refactor（epic，phase=plan）
里程碑：M1 基础能力 [pending] | M2 联调验证 [pending]

子变更矩阵：
  child-a  基础能力        complex  M1  依赖[]            pending  plan  G1✗ G2✗ G3✗
  child-b  业务功能        complex  M1  依赖[child-a]     pending  plan  G1✗ G2✗ G3✗
  child-c  联调验证        feature  M2  依赖[child-a,child-b] pending plan G1✗ G2✗ G3✗

动作：[next] 启动下一个可启动子变更 | [进入子变更] | [done] 父归档（未放行）
```

拆分流程产出：子变更清单（§3 三个 change.yaml）+ orchestration.yaml 初版（§4.1）+ 父变更 plan.md。子变更清单随父变更 plan 确认材料（op-html，默认 md）交用户确认。

用户确认后：父变更 `phase: plan → build`，进入编排执行。

**orchestration.yaml 变化**：无（初版已在确认时落盘，updated_at = 2026-08-11T09:00:00+08:00）。

### 步骤 2：`/op <parent> next` 启动 child-a

命令：`/op demo-multi-end-refactor next`

判定：取第一个 pending 且依赖满足的子变更 → child-a（`depends_on: []`，可启动；child-b 依赖 child-a 未 archived → 跳过；child-c 同理）。

编排视图展示：

```
[ next ] 启动 child-a（基础能力，complex，M1）→ 进入其 plan 阶段
```

**orchestration.yaml 变化**（updated_at = 2026-08-11T09:30:00+08:00）：

```yaml
milestones:
  - id: M1
    status: pending → in_progress   # 有子变更启动
children:
  - name: child-a
    status: pending → active
    phase: plan                     # 不变，进入其 plan 流程
```

### 步骤 3：child-a plan 完成 → G1 置 true

命令：`/op child-a`（子变更按自身 phase 路由到 op-plan）

child-a 为 complex → 加载 op-brainstorming 产出 brainstorm-summary.md → 产出 plan.md + tasks.md（§3.1）→ op-html 生成确认材料（默认 md）→ 用户确认 → `change.yaml.phase: plan → build`。

G1 判定通过：`change.yaml.phase` 已由 plan→build 且 confirm 产物存在（op-html 确认材料落盘）。

**orchestration.yaml 变化**（updated_at = 2026-08-11T11:00:00+08:00）：

```yaml
children:
  - name: child-a
    phase: plan → build
    gates:
      plan_confirmed: false → true   # G1 通过
```

### 步骤 4：child-a build 完成 → G2 置 true

命令：`/op child-a`（phase=build，路由到 op-build）

按 tasks.md 逐 task 实现并验证（§3.1.3 五个 task 每个立即验证），`done_count` 0→5，无未确认 skip，无 verify-browser: required 失败 → `change.yaml.build.done_count == total_count`，phase: build → done。

G2 判定通过：tasks.md 全部完成（done_count == total_count）、无未确认 skip。

**orchestration.yaml 变化**（updated_at = 2026-08-11T18:00:00+08:00）：

```yaml
children:
  - name: child-a
    phase: build → done
    status: active → done           # 三道门槛全过
    gates:
      build_verified: false → true  # G2 通过
    verified_at: "2026-08-11T18:00:00+08:00"
```

### 步骤 5：child-a done 归档 → G3 置 true（archived）

命令：`/op child-a`（phase=done，路由到 op-done）

op-done 六步收尾：清理 → 知识库归档 → 经验归档 → 设计资产沉淀评估 → safe-git-write 整体 commit（child-a 产物）→ 产出 archive.json / archive-summary.md → `change.yaml.phase: done → archive`。

G3 判定通过：`change.yaml.phase == archive` 且 archive.json 存在。

**orchestration.yaml 变化**（updated_at = 2026-08-12T10:00:00+08:00）：

```yaml
children:
  - name: child-a
    phase: done → archive
    status: done → archived
    gates:
      archived: false → true        # G3 通过
    verified_at: "2026-08-12T10:00:00+08:00"   # 保持 G2 通过时间；归档后 status=archived
```

> 注：`verified_at` 语义为"三道门槛全部满足（status=done）的时间"，归档后不回改（A2 规范 §4.3）。

### 步骤 6：`/op <parent> next` 尝试 child-b（依赖满足）

命令：`/op demo-multi-end-refactor next`

判定：child-a 已 archived（gates.archived=true）→ child-b 依赖满足，可启动；child-c 依赖 child-b 未 archived → 仍跳过。

**orchestration.yaml 变化**（updated_at = 2026-08-12T10:30:00+08:00）：

```yaml
children:
  - name: child-b
    status: pending → active
```

### 步骤 7：child-b plan/build → 验证失败 3 次 → blocked

命令：`/op child-b`（按自身 phase 路由）

- 08-12 14:00 G1 通过（complex 走 brainstorm + op-html 确认，plan → build）：`gates.plan_confirmed: true`、`phase: build`
- 08-12 15:00 起 build 阶段 task #1（服务申请接口）、task #2（核验规则引擎）验证通过（done_count=2）
- 08-12 16:00 进入 task #3（PC 端页面，verify-browser: required）：

```
[ task #3 ] PC 端服务办理页面（verify-browser: required）
第 1 次验证失败：SmartBrowser.run 回放失败 —— 登录态注入失效（token 过期）
第 2 次验证失败：SmartBrowser.run 回放失败 —— 页面选择器变更（新增弹层组件）
第 3 次验证失败：SmartBrowser.run 回放失败 —— 提交后核验结果未出现（接口超时）
→ op-build mandatory pause（同一 task 连续 3 次验证失败，RF-08）
选项：A. Retry  B. Skip  C. 加载 systematic-debugging  D. Abort 回 plan
```

op-build 暂停后，协调者回写编排状态：child-b 验证失败 3 次 → 暂停，阻塞其里程碑，父变更显示 blocked。

**orchestration.yaml 变化**（updated_at = 2026-08-12T17:30:00+08:00，即 §4.2 中间态）：

```yaml
milestones:
  - id: M1
    status: in_progress → blocked   # child-b 验证失败暂停
children:
  - name: child-b
    status: active → blocked
    phase: build                    # 暂停在 build 阶段，G1 已过、G2 未过
    gates:
      build_verified: false         # 保持 false
```

编排视图（父变更显示 blocked）：

```
⚠ 父变更 blocked：child-b 验证失败 3 次（task #3 PC 端页面，verify-browser: required）
  M1 基础能力 [blocked] | M2 联调验证 [pending]
  child-a  archived   M1  G1✓ G2✓ G3✓
  child-b  blocked    M1  G1✓ G2✗ G3✗  （task #3 连续 3 次失败，暂停）
  child-c  pending    M2  依赖未满足（child-b 未 archived）
决策：修复（继续 build）/ 调整范围 / 拆分
```

### 步骤 8：blocked 处理与恢复

用户决策：**修复**（选项 C：加载 systematic-debugging 定位根因）。

- 根因定位：登录态注入失效（token 缓存未刷新）+ 页面选择器变更（新增弹层组件）+ 接口超时（测试环境连接池配置过小）
- 修复动作：重新固化 task 资产（op-browser solidify 更新选择器与登录态注入）、调整测试环境连接池配置
- 恢复：协调者将 child-b `status: blocked → active`，M1 `blocked → in_progress`，继续 build（失败计数清零，重跑 task #3）

命令：`/op demo-multi-end-refactor next`（或直接 `/op child-b` 恢复 build）

**orchestration.yaml 变化**（updated_at = 2026-08-13T09:30:00+08:00）：

```yaml
milestones:
  - id: M1
    status: blocked → in_progress
children:
  - name: child-b
    status: blocked → active
```

- 08-13 10:00 重跑 task #3 通过（SmartBrowser.run 回放成功）；task #4（APP 端）通过；task #5 双端联调通过；task #6 文档人工评审通过
- 08-13 15:00 G2 通过（done_count=6 == total_count，无未确认 skip）：`gates.build_verified: true`、`phase: build → done`、`status: done`、`verified_at: 2026-08-13T15:00:00+08:00`
- 08-13 16:00 op-done 归档 → G3 通过：`phase: done → archive`、`status: archived`、`gates.archived: true`

### 步骤 9：child-b 归档后 M1 里程碑推进

命令：`/op demo-multi-end-refactor status`

判定：M1 内 child-a、child-b 均 `gates.archived == true` → M1 done。

**orchestration.yaml 变化**（updated_at = 2026-08-13T16:00:00+08:00）：

```yaml
milestones:
  - id: M1
    status: in_progress → done      # 全部子变更 archived
```

编排视图：

```
M1 基础能力 [done] | M2 联调验证 [pending]
  child-a  archived  M1  G1✓ G2✓ G3✓
  child-b  archived  M1  G1✓ G2✓ G3✓
  child-c  pending   M2  依赖 child-a✓ child-b✓ → 可启动
动作：[next] 启动 child-c | [done] 父归档（未放行：child-c 未 archived）
```

### 步骤 10：child-c 依赖检查与执行

命令：`/op demo-multi-end-refactor next`

依赖检查：child-c `depends_on: [child-a, child-b]`，两者均 archived（gates.archived=true）→ 依赖满足，启动。

**orchestration.yaml 变化**（updated_at = 2026-08-13T16:30:00+08:00）：

```yaml
milestones:
  - id: M2
    status: pending → in_progress
children:
  - name: child-c
    status: pending → active
```

child-c 执行（feature 路径）：
- 08-14 10:00 G1 通过（op-html 确认材料，plan → build）：`gates.plan_confirmed: true`、`phase: build`
- 08-14 15:00 build 完成（task #1 用例评审、#2 PC E2E、#3 APP E2E 均通过 verify-browser: required、#4 验收报告评审）：G2 通过 → `gates.build_verified: true`、`phase: done`、`status: done`、`verified_at: 2026-08-14T15:00:00+08:00`
- 08-14 16:00 op-done 归档 → G3 通过：`status: archived`、`gates.archived: true`

M2 内 child-c 已 archived → M2 done。

**orchestration.yaml 变化**（updated_at = 2026-08-14T16:00:00+08:00）：

```yaml
milestones:
  - id: M2
    status: in_progress → done
children:
  - name: child-c
    status: active → done → archived
    phase: plan → build → done → archive
    gates:
      plan_confirmed: true
      build_verified: true
      archived: true
    verified_at: "2026-08-14T15:00:00+08:00"
```

### 步骤 11：全部 archived → `/op <parent> done` 父变更归档

命令：`/op demo-multi-end-refactor done`

放行校验：全部子变更 `gates.archived == true`（child-a / child-b / child-c 均满足）→ 放行父归档。

父变更归档流程（阶段四）：
1. 生成父变更归档门户/汇总（op-html，默认 md）：汇总 3 个子变更产物、里程碑达成情况、编排记录
2. 走 op-done 整体归档（git 写操作唯一入口 safe-git-write）：产出父变更 archive.json / archive-summary.md
3. 父变更 `change.yaml.phase: done → archive`
4. orchestration.yaml 标记最终 `updated_at` 后随父变更归档保留（作为整次编排的完整记录）

**orchestration.yaml 变化**（updated_at = 2026-08-14T16:30:00+08:00，即 §4.3 最终态）：

```yaml
# 无状态变化，仅 updated_at 更新为最终归档时间；全部子变更 archived、M1/M2 done
```

`/op demo-multi-end-refactor`（phase=archive）→ 只读归档摘要：

```
父变更：demo-multi-end-refactor（epic，已归档 2026-08-14）
里程碑：M1 基础能力 [done] | M2 联调验证 [done]
子变更：child-a archived | child-b archived | child-c archived
归档：archive.json / archive-summary.md / orchestration.yaml（编排完整记录）
```

---

## 6. 状态迁移汇总

### 6.1 子变更状态迁移（含阻塞场景）

```
child-a: pending → active → done → archived
         （G1 08-11 11:00 → G2 08-11 18:00 → G3 08-12 10:00）

child-b: pending → active → done → archived
         （G1 08-12 14:00 → build 验证失败 3 次 blocked 08-12 17:30 → 修复恢复 active 08-13 09:30 → G2 08-13 15:00 → G3 08-13 16:00）

child-c: pending → active → done → archived
         （依赖 child-a、child-b archived 后才启动；G1 08-14 10:00 → G2 08-14 15:00 → G3 08-14 16:00）
```

### 6.2 里程碑状态迁移

```
M1: pending → in_progress（child-a 启动）→ blocked（child-b 验证失败）→ in_progress（恢复）→ done（child-b 归档）
M2: pending → in_progress（child-c 启动）→ done（child-c 归档）
```

### 6.3 门槛判定证据一览

| 子变更 | G1 证据 | G2 证据 | G3 证据 |
|--------|---------|---------|---------|
| child-a | change.yaml.phase=build + op-html 确认材料 | done_count=5/5、无 skip、无 verify-browser required 失败 | change.yaml.phase=archive + archive.json |
| child-b | change.yaml.phase=build + op-html 确认材料 | done_count=6/6（task #3 修复后通过）、无未确认 skip | change.yaml.phase=archive + archive.json |
| child-c | change.yaml.phase=build + op-html 确认材料 | done_count=4/4、#2/#3 verify-browser required 通过 | change.yaml.phase=archive + archive.json |

---

## Version

- v0.1（2026-08-10）：A7 产出，依据设计契约 v0.1 草案 §4/§5 + A2 orchestration-schema.md 编写。发现的问题见 `ISSUES.md`。
