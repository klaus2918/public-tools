---
name: op-orchestrate
category: core
description: "当变更类型为 epic、或 change.yaml 含 orchestration.enabled: true、或复杂需求需要拆分为多个关联子变更分阶段迭代、需要编排视图统一管理子变更时使用。由 /op 入口路由进入，负责子变更拆分、依赖 DAG 管理、三道门槛校验（plan_confirmed / build_verified / archived）与父变更整体归档。"
status: active
phase_role: entry
version: "0.2.3"
updated_at: 2026-09-14
invoked_by:
  - skill: op
    trigger: "change.yaml.type == epic 或 orchestration.enabled: true 时由 /op 路由到编排视图"
    required: true
dispatches:
  - op-plan
  - op-build
  - op-done
  - op-html
---

# op-orchestrate — 子变更编排 Skill

## Overview

复杂需求无法一次性规划/实现/验证完，需要拆成多个**关联子变更**，每个子变更独立走完整的 op 生命周期（plan → build → done），各自可验证、可闭环；同时保持**单一入口**、**统一状态管理**、**不偏离总目标**、**验证不堆积到最后**。

op-orchestrate 是 epic 父变更的编排层：

- **不替代**子变更的 plan/build/done，子变更完全复用现有 op-plan/op-build/op-done；
- **不写业务代码**，父变更 build 阶段只负责编排子变更执行；
- **唯一进度事实源** = `.op/changes/<parent>/orchestration.yaml`（子变更状态、依赖、三道门槛都在这里）；
- 父变更本身也是标准 op 变更（自己的 `change.yaml` + `plan.md`），生命周期为 `plan`（产出子变更清单 + orchestration.yaml 初版）→ `build`（编排执行）→ `done`（全部子变更归档后整体归档）。

详细规范见本 skill 的 references 文档：数据结构见 `references/orchestration-schema.md`，拆分规则与门槛判定细则见 `references/decomposition-rules.md`，看板输出规格见 `references/dashboard-spec.md`，路由契约见 `references/routing-contract.md`，注册与版本集成见 `references/registry-integration.md`，完整示例见 `references/example-epic.md`。

脚本：`scripts/orchestrate-reconcile.py`（对账回写兜底，方案 B）、`scripts/orchestrate-status.sh`（只读看板）、`scripts/op-orchestrate-validate.sh`（编排专属校验，由 op-000 validate 钩子调用）。

---

## When to Use

- `change.yaml.type == epic`（父变更，由 `/op <parent>` 自动路由到本 skill）
- `change.yaml.orchestration.enabled: true`
- 复杂需求需要拆分为多个关联子变更分阶段迭代，需要编排视图统一管理子变更
- 用户输入 `/op <parent> status` / `/op <parent> next` / `/op <parent> done`

**Do not use for:**
- 单变更的正常 plan/build/done（路由到 op-plan/op-build/op-done）
- 子变更内部的方案设计、编码实现、归档提交（子变更按自身 phase 正常路由）
- 决策已明确、无需拆分的小需求

---

## Quick Reference

| Command | Action |
|---------|--------|
| `/op <parent>` | type=epic 或 orchestration.enabled=true → 进入编排视图（看板 + 子变更状态矩阵），选择子变更进入其 phase |
| `/op <parent> status` | 显示编排看板（读 orchestration.yaml，输出规格见 references/dashboard-spec.md） |
| `/op <parent> next` | 自动找出下一个可启动子变更（pending 且依赖满足），进入其 plan |
| `/op <child>` | 子变更按自身 phase 正常路由（op-plan/op-build/op-done）；执行完 phase 后**返回编排视图**（对账在看板渲染时自动校正 orchestration.yaml） |
| `/op <parent> done` | 仅当全部子变更 archived 才放行父变更归档 |

---

## Core Rules

### 1. 单一入口 — /op 路由到编排视图

用户始终从 `/op <父变更>` 进入。路由判定（与 op 入口集成，细则见 `references/routing-contract.md`）：

| 判定 | 路由 |
|------|------|
| `change.yaml.type == epic` 或 `orchestration.enabled: true` | 进入 op-orchestrate 编排视图 |
| 子变更（`change.yaml.parent` 存在） | 按子变更自身 phase 路由到 op-plan/op-build/op-done |
| 其他普通变更 | 原有路由不变 |

编排视图展示：子变更状态矩阵（name/status/phase/gates/里程碑）、可执行动作（进入子变更 / next / done）。子变更执行完 phase 后必须**回到编排视图**，不允许停留在子变更上下文。

### 2. orchestration.yaml — 唯一进度事实源

位置：`.op/changes/<parent>/orchestration.yaml`。

- 由父变更 plan 阶段创建初版，之后**由 op-orchestrate 对账校正回写**（每次渲染编排视图 / 返回编排视图时执行，见 §6），子变更会话无需手工回写；
- 任何编排决策（能否启动、里程碑是否推进、父变更能否归档）都以它为准，不依赖记忆或 index.json；
- `change.yaml` 是子变更自身事实源，orchestration.yaml 是父变更编排事实源；两者冲突时：**子变更自身状态以子变更 change.yaml.phase 为准并回写修正 orchestration.yaml**，编排结论以 orchestration.yaml 为准；
- 字段定义、示例、校验规则见 `references/orchestration-schema.md`（本文件只列核心结构，见下）。

```yaml
parent: <parent-name>
updated_at: "2026-08-10T22:00:00+08:00"
milestones:
  - id: M1
    name: 基础能力
    status: in_progress   # pending | in_progress | blocked | done
children:
  - name: child-a
    title: 子变更A标题
    type: feature
    milestone: M1
    depends_on: []
    status: pending        # pending | active | blocked | done | archived
    phase: plan            # 当前子变更 phase（plan/build/done/archive）
    gates:                 # 三道门槛，全部通过才算完成
      plan_confirmed: false
      build_verified: false
      archived: false
    verified_at: null
```

### 3. 子变更三道门槛（每个子变更独立满足）

| 门槛 | 定义 | 判定来源 | 通过时机 |
|------|------|----------|----------|
| G1 `plan_confirmed` | 子变更 plan 产出经用户确认（feature/complex 需 op-html 确认材料） | 子变更 change.yaml.phase 已由 plan→build（phase ∈ {build, done, archive}）且 plan.md 存在（plan 确认产物，见 routing-contract §3.3） | 子变更 plan 阶段结束 |
| G2 `build_verified` | tasks.md 全部完成（done_count == total_count），无未确认 skip，verify-browser: required 的任务已通过 | 子变更 change.yaml.build.done_count == total_count 且 tasks.md 无未确认 skip 且 phase ∈ {done, archive}（phase 仅确认已退出 build，避免判定时序矛盾） | 子变更 build 阶段结束 |
| G3 `archived` | 子变更完成 op-done 归档 | 子变更 change.yaml.phase == archive 且 archive.json 存在 | 子变更 done 阶段结束 |

- 子变更 `type` 限定 `feature` / `complex`；hotfix / tweak 不得作为编排子变更（无 tasks.md，G1/G2 无法判定）。
- 三道门槛**全部通过**该子变更才算完成；任一门槛未过，父变更不得推进该子变更所属里程碑。
- 判定细则（skip 豁免、verify-browser required 阻塞、count 规则）见 `references/decomposition-rules.md`。

### 4. 依赖 DAG 与 blocked 规则

- 子变更依赖用 `depends_on: [<child-name>...]` 表达（DAG）；
- 子变更 `depends_on` 中**任一子变更未 archived** → 本子变更 `status = blocked`，**不得启动**（`/op <parent> next` 跳过它）；
- 依赖关系含环 → 父变更 plan 阶段必须解开（与 tasks.md DAG 同规则）；
- 同一里程碑内无依赖冲突的子变更可并行（协调者按 op-build DAG 并行分发能力或顺序推进均可，**默认顺序推进、可并行**）；
- `depends_on` 的判定与拓扑排序细则见 `references/decomposition-rules.md`。

### 5. 里程碑推进

- 里程碑定义在父变更 change.yaml 的 `orchestration.milestone_plan`，状态记录在 orchestration.yaml 的 `milestones[]`；
- 里程碑内**全部子变更 archived** 且无 blocked → 里程碑 `done`；
- 任一子变更验证失败（3 次）→ 该子变更暂停，**阻塞其里程碑**，父变更整体显示 `blocked`；
- 子变更可标注 `milestone: M1` 归属里程碑；无里程碑的子变更不参与里程碑推进，直接以"全部 archived"作为父变更归档条件。
- 里程碑状态按派生规则维护：`pending`=全部子变更 pending；`in_progress`=至少一个子变更 active/done/archived 且无 blocked；`blocked`=任一子变更 blocked；`done`=全部子变更 archived（对账时自动计算回写）。
- **父变更 blocked = 任一里程碑 blocked**（由编排视图派生，不新增父 change.yaml 字段）。

### 6. 回写协议（子变更执行完 phase 后）

回写统一由 **op-orchestrate 对账（reconciliation）** 完成（方案 B 兜底，零侵入）：每次渲染编排视图 / 返回编排视图时，运行 `scripts/orchestrate-reconcile.py <父变更名>`（或由 op-orchestrate 主流程内联执行），以子变更 change.yaml（证据源）重算并校正 orchestration.yaml（进度事实源）。子变更执行完 phase 后回到编排视图即触发对账，子变更会话无需手工回写。

各时机对账后应呈现的最终状态（对账脚本据此校正）：

| 时机 | 对账后状态 |
|------|----------|
| 子变更进入执行（phase=plan 开始） | `status: active`，`phase: plan` |
| G1 通过（plan→build） | `gates.plan_confirmed: true`，`phase: build` |
| G2 通过（build 全量验证完成） | `gates.build_verified: true`，`phase: done`，`status: done` |
| G3 通过（op-done 归档完成） | `gates.archived: true`，`phase: archive`，`status: archived`，`verified_at: <时间戳>` |
| 依赖未满足被阻塞 | `status: blocked`（对账按 depends_on 未 archived 自动判定） |

对账后**必须返回编排视图**向用户展示更新后的看板。回写格式与时间戳规范见 `references/orchestration-schema.md`。

### 7. 父变更（epic）生命周期

| 父变更 phase | 行为 | 产物 |
|--------------|------|------|
| `plan` | 拆分：**op-orchestrate 自实现拆分流程**（op-plan 类型表不识别 epic，不加载；复杂/模糊需求按 decomposition-rules §1.2 判定并加载 op-brainstorming），产出子变更清单（范围/验收/依赖/里程碑）+ orchestration.yaml 初版 | `plan.md`（含子变更清单）、`orchestration.yaml`、各子变更 change.yaml |
| `build` | 编排执行：看板管理、next 派发、门槛校验、里程碑推进；**本身不做业务编码** | 各子变更产物 + orchestration.yaml 更新 |
| `done` | 全部子变更 archived 后整体归档：**op-orchestrate 自实现父归档**（不经过 op-done，其 build 校验与类型识别不识别 epic）：生成 archive.json/archive-summary.md、更新 index.json、父 change.yaml.phase → archive；归档材料复用 op-html（默认 md），git 写操作走 safe-git-write | 父变更归档产物 |

父变更 `done` 的放行条件：**全部子变更 `gates.archived == true`**。任一未归档 → 拒绝并展示看板指明缺口。

---

## 契约：两级并行边界

| 层级 | 并行方式 | 路由/载体 |
|------|---------|----------|
| epic 子变更级 | **默认串行推进**（同一里程碑内无依赖冲突的子变更"可并行"，但默认顺序推进） | 经 `/op` 路由 + 编排对账（orchestration.yaml 唯一事实源） |
| task 级（单变更内） | DAG 并行（subagent-driven-development），仅限单变更内 `depends` 非空任务 | 子变更 build 阶段 tasks.md 依赖图 |

**两级层级不同，不得混用：**
- 子变更级并行 ≠ task 级 DAG：子变更的启动/并行决策由编排视图把关（`depends_on` 依赖 archived 判定），**不经过** subagent-driven-development；
- task 级 DAG 并行只作用于单个子变更自己的 tasks.md（`depends` 非空），**不得跨子变更并行分发任务**，也不得把子变更当作 task 挂到另一子变更的 tasks 依赖图；
- 两套依赖表达互不换算：子变更间用 `depends_on`（orchestration.yaml / change.yaml 扩展字段），task 间用 `depends`（tasks.md）。

## 契约：归档三处实现边界

归档契约（`archive.json` + `archive-summary.md` + 精简 change.yaml）由 **op 定义**，共三处实现：

| 实现处 | 负责范围 | 说明 |
|--------|---------|------|
| op | 契约定义 | archive.json / archive-summary.md / 精简 change.yaml 的格式与字段由 op 定义 |
| op-done | 普通变更归档 | 非 epic 变更走 op-done 归档流程 |
| op-orchestrate | epic 父变更归档（自实现） | 复用同一归档契约，但**不经过 op-done**（其 build 校验与类型识别不识别 epic），自实现生成归档产物 |

**演进同步要求**：归档契约变更时，三处（op 定义、op-done 实现、op-orchestrate 实现）必须同步更新，不得只改其一；op-done 与 op-orchestrate 产出的归档材料必须符合同一契约格式，保证 index.json / 归档门户（op-html）可统一消费。

---

## 子变更编排工作流

### 阶段一：父变更 plan 拆分

1. `/op <parent>` 进入编排视图，父变更 phase=plan → 由 op-orchestrate 自实现拆分流程（op-plan 类型表不识别 epic，不加载；复杂/模糊需求按 decomposition-rules §1.2 判定，加载 op-brainstorming）；
2. 产出子变更清单：每个子变更明确**范围 / 验收标准 / depends_on 依赖 / 所属里程碑**，按`references/decomposition-rules.md` 的拆分规则（内聚、可独立验证、单子变更任务量可控）；
3. 创建各子变更 `change.yaml`（含 `parent: <parent-name>`、`type: feature|complex`、`depends_on`、`milestone` 扩展字段，见 `references/orchestration-schema.md`）；
4. 生成 `orchestration.yaml` 初版：milestones 状态 + children 全量清单（status=pending、phase=plan、三道 gates=false）；
5. 子变更清单随父变更 plan 确认材料（op-html，默认 md）一起交用户确认；确认后父变更 phase → build，进入编排执行。

### 阶段二：子变更执行闭环

1. 在编排视图选择子变更，或 `/op <parent> next` 自动取第一个可启动子变更（pending 且依赖 archived）；
2. 子变更作为标准 op 变更，按自身 phase 独立走完 op-plan → op-build → op-done（复用 op-plan/op-build/op-done 全部规则，包括确认暂停、tasks DAG、safe-git-write 归档）；
3. 子变更执行完一个 phase 后按 §Core Rules 6 回写 orchestration.yaml；
4. 回写后返回编排视图，展示更新看板，继续下一个子变更（next 或用户选择）；
5. 任一子变更验证失败 3 次 → 暂停该子变更，阻塞其里程碑，父变更显示 blocked，向用户报告并等用户决策（修复 / 调整范围 / 拆分）。

### 阶段三：门槛校验

- 每次回写后、里程碑推进前、父变更归档前，按 §Core Rules 3 的三道门槛表逐子变更校验；
- 里程碑推进条件：该里程碑内全部子变更 `gates.archived == true`；
- 父变更归档放行条件：全部子变更 `gates.archived == true`；
- 校验工具/输出格式见 `references/dashboard-spec.md`。

### 阶段四：父变更归档

1. 全部子变更 archived 后，`/op <parent> done` 放行；
2. 由 op-orchestrate 自实现父归档（不经过 op-done：其 build 校验与类型识别不识别 epic）：生成 archive.json/archive-summary.md、更新 index.json、父 change.yaml.phase → archive；归档材料复用 op-html（默认 md）；git 写操作唯一入口 safe-git-write；
3. 父变更 phase → archive；orchestration.yaml 标记最终 updated_at 后随父变更归档保留，作为整次编排的完整记录。

---

## Red Flags — STOP

| Smell | Action |
|-------|--------|
| 父变更 build 阶段开始写业务代码 | STOP：epic 不编码，业务代码必须在子变更内实现 |
| 子变更执行完不返回编排视图（对账未触发）就继续下一个 | 先返回视图触发对账校正再前进；编排状态以文件为准，禁止凭记忆推进 |
| `depends_on` 依赖未 archived 的子变更被启动 | 拒绝；标记 blocked 并提示先完成依赖 |
| 子变更门槛未全过但父变更尝试 done | 拒绝归档，展示缺口看板 |
| 子变更 plan/build/done 直接互相调用 | 拒绝；子变更之间无直接调用，全部经 `/op` 路由 + 编排视图对账 |
| orchestration.yaml 与子变更 change.yaml 状态漂移 | 以子变更 change.yaml.phase 为准回写修正，再继续编排 |
| 依赖 DAG 存在环 | 父变更 plan 阶段必须解开；build 阶段发现环 → 暂停并回 plan 修正 |
| 用户在主流程中途直接调用子 skill 绕过 `/op` | 拒绝；提示由 `/op` 路由，子变更执行完 phase 后回到编排视图 |

---

## Common Mistakes

- **把父变更当大号 feature 直接规划全部任务。** epic 的产出是子变更清单 + orchestration.yaml，不是一张巨型 tasks.md；单子变更任务量过大说明拆分粒度不够。
- **凭记忆推进编排。** 不读 orchestration.yaml 就判断"哪个子变更做完了"；文件是唯一事实源。
- **子变更完成后不返回编排视图。** 对账在看板渲染时触发；不返回视图就看不到最新状态，父变更进度无法推进。
- **跳过子变更的独立确认。** 每个子变更仍是标准 op 变更，plan 确认、build 验证、done 归档一步不能省；验证不堆积到父变更最后。
- **在父变更里替子变更做验证。** 验证在子变更 build 阶段完成（G2），父变更只做门槛校验。
- **依赖判断只看 status 不看 gates。** 依赖满足 = 被依赖子变更 `gates.archived == true`，不是 status=done 或"感觉做完了"。
- **子变更命名/字段随意。** `parent` / `depends_on` / `milestone` 字段必须与 orchestration.yaml 一致，否则看板与校验失真。

---

## Version

| Field | Value |
|-------|-------|
| Skill | op-orchestrate |
| Version | 0.2.3 |
| Updated | 2026-09-14 |
| Key change | v0.2.3: 修复 Windows 下 python 管道输出走 GBK 致下游按 UTF-8 解码失败（validate.sh 强制 PYTHONUTF8/PYTHONIOENCODING；内嵌子进程 errors=replace）；v0.2.2: 3R2 演练修复——reconcile 回写 IndentDumper 缩进兼容 status.sh、done 状态可达性、G2 补 skip 检查、confirm.md→plan.md、子变更目录统一嵌套；v0.2.1: 新增两级并行边界契约与归档三处实现边界契约 |
| References | orchestration-schema.md / decomposition-rules.md / dashboard-spec.md / routing-contract.md / registry-integration.md / example-epic.md / ISSUES.md |
