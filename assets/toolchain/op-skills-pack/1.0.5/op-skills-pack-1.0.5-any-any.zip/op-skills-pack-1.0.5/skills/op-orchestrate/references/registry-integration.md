# op-orchestrate 注册与 op 体系集成说明

> 本文档为 op-orchestrate 的**注册与集成方案**（设计契约 §8 分工中 A6 的产物），供协调者（主会话）在注册阶段参考执行。
> 依据：`docs/design/op-orchestrate-design-contract.md`（v0.1 草案）、`op-000/registry.yaml`（version 2）、`op-000/scripts/op-000-register.sh`、`op-000/scripts/op-000-validate.sh`、`op/SKILL.md`。
> 本文档只做建议，不修改任何现有文件；注册动作由协调者经 op-000 执行。

---

## 1. 注册条目方案

### 1.1 完整注册条目（可粘贴）

在 `op-000/registry.yaml` 的 `skills:` 列表中添加以下条目（建议位置：`op-done` 之后、`op-html` 之前，与「入口 → 编排 → 子生命周期 → 支撑」的语义顺序一致；registry 是扁平列表，位置不影响校验）：

```yaml
  - name: op-orchestrate
    description: "当变更类型为 epic（change.yaml.type == epic）或 change.yaml 含 orchestration.enabled: true、需要将复杂需求拆分为多个子变更并统一编排其生命周期（plan→build→done）时使用。由 /op 入口对父变更（epic）路由到本 skill，维护 orchestration.yaml 进度事实源，按依赖 DAG 调度子变更并逐道通过三道验证门槛（plan 确认/build 全量验证/归档）后整体收口。子变更自身仍走标准 op-plan/op-build/op-done，不发明新阶段。"
    status: active
    phase_role: entry
    version: "1.0.0"
    created_at: "2026-08-10T23:20:00+08:00"
    updated_at: "2026-08-10T23:20:00+08:00"
    invoked_by:
      - skill: op
        trigger: "change.yaml.type == epic 或 orchestration.enabled: true 时由 /op 路由（进入编排看板/子变更选择）"
        required: true
    dispatches:
      - op-plan
      - op-build
      - op-done
      - op-html
    dependencies:
      optional:
        - skill: op-plan
          condition: "子变更进入 plan 阶段时按子变更自身 phase 路由"
        - skill: op-build
          condition: "子变更进入 build 阶段时按子变更自身 phase 路由（含 DAG 并行分发）"
        - skill: op-done
          condition: "子变更进入 done 阶段时按子变更自身 phase 路由"
        - skill: op-html
          condition: "子变更 plan 确认暂停点（feature/complex 需确认材料）或父变更整体归档门户"
```

### 1.2 字段逐项说明

| 字段 | 值 | 说明 |
|------|----|----|
| `name` | `op-orchestrate` | 与 SKILL.md frontmatter 的 `name` 必须完全一致（validate 检查 3 强制） |
| `description` | 中文触发条件式 | 与 SKILL.md frontmatter 的 `description` 一致；沿用 op 系列「当……时使用」格式 |
| `status` | `active` | 与全部现有条目一致 |
| `phase_role` | `entry` | 论证见 §4；register 脚本不校验取值，任何合法 YAML 字符串均可写入 |
| `version` | `"0.2.0"` | 当前版；必须与 SKILL.md frontmatter 的 `version` 完全一致（validate 检查 5.2 强制）。初始注册为 0.1.0，ISSUES 决策落地后升 0.2.0 |
| `created_at` | 注册当日时间戳 | 格式仿照 `op-deploy-prep`（`2026-08-05T19:31:05+08:00`） |
| `updated_at` | 与 created_at 相同（注册时） | 后续每次变更升级时更新 |
| `invoked_by` | op 路由 | 声明唯一合法调用方是 op 入口（符合 op「Never invoke sub-skills directly」路由铁律） |
| `dispatches` | op-plan/op-build/op-done/op-html | 声明本 skill 分发的子变更生命周期 skill 与支撑 skill |
| `dependencies` | optional 清单 | 与 dispatches 对应；子变更按自身 phase 路由，故均为 optional 触发条件 |

> 注意：`dispatches` 中列出的 op-plan/op-build/op-done 是**子变更**的执行方（被编排对象），本 skill 自身在父变更生命周期内**不直接承担** plan/build/done 的业务动作，二者不冲突。语义在 §5 关系图中进一步澄清。

---

## 2. 版本与一致性

### 2.1 validate 的版本一致性检查

`op-000-validate.sh` 检查 5.2（位于 op-design-extract 检查段内，但**遍历 registry 全部条目**，对 op-orchestrate 同样生效）：

- 从 `registry.yaml` 提取目标条目 `    version:` 值（`reg_version`）
- 从 `SKILL.md` 的 **frontmatter 段**（首对 `---` 之间）提取 `version:` 值（`skill_version`）
- 两者不一致 → `error`，validate 以非零退出（HAS_ERROR=true）

**结论：op-orchestrate 的 SKILL.md frontmatter 必须包含 `version` 字段，且与 registry.yaml 条目中的 `version` 逐字符一致（含引号风格不影响，取值字符串一致即可）。**

### 2.2 版本管理约定

沿用 op 系列既有惯例（参考 op-plan/op-build/op-html 的历史演进）：

1. **单一事实源 = SKILL.md frontmatter**：registry.yaml 的 `version` 由 `op-000-register.sh --sync` 从 SKILL.md 拉取覆盖（register 脚本 sync_skill 逻辑），**人工改 registry 的 version 属反模式**。
2. **变更即升版**：每次修改 SKILL.md（内容性变更）同步提升 `version`（patch 级 +0.0.1，功能级 +0.x.0），并同步更新 `updated_at`；随后跑 `op-000-register.sh --sync op-orchestrate` 回写 registry。
3. **初始版本**：实际注册以 `0.1.0` 起步（协调者决定），ISSUES 决策落地后升 `0.2.0`。**关键是 registry 与 SKILL.md 两侧一致**（validate 检查 5.2 强制）。
4. **updated_at 同步**：registry 头部 `updated_at` 由 register 脚本自动更新；条目内 `updated_at` 由 `--sync` 覆盖为 SKILL.md frontmatter 值。
5. **校验闭环**：注册/升级后必须跑 `op-000-validate.sh` 验证版本一致性（见 §6）。

---

## 3. validate 兼容性

`op-000-validate.sh` 现有检查对 op-orchestrate 的适用性逐项分析：

| 检查 | 内容 | 对 op-orchestrate 的适用性 | 要求 |
|------|------|---------------------------|------|
| 检查 0 | registry.yaml YAML 可解析、无编码污染（U+20AC/U+FFFD） | 完全适用 | description 保持 UTF-8 中文，无乱码字符 |
| 检查 1 | registry 条目 → SKILL.md 存在（op- 或 op_ 目录） | 完全适用 | `op-orchestrate/SKILL.md` 必须存在（由 A1 产出） |
| 检查 2 | SKILL.md frontmatter 有 `name` 和 `description` | 完全适用 | frontmatter 必须含 `name:`、`description:` 字段；`version` 此处不要求，但检查 5.2 要求 |
| 检查 3 | registry ↔ SKILL.md 的 name 一致；反向：registry 有但 SKILL.md 无 → error | 完全适用 | frontmatter `name: op-orchestrate` 与目录/registry 一致 |
| 检查 4 | 孤立检测（已构建未注册） | 完全适用 | 注册前 validate 会报「已构建但未注册」；注册后消除。SKILL.md 先于注册落地属正常流程 |
| 检查 5.2 | **版本一致性（遍历全部条目）** | 完全适用 | registry `version` == SKILL.md frontmatter `version`（见 §2） |
| 检查 5.1/5.3/5.4 | op-design-extract 专属 | 不涉及 | 与 op-orchestrate 无关，无影响 |

### 3.1 需要协调者注意的点

1. **`phase_role: entry` 是否被接受**：validate 与 register 脚本均**不校验 phase_role 的取值集合**（无白名单），`entry` 可直接写入且不会触发任何 error。`grep '  - name: op-'` 等判定只关心 name 与版本，不关心 phase_role。**结论：兼容，无需改动脚本。**
2. **注册顺序**：op-orchestrate 目录（含 SKILL.md）需先就位再注册，否则检查 1/检查 4 会报错——这是预期行为，不是兼容性问题。
3. **check_skill 的 name 提取**：检查 2/3 用 `sed -n 's/^name:[[:space:]]*//p' | head -1` 提取 SKILL.md **全文首个** `name:`，因此 frontmatter 的 `name` 必须出现在文件中**第一处** `name:` 的位置（op 系列约定 frontmatter 第二行，无冲突）。正文中不得在 frontmatter 之前出现 `name:` 开头的行。
4. **version 提取位置**：检查 5.2 只取 frontmatter 段内的 `version`，正文（如文末 Version 表格）中的 `version` 字样不会误命中——但注意正文表格里写 `| Version | 1.0.0 |` 用的是表格语法，不以 `version:` 开头，安全。

### 3.2 建议（以建议形式列出，不强制，由协调者决定是否落地）

1. **增加 phase_role 取值白名单校验（可选增强）**：在 validate 检查 2 或 register 的 validate_frontmatter 中增加 `phase_role ∈ {entry, plan, build, done, support, meta, foundation}` 校验，可提前捕获拼写错误（如 `entery`）。当前无该检查，`phase_role: entry` 不会被误伤，此项为防御性建议。
2. **编排专属检查（已落地，I-18）**：
   - **epic 父变更必须有 orchestration.yaml**：扫描 `.op/changes/*/change.yaml`，`type == epic` 或 `orchestration.enabled: true` 的变更目录必须存在 `orchestration.yaml`，否则 error。对应设计契约 §4.3「唯一进度事实源」。
   - **子变更 parent 引用完整性**：orchestration.yaml 中 `children[].name` 对应的子变更 change.yaml 必须含 `parent: <父变更名>`，且依赖 `depends_on` 引用的子变更必须存在于同一 orchestration.yaml。
   - **门槛与状态一致性**：子变更 `status: done` 时三道 `gates`（plan_confirmed/build_verified/archived）必须全为 true；`archived` 时子变更 change.yaml 的 `phase == archive` 且 archive.json 存在。
   - **已落地为 `op-orchestrate/scripts/op-orchestrate-validate.sh`**，由 op-000 validate 钩子在 op-orchestrate 存在时按需加载（避免拖慢主 validate，与检查 5 的 design-extract 分段思路一致）。
3. **register 脚本重复注册防护（低优先级）**：`register_skill` 在追加前已有 `grep -q "  - name: $name"` 去重判断，但**无并发/重复执行竞态保护**；协调者手动粘贴条目 + `--sync` 组合时若已有条目会先被 `--sync` 的 die 拦截，风险可控。可在本文档 §6 的命令清单中显式加前置检查。

---

## 4. phase_role 定位：entry vs support

**结论：建议 `phase_role: entry`。**

### 4.1 论证

| 维度 | 论证 |
|------|------|
| **调用方式** | op-orchestrate 是 `/op` 入口的**顶层路由目的地**（设计契约 §6：`/op <parent>` 且 type=epic 时直接进入 op-orchestrate），而非被某个阶段 skill 内部加载的支撑能力。这与 `support`（op-html/op-brainstorming/op-browser 等由 plan/build/done 内部 dispatch）有本质区别。 |
| **与 op 的分工边界** | op 仍是**唯一入口路由器**（负责检索、选变更、读 change.yaml、判断 type），op-orchestrate 是**路由的目的地之一**：当父变更 type=epic 或 orchestration.enabled=true 时，op 把控制权交给 op-orchestrate；op-orchestrate 负责编排看板、子变更调度、门槛把关、整体收口，**不负责**初始化新变更、检索、变更列表展示等入口职责。二者不是替代关系，是「路由器 → 编排目的地」的上下游关系。 |
| **与 phase_role 语义的兼容性** | 现有 `phase_role` 取值：`entry`（op）、`plan/build/done`（阶段 skill）、`support`（支撑）、`meta`（op-000）、`foundation`（能力层）。op-orchestrate 不落在任何一个具体 phase（父生命周期横跨 plan→build→done），用 `entry` 表达「由入口直达的顶层目的地」最贴切；也可理解为「entry 的扩展目的地」。 |
| **registry 现状** | 目前仅 op 一个 entry。增加第二个 entry 不破坏 validate（无 phase_role 白名单校验，见 §3.1）；op-000-list 等工具按 name 索引，不依赖 phase_role 唯一性。 |
| **风险提示** | 两个 entry 可能让后续读者困惑「谁是入口」——需在 description 与 SKILL.md Overview 中显式声明「唯一入口仍是 op，op-orchestrate 是 epic 变更的路由目的地」。此说明已写入 §1 的 description 与 §5 关系图。 |

### 4.2 分工边界（一句话版）

- **op**：负责「找变更、选变更、判断类型、按 phase/type 路由」；对普通变更按 phase 路由到 op-plan/op-build/op-done，对 epic 变更路由到 op-orchestrate。
- **op-orchestrate**：负责「epic 父变更的编排」——展示看板、调度子变更（依赖 DAG、里程碑）、逐子变更把关三道门槛、全部归档后收口父变更；不直接做子变更的 plan/build/done 业务动作，也不做入口检索。

---

## 5. 与 op 系列其他 skill 的关系

```
                          ┌──────────────────────────────┐
                          │            op               │
                          │   唯一入口路由器（检索/选择/路由） │
                          └──────────────┬───────────────┘
                                         │
                     type ∈ {feature, complex, ...}     type == epic 或 orchestration.enabled: true
                     （按 change.yaml.phase 路由）            │
                          ┌──────────────▼───────────────┐
                          │      op-orchestrate         │  父变更编排（phase_role: entry）
                          │  看板 / 子变更调度 / 门槛把关    │
                          └──────┬──────────┬───────────┘
                                 │          │
                 ┌───────────────┼──────────┼───────────────┐
                 │ 分发/路由子变更（按子变更自身 phase）        │
                 ▼               ▼          ▼               ▼
            ┌─────────┐    ┌─────────┐  ┌─────────┐   ┌──────────┐
            │ op-plan │    │ op-build│  │ op-done │   │ op-html  │
            │ 子变更方案 │    │ 子变更编码│  │ 子变更归档│   │ 确认材料/  │
            └─────────┘    └─────────┘  └─────────┘   │ 归档门户  │
                 │               │            │       └──────────┘
                 ▼               ▼            ▼
            ┌─────────────────────────────────────────┐
            │  支撑层（support/meta/foundation）         │
            │  op-brainstorming / op-design-extract /  │
            │  op-browser / op-worktree / safe-git-write│
            │  op-000（注册/校验） / op-html ...         │
            └─────────────────────────────────────────┘
```

关系要点：

1. **op → op-orchestrate**：`invoked_by` 唯一来源，触发条件为 `type: epic` 或 `orchestration.enabled: true`（见设计契约 §3/§6）。
2. **op-orchestrate → op-plan/op-build/op-done**：**子变更**的生命周期复用，编排器不发明新阶段（设计契约 §3「子变更生命周期：完全复用现有 op-plan/op-build/op-done」）。子变更执行完某 phase 后回写 orchestration.yaml 并返回编排视图。
3. **op-orchestrate → op-html**：子变更 plan 确认暂停点（feature/complex 需确认材料）与父变更整体归档门户时使用。
4. **op-000（meta）**：注册/校验/管理 op-orchestrate 的 registry 条目（本文档即其输入之一）；validate 的一致性约束对本 skill 生效。
5. **op 与 op-orchestrate 不互相 dispatch**：op-orchestrate 不调用 op（不存在环）；子变更回编排视图的路径由「回写 orchestration.yaml → 用户/协调者再次 `/op <parent>`」实现，不违反「子 skill 不得互相直接调用」。

---

## 6. 注册执行步骤（协调者操作清单）

前置条件：`op-orchestrate/SKILL.md` 已由 A1 完成并通过 frontmatter 检查（`name` 在文件第二行、含 `description`/`status`/`phase_role`/`version`/`created_at`/`updated_at`，可选用 `invoked_by`/`dispatches`/`dependencies`）。

```bash
# 0) 前置检查（防重复注册）
grep -n "  - name: op-orchestrate" <repo-root>\op-000\registry.yaml || echo "未注册，可继续"

# 1) 校验 SKILL.md frontmatter（只检查不注册）
cd <repo-root>\op-000\scripts
bash op-000-register.sh --check op-orchestrate

# 2) 注册基础字段（name/description/status/phase_role/version/created_at/updated_at）
bash op-000-register.sh op-orchestrate

# 3) 同步编排契约块（invoked_by / dispatches / dependencies 由 SKILL.md frontmatter 同步进 registry）
bash op-000-register.sh --sync op-orchestrate

# 4) 全量一致性校验
bash op-000-validate.sh
```

注意事项：

- **第 2、3 步必须连做**：`register_skill` 只追加基础字段，`invoked_by`/`dispatches`/`dependencies` 三个块**只在 `--sync` 时**从 SKILL.md frontmatter 同步（见 register 脚本 sync_skill 的 extract_block 逻辑）。若跳过 `--sync`，registry 条目缺这三个块，validate 不报错但丢失编排契约信息。
- **`--sync` 的字段来源**：sync 从 SKILL.md frontmatter 拉取 description/status/phase_role/version/updated_at 与三个块，因此 SKILL.md 必须已定稿；若后续升版，重复第 3 步即可。
- **若选择手工粘贴 §1 条目**：粘贴后**仍需**跑第 4 步 validate，且不建议再跑 `--sync`（会覆盖手工块，除非 SKILL.md 与之一致）；建议直接用 register + sync 两条命令，避免手工维护。
- **Windows 执行**：仓库在 Windows 上，用 Git Bash 或 WSL 执行 `.sh`（脚本使用 bash 语法）；不要用 cmd 直接运行。
- **validate 期望输出**：op-orchestrate 相关应出现「SKILL.md 存在」「核心字段完整」「registry ↔ SKILL.md name 一致」「registry ↔ SKILL.md 版本一致（1.0.0）」等 ✅；若 SKILL.md 缺失会报「已构建但未注册」或「SKILL.md 不存在」——先完成 A1 再注册。

---

## 7. 待办/风险清单（协调者确认）

| # | 事项 | 类型 |
|---|------|------|
| 1 | `phase_role` 定为 `entry`（本文档 §4 论证），需与 A5 路由契约、A1 SKILL.md 口径一致 | 一致性确认 |
| 2 | 初始 version 取 `1.0.0` 还是 `0.1.0`，需协调者与 A1 统一 | 一致性确认 |
| 3 | §3.2 编排专属校验（orchestration.yaml 存在性、parent 引用、门槛一致性）**已落地**（op-orchestrate/scripts/op-orchestrate-validate.sh + validate 钩子，I-18） | 已完成 |
| 4 | register 脚本不校验 phase_role 取值集合，拼写错误无预警；若决定加白名单需改 op-000（属于 op-000 范围，需协调者批准） | 可选增强 |
| 5 | 编排契约块（invoked_by/dispatches/dependencies）以 SKILL.md frontmatter 为准，SKILL.md 定稿前勿注册 | 顺序约束 |

---

## Version

| Field | Value |
|-------|-------|
| Skill | op-orchestrate |
| Doc | references/registry-integration.md |
| Version | 0.2.0 |
| Updated | 2026-08-11 |
| Based on | design-contract v0.1, registry.yaml version 2 |
