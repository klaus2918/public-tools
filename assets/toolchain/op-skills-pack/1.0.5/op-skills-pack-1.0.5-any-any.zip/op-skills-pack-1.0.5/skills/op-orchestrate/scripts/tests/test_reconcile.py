# -*- coding: utf-8 -*-
"""orchestrate-reconcile.py 冒烟测试（RED/GREEN + 幂等）
创建临时夹具 → 断言对账结果 → 清理。
"""
import io
import os
import shutil
import subprocess
import sys

FIX = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_fixture")
WS = os.path.join(FIX, "workspace")
PARENT = "parent-epic"
PARENT_DIR = os.path.join(WS, ".op", "changes", PARENT)
SCRIPT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "orchestrate-reconcile.py")

EPIC_CHANGE = """name: parent-epic
title: 对账测试父变更
type: epic
phase: build
created: 2026-08-11
status: active
description: 对账脚本冒烟测试
orchestration:
  enabled: true
  milestone_plan:
    - id: M1
      name: 基础能力
      children: [child-a, child-b]
    - id: M2
      name: 联调
      children: [child-c]
"""

ORCH_INIT = """parent: parent-epic
created: "2026-08-11T00:00:00+08:00"
updated_at: "2026-08-11T00:00:00+08:00"
milestones:
  - id: M1
    name: 基础能力
    status: pending
  - id: M2
    name: 联调
    status: pending
children:
  - name: child-a
    title: 子变更A
    type: feature
    milestone: M1
    depends_on: []
    status: pending
    phase: plan
    gates:
      plan_confirmed: false
      build_verified: false
      archived: false
    verified_at: null
    fail_count: 0
  - name: child-b
    title: 子变更B
    type: feature
    milestone: M1
    depends_on: [child-a]
    status: done
    phase: build
    gates:
      plan_confirmed: true
      build_verified: false
      archived: false
    verified_at: null
    fail_count: 0
  - name: child-c
    title: 子变更C
    type: complex
    milestone: M2
    depends_on: [child-b]
    status: pending
    phase: plan
    gates:
      plan_confirmed: false
      build_verified: false
      archived: false
    verified_at: null
    fail_count: 0
"""

CHILD_A = """name: child-a
title: 子变更A
parent: parent-epic
type: feature
phase: build
created: 2026-08-11
status: active
description: 测试
milestone: M1
depends_on: []
build:
  done_count: 1
  total_count: 3
"""

CHILD_B = """name: child-b
title: 子变更B
parent: parent-epic
type: feature
phase: archive
created: 2026-08-11
status: active
description: 测试
milestone: M1
depends_on: [child-a]
build:
  done_count: 5
  total_count: 5
"""

CHILD_C = """name: child-c
title: 子变更C
parent: parent-epic
type: complex
phase: plan
created: 2026-08-11
status: active
description: 测试
milestone: M2
depends_on: [child-b]
build:
  done_count: 0
  total_count: 2
"""

TASKS = """- [x] task 1
- [ ] task 2
- [ ] task 3
"""


def write(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with io.open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(content)


def setup():
    if os.path.isdir(FIX):
        shutil.rmtree(FIX)
    write(os.path.join(PARENT_DIR, "change.yaml"), EPIC_CHANGE)
    write(os.path.join(PARENT_DIR, "orchestration.yaml"), ORCH_INIT)
    write(os.path.join(PARENT_DIR, "child-a", "change.yaml"), CHILD_A)
    write(os.path.join(PARENT_DIR, "child-a", "plan.md"), "# 计划\n\n## 验收标准\n- 验收点1\n")
    write(os.path.join(PARENT_DIR, "child-a", "tasks.md"), TASKS)
    write(os.path.join(PARENT_DIR, "child-b", "change.yaml"), CHILD_B)
    write(os.path.join(PARENT_DIR, "child-b", "plan.md"), "# 计划\n\n## 验收标准\n- 验收点1\n")
    write(os.path.join(PARENT_DIR, "child-b", "archive.json"), '{"summary": "归档"}')
    write(os.path.join(PARENT_DIR, "child-c", "change.yaml"), CHILD_C)


# 统一 UTF-8 子进程环境：Windows 上 python 管道输出默认走本地代码页（GBK），
# 显式置 PYTHONUTF8/PYTHONIOENCODING 后子进程输出才能被 UTF-8 解码
UTF8_ENV = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8")


def run(args):
    return subprocess.run(
        [sys.executable, SCRIPT] + args,
        cwd=WS, capture_output=True, text=True, encoding="utf-8",
        errors="replace", env=UTF8_ENV)


def main():
    setup()
    ok = True

    # 1. dry-run：应检测到漂移且不写回
    r = run([PARENT, "--workspace", WS, "--dry-run"])
    out = r.stdout + r.stderr
    assert "漂移" in out, "dry-run 未报告漂移: %s" % out
    assert "child-a gates.plan_confirmed" in out, "child-a G1 未校正: %s" % out
    assert "child-a phase plan -> build" in out, "child-a phase 未校正: %s" % out
    assert "child-b status done -> archived" in out, "child-b archived 未校正: %s" % out
    assert "milestone M1 status pending -> in_progress" in out, "M1 未校正: %s" % out
    assert "milestone M2 status pending -> in_progress" not in out, "M2 不应推进: %s" % out
    print("[GREEN] dry-run 检测漂移正确")

    # 2. 真实对账：写回并验证文件
    r = run([PARENT, "--workspace", WS])
    assert "已回写" in (r.stdout + r.stderr), "未写回: %s" % (r.stdout + r.stderr)
    import yaml
    with io.open(os.path.join(PARENT_DIR, "orchestration.yaml"), encoding="utf-8") as f:
        orch = yaml.safe_load(f)
    by = {c["name"]: c for c in orch["children"]}
    assert by["child-a"]["phase"] == "build", by["child-a"]
    assert by["child-a"]["gates"]["plan_confirmed"] is True, by["child-a"]
    assert by["child-a"]["status"] == "active", by["child-a"]
    assert by["child-b"]["phase"] == "archive", by["child-b"]
    assert by["child-b"]["status"] == "archived", by["child-b"]
    assert by["child-b"]["gates"]["archived"] is True, by["child-b"]
    assert by["child-b"]["verified_at"], by["child-b"]
    assert by["child-c"]["status"] == "pending", by["child-c"]
    assert {m["id"]: m["status"] for m in orch["milestones"]} == {"M1": "in_progress", "M2": "pending"}, orch["milestones"]
    print("[GREEN] 真实对账写回正确")

    # 3. 幂等：重跑应无漂移
    r = run([PARENT, "--workspace", WS])
    assert "无漂移" in (r.stdout + r.stderr), "对账不幂等: %s" % (r.stdout + r.stderr)
    print("[GREEN] 对账幂等")

    # 4. 缺失目录 → missing 警告
    shutil.rmtree(os.path.join(PARENT_DIR, "child-c"))
    r = run([PARENT, "--workspace", WS])
    assert "child-c" in (r.stdout + r.stderr) and "missing" in (r.stdout + r.stderr).lower(), r.stdout + r.stderr
    print("[GREEN] 缺失目录标记 missing")

    print("=== reconcile 冒烟测试全部通过 ===")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
