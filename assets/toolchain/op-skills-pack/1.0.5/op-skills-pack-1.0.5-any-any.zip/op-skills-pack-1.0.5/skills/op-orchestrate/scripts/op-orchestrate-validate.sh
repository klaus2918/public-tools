#!/usr/bin/env bash
# op-orchestrate 编排一致性校验（op-000 validate 钩子调用；也可独立运行）
#
# 用法：bash op-orchestrate-validate.sh [WORKSPACE]
#   WORKSPACE 默认当前目录；扫描 .op/changes/*/change.yaml 中 type=epic 的变更，
#   对每个 epic 父变更执行编排校验。任何 ERROR → exit 1。
#
# 校验点实现依据：references/orchestration-schema.md §9、routing-contract.md §3.3
set -euo pipefail

# 强制 UTF-8 输出：Windows 上 python 管道输出默认走本地代码页（GBK），
# 会使按 UTF-8 解析本脚本输出的调用方报 UnicodeDecodeError（与 op-000-validate.sh 同约定）
export PYTHONUTF8="${PYTHONUTF8:-1}"
export PYTHONIOENCODING="${PYTHONIOENCODING:-utf-8}"

WORKSPACE="${1:-$(pwd)}"
CHANGES_DIR="$WORKSPACE/.op/changes"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RECONCILE="$SCRIPT_DIR/orchestrate-reconcile.py"

if [ ! -d "$CHANGES_DIR" ]; then
  echo "INFO|无变更目录（.op/changes 不存在），跳过编排校验"
  exit 0
fi

# 探测可用的 python（Windows 上 python3 可能是 Microsoft Store 占位符；
# 本机实测 python 常不在 PATH，仅 py launcher 可用——脚本不得裸调 python）
PY_CMD=""
for c in py python3 python; do
  if command -v "$c" >/dev/null 2>&1; then
    if "$c" -c 'import json' >/dev/null 2>&1; then
      PY_CMD="$c"
      break
    fi
  fi
done

if [ -z "$PY_CMD" ]; then
  echo "WARN|无可用 python（py/python3/python），跳过编排一致性校验"
  exit 0
fi

# 内嵌 python：扫描并校验全部 epic 父变更
output=$("$PY_CMD" - "$WORKSPACE" "$RECONCILE" <<'PY'
import io, os, re, sys

workspace, reconcile_script = sys.argv[1], sys.argv[2]
changes_dir = os.path.join(workspace, ".op", "changes")
try:
    import yaml
except ImportError:
    # 环境降级而非体系错误：WARN 不设失败，避免"❌ 输出 + exit 0"半掩蔽矛盾
    print("WARN|环境缺少 pyyaml，跳过编排校验（环境降级，非体系错误）")
    sys.exit(0)

def load(path):
    if not os.path.isfile(path):
        return None
    with io.open(path, encoding="utf-8") as f:
        try:
            return yaml.safe_load(f)
        except Exception as e:
            print("ERROR|YAML 解析失败 %s: %s" % (path, e))
            return {}

def read_text(path):
    try:
        with io.open(path, encoding="utf-8") as f:
            return f.read()
    except Exception:
        return ""

def child_dir(pdir, cname, workspace):
    """子变更目录：优先 .op/changes/<parent>/<child>；
    已被 op-done 物理移出时，回退 .op/archive/*/*/<child>（归档态识别）。"""
    live = os.path.join(pdir, cname or "")
    if os.path.isdir(live):
        return live
    import glob
    for h in glob.glob(os.path.join(workspace, ".op", "archive", "*", "*", cname or "")):
        if os.path.isdir(h):
            return h
    return None


def is_epic(cy):
    return (cy or {}).get("type") == "epic" or (cy or {}).get("orchestration", {}).get("enabled") is True

def iso_ok(s):
    if not isinstance(s, str):
        return False
    return bool(re.match(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[+-]\d{2}:\d{2}$", s))

def has_cycle(names, deps):
    """拓扑排序检测环。返回环上节点或 None。"""
    indeg = {n: 0 for n in names}
    adj = {n: [] for n in names}
    for n in names:
        for d in deps.get(n, []):
            if d in indeg:
                adj[d].append(n)
                indeg[n] += 1
    q = [n for n in names if indeg[n] == 0]
    cnt = 0
    while q:
        u = q.pop()
        cnt += 1
        for v in adj[u]:
            indeg[v] -= 1
            if indeg[v] == 0:
                q.append(v)
    if cnt != len(names):
        return [n for n in names if indeg[n] > 0]
    return None

# 找出所有 epic 父变更
parents = []
for name in sorted(os.listdir(changes_dir)):
    pdir = os.path.join(changes_dir, name)
    if not os.path.isdir(pdir):
        continue
    cy = load(os.path.join(pdir, "change.yaml"))
    if is_epic(cy):
        parents.append((name, pdir, cy))

if not parents:
    print("INFO|未发现 epic 父变更，跳过编排校验")
    sys.exit(0)

for pname, pdir, pcy in parents:
    print("CHECK|父变更 %s" % pname)
    # 1. type: epic 必须 orchestration.enabled: true
    if (pcy or {}).get("type") == "epic" and (pcy or {}).get("orchestration", {}).get("enabled") is not True:
        print("ERROR|type=epic 但 orchestration.enabled != true")
    # 2. orchestration.yaml 存在性
    orch_path = os.path.join(pdir, "orchestration.yaml")
    orch = load(orch_path)
    phase = (pcy or {}).get("phase", "plan")
    if orch is None:
        if phase == "plan":
            print("INFO|父 phase=plan，orchestration.yaml 尚未初始化（预期，待拆分定稿）")
        else:
            print("ERROR|父 phase=%s 但 orchestration.yaml 缺失" % phase)
        continue
    if orch is None:
        continue
    # 3. parent 一致
    if orch.get("parent") != pname:
        print("ERROR|orchestration.yaml.parent=%s 与 change.yaml.name=%s 不一致" % (orch.get("parent"), pname))
    # 3b. created/updated_at 格式
    if not iso_ok(orch.get("created")):
        print("ERROR|orchestration.yaml.created 缺失或非 ISO8601 带时区")
    if not iso_ok(orch.get("updated_at")):
        print("ERROR|orchestration.yaml.updated_at 缺失或非 ISO8601 带时区")
    # 4. children 双向匹配
    children = orch.get("children") or []
    child_names = [c.get("name") for c in children]
    dir_children = []
    for sub in sorted(os.listdir(pdir)):
        sdir = os.path.join(pdir, sub)
        cy2 = load(os.path.join(sdir, "change.yaml"))
        if cy2 and cy2.get("parent") == pname:
            dir_children.append(sub)
    for c in child_names:
        if child_dir(pdir, c, workspace) is None:
            print("ERROR|orchestration children 指向不存在的目录（活动区与归档区均无）：%s" % c)
    for d in dir_children:
        if d not in child_names:
            print("ERROR|子变更 %s 声明 parent=%s 但不在 orchestration children 清单" % (d, pname))
    # 5/6. 子变更声明检查
    deps = {}
    for c in children:
        cname = c.get("name")
        cdir = child_dir(pdir, cname, workspace) if cname else None
        ccy = load(os.path.join(cdir, "change.yaml")) if cdir else None
        if ccy is None:
            print("ERROR|子变更 %s 的 change.yaml 缺失（活动区与归档区均未找到）" % cname)
            continue
        if ccy.get("parent") != pname:
            print("ERROR|子变更 %s 的 parent 字段与父变更不一致" % cname)
        ctype = ccy.get("type")
        if ctype not in ("feature", "complex"):
            print("ERROR|子变更 %s type=%s 非法（限定 feature/complex）" % (cname, ctype))
        cdeps = ccy.get("depends_on") or []
        deps[cname] = cdeps
        if cname in cdeps:
            print("ERROR|子变更 %s 自引用 depends_on" % cname)
        for d in cdeps:
            if d not in child_names:
                print("ERROR|子变更 %s 依赖 %s 不在同一父变更 children 清单" % (cname, d))
        ms = ccy.get("milestone")
        if ms and ms not in [m.get("id") for m in (orch.get("milestones") or [])]:
            print("ERROR|子变更 %s milestone=%s 不在父里程碑计划" % (cname, ms))
        if ms and ms != c.get("milestone"):
            print("WARN|子变更 %s milestone 与 orchestration.yaml 不一致" % cname)
    # 7. 环检测
    cyc = has_cycle(child_names, deps)
    if cyc:
        print("ERROR|依赖存在环：%s" % " -> ".join(cyc))
    # 8. 门槛与状态一致性
    dep_status = {c.get("name"): c.get("status") for c in children}
    for c in children:
        cname = c.get("name")
        st = c.get("status")
        g = c.get("gates") or {}
        g_all = all(g.get(k) is True for k in ("plan_confirmed", "build_verified", "archived"))
        if st == "done" and not g_all:
            print("ERROR|子变更 %s status=done 但门槛未全过" % cname)
        if st == "archived":
            if not g.get("archived"):
                print("ERROR|子变更 %s status=archived 但 gates.archived 未置 true" % cname)
            if not c.get("verified_at"):
                print("ERROR|子变更 %s status=archived 但 verified_at 为空" % cname)
        if st == "blocked":
            dep_unarchived = [d for d in (c.get("depends_on") or []) if dep_status.get(d) != "archived"]
            if not dep_unarchived and (c.get("fail_count") or 0) < 3:
                print("WARN|子变更 %s status=blocked 但依赖均 archived 且 fail_count<3（可能是验证失败暂停，人工核对）" % cname)
    # 9. 父 phase 与编排进度冲突
    if phase == "done" and not all(s == "archived" for s in dep_status.values() if s is not None):
        print("ERROR|父 phase=done 但存在未 archived 子变更")
    # 10. 里程碑一致性
    for m in (orch.get("milestones") or []):
        msts = [c.get("status") for c in children if c.get("milestone") == m.get("id")]
        if not msts:
            continue
        expect = ("blocked" if "blocked" in msts else
                  "done" if all(s == "archived" for s in msts) else
                  "pending" if all(s == "pending" for s in msts) else "in_progress")
        if m.get("status") != expect:
            print("WARN|里程碑 %s status=%s 与派生规则不符（应为 %s，运行 reconcile 校正）" % (m.get("id"), m.get("status"), expect))
    # 11. 对账漂移提示（只读检查，不写回）
    if os.path.isfile(reconcile_script):
        import subprocess
        r = subprocess.run([sys.executable, reconcile_script, pname, "--workspace", workspace, "--dry-run"],
                           capture_output=True, text=True, encoding="utf-8", errors="replace")
        if "无漂移" not in (r.stdout + r.stderr):
            print("WARN|orchestration.yaml 与证据源存在漂移，建议运行 orchestrate-reconcile.py %s 校正" % pname)
PY
)

# 汇总（统一输出带徽标行，避免与原始输出重复）
has_error=false
while IFS= read -r line; do
  [ -z "$line" ] && continue
  case "$line" in
    ERROR\|*) has_error=true; echo "❌ ${line#ERROR|}";;
    WARN\|*)  echo "⚠️  ${line#WARN|}";;
    INFO\|*)  echo "ℹ️  ${line#INFO|}";;
    CHECK\|*) echo "📋 ${line#CHECK|}";;
    *)        echo "$line";;
  esac
done <<< "$output"

if [ "$has_error" = true ]; then
  exit 1
fi
exit 0
