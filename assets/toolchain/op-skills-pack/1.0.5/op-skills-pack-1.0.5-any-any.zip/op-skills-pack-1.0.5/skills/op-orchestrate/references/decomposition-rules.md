# op-orchestrate 拆分规则与验证门槛细则

> 定位：op-orchestrate 的「复杂需求拆分为子变更」规则与「验证门槛判定」细则（A3 产物）。
> 依据：`docs/design/op-orchestrate-design-contract.md` §2 设计目标、§5 状态机与门槛；`op-plan/SKILL.md` v3.4.0 §4.3 complex 触发判定。
> 使用方：协调者（父变更 plan 阶段拆分）、op-orchestrate 主流程（门槛判定/并行调度）、子变更执行者（验收自查）。

## Overview

本文档回答两件事：

1. **何时拆、怎么拆**：复杂需求满足什么条件应升级为 epic 编排，子变更的拆分原则与验收标准要求。
2. **何时算过**：每个子变更的三道验证门槛（G1 plan_confirmed / G2 build_verified / G3 archived）的判定细则与检查清单。

核心立场与契约 §2 一致：**验证前置，不堆积到最后**。验收标准在拆分时定义，门槛在 phase 流转时判定，父变更只在全部子变更归档后推进。

## When to Use

| 场景 | 参照章节 |
|------|----------|
| 父变更 plan 阶段：判断是否启用 epic、如何拆 | §1 拆分触发判定、§2 拆分原则 |
| 拆分时为子变更定义验收标准 | §3 验收标准要求 |
| 子变更 phase 流转：判定 G1/G2/G3 | §4 三道门槛判定细则 |
| 判断 blocked / 并行调度 | §5 依赖与并行规则 |
| 判断里程碑能否推进、失败如何暂停 | §6 里程碑推进规则 |

## Quick Reference

| 判定问题 | 一句话答案 | 详见 |
|----------|------------|------|
| 要不要拆成 epic？ | 命中"强制 epic"（任务 ≥30、分阶段表达、里程碑诉求）即拆；仅"倾向"需反问 | §1 |
| 子变更多大合适？ | 5-10 个 task；<3 合并，>15 再拆 | §2 |
| 验收标准何时定？ | 拆分时就定，G 门槛 + 业务验收点 2-5 条 | §3 |
| G1 怎么过？ | phase==build 且 plan/tasks/确认材料存在 | §4.1 |
| G2 怎么过？ | tasks 全完成、无未确认 skip、required 浏览器验证通过 | §4.2 |
| G3 怎么过？ | phase==archive 且 archive.json 存在 | §4.3 |
| 什么算 blocked？ | depends_on 任一未 archived | §5.2 |
| 什么能并行？ | 无直接/传递依赖、无共享写冲突、同里程碑 | §5.3 |
| 里程碑何时推进？ | 里程碑内全部子变更 archived | §6 |
| 失败几次暂停？ | 同一验证点连续 3 次失败 | §6.3 |

## Core Rules

### 1. 拆分触发判定

#### 1.1 complex 与 epic 的分界

| 层级 | 适用场景 | 生命周期 |
|------|----------|----------|
| `complex` | 单一不可分割的复杂目标；brainstorm 后仍作为**一个**变更走完 | plan → build → done |
| `epic`（编排） | 目标本身可拆为多个**有依赖关系、各自可独立闭环**的子目标，需要分阶段交付 | 父变更编排 + 子变更各自 plan → build → done |

分界判据：**拆出的每个子变更是否都能独立回答"输入→处理→输出"并独立验证**。能 → epic；不能 → 先做 complex，不要为拆而拆。

#### 1.2 epic 判定表（父变更 plan 阶段必走的决策表）

综合 op-plan §4.3 复杂判定信号，叠加"可分阶段交付"维度得到：

| # | 判定信号 | 命中值 | 决策 | 强制动作 |
|---|----------|--------|------|----------|
| 1 | 任务数预估 | ≥ 30 | **强制 epic** | `orchestration.enabled: true`，拆 3+ 子变更 |
| 2 | 任务数预估 | 15-29 | 倾向 epic | 反问用户是否拆分 |
| 3 | 跨模块数 | ≥ 3 且需分阶段交付 | 倾向 epic | 反问用户确认 |
| 4 | 数据模型变更 | 新增表/改字段 ≥ 5 | 倾向 epic | 反问（单一目标仍可 complex） |
| 5 | 外部集成 | ≥ 2 个独立第三方（API/SDK/中间件） | 倾向 epic | 反问 |
| 6 | 架构层改动 | 改 base/共享库/公共组件且影响 ≥ 3 模块 | 倾向 epic | 反问 |
| 7 | 用户表达 | 含"平台级/中台/多期/分阶段/统一" | **强制 epic** | 拆分 + 里程碑计划 |
| 8 | 里程碑诉求 | 用户明确要求分阶段交付/上线 | **强制 epic** | 拆分 + 里程碑计划 |
| 9 | 验证域 | ≥ 3 个独立验证域（浏览器/接口/DB/跨端联调） | 倾向 epic | 反问 |

**决策规则**（延续 op-plan §4.3 规则）：
- 任一"强制 epic"命中 → 拆分为 epic，不允许 `/op-plan` 自身跳过。
- 仅"倾向 epic"命中 → 反问用户；用户确认不拆 → 按 complex 走（须用户显式否决并签字留痕）。
- 全部未命中 → 按正常 op-plan 类型（feature/complex）走。

#### 1.3 拆分决策树

```
任务数预估 ≥ 30？ ──────────是──→ 强制 epic（拆 3+ 子变更）
   │否
含"分阶段/多期/平台级"表达？ ────是──→ 强制 epic
   │否
用户要求分阶段交付/上线？ ───────是──→ 强制 epic
   │否
跨模块 ≥3 且分阶段？ ───────────是──→ 倾向 epic → 反问
   │否
数据模型变更 ≥5？ ──────────────是──→ 倾向 epic → 反问
   │否
外部集成 ≥2？ ──────────────────是──→ 倾向 epic → 反问
   │否
验证域 ≥3？ ────────────────────是──→ 倾向 epic → 反问
   │否
按 feature/complex 正常走
```

#### 1.4 判定口诀

> **一个变更一个问题域；多期、多域、超量必拆分。** 命中"强制"不问能不能拆，只问怎么拆。

---

### 2. 拆分原则

#### 2.1 五条拆分原则

| 原则 | 要求 | 违反反例 |
|------|------|----------|
| **P1 完整可验证** | 每个子变更独立走 plan→build→done，验证不依赖其他子变更 | 子变更 A 的验收要等 B 上线才能测（隐藏依赖） |
| **P2 范围内聚** | 单一业务目标；目标不同就拆 | 一个子变更同时做"登录改造 + 报表导出" |
| **P3 大小适中** | 建议 5-10 个 task；<3 合并，>15 再拆 | 1 个 task 的子变更；25 个 task 的子变更 |
| **P4 依赖显式化** | `depends_on` 声明全部依赖，禁止隐含依赖 | 依赖共享表结构却不写 `depends_on` |
| **P5 里程碑归属清晰** | 每个子变更归属唯一里程碑 | 一个子变更横跨 M1/M2 |

#### 2.2 拆得过细的判断标准

| 信号 | 判定 | 处置 |
|------|------|------|
| 子变更 ≤ 2 个 task | 过细 | 合并进相邻子变更 |
| 子变更验收点与父验收点完全重复 | 过细 | 合并或删除该层 |
| 子变更间靠"口头约定"衔接（无文件/接口/表产物） | 过细且依赖不实 | 先补产物契约再拆 |
| 为拆而拆：子变更无独立用户价值 | 过细 | 合并 |

#### 2.3 拆得过粗的判断标准

| 信号 | 判定 | 处置 |
|------|------|------|
| 子变更 ≥ 15 个 task | 过粗 | 再拆一层（每层 5-10 task） |
| 子变更包含 ≥ 2 个业务目标 | 过粗 | 按目标拆分 |
| 子变更验证需要多轮联调才发现问题 | 过粗 | 抽出联调子变更（type: test） |
| 验证无法在 build 阶段收敛（验证堆积到里程碑末尾） | 过粗 | 细分验证单元 |

#### 2.4 拆分健康度五问（每拆出一个子变更都自检）

1. 能否独立回答"输入 → 处理 → 输出"？
2. 能否独立定义验收点并独立执行验证（不依赖其他子变更上线）？
3. 拆后是否产生隐藏前提（验证 A 必须先有 B）？
4. 子变更间是否有清晰产物契约（接口/表结构/共享文件）？
5. 每个子变更是否都有唯一里程碑归属？

任一问题答案为"否" → 回到拆分表重拆。

#### 2.5 拆分产出物

父变更 plan 阶段必须产出：

| 产物 | 内容 | 去向 |
|------|------|------|
| `orchestration.yaml` 初版 | 子变更清单 + `depends_on` + `milestone` | `.op/changes/<parent>/orchestration.yaml` |
| 子变更验收标准 | 每个子变更的 G 门槛 + 业务验收点（§3 模板，2-5 条） | orchestration.yaml `acceptance` 段（A2 已落地，见 orchestration-schema §4.5） |
| 子变更间契约 | 接口/表结构/共享文件约定（如有） | 写入对应子变更 plan.md「设计依据」 |
| 里程碑计划 | M1/M2... 各含哪些子变更 | change.yaml `orchestration.milestone_plan` |

> 拆分确认（I-13）：拆分清单（含子变更名称）经用户确认后，才创建子变更目录与 change.yaml，防止孤儿目录；确认留痕复用 op-html（默认 md）。

---

### 3. 验收标准要求

#### 3.1 三层验收模型（拆分时就定义，验证不堆积到最后）

| 层 | 内容 | 定义时机 | 判定时机 |
|----|------|----------|----------|
| G 门槛 | plan_confirmed / build_verified / archived | 拆分时登记 gates 为 false | phase 流转时逐道判定 |
| 业务验收点 | 用户可观察结果 2-5 条，可量化 | 拆分时定义 | build 验证时逐条核对 |
| 里程碑出口条件 | 里程碑级验收（可选） | 拆分时定义 | 里程碑推进时 |

#### 3.2 验收标准模板（orchestration.yaml，字段落地由 A2 在 schema 中定稿）

```yaml
- name: child-a
  title: 子变更A标题
  type: feature
  milestone: M1
  depends_on: []
  acceptance:
    gates:                      # 三道门槛，全部通过才算完成
      plan_confirmed: false
      build_verified: false
      archived: false
    business:                   # 业务验收点：可观察、可量化、可独立验证
      - "PC 端用户完成表单提交后看到成功提示（verify-browser: required）"
      - "提交数据落库，5 个关键字段与 DB 契约一致"
      - "接口冒烟：POST /api/xxx 返回 200 且重复提交幂等"
  exit_conditions:              # 可选：里程碑出口条件（通常放里程碑级，不放子变更）
    []
```

#### 3.3 业务验收点编写要求

| 要求 | 示例 |
|------|------|
| 每条含"角色 + 动作 + 可观察结果" | 审批人在 PC 端点击通过后，待办列表消失 |
| 数量 2-5 条 / 子变更 | 3 条 |
| 可量化 | 返回 200、5 个字段一致、页面 3 秒内加载 |
| 标注验证方式 | 接口冒烟 / 浏览器手测 / 浏览器自动化 |
| 与 tasks.md `verify` 字段对应 | 验收点→至少一条 task 落地该验证 |
| 禁止不可判定描述 | ✗"功能正常""跑通即可" ✓"提交后 5 秒内收到成功提示" |

#### 3.4 验收防堆积原则

- **拆分时定**：验收标准随拆分清单一起产出，不等 build 完补。
- **逐子变更判**：G1/G2/G3 在 phase 流转时判定，不积到里程碑末尾一次性验收。
- **业务验收点逐条过**：G2 通过的前提是 `business` 验收点全部满足（不仅 task 打勾）。

---

### 4. 三道门槛判定细则

#### 4.0 通用前置

| 项 | 约定 |
|----|------|
| 判定对象 | 每个子变更独立判定 |
| 判定时机 | phase 流转：plan→build 判 G1；build→done 判 G2；done→archive 判 G3 |
| 判定人 | 协调者 / op-orchestrate 主流程 |
| 判定依据 | orchestration.yaml（唯一进度事实源）+ 子变更目录产物 |
| 判定后动作 | 回写 orchestration.yaml gates + 子变更 status，再进入下一 phase |

#### 4.1 G1 plan_confirmed（plan 确认）

**定义**：子变更 plan 产出经用户确认，`phase` 由 plan → build。

**判定来源**（契约 §5.2）：子变更 `change.yaml.phase == build` 且 confirm 产物存在。

**检查清单**：

| # | 检查项 | 判据 |
|---|--------|------|
| 1 | phase 已切换 | `change.yaml.phase == build` |
| 2 | plan.md 存在 | `.op/changes/<parent>/<child>/plan.md` 可读 |
| 3 | plan.md 含验收标准章节 | 存在「验收标准」章节（feature/complex 必含） |
| 4 | tasks.md 存在 | `.op/changes/<parent>/<child>/tasks.md` 可读且 task 总数 ≥ 1 |
| 5 | 确认材料存在 | feature/complex：op-html 确认材料（`op-html/sites/<project>/<child>/` 或确认 md 文件）存在 |
| 6 | 用户确认留痕 | 确认文件/确认时间戳存在（口头确认不满足 feature/complex） |
| 7 | skip 已豁免 | tasks 含 `verify: skip` 时，plan.md 已有显式豁免说明（否则 RF-06 类问题） |

**判定脚本命令建议**（在 `.op/changes/<parent>/<child>/` 下执行）：

```bash
phase=$(grep -E '^phase:' change.yaml | awk '{print $2}')
[ "$phase" = "build" ] && \
[ -f plan.md ] && [ -f tasks.md ] && \
[ "$(grep -c '^- \[' tasks.md)" -ge 1 ] && \
grep -q '验收标准' plan.md && \
[ -n "$(find ../op-html -path '*<child>*' 2>/dev/null | head -1)" ] \
  && echo "G1 PASS" || echo "G1 FAIL"
```

**判定结果**：
- G1 PASS → 允许进入 build，回写 `gates.plan_confirmed: true`。
- G1 FAIL → 停留在 plan，禁止进入 build（对应 op-plan RF-05：feature/complex 未生成确认页不得切 phase）。

#### 4.2 G2 build_verified（构建验证）

**定义**：子变更 tasks.md 全部完成，无未确认 skip，`verify-browser: required` 任务已通过。

**判定来源**（契约 §5.2）：子变更 `change.yaml.build`（done_count == total_count）+ tasks.md 无未确认 skip + 验证记录；判定时点 phase ∈ {done, archive}（phase 仅确认已退出 build，避免判定时序矛盾，I-05）。

**检查清单**：

| # | 检查项 | 判据 |
|---|--------|------|
| 1 | 全部任务完成 | `[x]` 数量 == task 总数，无残留 `[ ]`（done_count == total_count） |
| 2 | 无未确认 skip | `verify: skip` 任务均有 plan.md 显式豁免说明，否则视为未确认 skip → G2 不过 |
| 3 | required 浏览器验证通过 | `verify-browser: required` 任务有通过记录（op-browser 会话/截图/日志） |
| 4 | 业务验收点满足 | §3 定义的 `business` 验收点逐条核对通过 |
| 5 | 失败次数未超限 | 同一验证点连续失败 ≤ 2 次（3 次触发暂停，见 §6.3） |
| 6 | phase 已退出 build | phase ∈ {done, archive}（G2 判定时点；避免 build 中途误判 done，I-05） |

**判定脚本命令建议**：

```bash
cd .op/changes/<child>
total=$(grep -c '^- \[' tasks.md)
done_n=$(grep -c '^- \[x\]' tasks.md)
skip=$(grep -c 'verify: skip' tasks.md)
req=$(grep -c 'verify-browser: required' tasks.md)
[ "$done_n" -eq "$total" ] || echo "未完成任务: $((total-done_n))"
echo "G2 判定: done=$done_n/$total skip=$skip browser_required=$req"
echo "未确认 skip 需人工核对 plan.md 豁免说明；required 需人工核对验证记录"
```

**判定结果**：
- G2 PASS → 允许进入 done，回写 `gates.build_verified: true`。
- G2 FAIL → 停留在 build：补任务/补验证/补豁免说明后重判。

#### 4.3 G3 archived（归档完成）

**定义**：子变更完成 op-done 归档。

**判定来源**（契约 §5.2）：子变更 `change.yaml.phase == archive` 且 archive.json 存在。

**检查清单**：

| # | 检查项 | 判据 |
|---|--------|------|
| 1 | phase 已归档 | `change.yaml.phase == archive` |
| 2 | 归档元数据存在 | `.op/changes/<parent>/<child>/archive.json` 存在且含归档摘要 |
| 3 | 归档门户（--full） | 走完整路径时归档门户/汇总已生成 |
| 4 | 编排回写 | orchestration.yaml 中该子变更 `gates` 全 true、`status == archived` |

**判定脚本命令建议**：

```bash
cd .op/changes/<child>
[ "$(grep -E '^phase:' change.yaml | awk '{print $2}')" = "archive" ] && \
[ -f archive.json ] && echo "G3 PASS" || echo "G3 FAIL"
```

**判定结果**：
- G3 PASS → 子变更完成（status=archived），其依赖方解除阻塞。
- G3 FAIL → 停留在 done，补归档。

#### 4.4 三门槛综合判定

**子变更完成 ⇔ G1 ∧ G2 ∧ G3**。任一未过时的状态归属：

| 门槛 | 未过时状态 | 处置 |
|------|-----------|------|
| G1 | 停留在 plan | 补确认材料/补 plan，不启动 build |
| G2 | 停留在 build | 修任务/补验证/补豁免 |
| G3 | 停留在 done | 补归档 |

**编排视图综合判定（orchestration.yaml 扫描）**：

```bash
# 伪代码：对每个 child 依次判定并回写 gates
for child in $(yq '.children[].name' orchestration.yaml); do
  g1=$(judge_g1 "$child")   # §4.1 检查清单
  g2=$(judge_g2 "$child")   # §4.2 检查清单
  g3=$(judge_g3 "$child")   # §4.3 检查清单
  yq -i ".children[] | select(.name==\"$child\") | \
        .gates = {plan_confirmed:$g1, build_verified:$g2, archived:$g3}" \
        orchestration.yaml
done
```

---

### 5. 依赖与并行规则

#### 5.1 DAG 表达

- 子变更 `depends_on` 构成 DAG，方向：被依赖 → 依赖方。
- `orchestration.yaml` 是依赖的唯一事实源；plan.md 中的依赖描述仅供参考，以 orchestration.yaml 为准。
- 依赖语义：`depends_on` 中所有子变更 **archived**（G1∧G2∧G3 全过）后，本子变更才可启动 plan。

#### 5.2 blocked 判定

| 条件 | 子变更 status | 处置 |
|------|--------------|------|
| `depends_on` 任一子变更未 archived | blocked | 不得启动 plan，看板显示依赖未完成 |
| 依赖已满足但自身 G 门槛未过（如 G1 未过） | active（停留在当前 phase） | 不算 blocked，继续补当前 phase |
| 所属里程碑 blocked / paused | 继承阻塞（blocked） | 里程碑恢复前不得启动 |

**判定脚本命令建议**：

```bash
# child-b 是否 blocked：检查其全部依赖是否 archived
for dep in $(yq ".children[] | select(.name==\"child-b\") | .depends_on[]" orchestration.yaml); do
  st=$(yq ".children[] | select(.name==\"$dep\") | .status" orchestration.yaml)
  [ "$st" = "archived" ] || echo "child-b blocked by $dep (status=$st)"
done
```

#### 5.3 并行判定

同一里程碑内、**同时满足全部条件**的子变更可并行：

| # | 条件 | 说明 |
|---|------|------|
| 1 | 无直接依赖 | 不在彼此 `depends_on` 中 |
| 2 | 无传递依赖 | 间接依赖也不构成先后 |
| 3 | 无共享写冲突 | 不写同一文件/同一表/同一共享组件/同一配置文件 |
| 4 | 验证域不互踩 | 各自验证手段独立（浏览器/接口/DB 不互相依赖） |

**共享资源冲突检测表**：

| 共享资源 | 冲突示例 | 处置 |
|----------|----------|------|
| 同一配置文件 | 两个子变更都改 application.yaml | 不可并行，串行 |
| 同一数据库表 | 都改 user 表结构 | 不可并行，串行或拆表 |
| 同一共享组件 | 都改公共 UI 组件 | 不可并行 |
| 无交集 | 各自独立模块/独立文件 | 可并行 |

**执行方式**：协调者按 op-build DAG 并行分发能力或顺序推进均可；**默认顺序推进、可并行**（契约 §5.3）。
**失败重试不并行**（I-14）：同一子变更验证失败重试期间，不启动依赖它的新并行子变更；重试由协调者确认通过后，其下游子变更才可启动。

#### 5.4 循环依赖禁止

- **规则**：`depends_on` 出现任何环（A→B→A 或更长的环）即非法，拆解时必须解环。
- **检测**：对 `depends_on` 做拓扑排序，排序成功输出执行顺序；排序失败即存在环。
- **解环方法**（按优先级）：
  1. **合并**：将环内子变更合并为一个，消除相互依赖。
  2. **引入共享基础**：抽出公共部分为独立子变更 C，A、B 都依赖 C（依赖方向变为 A→C、B→C）。
  3. **重划边界**：调整功能归属，消除"你中有我、我中有你"的边界。

**解环检测命令建议**：

```bash
# 拓扑排序；成功=有顺序输出，报错=存在环
yq -o=json orchestration.yaml \
  | jq -r '.children[] as $c | $c.depends_on[]? as $d | "\($c.name) \($d)"' \
  | tsort || echo "存在循环依赖，禁止推进，先解环"
```

---

### 6. 里程碑推进规则

#### 6.1 里程碑状态机

```
pending → in_progress（首个子变更启动）→ done（全部子变更 archived）
              │
              └─→ blocked（任一子变更 blocked（含验证失败暂停）或依赖死锁）
```

#### 6.2 推进条件

| 条件 | 动作 |
|------|------|
| 里程碑内全部子变更 archived | 里程碑 status=done，显示下一里程碑可启动 |
| 前一里程碑未 done | 后一里程碑子变更不得启动（里程碑间默认串行；并行须显式声明） |
| 全部里程碑 done + 全部子变更 archived | 父变更可走 op-orchestrate 阶段四（自实现父归档，不经过 op-done），父 phase → archive |

#### 6.3 失败暂停规则

| 项 | 约定 |
|----|------|
| 触发口径 | **同一子变更同一验证点连续失败 3 次**（与 op-build 的 systematic-debugging 触发一致：同 task 连续 3 次验证失败） |
| 动作 | 子变更 status=blocked（暂停语义，与依赖阻塞共用 blocked 取值）；所属里程碑 status=blocked；父变更显示 blocked（I-09 统一取值） |
| 记录 | 失败次数记入 orchestration.yaml `children[].fail_count`（A2 已落地，见 orchestration-schema §4.3） |
| 恢复 | 协调者介入（加载 systematic-debugging），调整方案/重拆后恢复；恢复时由对账将子变更 status 由 blocked 改回 active（依赖阻塞解除或暂停原因消除后） |
| 计数重置 | 该验证点通过后 `fail_count` 清零 |

#### 6.4 里程碑推进检查清单

- [ ] 里程碑内所有子变更 status=archived（G1∧G2∧G3 全过）
- [ ] 无子变更 paused / blocked
- [ ] orchestration.yaml 已回写最新状态与 gates
- [ ] 父变更全部里程碑 done
- [ ] 执行父变更 op-done 归档（生成归档门户/汇总）

---

### 7. git 提交边界约定（I-11 协调者已决策）

| 提交场景 | 允许包含 | 禁止 |
|----------|----------|------|
| 子变更执行提交（plan/build/done 归档） | 本子变更业务产物 + 与本子变更相关的编排产物（orchestration.yaml 对账变更、父 plan.md 更新） | 其他子变更的代码/产物；未确认的编排字段改动 |
| 父变更归档提交（阶段四） | 父级归档材料（archive.json/archive-summary.md、index.json、父 change.yaml.phase） | 子变更业务代码 |

理由：对账回写发生在返回编排视图时，子变更提交时编排文件可能已随之变化；允许包含编排产物可避免"文件已变但 git 未跟踪"的漂移。git 写操作统一走 safe-git-write。

---

## Red Flags — STOP

| Smell | Action |
|-------|--------|
| 拆分清单中出现 ≥ 15 task 的子变更 | 停止拆分流程，再拆一层 |
| 拆分清单中出现 ≤ 2 task 的子变更 | 合并进相邻子变更 |
| `depends_on` 存在环（tsort 报错） | 停止推进，先解环再继续 |
| 子变更验收依赖其他子变更上线 | 重拆，保证独立验证 |
| skip 任务无 plan.md 显式豁免 | 阻止 G2 通过 |
| G1 未过就切 build / G2 未过就切 done | 拒绝 phase 切换，回退 |
| 里程碑未 done 就启动下个里程碑子变更 | 阻止启动 |
| 子变更连续失败 3 次仍继续重试 | 暂停并走 systematic-debugging |
| 拆分时不定验收标准 | 阻止生成拆分清单，先补验收 |

## Common Mistakes

- **把 complex 当 epic 拆**：单一目标即使复杂（brainstorm）也不拆，拆了反而增加编排成本。
- **把 epic 当 complex 硬塞**：30+ task、多期交付仍压成一个变更，验证必然堆积到最后。
- **拆分时不写验收标准**：build 完才补，验证自然堆积，违背设计目标 4。
- **依赖写口头不写 `depends_on`**：orchestration.yaml 缺依赖，并行执行互相踩踏。
- **跳过 G 门槛直接推进**：没确认就进 build、没验证就归档、没归档就推进里程碑。
- **子变更 type 混入 hotfix/tweak**：无 tasks.md 的子变更使 G1/G2 判定失效（子变更 type 应限定 feature/complex）。

## Version

| Field | Value |
|-------|-------|
| Skill | op-orchestrate（references/decomposition-rules.md） |
| 分属 | A3 |
| Version | 0.2.0 |
| Updated | 2026-08-11 |
| 依据 | design-contract v0.1 §2/§5、op-plan v3.4.0 §4.3/§4.2 |
