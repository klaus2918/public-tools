# op-orchestrate 编排数据结构规范（orchestration-schema.md）

> 依据：`docs/design/op-orchestrate-design-contract.md` §4（v0.1 草案）
> 分工：A2（数据结构规范）。本文件只定义数据结构与同步规则；拆分规则见 `decomposition-rules.md`（A3）、看板见 `dashboard-spec.md`（A4）、路由见 `routing-contract.md`（A5）。

## 1. 概览

编排涉及三个数据载体：

| 载体 | 位置 | 作用 | 性质 |
|------|------|------|------|
| 父变更 change.yaml | `.op/changes/<parent>/change.yaml` | 声明 type=epic、启用编排、里程碑计划 | 静态声明 |
| 子变更 change.yaml | `.op/changes/<parent>/<child>/change.yaml` | 声明归属父变更、依赖、里程碑；维持自身 phase 生命周期 | 静态声明 + 门槛证据源 |
| orchestration.yaml | `.op/changes/<parent>/orchestration.yaml` | 编排唯一进度事实源：子变更状态矩阵、依赖、门槛、里程碑状态 | 动态进度 |

字段关系：父/子 change.yaml 是**声明**，orchestration.yaml 是**进度**。子变更的编排状态（status/phase/gates/verified_at）与里程碑状态只存在于 orchestration.yaml，不在子变更 change.yaml 中重复保存（见 §7，避免双写冲突）。

## 2. 父变更 change.yaml 扩展字段（契约 §4.1）

### 2.1 type

| 字段名 | type |
|--------|------|
| 类型 | string |
| 必填性 | 必填 |
| 取值范围 | 新增值 `epic`；其余沿用现有 feature/complex/tweak/hotfix |
| 说明 | 声明本变更为编排父变更。`/op` 路由据此进入 op-orchestrate 编排视图，而不是直接进 plan/build。epic 本身不做业务编码，其生命周期为 plan（拆分产出子变更清单）→ build（编排子变更执行）→ done（全部子变更归档后整体归档）。 |
| 示例 | `type: epic` |

### 2.2 orchestration.enabled

| 字段名 | orchestration.enabled |
|--------|-----------------------|
| 类型 | boolean |
| 必填性 | 必填（与 type: epic 成对出现） |
| 取值范围 | `true` / `false` |
| 说明 | 编排开关。`true` 时 `/op` 路由到 op-orchestrate。契约要求 type: epic 时必须为 `true`；出现 `type: epic` + `enabled: false` 视为契约违例，validate 报错。 |
| 示例 | `orchestration: { enabled: true }` |

### 2.3 orchestration.milestone_plan

| 字段名 | orchestration.milestone_plan |
|--------|------------------------------|
| 类型 | array（对象数组） |
| 必填性 | 可选（不提供时所有子变更归入单个隐式里程碑） |
| 取值范围 | 数组元素为里程碑计划对象，每项含 id/name/children |
| 说明 | 里程碑计划（静态声明）。在父变更 plan 阶段定稿并登记进 orchestration.yaml；此后只增不改，调整需走父变更 plan 变更流程。 |
| 示例 | 见 §2.4 |

milestone_plan 元素子字段：

| 字段名 | 类型 | 必填性 | 取值范围 | 说明 | 示例 |
|--------|------|--------|----------|------|------|
| id | string | 必填 | 全局唯一，建议 M 前缀递增（M1、M2…） | 里程碑标识；子变更 change.yaml.milestone 与 orchestration.yaml.milestones[].id 引用它 | `M1` |
| name | string | 必填 | 任意中文/英文标题 | 里程碑名称，看板显示用 | `基础能力` |
| children | array(string) | 必填（可为空数组） | 已登记子变更的 name | 归属该里程碑的子变更清单；同一子变更只能属于一个里程碑 | `[child-a, child-b]` |

### 2.4 父变更 change.yaml 完整示例

```yaml
name: parent-epic
title: 统一登录体系重构
type: epic
phase: plan
created: 2026-08-10
status: active
description: 编排父变更：拆分登录、会话、联调三个子变更，全部归档后整体收尾
has_ui: true
has_db: true
has_arch: false
orchestration:
  enabled: true
  milestone_plan:
    - id: M1
      name: 基础能力
      children: [child-a, child-b]
    - id: M2
      name: 联调
      children: [child-c]
```

> 说明：父变更（epic）的 has_ui/has_db/has_arch 不参与业务编码，可省略或仅作汇总标记；设计契约的 UI/DB/架构检查在**子变更**层面执行（子变更各自声明并走对应校验）。

## 3. 子变更 change.yaml 扩展字段（契约 §4.2）

现有字段（name/title/type/phase/created/status/description/has_ui/has_db/has_arch/build 等）沿用现有 op 规范不变，仅新增以下字段：

### 3.1 parent

| 字段名 | parent |
|--------|--------|
| 类型 | string |
| 必填性 | 必填（编排子变更必须声明归属） |
| 取值范围 | 已存在父变更的 name，必须与父变更 change.yaml.name 一致 |
| 说明 | 声明本变更属于哪个编排父变更。用于：子变更结束 phase 后返回编排视图、orchestration.yaml 登记校验、索引归档回溯。 |
| 示例 | `parent: parent-epic` |

### 3.2 type

| 字段名 | type |
|--------|------|
| 类型 | string |
| 必填性 | 必填 |
| 取值范围 | `feature` / `complex`（契约 §4.2 示例限定）；**不得**为 epic；hotfix/tweak 无 tasks.md，G1/G2 门槛无法判定，不得作为编排子变更（确需使用须协调者显式放行，见 ISSUES A3-03） |
| 说明 | 子变更本身是标准 op 变更，独立走 plan→build→done 全生命周期。type 决定 plan 产物粒度（feature/complex 需 op-html 确认材料，对应 G1 门槛）。 |
| 示例 | `type: feature` |

### 3.3 depends_on

| 字段名 | depends_on |
|--------|------------|
| 类型 | array(string) |
| 必填性 | 可选（默认空数组） |
| 取值范围 | 其他子变更 name 列表；必须指向同一父变更下的子变更，不得跨父引用，不得自引用，不得成环 |
| 说明 | 依赖声明，构成 DAG。被依赖子变更未 archived 时，本子变更 status=blocked 且不得启动。 |
| 示例 | `depends_on: [child-a]` |

### 3.4 milestone

| 字段名 | milestone |
|--------|-----------|
| 类型 | string |
| 必填性 | 可选（不填视为不归属任何里程碑，仍参与编排） |
| 取值范围 | 父变更 orchestration.milestone_plan 中已声明的 id |
| 说明 | 所属里程碑标识；应与父变更 milestone_plan.children 双向一致（validate 校验点）。 |
| 示例 | `milestone: M1` |

### 3.5 子变更 change.yaml 完整示例

```yaml
name: child-a
title: 登录模块改造
parent: parent-epic
type: feature
phase: plan
created: 2026-08-10
status: active
description: 登录模块拆分改造（编排子变更）
has_ui: true
has_db: false
has_arch: false
depends_on: []
milestone: M1
build:
  done_count: 0
  total_count: 0
```

> 注意：子变更 change.yaml **不新增**编排状态字段（pending/active/blocked/done/archived 等），这些状态只存在于 orchestration.yaml（§7.2 分工）。现有 change.yaml.status 保留原语义（op-done 收尾时写 archived），与编排 status 无关。

## 4. orchestration.yaml 完整字段定义（契约 §4.3）

位置：`.op/changes/<parent>/orchestration.yaml`（父变更目录内，与 change.yaml 同级）。

### 4.1 顶层字段

| 字段名 | 类型 | 必填性 | 取值范围 | 说明 | 示例 |
|--------|------|--------|----------|------|------|
| parent | string | 必填 | 父变更 name | 与父变更 change.yaml.name 一致；校验锚点 | `parent-epic` |
| created | string | 必填 | ISO8601 带时区（YYYY-MM-DDTHH:MM:SS+08:00） | 初版创建时间（父变更 plan 定稿登记时写入，此后不变） | `"2026-08-10T20:00:00+08:00"` |
| updated_at | string | 必填 | ISO8601 带时区（YYYY-MM-DDTHH:MM:SS+08:00） | 最近一次回写时间；任何状态/门槛/里程碑变更都必须同步更新 | `"2026-08-10T22:00:00+08:00"` |
| milestones | array | 必填（可为空数组） | 里程碑对象数组 | 里程碑状态清单，由父变更 milestone_plan 声明 + 进度回写 | 见 §4.2 |
| children | array | 必填 | 子变更对象数组 | 子变更清单，编排进度事实源的核心 | 见 §4.3 |

### 4.2 milestones[] 元素字段

| 字段名 | 类型 | 必填性 | 取值范围 | 说明 | 示例 |
|--------|------|--------|----------|------|------|
| id | string | 必填 | 与 milestone_plan.id 一致 | 里程碑标识 | `M1` |
| name | string | 必填 | 任意标题 | 里程碑名称，与 milestone_plan.name 同步 | `基础能力` |
| status | string | 必填 | `pending` / `in_progress` / `blocked` / `done` | pending=未启动；in_progress=有子变更执行中或已完成部分；blocked=有子变更 blocked 或门槛未过；done=全部子变更 archived | `in_progress` |

### 4.3 children[] 元素字段

| 字段名 | 类型 | 必填性 | 取值范围 | 说明 | 示例 |
|--------|------|--------|----------|------|------|
| name | string | 必填 | 子变更 name | 子变更标识，须与子变更 change.yaml.name 一致 | `child-a` |
| title | string | 必填 | 任意标题 | 子变更标题，与 change.yaml.title 同步，看板显示用 | `登录模块改造` |
| type | string | 必填 | feature/complex（与 §3.2 一致） | 子变更类型，与 change.yaml.type 同步 | `feature` |
| milestone | string/null | 必填（可空） | milestone id 或 null | 所属里程碑；null=不归属任何里程碑 | `M1` |
| depends_on | array(string) | 必填（可为空数组） | 子变更 name 列表 | 依赖声明，与 change.yaml.depends_on 同步；构成 DAG | `[child-a]` |
| status | string | 必填 | `pending` / `active` / `blocked` / `done` / `archived` | 编排状态（§5）：pending=未开始；active=执行中；blocked=依赖未完成/门槛未过/3 次验证失败暂停；done=三道门槛全过；archived=op-done 归档完成 | `pending` |
| phase | string | 必填 | `plan` / `build` / `done` / `archive` | 子变更当前阶段，与 change.yaml.phase 同步回写；archive 为 op-done 归档后阶段 | `plan` |
| gates | object | 必填 | 含三个 boolean 子字段 | 三道验证门槛 G1/G2/G3，全部 true 才算完成 | 见 §4.4 |
| verified_at | string/null | 必填 | ISO8601 带时区或 null | 三道门槛全部满足（status=done）的时间；未完成时为 null | `"2026-08-10T22:00:00+08:00"` |
| fail_count | integer | 必填 | ≥ 0 | 同一验证点连续失败次数（3 次触发暂停，见 decomposition-rules §6.3）；该验证点通过后清零 | `0` |
| acceptance | object | 可选 | 含 business 数组与 exit_conditions 数组 | 拆分时定义的业务验收点（2-5 条）与里程碑出口条件（见 §4.5）；验收点由人核对，脚本不自动判定 | 见 §4.5 |

### 4.4 gates 子字段（三道门槛）

| 字段名 | 类型 | 必填性 | 取值范围 | 说明 | 判定来源（证据） |
|--------|------|--------|----------|------|------------------|
| plan_confirmed | boolean | 必填 | true / false | G1：plan 产出经用户确认（feature/complex 需 op-html 确认材料） | 子变更 change.yaml.phase 由 plan→build 且确认产物存在 |
| build_verified | boolean | 必填 | true / false | G2：tasks.md 全部完成（done_count == total_count）、无未确认 skip、verify-browser required 任务已通过；phase ∈ {done, archive} 仅确认已退出 build（避免判定时序矛盾） | 子变更 change.yaml.build + tasks.md |
| archived | boolean | 必填 | true / false | G3：op-done 归档完成 | 子变更 change.yaml.phase == archive 且 archive.json 存在 |

### 4.5 acceptance 子字段（可选，业务验收点）

| 字段名 | 类型 | 必填性 | 取值范围 | 说明 |
|--------|------|--------|----------|------|
| business | array(string) | 可选（默认空数组） | 每条 2-5 条、可观察可量化 | 业务验收点（角色+动作+可观察结果），编写要求见 decomposition-rules §3.3；G2 判定时人工逐条核对 |
| exit_conditions | array(string) | 可选（默认空数组） | 里程碑出口条件 | 通常放里程碑级；子变更级一般不填 |

示例：

```yaml
acceptance:
  business:
    - "PC 端用户完成表单提交后看到成功提示（verify-browser: required）"
    - "提交数据落库，5 个关键字段与 DB 契约一致"
  exit_conditions: []
```

## 5. 编排状态机（字段取值参考）

子变更 status 迁移（契约 §5.1）：

```
pending → active（开始执行）→ done（三道门槛全过）→ archived（归档完成）
                   ↓ blocked（依赖未完成或门槛未过、3 次验证失败暂停）
```

里程碑 status 派生规则（协调者已采纳落地，见 ISSUES A2-3）：

| 里程碑状态 | 判定条件 |
|------------|----------|
| pending | 全部子变更 pending |
| in_progress | 至少一个子变更 active/done/archived，且无 blocked |
| blocked | 任一子变更 blocked |
| done | 全部子变更 archived |

## 6. orchestration.yaml 完整示例

父变更 `parent-epic`：3 个子变更（child-a、child-b、child-c），2 个里程碑（M1 基础能力、M2 联调）。依赖关系：child-b 依赖 child-a；child-c 依赖 child-a、child-b。示例快照时刻：child-a 在 build 中（G1 已过），child-b 因依赖未归档而 blocked，child-c 尚未启动。

```yaml
parent: parent-epic
created: "2026-08-10T20:00:00+08:00"
updated_at: "2026-08-10T22:00:00+08:00"
milestones:
  - id: M1
    name: 基础能力
    status: in_progress
  - id: M2
    name: 联调
    status: blocked
children:
  - name: child-a
    title: 登录模块改造
    type: feature
    milestone: M1
    depends_on: []
    status: active
    phase: build
    gates:
      plan_confirmed: true
      build_verified: false
      archived: false
    verified_at: null
    fail_count: 0
    acceptance:
      business:
        - "PC 端提交后 5 秒内收到成功提示（verify-browser: required）"
        - "提交数据落库，5 个关键字段与 DB 契约一致"
      exit_conditions: []
  - name: child-b
    title: 会话管理模块
    type: complex
    milestone: M1
    depends_on: [child-a]
    status: blocked
    phase: plan
    gates:
      plan_confirmed: false
      build_verified: false
      archived: false
    verified_at: null
    fail_count: 0
  - name: child-c
    title: 登录联调
    type: feature
    milestone: M2
    depends_on: [child-a, child-b]
    status: pending
    phase: plan
    gates:
      plan_confirmed: false
      build_verified: false
      archived: false
    verified_at: null
    fail_count: 0
```

配套父变更 change.yaml 见 §2.4；三个子变更 change.yaml 与 §3.5 同构（child-b 为 `type: complex`、`depends_on: [child-a]`、`milestone: M1`；child-c 为 `milestone: M2`、`depends_on: [child-a, child-b]`）。

## 7. 唯一进度事实源与同步规则

### 7.1 事实源声明

orchestration.yaml 是编排进度的**唯一事实源**：子变更的编排状态（status/phase/gates/verified_at）与里程碑状态均以它为准。所有路由决策（`/op next` 找可启动子变更、依赖放行、里程碑推进、父 done 放行）只读它，不得从子变更 change.yaml 直接推导编排状态。

### 7.2 与子变更 change.yaml 的分工

| 维度 | 子变更 change.yaml（证据源） | orchestration.yaml（进度事实源） |
|------|------------------------------|----------------------------------|
| 声明 | 静态声明：name/type/parent/depends_on/milestone | 镜像声明 + 动态进度 |
| 门槛判定 | 提供判定依据：phase、build.done_count/total_count、archive.json 存在性 | 存门槛结果：gates.* |
| 阶段 | phase 由子变更自身流程维护 | phase 回写镜像 |
| 编排状态 | 不存储 | 存 status（pending/active/blocked/done/archived） |

### 7.3 回写时机与对账校正（方案 B 兜底，I-04 已决策）

| 时机 | 谁写 | 写什么 |
|------|------|--------|
| 父变更 plan 定稿（子变更清单 + 里程碑计划确认） | 协调者（op-orchestrate plan 流程） | 创建 orchestration.yaml 初版：登记全部子变更；milestones 全部 pending；children 全部 status=pending、phase=plan、gates 全 false、verified_at=null |
| 子变更经 `/op next` 或手工选中启动 | 协调者（op-orchestrate build 流程） | 该子变更 status: pending → active；所属里程碑 → in_progress |
| 依赖未满足或验证失败（3 次）暂停 | 协调者（op-orchestrate build 流程） | 该子变更 status → blocked；受影响里程碑 → blocked；更新 updated_at |
| 子变更 phase 切换（plan→build、build→done、done→archive） | op-orchestrate 对账（orchestrate-reconcile.py 按 §4.4 判定来源检测后校正） | 镜像 phase；对应门槛置 true；三道全过时 status=done、verified_at=当前时间 |
| 子变更 op-done 归档完成 | op-orchestrate 对账 | status → archived、gates.archived=true |
| 里程碑内全部子变更 archived | op-orchestrate 对账 | 里程碑 status → done |
| 父变更全部子变更 archived | op-orchestrate 对账 | 父变更整体推进 done（放行父归档） |

### 7.4 冲突处理（以谁为准）

- **判定以证据源为准**：orchestration.yaml 的 gates/phase 与子变更 change.yaml（+tasks.md、archive.json）冲突时，以子变更 change.yaml 为准重新计算并回写 orchestration.yaml，同时更新 updated_at。即"证据在子变更，视图在编排文件"。
- **编排状态无冲突概念**：status、里程碑 status 只存在于 orchestration.yaml，任何流程不得绕过它直接假设子变更状态。
- **声明字段冲突报错不合并**：name/type/depends_on/milestone/parent 在两侧不一致属校验错误，由 validate 检测并报错，不自动合并。
- **并发写保护**：更新 orchestration.yaml 必须同时更新 updated_at；写入前先读 updated_at 做乐观锁比对，防止两个流程并发回写互相覆盖。

### 7.5 常见错误（反例）

- 子变更 build 完成后只改 orchestration.yaml，不改自己 change.yaml.phase → G2 证据缺失，validate 失败。
- 在子变更 change.yaml 里写 status: blocked 之类编排状态 → 双写冲突，以 orchestration.yaml 为准但视为违例。
- 回写 orchestration.yaml 忘记更新 updated_at → 冲突检测失效。

## 8. index.json 扩展建议

现状（只读参考）：`.op/index.json` 为 `{ "active": [...], "archived": [...] }` 结构，元素含 name/title/type/archived_at/module 等字段，由 op-done 归档时维护。

建议：

1. **父变更与子变更都出现在索引中**：各自独立条目，沿用现有结构，无需为编排拆分新列表。
2. **父变更条目加编排标记**：新增 `orchestration: true`（或依赖 `type: epic` 识别，但显式标记便于过滤）。archived 条目在归档时写入；active 条目如需同样可加。
3. **子变更条目加归属字段**：新增 `parent: <父变更 name>`，便于回溯与按父汇总。
4. **归档顺序**：子变更先归档进索引，父变更最后归档；父变更归档时子变更条目保持独立，不嵌套。

协调者决策（v1，I-12）：作为**文档级约定**采纳——父变更条目带 `orchestration: true`、子变更条目带 `parent: <父名>`、归档顺序子变更先、父变更后。op-done 写入逻辑不在 v1 修改（保持零侵入），由父归档流程（op-orchestrate 阶段四）在写入时附加标记；op-find.py 的父/子检索增强已落地（I-20）。

## 9. 校验点清单（已落地为 `scripts/op-orchestrate-validate.sh`，由 op-000 validate 钩子调用；清单即该校验脚本的实现依据）

- `type: epic` 必须有 `orchestration.enabled: true`。
- 子变更 `parent` 必须存在且与父变更 change.yaml.name 一致。
- 子变更 `type` ∈ {feature, complex}，hotfix/tweak 不得作为编排子变更（无 tasks.md，G1/G2 无法判定）。
- 子变更 `depends_on` 必须指向同一父变更下的子变更，不得自引用、不得成环（DAG 检测）。
- 子变更 `milestone` 必须存在于父变更 milestone_plan 与 orchestration.yaml.milestones。
- orchestration.yaml.children 集合与父变更下全部子变更（含 parent 字段）双向匹配。
- milestones[].id/name 与 milestone_plan 一致；children 集合与各子变更 milestone 字段一致。
- updated_at 为合法 ISO8601 带时区格式。
- gates 三值全 true ⇔ status=done；status=archived 必须同时 gates.archived=true 且 verified_at 非空。
- 子变更 status=blocked 时，其 depends_on 中必有子变更未 archived，或存在验证失败暂停记录。

## 10. Red Flags

- 同一子变更出现在两个里程碑（milestone 与 milestone_plan.children 冲突）。
- 子变更依赖成环。
- 父变更 type: epic 但 orchestration.yaml 缺失或 children 为空。
- 手工修改子变更 change.yaml 中的编排状态字段。
- orchestration.yaml 的 updated_at 早于任何子变更最近一次 phase 变更时间。

## Version

- v0.2（2026-08-11）：协调者落地 ISSUES 决策：新增 created/fail_count/acceptance 字段（I-19/I-07/I-23）、G2 判定时序修正（I-05）、回写责任人改为对账（I-04）、里程碑派生采纳（I-10）、index.json 决策记录（I-12）。与 ISSUES.md A2 小节联动。
