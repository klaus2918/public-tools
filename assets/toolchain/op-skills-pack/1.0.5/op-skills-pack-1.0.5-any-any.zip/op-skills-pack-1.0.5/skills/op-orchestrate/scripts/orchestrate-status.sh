#!/usr/bin/env bash
# ============================================================================
# op-orchestrate 编排看板脚本（只读）
#
# 用法: orchestrate-status.sh <父变更名>
# 读取 .op/changes/<父变更名>/orchestration.yaml，输出 Markdown 表格看板
# （父变更信息 + 里程碑矩阵 + 子变更矩阵 + 图例）。
#
# 本脚本只读：仅输出到 stdout/stderr，绝不写入或修改任何文件。
# 依赖: bash + grep/sed/awk（git-bash 自带），无 python 依赖。
# 编码: 输出 UTF-8；请在 UTF-8 终端（git-bash/mintty）下查看。
# ============================================================================

set -euo pipefail

# 错误退出（stderr）
die() {
  echo "错误: $*" >&2
  exit 1
}

# ---- 参数校验 ----
if [ $# -ne 1 ]; then
  echo "用法: orchestrate-status.sh <父变更名>" >&2
  exit 2
fi
PARENT="$1"

# ---- 定位编排文件（唯一事实源）----
YAML=".op/changes/${PARENT}/orchestration.yaml"
if [ ! -f "$YAML" ]; then
  echo "错误: 找不到编排文件 ${YAML}" >&2
  echo "提示: 请确认父变更 <${PARENT}> 已初始化编排（change.yaml 含 orchestration.enabled: true，且已生成 orchestration.yaml）" >&2
  exit 1
fi

# ---- 父变更标题（可选补充，来自父 change.yaml；读不到则留空）----
TITLE=""
CHANGE=".op/changes/${PARENT}/change.yaml"
if [ -f "$CHANGE" ]; then
  TITLE=$(grep -m1 '^title:' "$CHANGE" | sed 's/^title:[[:space:]]*//' | sed 's/[[:space:]]*$//')
fi

# ---- 解析 orchestration.yaml 关键字段并输出看板 ----
# 说明: 字段缩进按设计契约 §4.3（里程碑字段 4 空格、子变更字段 4 空格、门槛字段 6 空格）。
awk -v parent="$PARENT" -v title="$TITLE" '
function clean(s) {
  gsub(/^[ \t]+/, "", s)     # 去前导空白
  gsub(/[ \t\r]+$/, "", s)   # 去尾部空白/回车（兼容 CRLF）
  return s
}
function field(s) {
  s = clean(s)
  sub(/[ \t]+#.*$/, "", s)   # 去行尾注释（# 前须有空白）
  gsub(/["\047]/, "", s)       # 去引号（兼容单/双引号；单引号用八进制 \047 避免破坏 shell 引用）
  return s
}
function badge(s, b) {
  if (s == "pending")                    b = "P"
  else if (s == "active" || s == "in_progress") b = "A"
  else if (s == "blocked")               b = "B"
  else if (s == "done")                  b = "D"
  else if (s == "archived")              b = "AR"
  else                                   b = "?"
  return b
}
function dash(v) {
  return (v == "" || v == "null") ? "-" : v
}
BEGIN {
  sec = ""; m = 0; c = 0; mcur = 0; ccur = 0
  pname = parent; ptitle = title; pdate = ""
}
{
  # 顶层字段
  if ($0 ~ /^parent:/)      { pname = clean(substr($0, index($0, ":") + 1)); next }
  if ($0 ~ /^updated_at:/)  { pdate = field(substr($0, index($0, ":") + 1)); next }
  if ($0 ~ /^milestones:/)  { sec = "ms"; next }
  if ($0 ~ /^children:/)    { sec = "ch"; next }

  # 里程碑记录
  if (sec == "ms" && $0 ~ /^  - id:/) {
    m++; mcur = m
    ms_id[m] = field(substr($0, index($0, ":") + 1))
    ms_name[m] = ""; ms_status[m] = ""; ms_total[m] = 0; ms_done[m] = 0
    next
  }
  if (sec == "ms" && mcur > 0 && $0 ~ /^    name:/) {
    ms_name[mcur] = clean(substr($0, index($0, ":") + 1)); next
  }
  if (sec == "ms" && mcur > 0 && $0 ~ /^    status:/) {
    ms_status[mcur] = field(substr($0, index($0, ":") + 1)); next
  }

  # 子变更记录
  if (sec == "ch" && $0 ~ /^  - name:/) {
    c++; ccur = c
    ch_name[c] = field(substr($0, index($0, ":") + 1))
    ch_title[c] = ""; ch_type[c] = ""; ch_ms[c] = ""; ch_dep[c] = ""
    ch_status[c] = ""; ch_phase[c] = ""
    ch_g1[c] = "?"; ch_g2[c] = "?"; ch_g3[c] = "?"
    ch_vt[c] = ""
    next
  }
  if (sec == "ch" && ccur > 0 && $0 ~ /^    title:/) {
    ch_title[ccur] = clean(substr($0, index($0, ":") + 1)); next
  }
  if (sec == "ch" && ccur > 0 && $0 ~ /^    type:/) {
    ch_type[ccur] = field(substr($0, index($0, ":") + 1)); next
  }
  if (sec == "ch" && ccur > 0 && $0 ~ /^    milestone:/) {
    ch_ms[ccur] = field(substr($0, index($0, ":") + 1)); next
  }
  if (sec == "ch" && ccur > 0 && $0 ~ /^    depends_on:/) {
    d = field(substr($0, index($0, ":") + 1))
    gsub(/[\[\]"]/, "", d)
    gsub(/[ \t]+/, "", d)
    ch_dep[ccur] = d
    if (d == "") dep_flow[ccur] = 0   # block 风格：继续收集子行
    else dep_flow[ccur] = 1
    next
  }
  if (sec == "ch" && ccur > 0 && $0 ~ /^      - / && dep_flow[ccur] == 0) {
    dep_item = field(substr($0, index($0, "-") + 1))
    if (ch_dep[ccur] == "") ch_dep[ccur] = dep_item
    else ch_dep[ccur] = ch_dep[ccur] "," dep_item
    next
  }
  if (sec == "ch" && ccur > 0 && $0 ~ /^    status:/) {
    ch_status[ccur] = field(substr($0, index($0, ":") + 1)); next
  }
  if (sec == "ch" && ccur > 0 && $0 ~ /^    phase:/) {
    ch_phase[ccur] = field(substr($0, index($0, ":") + 1)); next
  }
  if (sec == "ch" && ccur > 0 && $0 ~ /^      plan_confirmed:/) {
    v = field(substr($0, index($0, ":") + 1))
    ch_g1[ccur] = (v == "true") ? "Y" : ((v == "false") ? "N" : "?"); next
  }
  if (sec == "ch" && ccur > 0 && $0 ~ /^      build_verified:/) {
    v = field(substr($0, index($0, ":") + 1))
    ch_g2[ccur] = (v == "true") ? "Y" : ((v == "false") ? "N" : "?"); next
  }
  if (sec == "ch" && ccur > 0 && $0 ~ /^      archived:/) {
    v = field(substr($0, index($0, ":") + 1))
    ch_g3[ccur] = (v == "true") ? "Y" : ((v == "false") ? "N" : "?"); next
  }
  if (sec == "ch" && ccur > 0 && $0 ~ /^    verified_at:/) {
    ch_vt[ccur] = field(substr($0, index($0, ":") + 1)); next
  }
}
END {
  # 统计: 里程碑完成数 / 各里程碑子变更总数与完成数 / 总体完成数
  ms_done_count = 0; ch_done_total = 0
  for (j = 1; j <= m; j++) {
    if (ms_status[j] == "done") ms_done_count++
  }
  for (i = 1; i <= c; i++) {
    for (j = 1; j <= m; j++) {
      if (ch_ms[i] == ms_id[j]) ms_total[j]++
    }
    if (ch_status[i] == "done" || ch_status[i] == "archived") {
      ch_done_total++
      for (j = 1; j <= m; j++) {
        if (ch_ms[i] == ms_id[j]) ms_done[j]++
      }
    }
  }

  # 头部: 父变更信息
  if (ptitle == "") hdr = "# 编排看板：（" pname "）"
  else hdr = "# 编排看板：" ptitle "（" pname "）"
  print hdr
  print ""
  print "> 更新于：" dash(pdate) " ｜ 子变更 " ch_done_total "/" c " 完成 ｜ 里程碑 " ms_done_count "/" m " 完成"
  print ""

  # 里程碑矩阵
  print "## 里程碑矩阵"
  print ""
  print "| ID | 名称 | 状态 | 子变更(完成/总数) |"
  print "|----|------|------|-------------------|"
  for (j = 1; j <= m; j++) {
    printf "| %s | %s | %s | %d/%d |\n", dash(ms_id[j]), dash(ms_name[j]), badge(ms_status[j]), ms_done[j], ms_total[j]
  }
  if (m == 0) print "| - | - | ? | - |"
  print ""

  # 子变更矩阵
  print "## 子变更矩阵"
  print ""
  print "| 名称 | 标题 | 类型 | 里程碑 | 依赖 | 状态 | Phase | G1 | G2 | G3 | 验证时间 |"
  print "|------|------|------|--------|------|------|-------|----|----|----|----------|"
  for (i = 1; i <= c; i++) {
    printf "| %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s |\n", \
      dash(ch_name[i]), dash(ch_title[i]), dash(ch_type[i]), dash(ch_ms[i]), dash(ch_dep[i]), \
      badge(ch_status[i]), dash(ch_phase[i]), ch_g1[i], ch_g2[i], ch_g3[i], dash(ch_vt[i])
  }
  if (c == 0) print "| - | - | - | - | - | ? | - | ? | ? | ? | - |"
  print ""

  # 图例与数据源
  print "图例：P=pending(待启动) A=active(进行中/里程碑in_progress) B=blocked(阻塞) D=done(完成) AR=archived(已归档)"
  print "门槛：G1=plan_confirmed G2=build_verified G3=archived，Y=通过 N=未过 ?=未知"
  print "数据源：" FILENAME "（每次运行直接读取，无缓存；本脚本只读，不写任何文件）"

  if (m == 0 || c == 0) {
    print "注意：未解析到里程碑或子变更，请检查 orchestration.yaml 缩进是否与设计契约 §4.3 一致。" > "/dev/stderr"
  }
}
' "$YAML"
