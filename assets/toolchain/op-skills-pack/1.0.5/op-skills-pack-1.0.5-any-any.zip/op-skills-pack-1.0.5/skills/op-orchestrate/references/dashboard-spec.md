# 编排看板（status 输出）规格

> op-orchestrate / references / dashboard-spec.md（A4）
> 对齐设计契约 v0.1 草案：§4.3 orchestration.yaml、§5.1 状态机、§5.2 三道门槛、§6 路由契约

## 1. Overview（概述）

`/op <parent>`（type=epic）进入编排视图时，以及 `/op <parent> status` 命令，均输出**编排看板**：把父变更的全部子变更、里程碑、三道门槛汇总为一张状态矩阵，让用户和协调者一眼看清"做到哪、卡在哪、下一步是谁"。

看板三条原则：

1. **单一事实源**：只读 `.op/changes/<parent>/orchestration.yaml`，直接生成，不缓存。
2. **纯只读输出**：status/next 不写任何文件，不修改 orchestration.yaml，不触发任何回写。
3. **门槛透明**：每个子变更的三道门槛（G1/G2/G3）逐项展示；未过门槛的 done 会被一眼识破。

## 2. 看板内容（字段清单）

### 2.1 父变更信息区

| 字段 | 来源 | 说明 |
|------|------|------|
| 父变更名称 | orchestration.yaml `parent` | 与入口参数一致 |
| 父变更标题 | 父 change.yaml `title` | orchestration.yaml 无 title 字段；读不到显示 `-` |
| 更新时间 | orchestration.yaml `updated_at` | 最后一次回写时间 |
| 总体进度 | 计算 | 子变更完成数/总数（done+archived）、里程碑完成数/总数（done） |
| 父变更整体状态 | 派生 | 任一里程碑 blocked → 父变更显示 blocked（I-08；不读父 change.yaml.status） |

### 2.2 里程碑矩阵

| 字段 | 来源 | 说明 |
|------|------|------|
| 里程碑 ID | `milestones[].id` | 如 M1、M2 |
| 名称 | `milestones[].name` | 里程碑名 |
| 状态 | `milestones[].status` | pending / in_progress / blocked / done |
| 子变更(完成/总数) | 统计 | 该里程碑下 status ∈ {done, archived} 的子变更数 / 归属该里程碑的子变更总数 |

### 2.3 子变更矩阵

| 字段 | 来源 | 说明 |
|------|------|------|
| 名称 | `children[].name` | 子变更唯一标识 |
| 标题 | `children[].title` | 一句话描述 |
| 类型 | `children[].type` | feature / complex（hotfix/tweak 不得作为编排子变更，I-06） |
| 里程碑 | `children[].milestone` | 所属里程碑 ID；无则 `-` |
| 依赖 | `children[].depends_on` | 逗号分隔的子变更名；无则 `-` |
| 状态 | `children[].status` | pending / active / blocked / done / archived |
| Phase | `children[].phase` | plan / build / done / archive |
| G1 / G2 / G3 | `children[].gates` | plan_confirmed / build_verified / archived 通过标记 |
| 验证时间 | `children[].verified_at` | null 显示 `-` |

## 3. 状态徽标约定

规范渲染（SKILL 生成、HTML 看板）用 emoji 徽标；纯文本/脚本环境用 ASCII 代码，二者等价：

| 状态 | emoji 徽标 | ASCII 代码 | 含义 |
|------|-----------|-----------|------|
| pending | ⬜ | P | 待启动：尚未开始 |
| active | 🔄 | A | 进行中：正在执行（里程碑 in_progress 同样用 🔄/A） |
| blocked | ⛔ | B | 阻塞：依赖未归档，或验证连续失败被暂停 |
| done | ✅ | D | 完成：三道门槛全过 |
| archived | 📦 | AR | 已归档：完成 op-done 归档 |

门槛标记：通过 ✅ / Y，未过 ❌ / N，未知（字段缺失）❓ / ?。

## 4. Markdown 表格模板

`orchestrate-status.sh` 与 SKILL 的 status 输出统一使用以下模板（脚本输出 ASCII 徽标，SKILL 输出 emoji 徽标）：

```markdown
# 编排看板：<父变更标题>（<父变更名>）

> 更新于：<updated_at> ｜ 子变更 <完成>/<总数> ｜ 里程碑 <完成>/<总数>

## 里程碑矩阵

| ID | 名称 | 状态 | 子变更(完成/总数) |
|----|------|------|-------------------|
| M1 | 基础能力 | 🔄 | 1/2 |
| M2 | 联调 | ⬜ | 0/1 |

## 子变更矩阵

| 名称 | 标题 | 类型 | 里程碑 | 依赖 | 状态 | Phase | G1 | G2 | G3 | 验证时间 |
|------|------|------|--------|------|------|-------|----|----|----|----------|
| child-a | 子变更A标题 | feature | M1 | - | ✅ | archive | ✅ | ✅ | ✅ | 2026-08-10T22:00:00+08:00 |
| child-b | 子变更B标题 | feature | M1 | - | 🔄 | build | ✅ | ❌ | ❌ | - |
| child-c | 子变更C标题 | complex | M2 | child-a | ⬜ | plan | ❌ | ❌ | ❌ | - |

图例：⬜=pending 🔄=active/in_progress ⛔=blocked ✅=done 📦=archived ｜ G1=plan_confirmed G2=build_verified G3=archived
```

## 5. ASCII 风格示意图（终端/纯文本）

```text
op-orchestrate 编排看板（只读）
父变更: demo-epic  演示父变更
更新于: 2026-08-10T22:00:00+08:00   进度: 子变更 2/3 | 里程碑 1/2

[里程碑矩阵]
+----+----------+--------+-------------------+
| ID | 名称     | 状态   | 子变更(完成/总数)  |
+----+----------+--------+-------------------+
| M1 | 基础能力 | [A]    | 1/2               |
| M2 | 联调     | [P]    | 0/1               |
+----+----------+--------+-------------------+

[子变更矩阵]
+---------+------------+---------+------+--------+------+-------+----+----+----+------------------+
| 名称    | 标题       | 类型    | 里程碑| 依赖   | 状态 | Phase | G1 | G2 | G3 | 验证时间         |
+---------+------------+---------+------+--------+------+-------+----+----+----+------------------+
| child-a | 子变更A标题 | feature | M1   | -      | [D]  | done  | Y  | Y  | Y  | 2026-08-10T22:00 |
| child-b | 子变更B标题 | feature | M1   | -      | [A]  | build | Y  | N  | N  | -               |
| child-c | 子变更C标题 | complex | M2   | child-a| [P]  | plan  | N  | N  | N  | -               |
+---------+------------+---------+------+--------+------+-------+----+----+----+------------------+

图例: [P]=pending [A]=active [B]=blocked [D]=done [AR]=archived
门槛: G1=plan_confirmed G2=build_verified G3=archived  Y=通过 N=未过 ?=未知

状态流转:  pending ──► active ──► done ──► archived
              │           │
              └──────► blocked ◄──────┘（依赖未归档 / 验证失败暂停）
```

## 6. 读取规则（不缓存）

1. status / next 每次调用**直接读取** `.op/changes/<parent>/orchestration.yaml`，禁止任何会话级或文件级缓存。
2. 唯一事实源是 orchestration.yaml；父 change.yaml 只用于补充标题，读不到不阻塞看板。
3. 不缓存的原因：子变更完成 phase 后会回写 orchestration.yaml（详见 routing-contract.md），多 agent 并行执行时缓存必然过期，导致调度错误。
4. 读取容错：文件缺失 → 明确报错并退出（脚本 exit 1）；字段缺失 → 显示 `-` / `?`，不中断输出；缩进与契约 §4.3 不符 → 无法解析的记录忽略，并给出格式提示。

## 7. next 命令输出规格

`/op <parent> next`：找出下一个可启动子变更，列出候选及进入方式。

### 7.1 候选判定

子变更 X 可启动，当且仅当：

1. X.status == pending；
2. X 的 depends_on 中每个子变更 status == archived（契约 §5.3：任一依赖未归档不得启动）；
3. X 所属里程碑 status != blocked（验证失败暂停的里程碑不放出新任务）。

候选排序：按 milestones 出现顺序，再按子变更名升序；第一个为**推荐候选**，其余为备选。

### 7.2 有候选时的输出

```markdown
# 下一个可启动子变更

推荐：child-c（子变更C标题）→ 进入方式：/op child-c（从 plan 开始）

| 候选 | 标题 | 类型 | 里程碑 | 依赖 | 进入方式 |
|------|------|------|--------|------|----------|
| child-c | 子变更C标题 | complex | M2 | child-a 📦 | /op child-c |
| child-d | 子变更D标题 | feature | M2 | - | /op child-d |

共 2 个候选；输入序号或 /op <子变更名> 进入其 plan。
```

依赖列中已归档依赖标注 📦（脚本环境标 AR）。

### 7.3 无候选时的输出（分情况说明原因）

```markdown
# 下一个可启动子变更

无可启动子变更。原因：

- 全部子变更已归档 → 父变更可整体收尾：/op <parent> done
- 存在阻塞子变更：child-b（依赖 child-a 未归档）/ child-e（验证失败暂停，阻塞里程碑 M2）
- 其余 pending 子变更均被依赖阻塞：child-f ← child-b
```

### 7.4 数据一致性提示

若发现 status=pending 但依赖未满足的子变更，说明 orchestration.yaml 未按契约回写（应置 blocked），在输出末尾提示协调者修复；next 只读，不自动修改文件。

## 8. 脚本 orchestrate-status.sh

- 用法：`orchestrate-status.sh <父变更名>`（在工作区根目录执行，读取 `.op/changes/<父变更名>/orchestration.yaml`）。
- 输出：本规格 §4 的 Markdown 表格模板（ASCII 徽标 + 中文标签），末尾附图例与数据源。
- 行为：只读 stdout/stderr；文件缺失报错并 exit 1；参数错误 exit 2；绝不写任何文件。
- 对账提示：status 为只读命令**不触发对账**；如需校正漂移，先运行 `scripts/orchestrate-reconcile.py <父变更名>` 再查看。
- 依赖：bash + grep/sed/awk（git-bash 自带），无 python 依赖。
- 编码：输出 UTF-8；Windows git-bash（mintty）默认 UTF-8 可正常显示中文。

## 9. Red Flags（红线）

- 对 orchestration.yaml 做缓存后输出看板。
- 看板流程中写任何文件，或修改 orchestration.yaml。
- 把未过三道门槛的子变更标为 done / 计入"完成"。
- next 把依赖未 archived 的 pending 子变更列为候选。
- 脚本对文件缺失静默通过。

## 10. Common Mistakes（常见错误）

- 状态字段拼写不一致（in-progress vs in_progress、archive vs archived）导致徽标显示 ?。
- depends_on 里的子变更名与 children 下 name 不一致，导致 next 判定失效。
- 把 verified_at 的 null 当成时间串直接输出。
- 子变更执行中多次调用 status 却不重新读文件，看到过期状态。
- 在纯 cmd 下直接运行脚本（需 git-bash/bash 环境）。

## Version

- v0.2（2026-08-11）：落地 ISSUES 决策：类型列限定 feature/complex（I-06）、父变更 blocked 派生（I-08）、status 对账提示（I-04）。
