# op-orchestrate 路由契约与 op 入口集成说明（routing-contract.md）

> 依据：`docs/design/op-orchestrate-design-contract.md` §6（v0.1 草案）、§3 架构选型
> 分工：A5（路由契约与 op 入口集成）。本文件只定义路由与集成方案；数据结构见 `orchestration-schema.md`（A2）、拆分与门槛判定见 `decomposition-rules.md`（A3）、看板输出见 `dashboard-spec.md`（A4）、注册集成见 `registry-integration.md`（A6）。
> 约束：本文件不修改任何现有 op 系列文件；§4 集成建议为建议清单，由协调者决策后落地。发现问题见 `ISSUES.md` A5 小节。

## 0. 术语

| 术语 | 含义 |
|------|------|
| 父变更（epic） | `change.yaml.type=epic` 且 `orchestration.enabled=true` 的变更，只做编排不做业务编码 |
| 子变更 | `change.yaml.parent` 指向某父变更的普通变更（feature/complex/tweak/hotfix），独立走 plan→build→done |
| 编排阶段 | 父变更 `change.yaml.phase` 在 epic 场景下的语义：plan=拆分规划、build=编排执行、done=整体归档、archive=只读 |
| orchestration.yaml | 父变更目录内编排进度**唯一事实源**（A2 §4，位于 `.op/changes/<parent>/orchestration.yaml`） |
| 编排视图（看板） | op-orchestrate 渲染的子变更状态矩阵，输出规格见 dashboard-spec.md（A4） |
| 孤儿 | 子变更 `change.yaml.parent` 指向不存在/非 epic 的父变更；或 orchestration.yaml 条目指向不存在的目录 |
| 对账（reconciliation） | 渲染看板时以子变更 change.yaml（证据源）校正 orchestration.yaml（进度事实源）的过程（A2 §7.4） |

## 1. 路由总览

### 1.1 触发判定（op 入口解析变更名后的三分支）

| 判定顺序 | 条件 | 结果 |
|----------|------|------|
| 1 | `change.yaml.type == epic` 或 `change.yaml.orchestration.enabled == true` | 路由 **op-orchestrate**（父变更路径，§2.1-2.3/2.5） |
| 2 | `change.yaml.parent` 存在 | **子变更路径**：按自身 phase 正常路由 + 归属提示与边界校验（§2.4） |
| 3 | 其他 | 现有 phase 路由不变（plan→op-plan、build→op-build、done→op-done、archive→只读摘要） |

> `type: epic` 与 `orchestration.enabled: true` 必须成对出现（A2 §2.2，违例由 validate 报错）；任一命中即进 op-orchestrate。

### 1.2 路由决策表（op 入口视角，含新增分支）

| 条件 | 现有行为 | 新增行为 |
|------|----------|----------|
| `/op <name>` 且 name 为 epic 父变更 | 无（type=epic 为新增值） | 路由 op-orchestrate：渲染编排看板 + 动作菜单（§2.1） |
| `/op <name> status` 且 name 为 epic | 无 | 路由 op-orchestrate status（§2.2） |
| `/op <name> next` 且 name 为 epic | 无 | 路由 op-orchestrate next（§2.3） |
| `/op <name> done` 且 name 为 epic | 无 | 路由 op-orchestrate done（§2.5，门槛校验后放行） |
| `/op <name>` 且 name 为子变更（parent 存在） | 按 phase 路由 op-plan/op-build/op-done | 不变 + 归属提示与边界校验（§2.4） |
| `/op <name>` 且 name 为普通变更 | 按 phase 路由 | 不变 |

### 1.3 父变更 phase 语义（epic 专属，与现有 phase 路由的关系）

**关键关系：父变更 phase 仍是 plan/build/done/archive，但路由目标是 op-orchestrate，而不是 op-plan/op-build/op-done 直接执行。** op 入口现有规则 `phase=plan → op-plan` 等对 epic 不适用；新增分支必须**置于 phase 行之前判定**（否则 epic 会被现有 phase 行错误路由，见 ISSUES A5-3）。

| 父变更 phase | 编排内部阶段 | 主要动作 | 可加载的支撑 |
|--------------|--------------|----------|--------------|
| plan | 编排规划 | 拆分需求 → 子变更清单（name/type/范围/验收/依赖/里程碑）→ 用户确认 → 初始化 orchestration.yaml 初版 | op-plan 方法论（参考）、op-brainstorming（复杂拆分）、op-html（确认材料，默认 md） |
| build | 编排执行 | 看板展示、next 找可启动子变更、路由子变更进入各自生命周期、回写进度、里程碑推进 | 子变更各自的 op-plan/op-build/op-done；op-build DAG 并行能力（§6） |
| done | 编排收尾 | 校验全部子变更 archived → 生成归档门户/汇总 → 父 phase=archive | op-html（归档材料，默认 md） |
| archive | 只读 | 编排归档摘要 | - |

父变更 phase 推进规则：

| 推进 | 触发条件 | 写入者 |
|------|----------|--------|
| plan→build | 子变更清单与 orchestration.yaml 初版经用户确认 | op-orchestrate |
| build→done | 全部子变更 archived（每次回写/看板渲染时检测，满足即提示 `/op <parent> done`） | op-orchestrate |
| done→archive | `/op <parent> done` 校验放行 | op-orchestrate |
| 冲突校正 | 父 change.yaml.phase 与编排进度冲突（如 phase=done 但子变更未全 archived） | 以 orchestration.yaml 为准，纠正父 change.yaml.phase（§5.5） |

## 2. 命令契约

统一前提：所有命令先解析变更名 → 按 §1.1 判定类型（epic / 子变更 / 普通）→ 进入对应契约。

### 2.1 `/op <parent>`

| 维度 | 定义 |
|------|------|
| 输入 | 父变更名（type=epic 或 orchestration.enabled=true） |
| 处理 | ① 读父 change.yaml + orchestration.yaml；② 对账（§3.3，必要时回写校正）；③ 渲染编排看板（里程碑进度 + 子变更矩阵 status/phase/gates/依赖/里程碑 + 阻塞与警告）；④ 展示动作菜单：进入子变更（编号选择）、`status`、`next`、`done`、归档摘要 |
| 输出 | 编排看板 + 动作菜单；顶部含父变更 title、phase、paused 状态 |
| 边界 | orchestration.yaml 缺失：父 phase=plan → 提示先完成拆分规划；父 phase≠plan → 视为损坏提示修复（§5.5）。无子变更 → 提示先拆分。存在 blocked → 看板标注阻塞原因与依赖链。全部 archived → 提示 `/op <parent> done`。父 paused → 看板顶部展示搁置原因，next/进入新子变更受限（§5.2） |

### 2.2 `/op <parent> status`

| 维度 | 定义 |
|------|------|
| 输入 | 父变更名 + `status`（可选过滤：`/op <parent> status <child>` 查看单子变更） |
| 处理 | 只读：读 orchestration.yaml → 渲染编排看板；指定 child 时输出该子变更详情（status/phase/gates/依赖/里程碑/verified_at/阻塞原因） |
| 输出 | 编排看板 / 单子变更详情；检测到漂移时输出"检测到 N 处漂移，进入 `/op <parent>` 时自动校正"警告，不直接写 |
| 边界 | orchestration.yaml 缺失 → 报"编排未初始化（父 phase=plan 或状态损坏）"，提示 `/op <parent>`。child 不在清单 → 报无此子变更，提示孤儿检测结果（§5.4）。status 为只读命令，不做回写（对账仅在看板渲染路径执行） |

### 2.3 `/op <parent> next`

| 维度 | 定义 |
|------|------|
| 输入 | 父变更名 + `next` |
| 处理 | ① 前置校验：父未 paused（§5.2）；父 phase ∈ {build, done}（plan 阶段尚未产出子变更清单，next 不可用）；② 读 orchestration.yaml，筛选候选：status=pending 且 depends_on 全部 archived；③ 排序：里程碑顺序 → 依赖拓扑序（依赖先行）；④ 多个候选 → 展示选择列表，用户确认（默认顺序推进；协调者可按 §6 并行启动多个）；⑤ 激活：orchestration.yaml 回写 child.status: pending→active、child.phase 与其 change.yaml 对齐（子变更 change.yaml.phase=plan，由子变更初始化流程写入）；⑥ 路由进入该子变更 op-plan |
| 输出 | "已激活 <child>（里程碑 <M>），进入其 plan 阶段" + 子变更 plan 流程 |
| 边界 | 无候选且存在 blocked → 列出阻塞链（依赖未 archived 的子变更清单）。无候选且存在 active → 提示先完成当前进行中（或询问并行）。无候选且全部 archived → 提示 `/op <parent> done`。候选子变更目录缺失 → 标记 missing 不选（§5.3）。父 phase=plan → 提示先完成拆分。父 paused → 拒绝并展示搁置原因 |

### 2.4 `/op <child>`（子变更直接路由）

| 维度 | 定义 |
|------|------|
| 输入 | 子变更名（change.yaml.parent 存在） |
| 处理 | ① 读子变更 change.yaml，检测 parent 字段；② 父变更存在 → 读父 orchestration.yaml 按 §5.1 状态矩阵校验；③ 输出归属提示："该变更为 <parent> 的子变更（编排 status/phase）；依赖未满足清单；返回编排视图：`/op <parent>`"；④ 按子变更自身 phase 正常路由 op-plan/op-build/op-done |
| 输出 | 归属提示 + 正常阶段执行 |
| 边界 | 父变更不存在 / 存在但非 epic → 孤儿（§5.4）。子变更 status=blocked → 提示依赖未 archived 清单；允许进入查看/恢复当前 phase 产物，阻断 build/done 推进（用户确认强推除外）。父 paused → §5.2。子变更不在父清单中（孤儿条目）→ 提示并允许继续，阶段切换不回写（§5.3） |

### 2.5 `/op <parent> done`

| 维度 | 定义 |
|------|------|
| 输入 | 父变更名 + `done` |
| 处理 | ① 前置校验：父未 paused。② 校验全部子变更 archived（G3 全过，按 §3.3 对账规则判定）；③ 全部通过 → 执行父归档：生成归档门户/汇总（复用 op-html，默认 md）、父 change.yaml.phase=archive、orchestration.yaml 标注 parent_status=archived、同步 index.json（A2 §8）；④ 输出归档摘要 |
| 输出 | 归档成功摘要 / 拒绝列表（未完成子变更分类） |
| 边界 | 未全过 → 拒绝并分类输出：pending（提示 next）、active（提示等待完成）、blocked（提示解除依赖）、missing（提示移除或恢复）。重复 done → 幂等：已归档则输出只读摘要。无子变更（空 epic）→ 拒绝并提示异常（除非用户显式确认空归档）。父 paused → 拒绝，先恢复。依赖循环（A→B→A，契约违例）→ 拒绝并报校验错误 |

## 3. 子变更执行闭环（orchestration.yaml 回写）

### 3.1 回写矩阵（谁写、何时写、写什么字段）

| 触发点（子变更侧事件） | 写入者 | orchestration.yaml 变更 | 对应门槛 |
|------------------------|--------|--------------------------|----------|
| `/op <parent> next` 激活（进入 plan 前） | op-orchestrate（build 流程） | child.status: pending→active；child.phase 与 change.yaml 对齐 | - |
| 子变更 plan 确认（phase: plan→build 且确认产物存在） | op-plan 收尾钩子 *或* op-orchestrate 对账 | child.phase: plan→build；gates.plan_confirmed: true | G1 |
| 子变更 build 完成（phase: build→done，done_count==total_count 且无未确认 skip） | op-build 收尾钩子 *或* op-orchestrate 对账 | child.phase: build→done；gates.build_verified: true | G2 |
| 子变更 done 归档（phase: done→archive，archive.json 存在） | op-done 收尾钩子 *或* op-orchestrate 对账 | child.phase: done→archive；child.status: →archived；gates.archived: true | G3 |
| 三道门槛全过 | 同上 | child.status: →done；verified_at=当前时间 | - |
| 连续 3 次验证失败暂停 | op-build 收尾钩子 *或* op-orchestrate 对账 | child.status: →blocked（phase 不变） | - |
| 依赖未满足（被依赖子变更未 archived） | op-orchestrate（对账 / next 校验） | child.status: →blocked；受影响里程碑 → blocked | - |
| 任何回写 | 写入者 | updated_at=当前 ISO8601（乐观锁，A2 §7.4） | - |

> `*或*` 表示：v1 以对账兜底为主（零侵入），收尾钩子为集成增强，见 §3.2。

### 3.2 回写机制（谁写）

| 方案 | 机制 | 优点 | 代价 |
|------|------|------|------|
| A 主动回写（增强） | op-plan/op-build/op-done 在"阶段切换 + index.json 同步"之后，检测本变更 change.yaml.parent 字段：存在则调用回写（读父 orchestration.yaml → 更新本 child 条目 + updated_at，乐观锁比对） | 实时性最好，看板即时准确 | 需改 3 个阶段 skill（跨 skill 改动，需协调者批准）；回写脚本归属 op-orchestrate（A1 实现） |
| B 对账兜底（v1 主用） | op-orchestrate 每次渲染编排看板时，扫描各子变更 change.yaml，按 §3.3 规则重算并校正 orchestration.yaml | 零侵入、自愈、幂等 | 实时性差一档；孤儿条目需看板渲染才暴露 |

结论：v1 **已决策**——以 B 为主并落地 `scripts/orchestrate-reconcile.py`（对账兜底，I-04）；A（阶段 skill 收尾钩子）暂缓。两方案写同一字段、同一乐观锁规则，可共存（A 实时写，B 兜底校正）。

### 3.3 对账规则（每次看板渲染时执行；status 命令只检测不写）

| orchestration.yaml 字段 | 对账依据（证据源） | 规则 |
|--------------------------|--------------------|------|
| child.phase | 子变更 change.yaml.phase | 不一致 → 以 change.yaml 为准更新（A2 §7.4） |
| gates.plan_confirmed | phase ≥ build 且 plan.md 存在 | 满足 → true |
| gates.build_verified | change.yaml.build.done_count==total_count 且 tasks.md 无未确认 skip | 满足 → true（verified_at 前提之一） |
| gates.archived | phase==archive 且 archive.json 存在 | 满足 → true |
| child.status | 由 gates + 依赖推导 | 全过且 archived → archived；依赖未满足 → blocked；有 phase 推进 → active；否则 pending（A2 §5） |
| verified_at | 三道门槛全过的时刻 | 全过且为 null → 补写当前时间 |
| child 目录存在性 | 文件系统 | 目录缺失 → 标记 missing（不清除条目，§5.3） |
| 声明字段（name/title/type/depends_on/milestone） | 子变更 change.yaml | 不一致 → 校验错误，报错不自动合并（A2 §7.4） |
| updated_at | - | 任何校正后必须更新 |

### 3.4 返回编排视图

- 子变更任何阶段执行结束/中断后，阶段流程输出提示："子变更 <child> 已推进至 <phase>。返回编排视图：`/op <parent>`"（由收尾钩子输出；v1 无钩子时，由 op-orchestrate 在看板渲染时展示"上次活跃子变更 <child> 当前 phase=build"）。
- 用户随时可 `/op <parent>` 回到看板；看板渲染即对账，保证返回视图时状态新鲜。

### 3.5 git 提交边界约定（I-11 协调者已决策）

- 子变更的执行提交允许包含与其相关的编排产物（orchestration.yaml 对账变更、父 plan.md 更新），因对账发生在返回编排视图时；禁止夹带其他子变更代码。
- 父变更归档提交仅包含父级归档材料（archive.json/archive-summary.md、index.json、父 change.yaml.phase），不夹带子变更业务代码。
- git 写操作统一走 safe-git-write。

## 4. op 入口（op/SKILL.md）集成建议

> 以下为建议清单，不直接修改任何文件，由协调者决策后落地。按实施优先级分组。

### 4.1 必须（epic 路由可用性的最小集）

| # | 建议 | 具体内容 | 落点 |
|---|------|----------|------|
| S1 | Routing Decision 表新增 epic 行 | `type=epic 或 orchestration.enabled=true` → 路由 op-orchestrate；**置于 phase 行之前判定**（否则 epic 会被现有 phase 行错误路由，ISSUES A5-3） | op/SKILL.md §Routing Decision |
| S2 | 父 phase 语义说明 | epic 变更的 phase=plan/build/done/archive 表示编排阶段，路由目标始终 op-orchestrate，不直接进 op-plan/op-build/op-done | op/SKILL.md §3 路由 |
| S3 | Quick Reference 新增命令 | `/op <parent>`、`/op <parent> status`、`/op <parent> next`、`/op <parent> done` | op/SKILL.md Quick Reference |
| S4 | When to Use 补充 | "进入编排父变更（type=epic）查看/推进子变更"场景 | op/SKILL.md When to Use |

### 4.2 建议（体验完整性）

| # | 建议 | 具体内容 | 落点 |
|---|------|----------|------|
| S5 | index.json orchestration 标记 | 父变更条目加 `orchestration: true`；子变更条目加 `parent: <父名>`；归档顺序子变更先、父变更后（与 A2 §8 一致）。**决策：v1 文档级约定**（I-12），op-done 逻辑不改，由父归档流程附加标记 | index.json 写入逻辑（op-done 维护处） |
| S6 | Resume Flow 子变更检索 | op-find.py 增加解析 type/parent 字段：命中父变更显示 🗂 徽标 + 子变更完成度（如 3/5 archived）；命中子变更显示 `📎<parent>` 归属列。**决策：已落地**（I-20） | op/scripts/op-find.py 输出格式 |
| S7 | Red Flags 新增行 | type=epic 被路由到 op-plan/op-build 直接执行 → STOP 改路由 op-orchestrate；子变更直接路由未提示父归属 → 补充提示 | op/SKILL.md Red Flags |
| S8 | 版本号 | op v2.3.0 → v2.4.0，updated_at 更新 | op/SKILL.md Version |

### 4.3 可选增强（协调者按资源决策）

| # | 建议 | 具体内容 | 落点 |
|---|------|----------|------|
| S9 | 阶段 skill 收尾回写钩子 | op-plan/op-build/op-done 阶段切换后检测 change.yaml.parent 并回写 orchestration.yaml（§3.2 方案 A） | op-plan/op-build/op-done SKILL.md |
| S10 | op-find 父变更汇总行 | 父变更命中时附子变更完成度摘要，提升恢复效率 | op-find.py |

## 5. 边界情况

### 5.1 子变更被 /op 直接路由（绕过父变更）

设计目标允许子变更独立路由（契约 §2 目标 2），但必须校验并提示归属：

| 子变更编排 status | `/op <child>` 行为 |
|--------------------|--------------------|
| pending 且依赖满足 | 正常进入自身 phase 路由 |
| pending 且依赖未满足（blocked） | 提示依赖未 archived 清单；允许进入 plan 查看，阻断 build/done 推进（用户确认强推除外） |
| active | 正常恢复当前 phase |
| done | 正常进入 op-done 归档流程 |
| archived | 只读归档摘要（同普通变更） |
| 不在父清单（孤儿条目） | 提示"父清单无此条目"，允许继续，阶段切换不回写 |

### 5.2 父变更 paused 时子变更可否继续

- 规则：父 paused = **编排级挂起**（比普通变更的"搁置提示"更强，见 ISSUES A5-4）。
  - `/op <parent>`：看板顶部展示搁置原因；动作菜单禁用 next/done。
  - `/op <parent> next`：拒绝，提示先恢复父变更。
  - `/op <child>`：允许进入查看/恢复进行中内容；**禁止启动新阶段**（pending→active 激活、plan→build 推进均提示"父已搁置，建议先恢复"）；已 active 的子变更允许完成当前阶段收尾（避免半途丢弃），完成后不再启动新子变更。
- 对比：普通变更 paused 仍可进入其 phase（op/SKILL.md 规则 3）；epic 的 paused 语义升级，需契约明确。

### 5.3 子变更删除 / 重命名

| 场景 | 检测 | 处理 |
|------|------|------|
| 删除子变更目录 | 对账时 child 条目目录缺失 | 标记 missing（⚠️，不清除条目）；依赖它的子变更 → blocked；无关子变更不受影响；用户可"移除条目"（记录 removed_at）或恢复目录 |
| 重命名子变更 | 旧 name 目录缺失（missing）+ 新 name 目录存在但不在清单（孤儿条目） | 提示用户确认重命名；确认后更新 orchestration.yaml 的 child.name 及依赖方 depends_on 引用；未确认前按 missing 处理 |
| 从清单移除条目但目录仍在 | 孤儿条目（change.yaml.parent 指向父，但清单无此 child） | `/op <child>` 时提示不在父清单；可"重新登记"或保持孤儿提示 |

### 5.4 孤儿子变更（parent 指向不存在父变更）

| 场景 | 检测 | 处理 |
|------|------|------|
| parent 指向的目录不存在 | `/op <child>` 路由时解析父目录失败 | 提示"父变更 <parent> 不存在（孤儿）"；允许按普通变更继续自身生命周期；阶段切换回写步骤跳过并输出一次性警告；修复路径：修正 parent 字段，或创建父变更后由 op-orchestrate 收养（v1 不自动收养，仅提示） |
| parent 指向的目录存在但非 epic | 父 change.yaml 无 type=epic / orchestration.enabled | 同孤儿处理（父类型不匹配） |
| 反向孤儿（清单有条目、目录无） | 对账 | §5.3 missing 处理 |

### 5.5 其他边界

| 场景 | 处理 |
|------|------|
| 父 change.yaml.phase 与编排进度冲突（如 phase=done 但子变更未全 archived） | 以 orchestration.yaml 为准；op-orchestrate 纠正父 change.yaml.phase 并提示 |
| orchestration.yaml 缺失 | 父 phase=plan → 正常初始化路径；否则视为损坏，提示走 plan 修复 |
| 嵌套 epic（子变更 type=epic） | v1 不支持：A2 §3.2 已禁止子变更 type=epic；路由/校验层检测到 → 报错提示扁平化 |
| `/op <parent> done` 幂等 | 已归档 → 输出只读摘要，不重复归档 |
| 多个 active 子变更并行回写 | 回写按 child.name 定位条目互不冲突；updated_at 乐观锁防并发覆盖（A2 §7.4） |
| 子变更依赖循环（A→B→A） | validate/对账检测 → 报错，next 不选任何环上子变更（A2 §9） |
| epic 变更被 `/op <parent> plan` 强制进入 | 语义为"进入编排规划阶段"（op-orchestrate 内），不路由 op-plan |

## 6. 与 op-build DAG 的关系

| 层级 | 载体 | 管理方 | 语义 |
|------|------|--------|------|
| 变更级 DAG | 子变更 change.yaml.depends_on / orchestration.yaml children[].depends_on | op-orchestrate（编排层） | 子变更之间先后关系；依赖未 archived 不得启动 |
| task 级 DAG | tasks.md depends 字段 | op-build（任务层） | 子变更内部任务并行（subagent-driven-development，max concurrency=4） |

- 两层不混淆：编排层不干预 task 细节，只消费结果（G2 门槛）。
- 编排层利用 op-build 并行分发能力：同一里程碑内依赖互不冲突的多个子变更可并行启动（协调者决策，默认顺序推进）。
- 子变更进入 build 后完全按 op-build v2 规则执行（含 verify-browser / verify-e2e / worktree / design-contract 路由），编排层不侵入。

## 7. Red Flags — STOP（路由视角）

| Smell | Action |
|-------|--------|
| type=epic 变更被直接路由到 op-plan/op-build/op-done | 拒绝；改路由 op-orchestrate |
| 子变更执行完未回写 orchestration.yaml（对账发现漂移） | 看板渲染时对账校正并告警 |
| `/op <parent> done` 但存在未 archived 子变更 | 拒绝并列出未完成项分类 |
| next 选中 blocked 子变更 | 拒绝；展示依赖链 |
| 父 paused 时启动新子变更 | 拒绝；提示恢复父变更 |
| 子变更依赖成环 | 报错；不启动环上任何子变更 |
| 手工编辑 orchestration.yaml 绕过乐观锁（updated_at 未更新） | 对账时检测 updated_at 陈旧 → 告警（A2 §7.5） |

## 8. Common Mistakes

- 把 epic 父变更当普通变更直接执行 plan/build（跳过编排，漏掉子变更清单与门槛）。
- 子变更间依赖写成 task 级 DAG（应在 change.yaml.depends_on 表达变更级依赖）。
- 手工编辑 orchestration.yaml 而不走 op-orchestrate/对账（产生漂移与并发覆盖风险）。
- 忽略孤儿提示继续开发子变更（回写会静默丢失）。
- 在子变更 change.yaml 中写编排状态字段（双写冲突，A2 §7.5 违例）。

## 9. Version

| 字段 | 值 |
|------|-----|
| 文档 | op-orchestrate/references/routing-contract.md |
| 版本 | v0.2 |
| 日期 | 2026-08-11 |
| 依据 | 设计契约 v0.1 §6、§3；A2 orchestration-schema.md v0.1 |
| 联动 | ISSUES.md A5 小节 |
