#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""op-orchestrate 对账脚本（方案 B 回写兜底，ISSUES I-04 落地）

用法：python orchestrate-reconcile.py <父变更名> [--workspace <根目录>] [--dry-run]

职责：以子变更 change.yaml（证据源）重算并校正 orchestration.yaml（进度事实源）。
对账规则见 references/routing-contract.md §3.3、orchestration-schema.md §4.4。

- 只校正：child.phase / gates.* / child.status / verified_at / milestones[].status / updated_at
- 不自动合并：声明字段（name/title/type/depends_on/milestone）不一致 → 输出 warning（由
  op-orchestrate-validate.sh 报 error）
- 子变更目录缺失 → 回退 .op/archive/<YYYY>/<MM>/<name>/（归档态识别）；归档区也没有才标记 missing
- 默认写回；--dry-run 只报告不写
"""
import argparse
import datetime
import io
import os
import sys

try:
    import yaml
except ImportError:
    sys.stderr.write("需要 pyyaml：pip install pyyaml\n")
    sys.exit(3)


def now_iso():
    now = datetime.datetime.now().astimezone()
    z = now.strftime("%z")  # +0800
    return now.strftime("%Y-%m-%dT%H:%M:%S") + z[:3] + ":" + z[3:]


def load_yaml(path):
    with io.open(path, encoding="utf-8") as f:
        return yaml.safe_load(f)


def find_archived_dir(workspace, name):
    """归档目录回退：.op/archive/<YYYY>/<MM>/<name>/（op-done 物理移出后的归档态）。"""
    import glob
    for h in sorted(glob.glob(os.path.join(workspace, ".op", "archive", "*", "*", name))):
        if os.path.isdir(h):
            return h
    return None


class IndentDumper(yaml.SafeDumper):
    """序列项也缩进（indentless=False），与 orchestrate-status.sh 的 awk 解析契约一致。"""

    def increase_indent(self, flow=False, indentless=False):
        return super().increase_indent(flow, False)


def save_yaml(path, data):
    with io.open(path, "w", encoding="utf-8", newline="\n") as f:
        yaml.dump(
            data, f, allow_unicode=True, sort_keys=False,
            default_flow_style=False, Dumper=IndentDumper,
        )


def phase_ge(phase, target):
    order = {"plan": 0, "build": 1, "done": 2, "archive": 3}
    return order.get(phase, 0) >= order.get(target, 0)


def count_tasks(child_dir):
    """tasks.md 完成度统计：返回 (done, total)。文件缺失返回 (None, None)。"""
    p = os.path.join(child_dir, "tasks.md")
    if not os.path.isfile(p):
        return None, None
    done = total = 0
    with io.open(p, encoding="utf-8") as f:
        for ln in f:
            s = ln.strip()
            if s.startswith("- ["):
                total += 1
                if s.startswith("- [x]") or s.startswith("- [X]"):
                    done += 1
    return done, total


def judge_gates(child_dir, c_phase, c_yaml):
    """按证据源判定三道门槛。返回 (plan_confirmed, build_verified, archived)。"""
    plan_md = os.path.isfile(os.path.join(child_dir, "plan.md"))
    archive_json = os.path.isfile(os.path.join(child_dir, "archive.json"))

    # G1：phase 已由 plan→build 且 plan.md 存在（feature/complex 确认产物的最小可判定集）
    g1 = phase_ge(c_phase, "build") and plan_md

    # G2：done_count == total_count 且无未确认 skip 且 phase ∈ {done, archive}
    g2 = False
    build = (c_yaml or {}).get("build") or {}
    done_n = build.get("done_count", 0)
    total_n = build.get("total_count", 0)
    t_done, t_total = count_tasks(child_dir)
    if total_n and total_n > 0:
        g2 = (done_n == total_n) and c_phase in ("done", "archive")
    elif t_total is not None and t_total > 0:
        # 兜底：change.yaml.build 缺失时按 tasks.md 打勾统计
        g2 = (t_done == t_total) and c_phase in ("done", "archive")
    # 未确认 skip 检查（decomposition-rules §4.2 检查项 2）：tasks.md 含 verify: skip
    # 且 plan.md 无显式豁免说明 → G2 不过
    if g2:
        tasks_md = os.path.join(child_dir, "tasks.md")
        plan_md_path = os.path.join(child_dir, "plan.md")
        if os.path.isfile(tasks_md) and os.path.isfile(plan_md_path):
            t_text = io.open(tasks_md, encoding="utf-8").read()
            if "verify: skip" in t_text:
                p_text = io.open(plan_md_path, encoding="utf-8").read()
                if not ("豁免" in p_text or "skip 豁免" in p_text or "verify: skip" in p_text):
                    print(f"[WARN] {os.path.basename(child_dir)}：tasks.md 含 verify: skip 但 plan.md 无豁免说明（G2 判不过）")
                    g2 = False

    # G3：phase == archive 且 archive.json 存在
    g3 = c_phase == "archive" and archive_json

    return g1, g2, g3


def derive_status(g1, g2, g3, deps_archived, phase):
    """按 gates + 依赖推导编排 status（契约 §3.3）。

    done = G1+G2 通过（G2 判定要求 phase ∈ {done, archive}，即 build 完成）；
    archived = 归档门槛 G3 通过。g1&&g2&&g3 分支不可达（g2 需 phase 非 archive 时成立，
    与 g3 的 phase == archive 互斥），故按文档语义改为 g1&&g2 → done。
    """
    if phase == "archive" and g1 and g2 and g3:
        return "archived"
    if not deps_archived:
        return "blocked"
    if g1 and g2:
        return "done"
    if phase != "plan":
        return "active"
    return "pending"


def reconcile(parent, workspace, dry_run):
    parent_dir = os.path.join(workspace, ".op", "changes", parent)
    orch_path = os.path.join(parent_dir, "orchestration.yaml")
    if not os.path.isfile(orch_path):
        sys.stderr.write("orchestration.yaml 不存在：%s\n" % orch_path)
        return 2

    orch = load_yaml(orch_path)
    changes = []
    for child in orch.get("children", []):
        name = child.get("name")
        child_dir = os.path.join(parent_dir, name)
        if not os.path.isdir(child_dir):
            archived_dir = find_archived_dir(workspace, name)
            if archived_dir:
                # 归档态识别：子变更已由 op-done 物理移出，证据源改读归档目录
                child_dir = archived_dir
                if "missing" in child:
                    del child["missing"]
            else:
                print("[WARN] %s：目录缺失，标记 missing（保留条目不修改）" % name)
                child["missing"] = True
                continue

        c_yaml = load_yaml(os.path.join(child_dir, "change.yaml"))
        c_phase = (c_yaml or {}).get("phase", "plan")

        # 声明字段一致性（不自动合并，仅警告）
        for field in ("title", "type", "milestone", "depends_on"):
            cv = c_yaml.get(field) if c_yaml else None
            ov = child.get(field)
            if field == "depends_on":
                if (cv or []) != (ov or []):
                    print("[WARN] %s：depends_on 与 change.yaml 不一致（校验由 validate 报错）" % name)
            elif cv is not None and cv != ov:
                print("[WARN] %s：%s 与 change.yaml 不一致（校验由 validate 报错）" % (name, field))

        g1, g2, g3 = judge_gates(child_dir, c_phase, c_yaml)
        gates = child.get("gates") or {}
        dep_status = {c["name"]: c.get("status") for c in orch.get("children", [])}
        deps_archived = all(
            dep_status.get(d, "missing") == "archived" for d in (child.get("depends_on") or [])
        )
        new_status = derive_status(g1, g2, g3, deps_archived, c_phase)

        if gates.get("plan_confirmed") != g1:
            changes.append("%s gates.plan_confirmed %s -> %s" % (name, gates.get("plan_confirmed"), g1))
            gates["plan_confirmed"] = g1
        if gates.get("build_verified") != g2:
            changes.append("%s gates.build_verified %s -> %s" % (name, gates.get("build_verified"), g2))
            gates["build_verified"] = g2
        if gates.get("archived") != g3:
            changes.append("%s gates.archived %s -> %s" % (name, gates.get("archived"), g3))
            gates["archived"] = g3
        child["gates"] = gates

        if child.get("phase") != c_phase:
            changes.append("%s phase %s -> %s" % (name, child.get("phase"), c_phase))
            child["phase"] = c_phase

        if child.get("status") != new_status:
            changes.append("%s status %s -> %s" % (name, child.get("status"), new_status))
            child["status"] = new_status

        if g1 and g2 and g3:
            if not child.get("verified_at"):
                ts = now_iso()
                changes.append("%s verified_at -> %s" % (name, ts))
                child["verified_at"] = ts
            if "missing" in child:
                del child["missing"]

    # 里程碑状态派生
    children = orch.get("children", [])
    by_ms = {}
    for child in children:
        by_ms.setdefault(child.get("milestone"), []).append(child.get("status"))
    for ms in orch.get("milestones", []):
        sts = by_ms.get(ms.get("id"), [])
        if not sts:
            continue
        new_ms = "blocked" if "blocked" in sts else (
            "done" if all(s == "archived" for s in sts) else (
                "pending" if all(s == "pending" for s in sts) else "in_progress"))
        if ms.get("status") != new_ms:
            changes.append("milestone %s status %s -> %s" % (ms.get("id"), ms.get("status"), new_ms))
            ms["status"] = new_ms

    if not changes:
        print("对账完成：无漂移（%s）" % parent)
        return 0

    print("对账完成：检测到 %d 处漂移" % len(changes))
    for c in changes:
        print("  ~ %s" % c)
    if dry_run:
        print("(--dry-run 未写回)")
        return 0
    orch["updated_at"] = now_iso()
    save_yaml(orch_path, orch)
    print("已回写 %s（updated_at 已更新）" % orch_path)
    return 0


def main():
    ap = argparse.ArgumentParser(description="op-orchestrate 对账脚本")
    ap.add_argument("parent", help="父变更 name")
    ap.add_argument("--workspace", default=os.getcwd(), help="工作区根目录（默认当前目录）")
    ap.add_argument("--dry-run", action="store_true", help="只报告不写回")
    args = ap.parse_args()
    sys.exit(reconcile(args.parent, args.workspace, args.dry_run))


if __name__ == "__main__":
    main()
