确 op-orchestrate 设计契约问题汇总（ISSUES.md）

> 分工：A7（校验与示例）汇总。依据：`docs/design/op-orchestrate-design-contract.md`（v0.1 草案）+ A1 SKILL.md + A2 orchestration-schema.md + A3 decomposition-rules.md + A5 routing-contract.md + A6 registry-integration.md + A7 example-epic.md 全流程推演。
> 用途：回报协调者，由协调者决策后更新契约/落地实现。禁止本文件之外的分身自行改契约。
> 历史说明：本文件经历 A2/A3/A6 多分身并行写入与覆盖（详见各分身小节标注），A7 汇总时将各分身内容统一为 I- 编号体系，并保留各分身原始小节于文末备查。
> 编号规则：I-01 起顺序编号；每条例"问题描述 / 影响 / 建议方案 / 状态"。状态取值：`open`（待决策）、`部分解决`（已给出建议但契约或实现未落地）、`已解决`（已闭环）。

---

## 一、epic 类型与现有 op 体系的兼容性（I-01 ~ I-03）

### I-01 epic 类型未纳入 op 入口路由

- **问题描述**：契约 §3/§6 要求 `change.yaml.type == epic` 时 `/op` 路由到 op-orchestrate，但现有 `op/SKILL.md` 的 Routing Decision 只按 `phase` 路由（plan→op-plan、build→op-build、done→op-done、archive→只读），无 `type=epic` 分支；`docs/design/op-orchestrate-integration-checklist.md` 将"决定是否落地 op/SKILL.md 路由扩展"标注为**建议项、由用户确认**。
- **影响**：未扩展前 `/op <parent>` 会按 phase 落入 op-plan/op-build/op-done，op-orchestrate 无法被触发，整个编排不可用。
- **建议方案**：扩展 op/SKILL.md Routing Decision：`type == epic` 或 `orchestration.enabled == true` → 路由到 op-orchestrate；子变更（`parent` 存在）按自身 phase 正常路由。由协调者确认后落地（涉及修改现有 op 入口，需解除"现有文件只读"约束）。A5 补充：新分支必须**置于现有 phase 路由行之前判定**，否则 epic 父变更 phase=build 时会被错误路由到 op-build（routing-contract.md §1.3 已固化）。
- **状态**：✅ 已解决（2026-08-10 协调者落地：op/SKILL.md 增加 epic 分支路由行 + Red Flag + 版本 2.4.0，epic 分支置于 phase 路由之前判定）

### I-02 epic 类型不在 op-plan 类型表，父变更拆分流程无法复用 op-plan

- **问题描述**：`op-plan` Core Rules 1 类型表只有 hotfix/tweak/feature/complex；契约 §3 说父变更 plan 阶段"产出子变更清单 + orchestration.yaml 初版"，SKILL.md 阶段一写"父变更 phase=plan → 加载 op-plan 拆分流程"，但 op-plan 不认识 epic，无对应产出路径。
- **影响**：父变更 plan 阶段若真的交给 op-plan，会因未知类型降级/报错；拆分流程（子变更清单、orchestration.yaml 初版、里程碑计划）无处落地。
- **建议方案**：二选一：(a) op-plan 增加 epic 分支（产出子变更清单 + orchestration.yaml 初版后转 op-orchestrate 编排）；(b) op-orchestrate 自实现父变更拆分流程（参照 op-plan 的 complex 规则：复杂需求加载 brainstorm），不依赖 op-plan。倾向 (b)，避免污染普通变更的 op-plan。
- **状态**：open

### I-03 epic 父变更无法直接走 op-done 归档

- **问题描述**：op-done Step 5 pre-commit check 要求 `change.yaml.build.done_count == total_count`（父变更没有 build 字段、没有 tasks.md）；Step 0 变更类型识别只有 skill/业务功能/配置/hotfix 四类，无 epic。SKILL.md 阶段四却写"走 op-done 整体归档"。
- **影响**：父变更归档时 op-done 会因 build 校验不通过拒绝；即使放行，父变更无 tasks 时 done_count 校验逻辑无定义。
- **建议方案**：op-done 增加 epic 分支（跳过 build 校验，以"全部子变更 gates.archived==true"作为归档前置），或父变更归档由 op-orchestrate 自实现（复用 safe-git-write 提交 + op-html 生成归档门户 + archive.json/index.json 更新），不经过 op-done。
- **状态**：open

---

## 二、门槛判定与状态机矛盾（I-04 ~ I-10）

### I-04 orchestration.yaml 回写责任人未落地（双写一致性核心）

- **问题描述**：契约 §4.3 定义 orchestration.yaml 为唯一进度事实源；SKILL.md §6 回写协议要求"子变更在 phase 切换时回写"，并说"由执行子变更的会话在阶段切换时完成"。但 op-plan/op-build/op-done 现有流程没有任何 orchestration.yaml 回写步骤，且全局规则禁止修改现有文件；三个子 skill 不会自己写编排文件。
- **影响**：子变更 phase 切换后 orchestration.yaml 无人更新 → 编排进度失实，父变更无法正确放行里程碑/归档，看板失真。这是"orchestration.yaml 与子变更 change.yaml 双写一致性"风险的操作侧根源。
- **建议方案**：协调者明确回写机制二选一：(a) 扩展 op-plan/op-build/op-done 增加回写钩子（改现有文件，需解除只读约束并同步更新三个 skill）；(b) **回写由 op-orchestrate 承担**——子变更每次 phase 切换后返回编排视图时，op-orchestrate 读取子变更 change.yaml（+tasks.md、archive.json）检测变化并回写 orchestration.yaml（证据在子变更、视图在编排文件，A2 §7.4 已定冲突规则）。A5 补充：routing-contract.md §3.2 给出具体机制——方案 A 主动回写（扩展三个子 skill 收尾钩子）+ 方案 B 对账兜底（op-orchestrate 渲染看板时以子变更 change.yaml 为证据源重算 gates/status 并校正，零侵入、幂等）；v1 建议以 B 为主、A 为可选增强，两方案共用 A2 §7.4 乐观锁规则。倾向 (b)。
- **状态**：open

### I-05 G2 判定来源与时序矛盾

- **问题描述**：契约 §5.2 G2 判定来源写"子变更 change.yaml.phase == build"，但 G2 通过瞬间 phase 已由 build→done（SKILL.md 回写协议：G2 通过 → `phase: done`、`status: done`）。判定时读到的 phase 是 done，条件永不成立。A2-5 已核实 `build.done_count/total_count` 字段在真实 change.yaml 中存在，判定依据本身成立，矛盾只在判定时序。
- **影响**：G2 无法按文档判定，校验逻辑会误报未通过。
- **建议方案**：判定条件改为"`change.yaml.build.done_count == total_count` 且无未确认 skip 且 phase ∈ {done, archive}"（phase 仅确认已退出 build）；同步修正契约 §5.2 与 A2 规范 §4.4。
- **状态**：open

### I-06 G1 对 tweak/hotfix 子变更的证据缺失

- **问题描述**：契约 §5.2 G1 判定来源"confirm 产物存在"，A2 规范 §3.2 允许子变更 type 为 tweak/hotfix；但 tweak/hotfix 走口头确认，无 op-html 确认材料（op-plan 只对 feature/complex 生成确认页）。SKILL.md 门槛表虽注明"hotfix/tweak 口头确认"，但没有对应的文件证据。
- **影响**：tweak/hotfix 子变更 G1 无判定依据；若子变更被限定 feature/complex，则契约应显式禁止其他类型。
- **建议方案**：采纳 A3-3 口径——强制校验子变更 type ∈ {feature, complex}，拒绝 hotfix/tweak 作为子变更（A6 在 validate 集成中加校验），同时契约 §4.2 显式注明。推荐此方案，保证每子变更都有文档化 plan 与确认材料，符合"验证前置"目标。
- **状态**：open

### I-07 "验证失败 3 次"的判定粒度与记录位置未定义

- **问题描述**：契约 §5.3"任一子变更验证失败（3 次）→ 暂停"，未定义：是单 task 连续 3 次（对齐 op-build RF-08）还是子变更内累计 3 次；失败计数记录在哪个文件（tasks.md / orchestration.yaml）；恢复后计数是否清零。
- **影响**：blocked 判定无法实现（无计数来源），示例 4.2 场景在真实流程中无落点。
- **建议方案**：采纳 A3-2 口径——"同一验证点连续 3 次失败"（与 op-build systematic-debugging 触发条件一致），orchestration.yaml children 增加 `fail_count` 字段（通过后清零）；op-orchestrate 在子变更返回编排视图时检测到 pause 状态即回写 blocked。字段落地待协调者确认（契约外扩展）。
- **状态**：open

### I-08 "父变更显示 blocked"无承载字段

- **问题描述**：契约 §5.3"父变更显示 blocked"，但父变更 change.yaml 没有 status 字段（只有 phase: plan/build/done/archive），index.json 也没有；blocked 只存在于 orchestration.yaml 的 milestones[].status。
- **影响**：父变更 blocked 状态无明确读取入口，看板/路由无法判断。
- **建议方案**：不新增父 change.yaml 字段（避免再一处双写），由编排视图从 orchestration.yaml 派生"父变更 blocked = 任一里程碑 blocked"；在 dashboard-spec.md 中定义该派生规则。
- **状态**：open

### I-09 blocked 恢复路径未定义

- **问题描述**：契约与 SKILL.md 只说"验证失败 3 次 → blocked → 向用户报告并等用户决策"，未定义恢复动作：谁执行 blocked→active、触发条件、恢复时是否重新校验依赖、失败计数是否清零。
- **影响**：示例步骤 8（修复后恢复）无规范支撑，实际恢复操作因人而异。
- **建议方案**：在 decomposition-rules.md / routing-contract.md 定义：恢复由协调者（op-orchestrate）在用户确认修复后执行；恢复前重新校验依赖（被依赖子变更仍须 archived）；失败计数清零；同一子变更累计 blocked ≥2 次时建议重新评估拆分粒度。
- **状态**：open

### I-10 里程碑级状态推进规则契约未完全定义

- **问题描述**：契约 §5.3 只定义"所有子变更 archived → 父变更整体 done"，未定义 M1 done、M2 in_progress、里程碑 blocked 的触发与派生；A2 规范 §5 已给出派生建议表（pending/in_progress/blocked/done 判定），并标注"契约未完全定义，见 ISSUES A2-3"。
- **影响**：里程碑推进依赖实现者自行理解，示例 4.2 中间态 M1=blocked、M2=pending 的取值缺乏契约依据。
- **建议方案**：契约 §5.3 补充里程碑状态迁移表（采纳 A2 规范 §5 派生建议：全 pending→pending；有 active/done/archived 且无 blocked→in_progress；有 blocked→blocked；全 archived→done）。
- **状态**：部分解决（A2 建议已给，契约未更新）

---

## 三、index.json 与 Git 提交（I-11 ~ I-12）

### I-11 子变更 commit 范围与父变更/其他子变更产物重叠

- **问题描述**：op-done 采用"整体 git add 所有变更文件 + 一次 commit"；子变更归档时会 add 整个工作区，可能把父变更的 plan.md、orchestration.yaml 初版、其他子变更的未提交产物一并提交 → 提交边界混乱，父变更归档时无独立变更可提交或重复提交。
- **影响**：编排多变更场景下 git 历史无法按子变更归属；父归档产物（orchestration.yaml 最终态）与子变更提交混在一起。
- **建议方案**：子变更归档时限定 add 范围（`.op/changes/<parent>/<child>/` + 该子变更声明的业务路径），父变更产物（orchestration.yaml、父 plan.md、归档门户）留待父归档时提交；需要 safe-git-write 支持按路径限定的暂存。若路径限定不可行，则约定"子变更 commit 允许包含编排产物，父归档仅提交父级归档材料"并在文档中明示。
- **状态**：open

### I-12 index.json 对编排的支持未落地

- **问题描述**：A2 规范 §8 建议父条目加 `orchestration: true`、子条目加 `parent` 字段、归档顺序"子先父后"，涉及 op-done 的 index.json 写入逻辑变更；另子变更条目何时创建未定义（父 plan 阶段批量创建子变更时是否立即进 index.json？）。
- **影响**：子变更无法被 `/op <child>` 独立检索；父变更归档后子变更条目无法回溯归属。
- **建议方案**：协调者决策扩展 op-done/index.json 写入逻辑；子变更条目在父 plan 确认后创建（与子变更 change.yaml 同时），父变更条目在父归档时写入 archived_changes 且子条目保持独立。
- **状态**：部分解决（建议已给，未落地）

---

## 四、流程细节与并发（I-13 ~ I-17）

### I-13 子变更目录创建与用户确认粒度

- **问题描述**：父 plan 阶段批量创建 3 个子变更 change.yaml，但 op 入口 `/op init` 要求用户确认；批量创建是否需逐个确认、父 plan 确认材料（op-html）是否覆盖子变更创建确认、父 plan 被拒后子变更目录残留处理，均未定义。
- **影响**：可能绕过用户确认批量创建变更目录，或被拒后留下孤儿目录。
- **建议方案**：父 plan 确认材料一次性覆盖"子变更清单 + 里程碑计划 + 目录创建"，用户确认即批量创建；父 plan 被拒时清理已建子变更目录（或标记 `activated: false` 不参与编排）。
- **状态**：open

### I-14 并行子变更回写 orchestration.yaml 的并发写

- **问题描述**：契约 §5.3 允许同一里程碑内无依赖冲突的子变更并行；并行时两个会话同时回写 orchestration.yaml 会互相覆盖。A2 规范 §7.4 已提乐观锁（写前读 updated_at 比对），但冲突后"重读合并重写"的协调者/重试机制未定义。
- **影响**：并行场景下编排进度可能丢失更新。
- **建议方案**：回写协议统一为"读 → 比对 updated_at → 合并修改 → 写回并更新 updated_at"，冲突时重读最新文件重试（≤3 次）；默认顺序推进可完全规避，并行作为可选增强。
- **状态**：部分解决（乐观锁已提，重试机制未定）

### I-15 父变更 has_ui/has_db/has_arch 声明语义不明

- **问题描述**：A2 规范 §2.4 父变更示例含 has_ui/has_db/has_arch，但 op-plan 的 op-design-extract 触发集合是 {feature, complex}，epic 不触发，父变更声明这些字段无消费方；设计契约检查实际应在子变更层面触发（示例中 child-a 声明 has_db/has_arch，child-b/c 声明 has_ui）。
- **影响**：父变更字段冗余且易误导（以为父变更会做设计契约检查）。
- **建议方案**：父变更可不填或仅作汇总标记；子变更各自声明并触发 op-design-extract；在 orchestration-schema.md 注明。
- **状态**：open（minor）

### I-16 父变更 plan 确认材料（op-html）对 epic 类型支持未验证

- **问题描述**：父变更 type=epic，op-html 确认材料（默认 md）是否识别 epic 类型（需要展示子变更清单 + 里程碑计划 + 依赖 DAG）未定义。
- **影响**：父变更 plan 确认暂停点可能产出格式不合适的确认材料。
- **建议方案**：op-html 扩展 epic 渲染模板（子变更矩阵 + 里程碑），或父变更确认材料使用通用模板并在 op-orchestrate 侧补充编排信息。
- **状态**：open（minor）

### I-17 `/op <parent> next` 多候选排序与空结果语义

- **问题描述**：契约 §6 定义 next"自动找出下一个可启动子变更（pending 且依赖满足）"，但多个候选时取哪个、无候选（全部 blocked 或全部 archived）时返回什么，未定义。
- **影响**：next 行为不确定，示例步骤 2/6/10 按声明顺序选取属实现约定而非契约。
- **建议方案**：默认按 orchestration.yaml children 声明顺序取第一个；无候选时输出 blocked 原因矩阵（依赖缺口 / 验证失败暂停）或"全部完成"提示，不放行进入任何子变更。
- **状态**：open（minor）

---

## 五、校验与工具链（I-18 ~ I-19）

### I-18 校验点依赖 op-000 validate 扩展未落地

- **问题描述**：A2 规范 §9 校验点（type=epic↔enabled、parent 一致性、DAG 无环、milestone 双向一致、gates 三值全 true ⇔ status=done、updated_at 格式等）需要 op-000-validate.sh 支持，未定义实现。A6-2#8 已给出编排专属校验建议（a/b/c 三项）。
- **影响**：编排文件的一致性（双写漂移、声明冲突）无自动检测手段。
- **建议方案**：op-000-validate.sh 增加 op-orchestrate 校验段（采纳 A6-2#8：epic 目录必有 orchestration.yaml、children 与 parent 双向一致、gates⇔status 与 archive 一致性），或独立 validate 脚本按需加载，避免拖慢主 validate。
- **状态**：open

### I-19 orchestration.yaml 缺少创建时间字段

- **问题描述**：A2 规范 §4.1 顶层字段只有 parent/updated_at/milestones/children，无 created；无法区分文件创建时间与最近回写时间。
- **影响**：审计时无法区分初版落盘时间与最终更新，校验"updated_at 不早于任何子变更 phase 变更"时缺少初版锚点。
- **建议方案**：顶层可选加 `created`（ISO8601 带时区），初版落盘时写入，之后不变。
- **状态**：open（minor）

---

## 六、示例推演额外发现

| 编号 | 发现 | 关联 |
|------|------|------|
| E-01 | 示例步骤 4 中 G2 通过瞬间 phase 由 build→done，与 I-05 判定矛盾同源；示例按"done_count==total_count 且 phase 已退出 build"表述 | I-05 |
| E-02 | 示例 child-b blocked 时其 change.yaml.phase 保持 build、status 概念只存在于 orchestration.yaml；若实现者误把 status 写入子变更 change.yaml 会双写违例（A2 §7.5 反例） | I-04 |
| E-03 | 示例父归档仅更新 orchestration.yaml 的 updated_at；父归档产物（父 archive.json、归档门户）的写入时机与 op-done 兼容性未决 | I-03, I-11 |
| E-04 | 示例子变更确认材料路径沿用 op-html `sites/<project>/<child>/`；project_slug（示例 demo-service）需在子变更 change.yaml 声明（has_ui 时必填），父变更无需声明 | I-15 |

---

## 七、A5 补充（路由契约与 op 入口集成视角，I-20 ~ I-22）

> A5 追加于 routing-contract.md 编写期间，编号接续 I-19；已并入 A7 汇总体系，保留原文备查。

### I-20 op-find.py 检索不识别 type/parent，Resume Flow 缺失编排上下文

- **问题描述**：op 入口 Resume Flow 的检索脚本 `op/scripts/op-find.py` 只解析 name/title/phase/paused/keywords/usage_scene/usage_tags 字段，输出格式为 `name | phase | ⏸ | title`；不认识 `type: epic` 与子变更 `parent` 字段。父变更被命中时无 🗂 徽标与子变更完成度；子变更被命中时无 `📎<parent>` 归属列，用户从检索结果无法知道它属于哪个编排。
- **影响**：以业务主题恢复编排工作流时，检索结果丢失父/子上下文，可能误路由到普通 phase 流程。
- **建议方案**：扩展 op-find.py 解析 type/parent 字段：父变更命中显示 🗂 徽标 + 子变更完成度（如 3/5 archived）；子变更命中显示 `📎<parent>` 归属列。涉及修改 op/scripts/op-find.py（op 入口集成，协调者决策）。
- **状态**：open

### I-21 epic 父变更 paused 语义升级未定义（编排级挂起）

- **问题描述**：op/SKILL.md 规则 3 定义普通变更 paused=true 时"展示搁置状态后仍可进入其 phase"；编排父变更若沿用该语义，父挂起但子变更仍可启动/推进，会偏离总目标。契约与 A2 规范均未定义 epic 场景下 paused 的行为。
- **影响**：父变更搁置期间子变更继续执行，编排进度与挂起意图矛盾。
- **建议方案**：定义 epic 父变更 paused = 编排级挂起：`/op <parent> next` 与 `/op <parent> done` 拒绝；`/op <child>` 允许查看/恢复进行中内容，但禁止启动新阶段（pending→active、plan→build 推进）；已 active 子变更允许完成当前阶段收尾，完成后不再启动新子变更。已写入 routing-contract.md §5.2。
- **状态**：open

### I-22 孤儿子变更（parent 指向不存在/非 epic 父变更）检测与处理未定义

- **问题描述**：契约未定义子变更 `change.yaml.parent` 指向的父变更目录不存在、或父变更非 epic 时的行为；也未定义反向孤儿（orchestration.yaml 条目指向不存在的子变更目录，如子变更被删除/重命名）的检测。
- **影响**：孤儿状态下子变更回写无处可写（静默丢失），删除/重命名子变更后编排清单残留陈旧条目，依赖它的子变更状态失真。
- **建议方案**：路由层检测两类孤儿：① `parent` 指向不存在/非 epic 父变更 → 允许子变更按普通变更继续自身生命周期，阶段切换回写跳过并输出一次性警告，修复路径为修正 parent 字段（v1 不自动收养）；② orchestration.yaml 条目目录缺失 → 对账标记 missing（不清除条目，依赖方 blocked），用户可移除条目或恢复目录；重命名经用户确认后同步更新清单 name 与依赖方 depends_on。已写入 routing-contract.md §5.3/§5.4。
- **状态**：open

---

## 八、A7 整合补充（I-23 ~ I-24）

### I-23 orchestration.yaml children 缺 acceptance 段字段定义

- **问题描述**：契约 §4.3 children 无 `acceptance` 段（G 门槛 + 业务验收点）字段定义，拆分时子变更验收标准无处登记（A3-4 提出）。
- **影响**：父变更 plan.md「子变更拆分」章节承载验收标准后，orchestration.yaml 无法反映业务验收点，校验只看 G 门槛，业务验收脱节。
- **建议方案**：待协调者确认后由 A2 在 orchestration-schema.md §4.3 落地 `acceptance.business`（验收点列表）字段；模板已提供于 decomposition-rules.md §3.2。契约未确认前以父变更 plan.md 承载。
- **状态**：open

### I-24 里程碑间默认串行/可并行未明确

- **问题描述**：契约 §5.3 只提里程碑内并行，未明确里程碑间是否可并行（A3-5 提出）。
- **影响**：M1 未完成时 M2 子变更能否启动无契约依据（示例按依赖 DAG 天然串行，但无依赖的跨里程碑子变更可能被误并行）。
- **建议方案**：明确"里程碑间默认串行，显式声明才可并行"（decomposition-rules.md §6.2 已按默认串行落地）；里程碑状态推进仍按 I-10 规则。
- **状态**：open

---

## 待协调者决策清单（Top 5）

1. **I-01/I-02/I-03**：epic 类型是否穿透修改 op 入口 + op-plan + op-done（三处现有文件），还是 op-orchestrate 自实现拆分/编排/归档（推荐后者，最小侵入）。
2. **I-04**：orchestration.yaml 回写由谁执行（扩展三个子 skill vs op-orchestrate 统一回写 + 对账兜底）。
3. **I-11**：子变更 commit 是否支持路径限定 add，解决提交边界重叠。
4. **I-10**：里程碑状态迁移表是否按 A2 规范 §5 建议补入契约 §5.3。
5. **I-12**：index.json 编排扩展（父条目 orchestration 标记 + 子条目 parent）是否落地。

---

## 九、各分身原始小节（已并入上述编号体系，保留备查）

> 说明：本部分保留 A2/A3/A6 分身原始写入内容（含并发覆盖恢复的标注），供协调者对照编号映射查阅。映射关系：I-12↔A2-1、I-04↔A2-2、I-10↔A2-3、A2-4/A2-5↔I-07/I-05、I-05↔A3-1、I-07↔A3-2、I-06↔A3-3、I-23↔A3-4、I-24↔A3-5、I-12/I-18↔A6-1~A6-3。

### A2 小节（数据结构规范）

#### A2-1：index.json 扩展需协调者决策

- **问题**：编排引入父变更（type: epic）与子变更（parent 字段）后，`.op/index.json` 是否需要扩展未在契约中明确。
- **建议**：父变更与子变更都出现在索引中（独立条目，沿用现有结构）；父变更条目加 `orchestration: true` 标记；子变更条目加 `parent: <父变更 name>` 字段；归档顺序为子变更先、父变更后。
- **影响**：涉及 op-done 的 index.json 写入逻辑变更（超出 A2 范围），需协调者决策后落地。

#### A2-2：change.yaml.status 与编排 status 语义重叠

- **问题**：现有 change.yaml 已有 `status` 字段（如 archived，op-done 收尾写入）；契约 §4.3 又为子变更定义编排 status（pending/active/blocked/done/archived）。两处同名易双写冲突。
- **建议**：子变更 change.yaml 不新增编排状态字段，编排 status 只存在于 orchestration.yaml（唯一进度事实源）；change.yaml.status 保留原语义。已按此写入 orchestration-schema.md §3.5/§7.2。
- **待确认**：请协调者确认后补充进契约，避免 A3/A5 分身实现不一致。

#### A2-3：里程碑状态推进规则契约未完整定义

- **问题**：契约 §4.3 定义了 milestones[].status 取值范围（pending/in_progress/blocked/done），但推进时机（由谁、何时写）未写全。
- **建议**：按派生规则实现：pending=全部子变更 pending；in_progress=至少一个子变更 active/done/archived 且无 blocked；blocked=任一子变更 blocked；done=全部子变更 archived。已写入 orchestration-schema.md §5。
- **待确认**：请协调者确认该派生规则，并同步 A3（decomposition-rules.md）保持一致。

#### A2-4：对 A3-02/A3-04 指派项的回应（fail_count、acceptance 段）

- **A3-02**（验证失败 3 次计数口径）：同意"同一验证点连续 3 次失败"口径；但 orchestration.yaml 新增 `fail_count` 字段属契约 §4.3 之外的扩展，A2 不在协调者确认前擅自落地，确认后补入 schema。
- **A3-04**（children 增加 `acceptance` 段）：同理，属契约外扩展，待协调者确认后由 A2 在 orchestration-schema.md §4.3 落地 `acceptance.business` 与 `fail_count` 字段定义。

#### A2-5：对 A3-01 的核实结论（G2 判定依据）

- **核实**：真实 change.yaml（如 zcode-op-integrate）已含 `build.done_count/total_count` 字段，契约 §4.2 只是未列全已有字段；G2 判定依据「change.yaml.build + tasks.md」成立，无歧义。
- **动作**：orchestration-schema.md §4.4 已按此口径写明判定来源；无需修改契约。

### A3 小节（拆分规则与门槛判定）

> 依据：`docs/design/op-orchestrate-design-contract.md` v0.1 §5、`op-plan/SKILL.md` v3.4.0 §4.3。详细规则见 `decomposition-rules.md`。

#### A3-1：G2 判定来源字段未定义

- **问题**：契约 §5.2 中 G2 判定来源写「子变更 change.yaml.build + tasks.md」，但 §4.2 子变更字段定义中无 `build` 字段，判定依据有歧义。
- **建议**：明确 G2 判定依据为「tasks.md 完成度（done_count==total_count）+ 验证记录 + orchestration.yaml gates 回写」。
- **影响**：已按建议口径落地于 `decomposition-rules.md` §4.2；需协调者更新契约措辞。

#### A3-2：「验证失败 3 次」计数口径未定义

- **问题**：契约 §5.3 未定义「验证失败（3 次）」的计数口径（同一验证点连续 vs 累计）。
- **建议**：统一为「同一验证点连续 3 次失败」（与 op-build systematic-debugging 触发条件一致），orchestration.yaml 增加 `fail_count` 字段（通过后清零）。
- **影响**：字段落地依赖 A2 在 orchestration-schema.md 补充 `fail_count`。

#### A3-3：子变更 type 未显式禁止 hotfix/tweak

- **问题**：契约 §4.2 子变更 `type` 限定 `feature|complex`，但未显式禁止 `hotfix|tweak`；tweak 无 tasks.md，会导致 G1/G2 判定失效。
- **建议**：强制校验子变更 type ∈ {feature, complex}，拒绝 hotfix/tweak 作为子变更。
- **影响**：需 A6 在 validate 集成中加校验（与 A6 第 8 项编排专属校验建议呼应）。

#### A3-4：orchestration.yaml children 缺 acceptance 段字段定义

- **问题**：契约 §4.3 children 无 `acceptance` 段（G 门槛 + 业务验收点）字段定义，拆分时验收标准无处登记。
- **建议**：A2 在 orchestration-schema.md 中落地 `acceptance.business`（验收点列表）字段；模板已提供于 `decomposition-rules.md` §3.2。
- **影响**：A2 schema 定稿前，验收标准以父变更 plan.md「子变更拆分」章节承载。

#### A3-5：里程碑间默认串行/可并行未明确

- **问题**：契约 §5.3 只提里程碑内并行，未明确里程碑间是否可并行。
- **建议**：明确「里程碑间默认串行，显式声明才可并行」。
- **影响**：已按默认串行落地于 `decomposition-rules.md` §6.2；需协调者确认。

### A6 小节（注册与版本集成）

> 时间：2026-08-10。依据：`docs/design/op-orchestrate-design-contract.md` v0.1、`op-000/registry.yaml`、`op-000/scripts/op-000-register.sh`、`op-000/scripts/op-000-validate.sh`。

#### A6-1：待协调者确认的事项（非阻塞，但影响注册口径）

| # | 问题 | 影响 | 建议 |
|---|------|------|------|
| 1 | 设计契约 §3 写 `phase_role: entry/support` 二选一未定。本分身论证取 **entry**（见 registry-integration.md §4） | 影响 SKILL.md frontmatter（A1）、注册条目、validate 表现 | 协调者确认后通知 A1 按同一取值写 frontmatter（注：SKILL.md v0.1.0 已采用 entry，待协调者追认） |
| 2 | 初始版本未定：`1.0.0`（与 op-docgen/op-deploy-prep 一致）还是 `0.1.0`（与契约草案号呼应） | registry 与 SKILL.md 必须一致，两侧都改 | 协调者定一个值，A1 在 SKILL.md 写死，注册时保持一致（注：SKILL.md v0.1.0 已采用 0.1.0，待协调者追认） |
| 3 | `dispatches: [op-plan, op-build, op-done, op-html]` 语义：op-plan/op-build/op-done 是**子变更**的执行方（被编排对象），非父变更自身阶段 | 读者可能误读为「父变更也走这三个阶段」 | 需在 SKILL.md Overview 显式澄清「父变更自身不做 plan/build/done 业务动作，仅编排子变更走这三者」 |
| 4 | registry 现有两个 entry（op 与新增 op-orchestrate），`op-000-list`/路由脚本不依赖 phase_role 唯一性，但需防歧义 | 文档与路由需显式声明「唯一入口仍是 op」 | 已写入 registry-integration.md §1 description 与 §4 |

#### A6-2：validate / register 脚本层面的观察（供协调者决定是否增强 op-000）

| # | 观察 | 严重度 | 说明 |
|---|------|--------|------|
| 5 | validate 与 register 均**不校验 phase_role 取值集合**，`phase_role: entry` 可直接通过，无兼容性问题 | 低（信息） | 拼写错误（如 `entery`）无预警；如需白名单校验属 op-000 增强，需协调者批准 |
| 6 | 版本一致性检查（检查 5.2）挂在 op-design-extract 检查段内（`if [ -f op-design-extract/SKILL.md ]`），**依赖 op-design-extract 目录存在**才会对全量条目生效 | 中（风险） | 若 op-design-extract 被移除/改名，op-orchestrate 的版本一致性将失去校验；建议协调者评估把 5.2 提升为独立检查 |
| 7 | `register_skill` 的去重判断（`grep -q "  - name: ..."`）无并发/重复执行竞态保护；手动粘贴 + `--sync` 组合需前置检查 | 低 | registry-integration.md §6 已给出前置 grep 检查命令 |
| 8 | **建议新增编排专属校验**（需协调者批准后落地 op-000）：a) `type: epic` 或 `orchestration.enabled: true` 的变更目录必须有 `orchestration.yaml`；b) orchestration.yaml 的 `children[].name` 与子变更 change.yaml 的 `parent` 引用双向一致；c) 子变更 `status: done` 时三道 gates 全 true、`archived` 时 change.yaml.phase == archive 且 archive.json 存在 | 中（增强建议） | 建议独立为「检查 6」或独立脚本按需加载，避免拖慢主 validate |

#### A6-3：对 A1/A5 的集成提示

- A5 路由契约中 `/op <parent>`（type=epic）→ op-orchestrate 的触发条件，需与 registry `invoked_by` 中的 trigger 文案保持一致。
- A1 的 SKILL.md frontmatter 必须包含 `version` 字段且位于首对 `---` 之间（validate 检查 5.2 按 frontmatter 段提取）；`name` 必须是文件中**第一处** `name:`（检查 2/3 取全文首个）。
- SKILL.md 完成前不要注册（register 的 `--sync` 会以 SKILL.md frontmatter 覆盖 registry 三个编排契约块）。

---

## 十、协调者决策记录（v1，2026-08-11）

协调者对 24 条问题的决策汇总（分类：Implemented=已落地到代码/文档；Adopted=契约采纳；Convention=文档级约定；Deferred=暂缓）。全部文档修正与脚本落地已随 v0.2.0 提交。

| 条目 | 问题 | 决策 | 落地位置 |
|------|------|------|----------|
| I-01 | epic 类型未纳入 op 入口路由 | Adopted | op/SKILL.md v2.4.0：epic 判定优先于 phase 路由 |
| I-02 | op-plan 不识别 epic | Implemented | SKILL.md 阶段一 + decomposition §1：op-orchestrate 自实现拆分，复杂需求加载 op-brainstorming |
| I-03 | op-done 不识别 epic | Implemented | SKILL.md 阶段四：op-orchestrate 自实现父归档（不经过 op-done） |
| I-04 | 回写协议归属 | Implemented | 方案 B 对账兜底：scripts/orchestrate-reconcile.py + SKILL.md §6 改造 |
| I-05 | G2 判定时序矛盾 | Implemented | schema §4.4、decomposition §4.2：phase ∈ {done, archive} 仅确认已退出 build |
| I-06 | 子变更 type 限定 | Implemented | schema §3.2、dashboard §2.3、validate 检查：hotfix/tweak 禁止 |
| I-07 | fail_count 字段 | Implemented | schema §4.3、decomposition §6.3：连续失败 3 次暂停并记录 |
| I-08 | 父变更 blocked 派生 | Implemented | dashboard §2.1：任一里程碑 blocked → 父变更显示 blocked |
| I-09 | paused 与 blocked 统一 | Implemented | decomposition §6.1/§6.3：统一 status=blocked |
| I-10 | 里程碑派生规则 | Adopted | schema §5：pending/in_progress/blocked/done 派生表 |
| I-11 | git 提交边界 | Convention | decomposition §7 + routing §3.5：子变更提交可含编排产物，父归档仅父级材料 |
| I-12 | index.json 编排标记 | Convention | schema §8：v1 文档级约定，op-done 不改，父归档附加标记 |
| I-13 | 子变更目录创建确认 | Implemented | decomposition §2.5：拆分清单确认后才建目录 |
| I-14 | 并行重试机制 | Implemented | decomposition §5.3：失败重试期间不启动新并行子变更 |
| I-15 | 父变更 has_ui 说明 | Implemented | schema §2.4：父变更 UI/DB/架构检查在子变更层面 |
| I-16 | op-html epic 模板 | Deferred | 父归档复用默认 md，不扩展模板（后续按需） |
| I-17 | next 候选排序 | Adopted | dashboard §7：里程碑顺序 + 拓扑序，首个为推荐 |
| I-18 | 编排专属校验 | Implemented | scripts/op-orchestrate-validate.sh + op-000-validate.sh 检查 6 钩子 |
| I-19 | created 字段 | Implemented | schema §4.1：orchestration.yaml 初版创建时间 |
| I-20 | op-find 增强 | Implemented | op/scripts/op-find.py：type/parent 解析、🗂/📎 徽标、子变更完成度、检索范围扩到子变更 |
| I-21 | paused 语义升级 | Adopted | routing §5.2：父 paused = 编排级挂起，禁止新阶段 |
| I-22 | 孤儿子变更 | Adopted | routing §5.4：孤儿检测与提示，v1 不自动收养 |
| I-23 | acceptance 字段 | Implemented | schema §4.3/§4.5：业务验收点 2-5 条，人核对 |
| I-24 | 里程碑间默认串行 | Adopted | decomposition §6.2：前一里程碑 done 后才启动后一里程碑 |

实现清单（本次提交）：
1. SKILL.md 0.1.0 → 0.2.0：对账回写语义、门槛表修正、父生命周期自实现、里程碑派生、脚本引用。
2. references 五文档一致性修正（schema/rules/dashboard/routing/registry）。
3. 新增 `scripts/orchestrate-reconcile.py`（对账兜底，含 dry-run/幂等/missing 处理）。
4. 新增 `scripts/op-orchestrate-validate.sh`（编排一致性校验）+ op-000-validate.sh「检查 6」钩子。
5. 增强 `op/scripts/op-find.py`（I-20：父/子徽标 + 完成度 + 检索范围扩展）。
6. 新增 `scripts/tests/test_reconcile.py`、`test_validate.py` 回归测试。

---

## Version

- v0.3（2026-08-11）：协调者决策记录（第十节）与实现清单。落地 I-04/05/06/07/08/09/13/14/15/18/19/20/23 与 I-02/03 自实现；约定 I-11/12；暂缓 I-16。
- v0.2（2026-08-10）：A7 重建合并版。在 A7 汇总（I-01~I-19 + E-01~E-04）基础上并入 A5 补充（I-20~I-22）、A7 整合补充（I-23~I-24），并恢复 A2/A3/A6 分身原始小节（此前被并行覆盖，A7 从会话历史恢复，见第九节）。
- v0.1（2026-08-10）：A7 初版汇总，基于设计契约 v0.1 草案、A1 SKILL.md、A2 orchestration-schema.md 与 A7 example-epic.md 推演。共 19 条问题 + 4 条示例推演发现。
