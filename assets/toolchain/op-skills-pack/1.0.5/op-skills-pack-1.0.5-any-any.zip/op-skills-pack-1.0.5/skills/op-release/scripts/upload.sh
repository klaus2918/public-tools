#!/usr/bin/env bash
# ============================================
# upload.sh — 远程构建脚本
# ============================================
# 功能：SCP 上传本地产物 → SSH 远程构建 Docker 镜像
#       镜像默认推送到 dockerhub（不做本地归档），加 --download 下载到本地 CI/ 目录
#
# 用法：./upload.sh <project> <end> <tag> [--download] [--dir <path>]
#   参数说明：
#     project         项目名称（对应 config.yaml 一级 key）
#     end             端名称：backend | pc | app
#     tag             Docker 镜像标签，如 r-1.01.00-CI
#     --download      显式开启镜像下载到本地 CI/ 目录（默认跳过，因为 docker-split.sh 已推送到仓库）
#
# 示例：
#   ./upload.sh demo-project backend r-1.01.00-CI           # 仅上传+远程构建（不下载）
#   ./upload.sh demo-project pc r-1.01.00-CI --download     # 上传+构建+下载到本地
#
# 认证优先级：
#   1. SSH 密钥（免密）
#   2. sshpass + 密码（从 password_env_var 指定的环境变量读取）
# ============================================

set -euo pipefail

# --- 路径常量 ---
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
CONFIG_FILE="$PROJECT_DIR/config.yaml"

# --- 配置解析共享库（pyyaml 结构化取值，替代 grep 行窗口）---
# shellcheck source=lib-config.sh
. "$SCRIPT_DIR/lib-config.sh"

# --- 颜色 ---
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# --- 辅助函数 ---
timestamp() {
  date '+%Y-%m-%d %H:%M:%S'
}

log_info() {
  echo -e "${GREEN}[$(timestamp)] [INFO]${NC} $*"
}

log_warn() {
  echo -e "${YELLOW}[$(timestamp)] [WARN]${NC} $*"
}

log_error() {
  echo -e "${RED}[$(timestamp)] [ERROR]${NC} $*" >&2
}

log_step() {
  echo -e "${CYAN}[$(timestamp)] [STEP]${NC} $*"
}

# --- YAML 值读取函数 ---
# 从 config.yaml 读取顶层 section 下的 key（结构化解析，底层见 lib-config.sh）
read_config() {
  local key="$1"
  local section="$2"
  cfg_get "$key" "$section"
}

# --- SSH/SCP 执行函数（优先密钥，降级 sshpass）---
SSH_CMD="ssh"
SCP_CMD="scp"
SSH_OPTS="-o StrictHostKeyChecking=no -o ConnectTimeout=${CONNECT_TIMEOUT:-10}"
SSHPASS_PREFIX=""

setup_auth() {
  local host="$1"
  local port="$2"
  local user="$3"
  local password_env_var="$4"
  local identity_file="$5"

  local test_opts="$SSH_OPTS"

  # 尝试 SSH 密钥认证（免密）
  local auth_success=false
  if [ -n "$identity_file" ]; then
    # 明确指定密钥文件测试
    local expanded_key
    expanded_key=$(eval echo "$identity_file")
    if [ -f "$expanded_key" ]; then
      if ssh -i "$expanded_key" -o StrictHostKeyChecking=no -o BatchMode=yes -o ConnectTimeout="${CONNECT_TIMEOUT:-10}" -p "$port" "${user}@${host}" "echo ok" &>/dev/null; then
        log_info "SSH 密钥认证成功（免密，密钥：${identity_file}）"
        SSH_OPTS="$SSH_OPTS -i $expanded_key"
        auth_success=true
      fi
    else
      log_warn "指定的密钥文件不存在：${expanded_key}"
    fi
  fi

  if [ "$auth_success" = false ]; then
    # 不指定密钥，尝试 ssh-agent 加载的密钥
    if ssh -o StrictHostKeyChecking=no -o BatchMode=yes -o ConnectTimeout="${CONNECT_TIMEOUT:-10}" -p "$port" "${user}@${host}" "echo ok" &>/dev/null; then
      log_info "SSH 密钥认证成功（ssh-agent）"
      auth_success=true
    fi
  fi

  if [ "$auth_success" = true ]; then
    SSH_CMD="ssh"
    SCP_CMD="scp"
    SSHPASS_PREFIX=""
    return 0
  fi

  # 降级：尝试 sshpass 密码认证
  local password="${!password_env_var:-}"
  if [ -n "$password" ]; then
    if command -v sshpass &>/dev/null; then
      log_warn "SSH 密钥认证失败，降级使用 sshpass（环境变量 ${password_env_var}）"
      export SSHPASS="$password"
      SSH_CMD="sshpass -e ssh"
      SCP_CMD="sshpass -e scp"
      SSHPASS_PREFIX="sshpass -e"
      return 0
    else
      log_error "已设置 ${password_env_var} 环境变量但未安装 sshpass，请先安装 sshpass"
      return 1
    fi
  fi

  log_error "SSH 密钥认证失败，且 ${password_env_var} 环境变量未设置"
  log_error "请先运行 init-ssh.sh 配置 SSH 密钥，或设置 SSHPASS 环境变量"
  return 1
}

# --- 上传函数 ---
upload_artifact() {
  local src="$1"
  local dest="$2"
  local port="$3"
  local identity="$4"

  if [ ! -e "$src" ]; then
    log_error "上传的本地产物不存在：$src"
    return 1
  fi

  local dest_file="${dest}/$(basename "$src")"
  log_info "上传：$src → $dest_file"

  if [ -n "$SSHPASS_PREFIX" ]; then
    $SCP_CMD $SSH_OPTS -P "$port" -r "$src" "${SSH_TARGET}:${dest}/"
  else
    if [ -n "$identity" ]; then
      scp $SSH_OPTS -P "$port" -i "$identity" -r "$src" "${SSH_TARGET}:${dest}/"
    else
      scp $SSH_OPTS -P "$port" -r "$src" "${SSH_TARGET}:${dest}/"
    fi
  fi

  local ret=$?
  if [ $ret -eq 0 ]; then
    log_info "上传完成：$dest_file"
  else
    log_error "上传失败：$src（退出码：$ret）"
  fi
  return $ret
}

# --- 远程执行函数（前置 LANG=zh_CN.UTF-8）---
remote_exec() {
  local cmd="$1"
  local port="$2"
  local identity="$3"

  local remote_cmd="export LANG=zh_CN.UTF-8; $cmd"

  if [ -n "$SSHPASS_PREFIX" ]; then
    $SSH_CMD $SSH_OPTS -p "$port" "${SSH_TARGET}" "$remote_cmd"
  else
    if [ -n "$identity" ]; then
      ssh $SSH_OPTS -p "$port" -i "$identity" "${SSH_TARGET}" "$remote_cmd"
    else
      ssh $SSH_OPTS -p "$port" "${SSH_TARGET}" "$remote_cmd"
    fi
  fi
}

# --- 下载函数 ---
download_image() {
  local remote_path="$1"
  local local_dir="$2"
  local port="$3"
  local identity="$4"

  # 创建本地 CI 目录
  mkdir -p "$local_dir"

  log_info "下载：${SSH_TARGET}:${remote_path} → $local_dir/"

  if [ -n "$SSHPASS_PREFIX" ]; then
    $SCP_CMD $SSH_OPTS -P "$port" "${SSH_TARGET}:${remote_path}" "$local_dir/"
  else
    if [ -n "$identity" ]; then
      scp $SSH_OPTS -P "$port" -i "$identity" "${SSH_TARGET}:${remote_path}" "$local_dir/"
    else
      scp $SSH_OPTS -P "$port" "${SSH_TARGET}:${remote_path}" "$local_dir/"
    fi
  fi

  local ret=$?
  if [ $ret -eq 0 ]; then
    log_info "下载完成：${local_dir}/"
  else
    log_error "下载失败（退出码：$ret）"
  fi
  return $ret
}

# --- 查找本地构建产物 ---
find_artifact() {
  local end="$1"
  local local_path="$2"

  case "$end" in
    backend)
      # 查找 target/*.jar（排除 *-sources.jar、*-tests.jar）
      local jar
      jar=$(find "$local_path/target" -maxdepth 1 -name "*.jar" \
        ! -name "*-sources.jar" \
        ! -name "*-tests.jar" \
        ! -name "original-*.jar" \
        2>/dev/null | head -1)
      if [ -n "$jar" ]; then
        echo "$jar"
      else
        log_error "后端构建产物未找到：${local_path}/target/*.jar"
        return 1
      fi
      ;;
    pc|app)
      # 前端 dist 目录
      if [ -d "$local_path/dist" ]; then
        echo "$local_path/dist"
      else
        log_error "前端构建产物未找到：${local_path}/dist/"
        return 1
      fi
      ;;
  esac
}

# --- 远程产物清空函数（上传前按端类型清空，消除旧版本残留）---
clean_remote_artifacts() {
  local end="$1"
  local remote_dir="$2"
  local port="$3"
  local identity="$4"

  # 空值/危险路径校验：remote_dir 必须非空、非根危险路径（/、.、..）
  local trimmed="${remote_dir%/}"
  if [ -z "$trimmed" ] || [ "$trimmed" = "/" ] || [ "$trimmed" = "." ] || [ "$trimmed" = ".." ]; then
    log_warn "远程目录路径为空或不安全，跳过清空：'${remote_dir}'"
    return 0
  fi

  # 安全校验：远程清空路径必须以 /home/ 开头，防止误删系统目录
  if ! printf '%s' "$trimmed" | grep -Eq '^/home/'; then
    log_error "远程清空路径不在 /home/ 下，终止：${trimmed}"
    return 1
  fi

  # 安全校验：远程目录必须真实存在，不存在则报错终止
  if ! remote_exec "test -d '${trimmed}'" "$port" "$identity" 2>/dev/null; then
    log_error "远程目录不存在，终止清空：${trimmed}"
    return 1
  fi

  case "$end" in
    backend)
      # 后端：remote_dir 即 target 目录，整体清空其内容（保留目录本身）
      log_info "清空远程后端产物目录内容（保留目录）：${trimmed}"
      remote_exec "find '${trimmed}' -mindepth 1 -delete 2>/dev/null" "$port" "$identity" \
        || log_warn "远程后端目录清空失败（仅告警，不中断流程）：${trimmed}"
      ;;
    pc|app)
      # 前端：remote_dir 即 dist 目录本身，清空其所有内容（保留目录）
      # 与 bat 脚本行为一致：rm -rf %REMOTE_UPLOAD_DIR%/*
      log_info "清空远程前端 dist 目录内容（保留目录）：${trimmed}"
      remote_exec "rm -rf '${trimmed}'/* '${trimmed}'/.[!.]* '${trimmed}'/.??* 2>/dev/null && mkdir -p '${trimmed}'" "$port" "$identity" \
        || log_warn "远程前端 dist 清空失败（仅告警，不中断流程）：${trimmed}"
      ;;
  esac
  return 0
}

# --- 镜像文件选择纯函数（供动态匹配段与 test-image-match.sh 共用，免 SSH 可测）---
# 不依赖 SSH/远程，仅基于传入的文件清单做选择，便于本地单测打桩注入。
# 入参（环境变量）：
#   SIM_FILES  远程镜像目录候选清单，每行一个完整路径，已按优先级排序（如修改时间倒序）
#   SIM_IMAGE  镜像名 IMAGE_NAME
#   SIM_TAG    镜像标签 TAG
# 输出：
#   stdout 选中文件完整路径（命中时）
#   stderr 全部候选清单（仅在多候选歧义时，每行一个，供调用方日志列示）
# 返回码：0 命中唯一候选；2 命中多个（歧义，stdout 给最新/首个）；1 未命中
# 策略：① 精确候选优先（basename 恰为 IMAGE_NAME-TAG.tar.gz 或 IMAGE_NAME_TAG.tar.gz），
#       避免宽 glob 在镜像名互为前缀时误匹配（demo-backend 与
#       demo-frontend）；② 精确缺失时降级分隔符约束 glob + 严格正则
#       过滤（IMAGE_NAME 后紧跟 - 或 _，含 TAG，以 .tar.gz 结尾），不使用裸 IMAGE_NAME 子串。
select_image_file() {
  local files="${SIM_FILES:-}"
  local image="${SIM_IMAGE:-}"
  local tag="${SIM_TAG:-}"
  local exact_dash="${image}-${tag}.tar.gz"
  local exact_under="${image}_${tag}.tar.gz"
  local line bn under_hit=""

  # ---- ① 精确候选优先（dash 优先于 under）----
  while IFS= read -r line; do
    [ -z "$line" ] && continue
    bn="${line##*/}"
    if [ "$bn" = "$exact_dash" ]; then
      printf '%s\n' "$line"
      return 0
    fi
    if [ "$bn" = "$exact_under" ] && [ -z "$under_hit" ]; then
      under_hit="$line"
    fi
  done < <(printf '%s\n' "$files")
  if [ -n "$under_hit" ]; then
    printf '%s\n' "$under_hit"
    return 0
  fi

  # ---- ② 降级：分隔符约束 glob + 严格正则过滤 ----
  local esc_image esc_tag strict_re
  esc_image=$(printf '%s' "$image" | sed 's#[][\\.^$*+?(){}|/]#\\&#g')
  esc_tag=$(printf '%s' "$tag" | sed 's#[][\\.^$*+?(){}|/]#\\&#g')
  strict_re="^${esc_image}[-_].*${esc_tag}.*\.tar\.gz$"

  local first="" all="" cnt=0
  while IFS= read -r line; do
    [ -z "$line" ] && continue
    bn="${line##*/}"
    if printf '%s\n' "$bn" | grep -Eq "${strict_re}"; then
      [ -z "$first" ] && first="$line"
      all+="${line}"$'\n'
      cnt=$((cnt + 1))
    fi
  done < <(printf '%s\n' "$files")

  if [ "$cnt" -eq 0 ]; then
    return 1
  fi
  printf '%s\n' "$first"
  if [ "$cnt" -gt 1 ]; then
    printf '%s' "$all" >&2
    return 2
  fi
  return 0
}

# 被其它脚本（如 test-image-match.sh）source 时，仅暴露上方函数库，不执行主流程
if [ "${BASH_SOURCE[0]}" != "${0}" ]; then
  return 0 2>/dev/null || true
fi

# ============================================
# 主流程
# ============================================

# --- 参数解析 ---
if [ $# -lt 3 ]; then
  log_error "参数不足。用法：$0 <project> <end> <tag> [--download] [--dir <path>]"
  log_error "  project 项目名称（对应 config.yaml 一级 key）"
  log_error "  end     端名称：backend | pc | app"
  log_error "  tag     Docker 镜像标签，如 r-1.01.00-CI"
  log_error "  --download  构建后下载镜像到本地 CI/ 目录（默认跳过，镜像已推送仓库）"
  log_error "  --dir <path>     指定目标目录（替代 config.yaml 的 local_path，在指定目录查找产物）"
  exit 1
fi

PROJECT="$1"
END="$2"
TAG="$3"
SKIP_DOWNLOAD=true   # 默认跳过下载（docker-split.sh 只 push 到仓库，不存 .tar.gz）
NEED_DOWNLOAD=false  # --download：显式开启镜像下载到本地 CI/ 目录
BUILD_DIR=""
shift 3

# 解析可选参数
while [ $# -gt 0 ]; do
  case "$1" in
    --download)
      SKIP_DOWNLOAD=false
      NEED_DOWNLOAD=true
      shift
      ;;
    --dir)
      BUILD_DIR="$2"; shift 2
      ;;
    *)
      log_warn "忽略未知参数：$1"; shift
      ;;
  esac
done

# 验证 end 参数
case "$END" in
  backend|pc|app)
    ;;
  all)
    log_info "end=all 由 Agent 子代理并行调度，请使用：/op-release ${PROJECT} all ${TAG}"
    exit 0 ;;
  *)
    log_error "无效的端名称：$END（只允许 backend、pc、app 或 all）"
    exit 1
    ;;
esac

log_info "开始远程构建流程：项目=${PROJECT}，端=${END}，标签=${TAG}"
if [ "$NEED_DOWNLOAD" = true ]; then
  log_info "选项：--download（构建后下载镜像到本地 CI/ 目录）"
fi

# --- 检查配置文件 ---
if [ ! -f "$CONFIG_FILE" ]; then
  log_error "配置文件不存在：$CONFIG_FILE"
  log_error "请先初始化配置文件，执行："
  log_error "  cp op-release/references/config-example.yaml op-release/config.yaml"
  log_error "（或直接用绝对路径：cp \"$PROJECT_DIR/references/config-example.yaml\" \"$CONFIG_FILE\"）"
  log_error "然后编辑 config.yaml，填写关键字段："
  log_error "  server: host / port / user / images_dir（远程服务器与镜像存储目录）"
  log_error "  各端 backend/pc/app: local_path / image_name / remote_upload_dir / ci_download_dir"
  exit 1
fi

# --- 读取远程服务器配置 ---
SERVER_HOST=$(read_config "host" "server")
SERVER_PORT=$(read_config "port" "server")
SERVER_USER=$(read_config "user" "server")
REMOTE_SCRIPT=$(read_config "remote_script" "server")
IMAGES_DIR=$(read_config "images_dir" "server")
PASSWORD_ENV_VAR=$(read_config "password_env_var" "server")
IDENTITY_FILE=$(cfg_get "identity_file" "server")
CONNECT_TIMEOUT=$(read_config "connect_timeout" "server")

if [ -z "$SERVER_HOST" ] || [ -z "$SERVER_USER" ]; then
  log_error "配置不完整：缺少 server.host 或 server.user"
  exit 1
fi

SSH_TARGET="${SERVER_USER}@${SERVER_HOST}"

# --- 读取项目端配置 ---
if [ -n "$BUILD_DIR" ]; then
  # --dir 模式：跳过 local_path 读取（IMAGE_NAME 等共用字段在下方统一读取）
  LOCAL_PATH="$BUILD_DIR"
  log_info "使用 --dir 指定的目录：${LOCAL_PATH}"
else
  # 常规模式：从 config.yaml 读取所有项目端配置
  LOCAL_PATH=$(cfg_get_end "$PROJECT" "$END" "local_path")
fi

# --- 两端共用字段：按 project.end 路径结构化取值（lib-config.sh）---
IMAGE_NAME=$(cfg_get_end "$PROJECT" "$END" "image_name")
REMOTE_UPLOAD_DIR=$(cfg_get_end "$PROJECT" "$END" "remote_upload_dir")
CI_DOWNLOAD_DIR=$(cfg_get_end "$PROJECT" "$END" "ci_download_dir")

if [ -z "$LOCAL_PATH" ] || [ -z "$IMAGE_NAME" ] || [ -z "$REMOTE_UPLOAD_DIR" ]; then
  if [ -n "$BUILD_DIR" ] && [ -n "$IMAGE_NAME" ] && [ -n "$REMOTE_UPLOAD_DIR" ]; then
    : # --dir 模式：LOCAL_PATH 由 --dir 提供，跳过 local_path 检查
  else
    log_error "在 config.yaml 中未找到 ${PROJECT}.${END} 的完整配置（image_name/remote_upload_dir）"
    exit 1
  fi
fi

if [ -z "$CI_DOWNLOAD_DIR" ]; then
  CI_DOWNLOAD_DIR="CI/${PROJECT}/${END}"
  log_warn "未配置 ci_download_dir，使用默认值：${CI_DOWNLOAD_DIR}"
fi
# 相对路径基于仓库 local_path 解析（而非执行 cwd），保证从任意目录调用都归档到仓库 CI/
if [ "${CI_DOWNLOAD_DIR:0:1}" != "/" ] && [ "${CI_DOWNLOAD_DIR:1:1}" != ":" ]; then
  CI_DOWNLOAD_DIR="${LOCAL_PATH}/${CI_DOWNLOAD_DIR}"
  log_info "下载目录（基于仓库）：${CI_DOWNLOAD_DIR}"
fi

# --- 设置认证 ---
log_step "Step 1/4：配置 SSH 认证"
setup_auth "$SERVER_HOST" "$SERVER_PORT" "$SERVER_USER" "$PASSWORD_ENV_VAR" "$IDENTITY_FILE"

# --- 查找本地产物 ---
log_step "Step 2/4：查找本地构建产物"
cd "$LOCAL_PATH"
ARTIFACT=$(find_artifact "$END" "$LOCAL_PATH")
if [ -z "$ARTIFACT" ]; then
  # find_artifact 内部已输出错误信息
  exit 1
fi
log_info "找到产物：$ARTIFACT"

# --- SCP 上传 ---
log_step "Step 3/4：上传产物到远程服务器"
log_info "上传目标：${SSH_TARGET}:${REMOTE_UPLOAD_DIR}"

# ---- 上传前打印操作确认信息（对齐 bat 脚本风格）----
echo ""
echo "==============================================="
echo "  即将执行以下远程操作："
echo "-----------------------------------------------"
echo "  服务器：${SSH_TARGET}"
echo "  项目：${PROJECT}"
echo "  端：${END}"
echo "  标签：${TAG}"
echo "  本地产物：${ARTIFACT}"
echo "  远程目标目录：${REMOTE_UPLOAD_DIR}"
if [ "$END" = "backend" ]; then
  CLEAN_ACTION="清空远程目录内容：${REMOTE_UPLOAD_DIR}/*"
  UPLOAD_ACTION="上传 jar → ${REMOTE_UPLOAD_DIR}/"
else
  CLEAN_ACTION="清空远程目录内容：${REMOTE_UPLOAD_DIR}/*"
  UPLOAD_ACTION="上传 dist/* → ${REMOTE_UPLOAD_DIR}/"
fi
echo "  清理操作：${CLEAN_ACTION}"
echo "  上传操作：${UPLOAD_ACTION}"
echo "==============================================="
echo ""

# 确保远程上传目录存在
remote_exec "mkdir -p '${REMOTE_UPLOAD_DIR}'" "$SERVER_PORT" "$IDENTITY_FILE" || true

# 上传前按端类型清空远程产物目录，消除旧版本残留（后端多 jar / 前端旧 dist）
clean_remote_artifacts "$END" "$REMOTE_UPLOAD_DIR" "$SERVER_PORT" "$IDENTITY_FILE"

# 上传产物
if [ "$END" = "backend" ]; then
  # 后端：上传 jar 文件本身
  if ! upload_artifact "$ARTIFACT" "$REMOTE_UPLOAD_DIR" "$SERVER_PORT" "$IDENTITY_FILE"; then
    log_error "上传失败，终止流程"
    exit 1
  fi
else
  # 前端：上传 dist/ 目录的内容（不是 dist 目录本身），与 bat 脚本 scp -r "dist/*" 一致
  log_info "上传：$ARTIFACT/* → ${REMOTE_UPLOAD_DIR}/"
  if [ -n "$SSHPASS_PREFIX" ]; then
    $SCP_CMD $SSH_OPTS -P "$SERVER_PORT" -r "${ARTIFACT}/"* "${SSH_TARGET}:${REMOTE_UPLOAD_DIR}/"
  else
    if [ -n "$IDENTITY_FILE" ]; then
      scp $SSH_OPTS -P "$SERVER_PORT" -i "$IDENTITY_FILE" -r "${ARTIFACT}/"* "${SSH_TARGET}:${REMOTE_UPLOAD_DIR}/"
    else
      scp $SSH_OPTS -P "$SERVER_PORT" -r "${ARTIFACT}/"* "${SSH_TARGET}:${REMOTE_UPLOAD_DIR}/"
    fi
  fi
  ret=$?
  if [ $ret -eq 0 ]; then
    log_info "上传完成：${REMOTE_UPLOAD_DIR}/"
  else
    log_error "上传失败：${ARTIFACT}/*（退出码：$ret）"
    exit 1
  fi
fi

# --- SSH 远程构建镜像 ---
log_step "Step 4/4：SSH 远程构建 Docker 镜像"

IMAGE_FULL="${IMAGE_NAME}:${TAG}"
# 镜像文件存储路径（连字符，与远程 docker-split.sh 产出对齐：docker save | gzip > ${IMAGE_NAME}-${TAG}.tar.gz）
IMAGE_FILE="${IMAGES_DIR}${IMAGE_NAME}-${TAG}.tar.gz"

# ---- 远程构建前打印操作确认信息 ----
echo ""
echo "==============================================="
echo "  即将执行远程 Docker 镜像构建："
echo "-----------------------------------------------"
echo "  服务器：${SSH_TARGET}"
echo "  镜像名称：${IMAGE_FULL}"
echo "  构建脚本：${REMOTE_SCRIPT}"
echo "  构建命令：cd $(dirname "${REMOTE_SCRIPT}") && ${REMOTE_SCRIPT} ${IMAGE_FULL}"
echo "  产物推送：<REGISTRY_HOST>/<REGISTRY_PROJECT>/${IMAGE_FULL}（实际仓库地址由远程 docker-split.sh 配置决定）"
echo "==============================================="
echo ""

log_info "远程构建：${REMOTE_SCRIPT} ${IMAGE_FULL}"

# 前置 cd 到 REMOTE_SCRIPT 所在目录：SSH 远程默认家目录，docker-split.sh 内相对 cd 需以脚本所在目录（构建上下文根）为基准
# REMOTE_SCRIPT 为绝对路径，dirname 本地展开结果即远程脚本所在目录，与远程一致
BUILD_CMD="cd \"$(dirname "${REMOTE_SCRIPT}")\" && ${REMOTE_SCRIPT} ${IMAGE_FULL}"

# ---- 执行远程构建：终端实时输出 + PIPESTATUS 保留 ssh 真实退出码 ----
# 不用 $(...) 命令替换：docker build/push/save 的错误走 stderr，捕获会失联；
# 且远端链条末尾是 docker rmi（退出码 0 不代表归档已生成），只看 ssh 码会误判成功。
BUILD_LOG="$(mktemp 2>/dev/null || printf '%s' "${TMPDIR:-/tmp}/upload-build.$$.log")"
log_info "远程构建输出实时打印（完整日志：${BUILD_LOG}）"
BUILD_RC=0
if remote_exec "$BUILD_CMD" "$SERVER_PORT" "$IDENTITY_FILE" 2>&1 | tee "$BUILD_LOG"; then
  :
else
  BUILD_RC=${PIPESTATUS[0]}
fi

if [ "$BUILD_RC" -ne 0 ]; then
  log_error "远程构建失败（退出码：${BUILD_RC}），完整输出：${BUILD_LOG}"
  tail -60 "$BUILD_LOG" 2>/dev/null | sed 's/^/  /' || true
  exit 1
fi
log_info "远程构建完成（退出码：0）"

# ---- 构建后归档校验：docker-split.sh 的 save 环节可能晚于 ssh 返回（竞态）----
# 实证：upload.sh 检查时文件未出现，约 57s 后才生成。此处轮询等待归档出现。
log_info "校验远程镜像归档：${IMAGES_DIR}${IMAGE_NAME}-${TAG}.tar.gz"
ARCHIVE_FOUND=false
for attempt in 1 2 3 4 5 6 7 8 9 10; do
  if remote_exec "ls -s ${IMAGES_DIR}${IMAGE_NAME}-${TAG}.tar.gz 2>/dev/null | awk '{print \$1}'" "$SERVER_PORT" "$IDENTITY_FILE" | grep -Eq '^[0-9]+$'; then
    ARCHIVE_FOUND=true
    log_info "归档已生成（第 ${attempt} 次检查）"
    break
  fi
  [ "$attempt" -lt 10 ] && { log_info "归档尚未生成，等待 6s 重试（${attempt}/10）..."; sleep 6; }
done
if [ "$ARCHIVE_FOUND" = false ]; then
  log_warn "远程归档未出现（save 可能静默失败）。排查："
  remote_exec "ls -la ${IMAGES_DIR} | tail -15" "$SERVER_PORT" "$IDENTITY_FILE" | sed 's/^/  /' || true
  log_warn "镜像已推送到仓库，可去掉 --download 仅用仓库镜像"
fi

# --- 下载镜像到本地 CI/ 目录（默认跳过，仅 --download 时执行）---
if [ "$SKIP_DOWNLOAD" = false ]; then
  if [ "$ARCHIVE_FOUND" = false ]; then
    log_error "归档未生成，无法下载。请检查远程 docker-split.sh 的 save 环节"
    exit 1
  fi
  log_info "开始下载镜像（--download）..."
  GLOB_DASH="${IMAGES_DIR}${IMAGE_NAME}-*${TAG}*"
  GLOB_UNDER="${IMAGES_DIR}${IMAGE_NAME}_*${TAG}*"
  log_info "动态匹配远程镜像文件：${GLOB_DASH} / ${GLOB_UNDER}"

  LIST_CMD="ls -1t ${GLOB_DASH} ${GLOB_UNDER} 2>/dev/null"
  # 关键：ls 多参数时只要有一个 glob 无匹配就返回非零（部分失败），但 stdout 仍输出匹配文件；
  # set -e 下不能写 `|| RAW_LIST=""`（会把已捕获的文件名清空），用 `|| true` 保留 stdout 且不退出。
  RAW_LIST=$(remote_exec "$LIST_CMD" "$SERVER_PORT" "$IDENTITY_FILE" || true)

  CAND_TMP="$(mktemp 2>/dev/null)" || CAND_TMP="${TMPDIR:-/tmp}/sim.$$"
  SEL_RC=0
  IMAGE_FILE=$(SIM_FILES="$RAW_LIST" SIM_IMAGE="$IMAGE_NAME" SIM_TAG="$TAG" \
    select_image_file 2>"$CAND_TMP") || SEL_RC=$?

  case "$SEL_RC" in
    0)
      log_info "命中镜像文件：$IMAGE_FILE"
      ;;
    2)
      log_warn "匹配到多个镜像文件（歧义），按修改时间取最新：$IMAGE_FILE"
      while IFS= read -r cand; do
        [ -n "$cand" ] && log_warn "  候选：$cand"
      done < "$CAND_TMP"
      ;;
    *)
      log_error "远程未找到匹配的镜像文件"
      log_error "确认项："
      log_error "  - 远程 docker-split.sh 是否成功执行 save（本次构建日志：${BUILD_LOG}）"
      log_error "  - IMAGE_NAME(${IMAGE_NAME}) / TAG(${TAG}) 是否正确"
      log_error "  - ${IMAGES_DIR} 下是否有文件："
      remote_exec "ls -la ${IMAGES_DIR} 2>&1 | tail -10" "$SERVER_PORT" "$IDENTITY_FILE" | sed 's/^/    /' || true
      rm -f "$CAND_TMP" 2>/dev/null
      exit 1
      ;;
  esac
  rm -f "$CAND_TMP" 2>/dev/null

  log_info "下载镜像：$IMAGE_FILE → ${CI_DOWNLOAD_DIR}/"
  if ! download_image "$IMAGE_FILE" "$CI_DOWNLOAD_DIR" "$SERVER_PORT" "$IDENTITY_FILE"; then
    log_error "镜像下载失败"
    exit 1
  fi
else
  log_info "镜像已推送到仓库，跳过本地下载（加 --download 可下载到本地 CI/ 目录）"
fi

# --- 完成 ---
log_info "远程构建流程完成：${PROJECT}/${END} @ ${TAG}"
