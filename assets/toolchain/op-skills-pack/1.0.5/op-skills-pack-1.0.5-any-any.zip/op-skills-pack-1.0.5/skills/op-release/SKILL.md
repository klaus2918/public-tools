---
name: op-release
category: support
description: 多端项目打包与镜像部署。本地打包、SCP 上传、远程 Docker 镜像构建。可独立使用。
status: active
phase_role: support
version: "2.2.0"
updated_at: 2026-09-19
---

# op-release — 三端打包与镜像部署

集中管理多端项目（后端/PC 前端/APP 前端）的本地打包、SCP 上传、远程 Docker 镜像构建、镜像下载。

与 op-deploy-prep 分工：本 skill 管「包怎么发」，op-deploy-prep 管「环境怎么同步」。

---

## Quick Reference

```
/op-release <project> <end> <tag> [--skip-build] [--download] [--force] [--mode <env>] [--dir <path>] [--tool <tool>]
```

### 参数说明

| 参数 | 必填 | 说明 |
|------|------|------|
| `project` | 是 | 项目名称（对应 config.yaml 一级 key） |
| `end` | 是 | 端名称：`backend` / `pc` / `app` / `all` |
| `tag` | 是 | Docker 镜像标签，如 `r-1.01.00-CI` |
| `--skip-build` | 否 | 跳过本地打包 |
| `--download` | 否 | 下载镜像到本地 CI/ |
| `--force` | 否 | 强制重建 |
| `--mode <env>` | 否 | 前端构建环境（默认 production） |
| `--dir <路径>` | 否 | 指定目标目录 |
| `--tool <工具>` | 否 | 前端构建工具（bun/npm/pnpm/yarn） |

---

## 项目-端映射

| 端 | 产物 | 构建命令 |
|----|------|----------|
| `backend` | `target/*.jar` | `mvnd clean package -DskipTests -T 4`（未安装 mvnd 时自动降级 `mvn` 并打印 WARN；并行度可用环境变量 `MVN_T` 覆盖） |
| `pc` | `dist/` | `npm run build` |
| `app` | `dist/` | `npm run build` |

---

## 流程

```
[build.sh] 本地打包 → [upload.sh] SCP 上传 → SSH 构建 Docker 镜像 → SCP 下载到 CI/
```

---

## 约束

1. **密码安全**：优先 SSH 密钥，降级 SSHPASS 环境变量
2. **中文编码**：远程 SSH 命令前置 `export LANG=zh_CN.UTF-8`
3. **并发处理**：`end=all` 时多端并行
4. **构建加速**：后端优先 `mvnd`（daemon 复用 + 模块级并行 `-T 4`）；未安装 mvnd 时降级 `mvn` 并打印 WARN；并行度由环境变量 `MVN_T` 覆盖（默认 `4`，兼容 `1C` 等写法）

---

## 资产分离

```
op-release/                       ← Skill 代码（进 Git）
.basic/evolved/op-release/       ← 运行时资产（不进 Git，junction 链接）
├── config.yaml                   ← 项目配置（本地实例文件，不进 Git）
└── CI/                           ← 镜像产物
```

**配置来源**：仓库内只提供模板 `references/config-example.yaml`（占位示例值）。
`config.yaml` 为本地实例文件，含真实服务器地址与账号，**被 .gitignore 排除，严禁入库**。
首次使用：`cp references/config-example.yaml config.yaml`，再按实际环境填写各字段。

**配置解析**（2.1.0 起统一入口）：

- `scripts/lib-config.sh`：取值共享库，由 `build.sh` / `upload.sh` / `init-ssh.sh` source 引入
- `scripts/config-get.py`：底层结构化解析（pyyaml），替代历史 `grep -A N | grep -A M | sed` 行窗口
- 提供 `cfg_get <key> <section>`、`cfg_get_path <a.b.c>`、`cfg_get_end <project> <end> <key>`、`cfg_dump_end`、`cfg_projects`
- 取值语义：未找到输出空串，调用方以 `[ -z "$v" ]` 判断（与历史一致）；不再受注释行数与块内字段数影响
- 环境依赖：**含 pyyaml 的 python**（按 `py` → `python3` → `python` 探测）；缺失时快速失败（exit 2）并提示安装命令

junction 由 op-000 统一管理。

---

## Version

| Field | Value |
|-------|-------|
| Skill | op-release |
| Version | 2.2.0 |
| Updated | 2026-09-19 |
| Key change | v2.2.0: 后端构建切换 mvnd 并行（`mvnd clean package -DskipTests -T 4`）；未安装 mvnd 时探测降级 `mvn` 并打印 WARN；并行度可用 `MVN_T` 覆盖 |
