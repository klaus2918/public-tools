#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ============================================
# config-get.py — config.yaml 结构化取值（pyyaml）
# ============================================
# 用途：替代各脚本中「grep -A N | grep -A M | sed」的配置解析，消除三类历史缺陷：
#   1. 固定行窗口（-A 20 / -A 5）在注释较多或字段较多时取不到值
#   2. 跨块误匹配（同名 key 出现在前一个块时取到错值）
#   3. 行内注释、引号需靠 sed 二次剥离
#
# 用法：
#   config-get.py --config <file> --projects
#   config-get.py --config <file> --path <a.b.c>
#   config-get.py --config <file> --dump <project> <end>
#
# 退出码：
#   0  成功，值已输出到 stdout
#   2  配置错误（文件不存在 / YAML 解析失败 / 参数不合法）
#   3  路径不存在或值为空
#
# 说明：成功时 stdout 仅输出值本身（不带引号与多余空白），错误信息一律走 stderr。
# 依赖：python3 + pyyaml（env_requirements 已登记）；无 pyyaml 时由 lib-config.sh 提前拦截。

import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")


def fail(code, msg):
    sys.stderr.write("[config-get] " + msg + "\n")
    sys.exit(code)


def fmt(value):
    """标量值转字符串；非标量（映射/列表）返回 None。"""
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, str):
        return value
    return None


def load_config(path):
    try:
        import yaml
    except ImportError:
        fail(2, "缺少 pyyaml：请执行 py -m pip install pyyaml")
    import os

    if not os.path.isfile(path):
        fail(2, "配置文件不存在：" + path)
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh)
    except UnicodeDecodeError as exc:
        fail(2, "配置文件不是合法 UTF-8：" + str(exc))
    except Exception as exc:  # yaml.YAMLError 及 IO 错误
        fail(2, "配置文件解析失败：" + str(exc))
    if data is None:
        fail(2, "配置文件为空：" + path)
    if not isinstance(data, dict):
        fail(2, "配置文件顶层不是映射结构：" + path)
    return data


def parse_args(argv):
    config = ""
    mode = ""
    args = []
    i = 0
    while i < len(argv):
        token = argv[i]
        if token == "--config":
            i += 1
            if i >= len(argv):
                fail(2, "参数错误：--config 缺少值")
            config = argv[i]
        elif token == "--projects":
            mode = "projects"
        elif token == "--path":
            i += 1
            if i >= len(argv):
                fail(2, "参数错误：--path 缺少值")
            mode = "path"
            args = [argv[i]]
        elif token == "--dump":
            if i + 2 >= len(argv):
                fail(2, "参数错误：--dump 需要 project 与 end 两个值")
            mode = "dump"
            args = [argv[i + 1], argv[i + 2]]
            i += 2
        else:
            fail(2, "参数错误：未知参数 " + token)
        i += 1

    if not mode:
        fail(2, "参数错误：必须指定 --projects / --path / --dump 之一")
    if not config:
        fail(2, "参数错误：必须指定 --config <file>")
    return config, mode, args


def main(argv):
    config_path, mode, args = parse_args(argv)
    data = load_config(config_path)

    if mode == "projects":
        # 顶层 key，排除 server 段；保持文件中的声明顺序（与历史 grep 顺序一致）
        names = [str(k) for k in data.keys() if str(k) != "server"]
        if not names:
            sys.exit(3)
        sys.stdout.write("\n".join(names) + "\n")
        return

    if mode == "path":
        node = data
        for seg in args[0].split("."):
            if not isinstance(node, dict) or seg not in node:
                sys.exit(3)
            node = node[seg]
        if isinstance(node, dict) or isinstance(node, list):
            fail(2, "路径不是标量值：" + args[0])
        text = fmt(node)
        if text == "":
            sys.exit(3)
        sys.stdout.write(text + "\n")
        return

    # mode == "dump"：输出 project.end 下全部标量字段的 key=value 行
    project, end = args
    node = data.get(project)
    if not isinstance(node, dict) or end not in node or not isinstance(node[end], dict):
        sys.exit(3)
    lines = []
    for key, value in node[end].items():
        text = fmt(value)
        if text is None or text == "":
            continue
        lines.append("%s=%s" % (key, text))
    if not lines:
        sys.exit(3)
    sys.stdout.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    main(sys.argv[1:])
