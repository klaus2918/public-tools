#!/usr/bin/env bash
# ============================================
# lib-config.sh — config.yaml 取值共享库
# ============================================
# 由 build.sh / upload.sh / init-ssh.sh source 引入，是配置解析的唯一入口。
# 底层调用同目录 config-get.py（pyyaml 结构化解析），不再用 grep 行窗口。
#
# 依赖（已在 op-000/registry.yaml 的 env_requirements 登记）：
#   - 含 pyyaml 的 python 解释器（按 py → python3 → python 顺序探测）
#
# 提供函数（取值函数「未找到」时输出空串并返回 0，调用方用 [ -z "$v" ] 判断，与历史语义一致）：
#   cfg_get <key> <section>            顶层 section 下的 key（兼容旧 read_config 签名）
#   cfg_get_path <a.b.c>               任意点路径取值
#   cfg_get_end <project> <end> <key>  项目端字段取值
#   cfg_dump_end <project> <end>       输出该端全部 key=value 行
#   cfg_projects                       输出全部项目 key（不含 server）
#
# 前置变量：SCRIPT_DIR（脚本目录）、CONFIG_FILE（配置文件路径）须已在调用方定义。

CFG_GET_PY="${SCRIPT_DIR}/config-get.py"
_CFG_PY=""
_CFG_PY_READY=""

# 解释器探测：首次用到配置时执行一次；无可用解释器则快速失败（exit 2）
_cfg_ensure_py() {
  if [ -n "$_CFG_PY_READY" ]; then
    [ "$_CFG_PY_READY" = "ok" ] || exit 2
    return 0
  fi
  local c
  for c in py python3 python; do
    if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import yaml' >/dev/null 2>&1; then
      _CFG_PY="$c"
      _CFG_PY_READY="ok"
      return 0
    fi
  done
  _CFG_PY_READY="missing"
  echo "[ERROR] 环境不可用：配置解析需要含 pyyaml 的 python（按 py / python3 / python 探测）" >&2
  echo "[ERROR] 安装示例：py -m pip install pyyaml" >&2
  exit 2
}

# 底层调用：stdout 为值，退出码由调用方忽略（历史 grep 路径同样靠空串判断）
_cfg_raw() {
  _cfg_ensure_py
  "$_CFG_PY" "$CFG_GET_PY" --config "$CONFIG_FILE" "$@" 2>/dev/null || true
}

# 顶层 section 下的 key，如 cfg_get host server → server.host
cfg_get() {
  cfg_get_path "$2.$1"
}

# 任意点路径取值，如 cfg_get_path demo-project.backend.local_path
cfg_get_path() {
  _cfg_raw --path "$1"
}

# 项目端字段取值，如 cfg_get_end demo-project backend local_path
cfg_get_end() {
  cfg_get_path "$1.$2.$3"
}

# 项目端全字段，输出多行 key=value（供 while IFS='=' read 使用）
cfg_dump_end() {
  _cfg_raw --dump "$1" "$2"
}

# 全部项目 key（保持文件声明顺序），多行输出
cfg_projects() {
  _cfg_raw --projects
}
