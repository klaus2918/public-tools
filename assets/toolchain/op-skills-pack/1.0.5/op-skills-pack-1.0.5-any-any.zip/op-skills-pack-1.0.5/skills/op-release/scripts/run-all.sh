#!/usr/bin/env bash
# ============================================
# run-all.sh — 三端并行编排脚本
# ============================================
# 功能：并发执行 backend / pc / app 三端的「本地打包 → 上传 → 远程构建 → 下载」完整流程
#       单端失败不中断其他端（失败隔离），全部结束后汇总各端结果与用时
#
# 用法：./run-all.sh <project> <tag> [--skip-build] [--skip-download] [--mode <env>] [--tool <tool>]
#   参数说明：
#     project         项目名称（对应 config.yaml 一级 key）
#     tag             Docker 镜像标签，如 r-1.01.00-CI
#     --skip-build    跳过本地打包阶段，直接上传（复用已有产物）
#     --skip-download 远程构建后跳过镜像下载
#     --mode <env>    前端构建环境，默认 production（透传给 build.sh）
#     --tool <tool>   前端构建工具：bun/npm/pnpm/yarn（透传给 build.sh）
#
# 示例：
#   ./run-all.sh demo-project r-1.01.00-CI
#   ./run-all.sh demo-project r-1.01.00-CI --skip-build --skip-download
#   ./run-all.sh demo-project r-1.01.00-CI --tool bun --mode test
#
# 退出码：三端全部成功为 0；任一端失败为 1
# ============================================

set -uo pipefail

# --- 路径常量 ---
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
BUILD_SH="$SCRIPT_DIR/build.sh"
UPLOAD_SH="$SCRIPT_DIR/upload.sh"
LOG_DIR="$PROJECT_DIR/.run-all-logs"

# --- 颜色 ---
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# --- 辅助函数 ---
timestamp() {
  date '+%Y-%m-%d %H:%M:%S'
}

log_info()  { echo -e "${GREEN}[$(timestamp)] [INFO]${NC} $*"; }
log_warn()  { echo -e "${YELLOW}[$(timestamp)] [WARN]${NC} $*"; }
log_error() { echo -e "${RED}[$(timestamp)] [ERROR]${NC} $*" >&2; }
log_step()  { echo -e "${CYAN}[$(timestamp)] [STEP]${NC} $*"; }

# --- 参数解析 ---
PROJECT=""
TAG=""
SKIP_BUILD=false
DOWNLOAD=false
FORCE=false
NO_TYPECHECK=false
MODE=""
TOOL=""

POSITIONAL=()
while [ $# -gt 0 ]; do
  case "$1" in
    --skip-build)
      SKIP_BUILD=true; shift
      ;;
    --download)
      DOWNLOAD=true; shift
      ;;
    --force)
      FORCE=true; shift
      ;;
    --no-typecheck)
      NO_TYPECHECK=true; shift
      ;;
    --mode)
      [ $# -lt 2 ] && { log_error "--mode 需要一个参数值"; exit 1; }
      MODE="$2"; shift 2
      ;;
    --tool)
      [ $# -lt 2 ] && { log_error "--tool 需要一个参数值"; exit 1; }
      TOOL="$2"; shift 2
      ;;
    -h|--help)
      echo "用法：$0 <project> <tag> [--skip-build] [--download] [--force] [--no-typecheck] [--mode <env>] [--tool <tool>]"
      exit 0
      ;;
    --)
      shift; break
      ;;
    -*)
      log_warn "忽略未知参数：$1"; shift
      ;;
    *)
      POSITIONAL+=("$1"); shift
      ;;
  esac
done
for arg in "$@"; do
  POSITIONAL+=("$arg")
done

PROJECT="${POSITIONAL[0]:-}"
TAG="${POSITIONAL[1]:-}"

if [ -z "$PROJECT" ] || [ -z "$TAG" ]; then
  log_error "参数不足。用法：$0 <project> <tag> [--skip-build] [--download] [--force] [--no-typecheck] [--mode <env>] [--tool <tool>]"
  [ -z "$PROJECT" ] && log_error "  缺失必需参数：project（项目名称）"
  [ -z "$TAG" ] && log_error "  缺失必需参数：tag（Docker 镜像标签）"
  exit 1
fi

# --- 前置校验 ---
[ -f "$BUILD_SH" ]  || { log_error "build.sh 不存在：$BUILD_SH"; exit 1; }
[ -f "$UPLOAD_SH" ] || { log_error "upload.sh 不存在：$UPLOAD_SH"; exit 1; }
mkdir -p "$LOG_DIR"

# 透传给子脚本的命名参数串（不加引号，依赖 word splitting 展开为多个参数）
BUILD_OPTS=""
[ -n "$MODE" ] && BUILD_OPTS="$BUILD_OPTS --mode $MODE"
[ -n "$TOOL" ] && BUILD_OPTS="$BUILD_OPTS --tool $TOOL"
[ "$FORCE" = true ] && BUILD_OPTS="$BUILD_OPTS --force"
[ "$NO_TYPECHECK" = true ] && BUILD_OPTS="$BUILD_OPTS --no-typecheck"
UPLOAD_OPTS=""
# upload.sh 只认 --download（--skip-download 是文档遗留，会被忽略）；显式下载时透传
[ "$DOWNLOAD" = true ] && UPLOAD_OPTS="$UPLOAD_OPTS --download"

ENDS=(backend pc app)

# --- 单端执行（build → upload），返回该端退出码 ---
run_one_end() {
  local end="$1"
  local start_ts end_ts elapsed rc

  start_ts=$(date +%s)
  if [ "$SKIP_BUILD" = false ]; then
    log_info "[${end}] 阶段1/2：本地打包"
    bash "$BUILD_SH" "$PROJECT" "$end" $BUILD_OPTS
    rc=$?
    if [ $rc -ne 0 ]; then
      end_ts=$(date +%s); elapsed=$((end_ts - start_ts))
      log_error "[${end}] 打包失败（退出码 ${rc}，用时 ${elapsed}s）"
      return $rc
    fi
  fi

  log_info "[${end}] 阶段2/2：上传 + 远程构建 + 下载"
  bash "$UPLOAD_SH" "$PROJECT" "$end" "$TAG" $UPLOAD_OPTS
  rc=$?
  end_ts=$(date +%s); elapsed=$((end_ts - start_ts))
  if [ $rc -ne 0 ]; then
    log_error "[${end}] 上传/构建失败（退出码 ${rc}，用时 ${elapsed}s）"
  else
    log_info "[${end}] 成功完成（用时 ${elapsed}s）"
  fi
  return $rc
}

# --- 并发启动三端，各端输出写入独立日志 ---
LOG_STAMP="$(date '+%Y%m%d-%H%M%S')"
declare -A END_PID END_LOG RESULT

log_step "三端并行启动：项目=${PROJECT}，标签=${TAG}"
for end in "${ENDS[@]}"; do
  end_log="$LOG_DIR/${LOG_STAMP}-${end}.log"
  END_LOG[$end]="$end_log"
  log_info "[${end}] 已启动，日志：${end_log}"
  ( run_one_end "$end" ) >"$end_log" 2>&1 &
  END_PID[$end]=$!
done

# --- 等待全部完成并收集结果（单端失败不影响其他端）---
log_step "等待三端执行完成..."
ALL_OK=true
for end in "${ENDS[@]}"; do
  wait "${END_PID[$end]}"
  rc=$?
  if [ $rc -eq 0 ]; then
    RESULT[$end]="成功"
  else
    RESULT[$end]="失败(退出码 ${rc})"
    ALL_OK=false
  fi
done

# --- 结果汇总 ---
log_step "三端执行结果汇总"
for end in "${ENDS[@]}"; do
  if [ "${RESULT[$end]}" = "成功" ]; then
    log_info "  [${end}] ✅ 成功   日志：${END_LOG[$end]}"
  else
    log_error "  [${end}] ❌ ${RESULT[$end]}   日志：${END_LOG[$end]}"
  fi
done

if [ "$ALL_OK" = true ]; then
  log_info "三端并行流程全部成功：${PROJECT} @ ${TAG}"
  exit 0
else
  log_error "存在失败的端，详见各端日志：${LOG_DIR}/"
  exit 1
fi
