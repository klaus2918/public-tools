#!/usr/bin/env bash
# ============================================
# test-image-match.sh —— 镜像文件名动态匹配的前缀冲突单测（本地可跑，免真实 SSH）
# ============================================
# 原理：source upload.sh 仅加载纯函数 select_image_file（upload.sh 内置 source 守卫，
#       被 source 时不执行主流程），向其注入打桩的远程文件清单 SIM_FILES，断言选择结果。
#       单测验证的就是 upload.sh 动态匹配段使用的同款选择逻辑，无重复实现。
# 运行：bash op-release/scripts/test-image-match.sh
# 退出：0 全部通过；1 存在失败（并打印实际命中的文件名以便定位）
# ============================================

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
UPLOAD_SH="$SCRIPT_DIR/upload.sh"

PASS=0
FAIL=0

red()    { printf '\033[0;31m%s\033[0m\n' "$*"; }
green()  { printf '\033[0;32m%s\033[0m\n' "$*"; }

# 期望命中某文件（rc=0 或 rc=2 均视为命中，比对 basename）
assert_select() {
  local name="$1" expect_bn="$2" files="$3" image="$4" tag="$5"
  local got rc got_bn
  got=$(SIM_FILES="$files" SIM_IMAGE="$image" SIM_TAG="$tag" select_image_file 2>/dev/null)
  rc=$?
  got_bn="${got##*/}"
  if [ "$rc" -eq 1 ]; then
    red "[FAIL] $name：期望命中 '$expect_bn'，实际未命中（rc=1）"
    FAIL=$((FAIL + 1)); return
  fi
  if [ "$got_bn" = "$expect_bn" ]; then
    green "[PASS] $name → $got_bn"
    PASS=$((PASS + 1))
  else
    red "[FAIL] $name：期望 '$expect_bn'，实际命中 '$got'（rc=$rc）"
    FAIL=$((FAIL + 1))
  fi
}

# 期望未命中（rc=1 且 stdout 为空）
assert_miss() {
  local name="$1" files="$2" image="$3" tag="$4"
  local got rc
  got=$(SIM_FILES="$files" SIM_IMAGE="$image" SIM_TAG="$tag" select_image_file 2>/dev/null)
  rc=$?
  if [ "$rc" -eq 1 ] && [ -z "$got" ]; then
    green "[PASS] $name → 未命中（符合预期）"
    PASS=$((PASS + 1))
  else
    red "[FAIL] $name：期望未命中，实际 rc=$rc 命中 '$got'"
    FAIL=$((FAIL + 1))
  fi
}

# 期望多候选歧义（rc=2），stdout 给出清单首个候选
assert_ambiguous() {
  local name="$1" expect_first_bn="$2" files="$3" image="$4" tag="$5"
  local got rc got_bn
  got=$(SIM_FILES="$files" SIM_IMAGE="$image" SIM_TAG="$tag" select_image_file 2>/dev/null)
  rc=$?
  got_bn="${got##*/}"
  if [ "$rc" -ne 2 ]; then
    red "[FAIL] $name：期望歧义(rc=2)，实际 rc=$rc 命中 '$got'"
    FAIL=$((FAIL + 1)); return
  fi
  if [ "$got_bn" = "$expect_first_bn" ]; then
    green "[PASS] $name → 歧义，取首个 '$got_bn'"
    PASS=$((PASS + 1))
  else
    red "[FAIL] $name：歧义但首个应为 '$expect_first_bn'，实际 '$got'"
    FAIL=$((FAIL + 1))
  fi
}

# ---- 加载被测纯函数（upload.sh source 守卫保证不跑主流程）----
# shellcheck disable=SC1091
source "$UPLOAD_SH" || { red "加载 upload.sh 失败：$UPLOAD_SH"; exit 1; }
# upload.sh 内部已 set -euo pipefail；本测试关闭 errexit，由断言函数自控退出
set +e +o pipefail 2>/dev/null || true

DIR="/data/images/"

# ============================================================
# 用例组1：镜像名互为前缀（核心缺陷场景）
# 后端 demo-backend 与前端 demo-frontend
# ============================================================
TAG1="r-1.01.00-CI"
FILES1="${DIR}demo-backend-${TAG1}.tar.gz"$'\n'"${DIR}demo-frontend-${TAG1}.tar.gz"
assert_select "互为前缀·下载后端（后端在前）" \
  "demo-backend-${TAG1}.tar.gz" \
  "$FILES1" "demo-backend" "$TAG1"

# 清单顺序颠倒（前端在前），精确候选仍应只命中后端，不误取前端
FILES1B="${DIR}demo-frontend-${TAG1}.tar.gz"$'\n'"${DIR}demo-backend-${TAG1}.tar.gz"
assert_select "互为前缀·下载后端（前端在前）" \
  "demo-backend-${TAG1}.tar.gz" \
  "$FILES1B" "demo-backend" "$TAG1"

# 反向：以前端镜像名为目标，应命中前端、不误取后端
assert_select "互为前缀·下载前端" \
  "demo-frontend-${TAG1}.tar.gz" \
  "$FILES1" "demo-frontend" "$TAG1"

# ============================================================
# 用例组2：示例配置回归（非互为前缀，正常命中，行为不回退）
# ============================================================
FILES2="${DIR}demo-project-backend-r-1.01.00-CI.tar.gz"
assert_select "回归·demo-project-backend（连字符）" \
  "demo-project-backend-r-1.01.00-CI.tar.gz" \
  "$FILES2" "demo-project-backend" "r-1.01.00-CI"

FILES3="${DIR}demo-project-pc-r-1.01.00-CI.tar.gz"
assert_select "回归·demo-project-pc（连字符）" \
  "demo-project-pc-r-1.01.00-CI.tar.gz" \
  "$FILES3" "demo-project-pc" "r-1.01.00-CI"

# 下划线分隔符候选（精确 under 命中）
FILES4="${DIR}myapp_pc_1.0.0.tar.gz"
assert_select "回归·下划线分隔符" \
  "myapp_pc_1.0.0.tar.gz" \
  "$FILES4" "myapp_pc" "1.0.0"

# ============================================================
# 用例组3：未命中
# ============================================================
FILES5="${DIR}other-image-r-2.0.0.tar.gz"
assert_miss "未命中·无关镜像" \
  "$FILES5" "demo-backend" "$TAG1"

# IMAGE_NAME 作为别的镜像名中间子串出现（裸子串会误命中，严格正则不会）
FILES6="${DIR}x-demo-backend-${TAG1}.tar.gz"
assert_miss "未命中·IMAGE_NAME 非边界子串" \
  "$FILES6" "demo-backend" "$TAG1"

# ============================================================
# 用例组4：多候选歧义（同镜像多 build，精确候选不命中）
# ============================================================
FILES7="${DIR}demo-v1-abcd.tar.gz"$'\n'"${DIR}demo-v1-efgh.tar.gz"
assert_ambiguous "歧义·同镜像多build" \
  "demo-v1-abcd.tar.gz" \
  "$FILES7" "demo" "v1"

# ============================================================
# 汇总
# ============================================================
echo "----------------------------------------"
if [ "$FAIL" -eq 0 ]; then
  green "全部通过：PASS=$PASS FAIL=$FAIL"
  exit 0
else
  red "存在失败：PASS=$PASS FAIL=$FAIL"
  exit 1
fi
