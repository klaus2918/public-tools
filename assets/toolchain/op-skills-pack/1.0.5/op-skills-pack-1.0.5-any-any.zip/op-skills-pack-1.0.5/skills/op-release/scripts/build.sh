#!/usr/bin/env bash
# ============================================
# build.sh — 本地打包脚本
# ============================================
# 功能：根据项目配置和端类型执行本地构建
#       后端：mvnd clean package -DskipTests -T 4（未安装 mvnd 时自动降级 mvn，并打印 WARN）
#       前端：npm run build / bun run build [--mode <env>]
#
# 支持增量缓存检测：产物新鲜时自动跳过构建，加 --force 强制重建。
#
# 用法：./build.sh <project> <end> [mode] [--dir <path>] [--tool <tool>] [--no-typecheck] [--jdk-path <path>] [--force]
#   参数说明：
#     project  项目名称（对应 config.yaml 一级 key）
#     end      端名称：backend | pc | app
#     mode     前端构建环境（仅前端有效），默认 production
#     --dir    指定目标目录（替代 config.yaml 的 local_path）
#     --tool   前端构建工具：bun / npm / pnpm / yarn（默认 npm）
#     --no-typecheck  跳过 vue-tsc 类型检查、直接 vite build（仅前端 pc/app 有效）
#     --jdk-path <path>  指定 JDK 根目录，自动加到 PATH 最前并设 JAVA_HOME
#     --force  强制重建，跳过增量缓存检测
#
# 示例：
#   ./build.sh demo-project backend                              # 打包后端
#   ./build.sh demo-project pc                                   # 打包 PC 前端
#   ./build.sh demo-project backend --jdk-path /d/tools/jdk-17   # 指定 JDK 路径打包后端
#   ./build.sh demo-project pc --dir /path/to/worktree           # 指定目录打包
#   ./build.sh demo-project pc --tool bun                        # 用 bun 打包
#   ./build.sh demo-project pc --force                           # 强制重建前端
# ============================================

set -euo pipefail

# --- 路径常量 ---
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
CONFIG_FILE="$PROJECT_DIR/config.yaml"

# --- 配置解析共享库（pyyaml 结构化取值，替代 grep 行窗口）---
# shellcheck source=lib-config.sh
. "$SCRIPT_DIR/lib-config.sh"

# --- 颜色 ---
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# --- 辅助函数 ---
timestamp() { date '+%Y-%m-%d %H:%M:%S'; }
log_info()  { echo -e "${GREEN}[$(timestamp)] [INFO]${NC} $*"; }
log_warn()  { echo -e "${YELLOW}[$(timestamp)] [WARN]${NC} $*"; }
log_error() { echo -e "${RED}[$(timestamp)] [ERROR]${NC} $*" >&2; }

# --- 构建器与并行度（mvnd 优先；缺失降级 mvn；并行度默认 4，可用 MVN_T 覆盖）---
# 依据：变更 op-release-mvnd-build（plan.md 决策 B4/B5/D1/D3）
MVN_T="${MVN_T:-4}"
if command -v mvnd >/dev/null 2>&1; then
  MVN_CMD="mvnd"
  log_info "构建器：mvnd（daemon 复用），并行度 -T ${MVN_T}"
else
  MVN_CMD="mvn"
  log_warn "未找到 mvnd，已降级 mvn（无 daemon 复用；安装 mvnd 可显著加速重复构建）"
  log_warn "并行度仍使用 -T ${MVN_T}（可用 MVN_T 覆盖，如 MVN_T=1C）"
fi

# --- 参数解析 ---
PROJECT=""
END=""
MODE="production"
BUILD_DIR=""
TOOL=""
NO_TYPECHECK=false
FORCE=false
JDK_PATH=""

POSITIONAL=()
while [ $# -gt 0 ]; do
  case "$1" in
    --dir)        [ $# -lt 2 ] && { log_error "--dir 需要一个参数值"; exit 1; }
                  BUILD_DIR="$2"; shift 2 ;;
    --tool)       [ $# -lt 2 ] && { log_error "--tool 需要一个参数值"; exit 1; }
                  TOOL="$2"; shift 2 ;;
    --mode)       [ $# -lt 2 ] && { log_error "--mode 需要一个参数值"; exit 1; }
                  MODE="$2"; shift 2 ;;
    --no-typecheck) NO_TYPECHECK=true; shift ;;
    --jdk-path)   [ $# -lt 2 ] && { log_error "--jdk-path 需要一个参数值"; exit 1; }
                  JDK_PATH="$2"; shift 2 ;;
    --force)      FORCE=true; shift ;;
    --)           shift; break ;;
    -*)           log_warn "忽略未知参数：$1"; shift ;;
    *)            POSITIONAL+=("$1"); shift ;;
  esac
done
for arg in "$@"; do POSITIONAL+=("$arg"); done

PROJECT="${POSITIONAL[0]:-}"
END="${POSITIONAL[1]:-}"
[ -n "${POSITIONAL[2]:-}" ] && MODE="${POSITIONAL[2]}"
[ "${#POSITIONAL[@]}" -gt 3 ] && log_warn "位置参数多于 3 个，已忽略多余项：${POSITIONAL[*]:3}"

if [ -z "$PROJECT" ] || [ -z "$END" ]; then
  log_error "参数不足。用法：$0 <project> <end> [mode] [--dir <path>] [--tool <tool>] [--no-typecheck] [--jdk-path <path>] [--force]"
  [ -z "$PROJECT" ] && log_error "  缺失必需参数：project"
  [ -z "$END" ] && log_error "  缺失必需参数：end（backend | pc | app）"
  exit 1
fi

case "$END" in
  backend|pc|app) ;;
  all)
    log_info "end=all 由 Agent 子代理并行调度，请使用：/op-release ${PROJECT} all <tag> [options]"
    exit 0 ;;
  *) log_error "无效的端名称：$END（只允许 backend、pc、app 或 all）"; exit 1 ;;
esac

# --- 确定工作目录 ---
if [ -n "$BUILD_DIR" ]; then
  WORK_DIR="$BUILD_DIR"
  log_info "开始打包：项目=${PROJECT}，端=${END}，模式=${MODE}，目标目录：${WORK_DIR}（--dir 指定）"
else
  [ ! -f "$CONFIG_FILE" ] && {
    log_error "配置文件不存在：$CONFIG_FILE"
    log_error "请先初始化：cp op-release/references/config-example.yaml op-release/config.yaml"
    exit 1
  }
  LOCAL_PATH=$(cfg_get_end "$PROJECT" "$END" "local_path")
  if [ -z "$LOCAL_PATH" ]; then
    log_error "在 config.yaml 中未找到 ${PROJECT}.${END}.local_path"
    log_error "请确认项目 key 与文档一致（当前 config 项目：$(cfg_projects | tr '\n' ' ')）"
    exit 1
  fi
  WORK_DIR="$LOCAL_PATH"
  log_info "开始打包：项目=${PROJECT}，端=${END}，模式=${MODE}，项目路径：${WORK_DIR}"
fi

[ ! -d "$WORK_DIR" ] && { log_error "目录不存在：$WORK_DIR"; exit 1; }
cd "$WORK_DIR"

# --- JDK 路径：CLI > config.yaml > 不指定 ---
if [ -z "$JDK_PATH" ] && [ -f "$CONFIG_FILE" ]; then
  CFG_JDK=$(cfg_get_end "$PROJECT" "$END" "jdk_path")
  if [ -n "$CFG_JDK" ]; then
    JDK_PATH="$CFG_JDK"
    log_info "JDK 路径：从 config.yaml 读取 jdk_path=${JDK_PATH}"
  fi
fi
if [ -n "$JDK_PATH" ] && [ "$END" = "backend" ]; then
  [ ! -d "$JDK_PATH" ] && { log_error "--jdk-path 指定的路径不存在：${JDK_PATH}"; exit 1; }
  [ ! -f "${JDK_PATH}/bin/java" ] && { log_error "--jdk-path 中未找到 bin/java：${JDK_PATH}"; exit 1; }
  export JAVA_HOME="$(cd "$JDK_PATH" && pwd)"
  export PATH="${JAVA_HOME}/bin:$PATH"
  log_info "JDK 已激活：${JAVA_HOME}"
fi

# === 读取 config 的 per-end 字段（build_tool 等），CLI 参数优先 ===
if [ -z "$TOOL" ] && [ -f "$CONFIG_FILE" ]; then
  CFG_TOOL=$(cfg_get_end "$PROJECT" "$END" "build_tool")
  if [ -n "$CFG_TOOL" ]; then
    TOOL="$CFG_TOOL"
    log_info "构建工具：从 config.yaml 读取 build_tool=${CFG_TOOL}"
  fi
fi

# === 增量缓存检测（产物 vs 源码最新 mtime；--force 跳过）===
# 只比 package.json/dist 会漏掉 src/ 改动（曾导致 APP 用 7/29 旧产物打镜像），
# 因此用 find 扫描 src/、*.env*、package.json、pom.xml 的最新 mtime 与产物目录比较。
CACHE_HIT=false
if [ "$FORCE" = false ]; then
  case "$END" in
    backend)
      if [ -f "pom.xml" ] && ls target/*.jar &>/dev/null 2>/dev/null; then
        SRC_MTIME=$(find pom.xml src -type f -newer "target" -printf '%T@\n' 2>/dev/null | sort -rn | head -1)
        [ -z "$SRC_MTIME" ] && SRC_MTIME=0
        LATEST_JAR=$(ls -t target/*.jar 2>/dev/null | head -1)
        JAR_MTIME=$(stat -c %Y "$LATEST_JAR" 2>/dev/null || stat -f %m "$LATEST_JAR" 2>/dev/null)
        # 无源码比产物新 → 缓存命中
        [ -n "$JAR_MTIME" ] && [ "$SRC_MTIME" -le "$JAR_MTIME" ] && CACHE_HIT=true
      fi
      ;;
    pc|app)
      if [ -d "dist" ] && [ -f "package.json" ]; then
        # 扫描源码与配置文件的最新 mtime（src/、index.html、vite.config.*、.env*、package.json）
        SRC_MTIME=$(find src index.html vite.config.* .env* package.json -type f -newer "dist" -printf '%T@\n' 2>/dev/null | sort -rn | head -1)
        [ -z "$SRC_MTIME" ] && SRC_MTIME=0
        DIST_MTIME=$(stat -c %Y "dist" 2>/dev/null || stat -f %m "dist" 2>/dev/null)
        # 无源码比 dist 新 → 缓存命中（dist 目录 mtime 随写入变化，保守取 >= 比较）
        [ -n "$DIST_MTIME" ] && [ "$SRC_MTIME" -le "$DIST_MTIME" ] && CACHE_HIT=true
      fi
      ;;
  esac
  if [ "$CACHE_HIT" = true ]; then
    log_info "缓存命中：产物新鲜，跳过构建（加 --force 强制重建）"
  fi
fi

# === 执行构建 ===
case "$END" in
  backend)
    if [ "$CACHE_HIT" = true ]; then
      :  # skip
    else
      java_ver=$(java -version 2>&1 | head -1) || {
        log_error "未找到 java 命令，后端构建要求 JDK17"
        log_error "解决方法：在 config.yaml 中配置 ${PROJECT}.${END}.jdk_path 或加 --jdk-path 参数"
        exit 1
      }
      if ! printf '%s' "$java_ver" | grep -Eq 'version "17'; then
        log_error "后端构建要求 JDK17，当前 java 非 JDK17：${java_ver}"
        log_error "解决方法："
        log_error "  1) 固化到 config.yaml：在 ${PROJECT}.${END} 下加 jdk_path: /d/tools/jdk-17"
        log_error "  2) 临时传 --jdk-path：$0 ${PROJECT} ${END} --jdk-path /d/tools/jdk-17"
        log_error "  3) 手动：export JAVA_HOME=/path/to/jdk-17 && export PATH=\$JAVA_HOME/bin:\$PATH"
        exit 1
      fi
      log_info "JDK17 检查通过：${java_ver}"
      log_info "开始构建后端（${MVN_CMD}，并行度 -T ${MVN_T}）..."
      if "$MVN_CMD" clean package -DskipTests -T "$MVN_T"; then
        log_info "后端打包成功（${MVN_CMD} clean package -DskipTests -T ${MVN_T}）"
      else
        log_error "后端打包失败：${MVN_CMD} clean package -DskipTests -T ${MVN_T} 返回非零退出码"
        exit 1
      fi
    fi
    ;;

  pc|app)
    if [ "$CACHE_HIT" = true ]; then
      :  # skip
    else
      [ ! -f "package.json" ] && { log_error "项目目录缺少 package.json：$WORK_DIR"; exit 1; }

      if [ "$NO_TYPECHECK" = true ]; then
        [ ! -f "node_modules/.bin/vite" ] && { log_error "未找到 vite：node_modules/.bin/vite"; exit 1; }
        log_info "开始构建前端（跳过类型检查 --no-typecheck）..."
        if ./node_modules/.bin/vite build --mode "$MODE"; then
          log_info "前端打包成功（跳过类型检查，模式：${MODE}）"
        else
          log_error "前端打包失败：vite build --mode ${MODE} 返回非零退出码"
          exit 1
        fi
        log_info "打包完成：${PROJECT}/${END}"
        exit 0
      fi

      case "${TOOL:-npm}" in
        bun)
          command -v bun &>/dev/null || { log_error "bun 未安装或不在 PATH"; exit 1; }
          log_info "开始构建前端（bun）..."
          bun run build -- --mode "$MODE" && log_info "前端打包成功（工具：bun，模式：${MODE}）" \
            || { log_error "前端打包失败：bun run build"; exit 1; } ;;
        npm)
          log_info "开始构建前端（npm）..."
          npm run build -- --mode "$MODE" && log_info "前端打包成功（工具：npm，模式：${MODE}）" \
            || { log_error "前端打包失败：npm run build"; exit 1; } ;;
        pnpm)
          command -v pnpm &>/dev/null || { log_error "pnpm 未安装或不在 PATH"; exit 1; }
          log_info "开始构建前端（pnpm）..."
          pnpm run build -- --mode "$MODE" && log_info "前端打包成功（工具：pnpm，模式：${MODE}）" \
            || { log_error "前端打包失败：pnpm run build"; exit 1; } ;;
        yarn)
          command -v yarn &>/dev/null || { log_error "yarn 未安装或不在 PATH"; exit 1; }
          log_info "开始构建前端（yarn）..."
          yarn run build -- --mode "$MODE" && log_info "前端打包成功（工具：yarn，模式：${MODE}）" \
            || { log_error "前端打包失败：yarn run build"; exit 1; } ;;
        *)
          log_error "不支持的前端构建工具：${TOOL}（支持：bun / npm / pnpm / yarn）"
          exit 1 ;;
      esac
    fi
    ;;
esac

log_info "打包完成：${PROJECT}/${END}"
