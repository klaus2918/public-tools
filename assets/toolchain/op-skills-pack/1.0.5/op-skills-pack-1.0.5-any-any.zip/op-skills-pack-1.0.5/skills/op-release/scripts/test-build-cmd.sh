#!/usr/bin/env bash
# ============================================
# test-build-cmd.sh —— 远程构建命令构造（A1）与主流程 local 误用（A2）回归断言
# ============================================
# 背景：2026-07-09 DEMO-PROJECT dev 三端打包实战（tag r-1.02.61-CI）暴露两个致命缺陷：
#   A1：upload.sh 主流程构造远程构建命令 BUILD_CMD 时，未先 cd 到 REMOTE_SCRIPT 所在目录。
#       SSH 登录后默认工作目录为家目录（/root），直接执行 docker-split.sh 时，脚本内部
#       的相对路径 cd（如 cd demo-backend）因工作目录非镜像构建上下文根
#       （/home/deploy/）而失败：No such file or directory。三端必现。
#   A2：upload.sh 主流程（非函数体内）使用 `local ret=$?` 捕获 remote_exec 退出码。
#       bash 规定 local 仅能在函数内使用，主流程执行会报 'local: can only be used in a
#       function'，导致 ret 未被正确赋值，掩盖远程构建的真实退出码与错误。
#
# 本脚本为 RED 阶段回归基线（TDD）：
#   - 静态断言驱动 RED/GREEN：直接检查 upload.sh 源码是否符合期望写法。
#   - 行为复现：用 mock/迷你脚本把缺陷现象跑出来，让 RED 状态可观测。
#   当前（未修复）upload.sh：A1/A2 静态断言均失败 → 退出码 1（RED）。
#   P003 修复后：静态断言转绿 → 退出码 0（GREEN）。
#
# 运行：bash op-release/scripts/test-build-cmd.sh
# 退出：0 全部通过（GREEN）；1 存在失败（RED）
# ============================================

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
UPLOAD_SH="$SCRIPT_DIR/upload.sh"

PASS=0
FAIL=0

red()    { printf '\033[0;31m%s\033[0m\n' "$*"; }
green()  { printf '\033[0;32m%s\033[0m\n' "$*"; }
yellow() { printf '\033[1;33m%s\033[0m\n' "$*"; }

pass() { green "[PASS] $1"; PASS=$((PASS + 1)); }
fail() { red   "[FAIL] $1"; FAIL=$((FAIL + 1)); }

[ -f "$UPLOAD_SH" ] || { red "未找到 upload.sh：$UPLOAD_SH"; exit 1; }

# 关闭 errexit：断言中 grep 不匹配等属正常分支，不应中断测试
set +e +o pipefail 2>/dev/null || true

# ============================================================
# A1：BUILD_CMD 必须先 cd 到 REMOTE_SCRIPT 所在目录再执行
# ============================================================
echo "---- A1：远程构建命令 BUILD_CMD 构造 ----"

# --- A1 行为复现：不前置 cd 时，脚本内相对路径 cd 报 No such file or directory ---
# mock：REMOTE_SCRIPT 所在目录下有构建上下文子目录 demo-backend，
#       docker-split.sh 内部相对 cd 进入该子目录（依赖调用方工作目录 = 脚本所在目录）。
a1_ctx=$(mktemp -d)                                  # 模拟 REMOTE_SCRIPT 所在目录（构建上下文根）
mkdir -p "$a1_ctx/demo-backend"        # 模拟镜像构建上下文子目录
a1_remote_script="$a1_ctx/docker-split.sh"
printf '%s\n' '#!/usr/bin/env bash' 'cd demo-backend' > "$a1_remote_script"
chmod +x "$a1_remote_script" 2>/dev/null || true
a1_home=$(mktemp -d)                                 # 模拟 SSH 登录家目录（/root）
# 当前构造方式：不前置 cd，从家目录直接执行 REMOTE_SCRIPT
a1_demo_err=$( { cd "$a1_home" && "$a1_remote_script" demo-project-pc:r-1.02.61-CI 1>/dev/null; } 2>&1 )
a1_demo_rc=$?
rm -rf "$a1_ctx" "$a1_home"
if printf '%s' "$a1_demo_err" | grep -qi "No such file or directory"; then
  yellow "  [复现] 不前置 cd 时：docker-split.sh 内相对 cd 失败（rc=$a1_demo_rc）：$a1_demo_err"
else
  yellow "  [复现] 未捕获到 No such file or directory（rc=$a1_demo_rc）：$a1_demo_err"
fi

# --- A1 静态断言：BUILD_CMD 行应在执行 REMOTE_SCRIPT 之前先 cd 到其所在目录 ---
# 期望形态：cd "$(dirname "${REMOTE_SCRIPT}")" && ${REMOTE_SCRIPT} ${IMAGE_FULL}
# 判定依据：BUILD_CMD 赋值行含 `cd ... && ... REMOTE_SCRIPT` 模式（先 cd 再执行脚本）
a1_line=$(grep -nE '^[[:space:]]*BUILD_CMD=' "$UPLOAD_SH" | head -1)
if [ -z "$a1_line" ]; then
  fail "A1·未在 upload.sh 找到 BUILD_CMD= 赋值行"
elif printf '%s' "$a1_line" | grep -Eq 'cd[[:space:]].*&&[[:space:]].*(\$\{REMOTE_SCRIPT\}|\$REMOTE_SCRIPT)'; then
  pass "A1·BUILD_CMD 已先 cd 到 REMOTE_SCRIPT 所在目录再执行"
else
  fail "A1·BUILD_CMD 未先 cd 到 REMOTE_SCRIPT 所在目录（当前：${a1_line#*:}）——从 /root 出发执行 docker-split.sh，其内相对路径 cd 必报 No such file or directory"
fi

# ============================================================
# A2：主流程（BUILD_CMD 错误处理块）不得使用 local
# ============================================================
echo "---- A2：主流程错误处理 local 误用 ----"

# --- A2 行为复现：非函数上下文 local 触发 'can only be used in a function'，ret 未捕获 ---
# mini 脚本模拟 upload.sh 主流程 `|| { local ret=$?; ... }`：remote_exec 失败（返回非零）后
# 进入错误处理块，local 在主流程报错，ret 不被赋值（本应捕获到退出码）。
a2_mini=$(mktemp)
printf '%s\n' \
  '#!/usr/bin/env bash' \
  '# 模拟 upload.sh 主流程（非函数体内）的 || { local ret=$?; ... }' \
  'BUILD_OUTPUT=$(false) || {' \
  '  local ret=$?' \
  '  echo "RET=[${ret}]"' \
  '  exit 1' \
  '}' > "$a2_mini"
a2_demo_out=$(bash "$a2_mini" 2>&1)
a2_demo_rc=$?
rm -f "$a2_mini"
if printf '%s' "$a2_demo_out" | grep -qi "can only be used in a function"; then
  yellow "  [复现] 非函数 local 报错（rc=$a2_demo_rc）：$a2_demo_out（ret 未捕获退出码，掩盖远程真实错误）"
else
  yellow "  [复现] 未捕获到 local 报错（rc=$a2_demo_rc）：$a2_demo_out"
fi

# --- A2 静态断言：BUILD_CMD 之后的错误处理块不得含 local（主流程） ---
a2_line_no=$(grep -nE '^[[:space:]]*BUILD_CMD=' "$UPLOAD_SH" | head -1 | cut -d: -f1)
if [ -z "$a2_line_no" ]; then
  fail "A2·无法定位 BUILD_CMD 行号，跳过主流程 local 检测"
else
  a2_block=$(sed -n "${a2_line_no},$((a2_line_no + 8))p" "$UPLOAD_SH")
  # local 作为命令词（前为行首/非单词字符，后为空白），避免误匹配 local_xxx 等
  if printf '%s\n' "$a2_block" | grep -Eq '(^|[^a-zA-Z_])local[[:space:]]'; then
    fail "A2·BUILD_CMD 错误处理块（主流程）含 local 赋值——bash 必报 'local: can only be used in a function'，掩盖远程退出码"
  else
    pass "A2·BUILD_CMD 错误处理块（主流程）无 local"
  fi
fi

# ============================================================
# 汇总
# ============================================================
echo "----------------------------------------"
if [ "$FAIL" -eq 0 ]; then
  green "全部通过：PASS=$PASS FAIL=$FAIL（GREEN）"
  exit 0
else
  red "存在失败：PASS=$PASS FAIL=$FAIL（RED：A1/A2 未修复）"
  exit 1
fi
