#!/usr/bin/env bash
# ============================================
# init-ssh.sh — SSH 密钥引导与免密配置
# ============================================
# 功能：引导用户生成 RSA 4096 密钥对并将公钥复制到远程服务器，
#       实现免密 SSH 登录。同时在密钥认证不可用时，提供
#       sshpass 降级方案的环境变量设置说明。
#
# 用法：./init-ssh.sh [project]
#   参数说明：
#     project  可选。项目名称，用于读取 config.yaml 中的远程服务器信息。
#              不指定时提示用户手动输入服务器信息。
#
# 示例：
#   ./init-ssh.sh              # 手动输入服务器信息
#   ./init-ssh.sh demo-project        # 从 config.yaml 读取 DEMO-PROJECT 的远程服务器配置
# ============================================

set -euo pipefail

# --- 路径常量 ---
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
CONFIG_FILE="$PROJECT_DIR/config.yaml"

# --- 配置解析共享库（pyyaml 结构化取值，替代 grep 行窗口）---
# shellcheck source=lib-config.sh
. "$SCRIPT_DIR/lib-config.sh"

# --- 颜色 ---
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# --- 辅助函数 ---
log_info()  { echo -e "${GREEN}[INFO]${NC} $*"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC} $*"; }
log_error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }
log_step()  { echo -e "${CYAN}[STEP]${NC} $*"; }

# --- 检查命令可用性 ---
check_command() {
  if ! command -v "$1" &>/dev/null; then
    log_error "未找到命令：$1，请先安装"
    return 1
  fi
}

# --- 从 config.yaml 读取服务器信息 ---
read_server_config() {
  local project="$1"

  if [ ! -f "$CONFIG_FILE" ]; then
    return 1
  fi

  # 读取 server 段配置（结构化解析，底层见 lib-config.sh）
  local host port user

  host=$(cfg_get "host" "server")
  port=$(cfg_get "port" "server")
  user=$(cfg_get "user" "server")

  if [ -n "$host" ] && [ -n "$user" ]; then
    SERVER_HOST="$host"
    SERVER_PORT="${port:-22}"
    SERVER_USER="$user"
    return 0
  fi

  return 1
}

# ============================================
# 主流程
# ============================================

echo ""
echo "============================================"
echo "  SSH 密钥引导与免密配置"
echo "============================================"
echo ""

# --- 检查必要命令 ---
check_command ssh-keygen || exit 1
check_command ssh-copy-id || log_warn "ssh-copy-id 未找到，将提供手动复制说明"

# --- 解析参数 / 读取配置 ---
SERVER_HOST=""
SERVER_PORT=22
SERVER_USER=""

if [ $# -ge 1 ]; then
  PROJECT="$1"
  log_info "尝试从 config.yaml 读取项目 [${PROJECT}] 的服务器配置..."
  if read_server_config "$PROJECT"; then
    log_info "从配置读取到服务器信息：${SERVER_USER}@${SERVER_HOST}:${SERVER_PORT}"
  else
    log_warn "未找到 config.yaml 或配置不完整，将手动输入"
  fi
else
  log_info "未指定项目，将手动输入服务器信息"
fi

# --- 引导用户输入服务器信息（如果未从配置读取）---
if [ -z "$SERVER_HOST" ]; then
  read -r -p "请输入远程服务器 IP 地址或域名： " SERVER_HOST
  if [ -z "$SERVER_HOST" ]; then
    log_error "服务器地址不能为空"
    exit 1
  fi
fi

if [ -z "$SERVER_USER" ]; then
  read -r -p "请输入远程服务器登录用户名 [root]： " input_user
  SERVER_USER="${input_user:-root}"
fi

read -r -p "请输入 SSH 端口号 [22]： " input_port
SERVER_PORT="${input_port:-22}"

echo ""
log_info "目标服务器：${SERVER_USER}@${SERVER_HOST}:${SERVER_PORT}"
echo ""

# --- Step 1: 检查/生成 SSH 密钥对 ---
log_step "Step 1/3：检查 SSH 密钥对"

DEFAULT_KEY="$HOME/.ssh/id_rsa"

if [ -f "${DEFAULT_KEY}" ]; then
  log_info "已存在 SSH 密钥对：${DEFAULT_KEY}"
  log_info "公钥：${DEFAULT_KEY}.pub"

  read -r -p "是否使用现有密钥？[Y/n] " use_existing
  if [[ "$use_existing" =~ ^[Nn] ]]; then
    read -r -p "请输入新的密钥路径 [${DEFAULT_KEY}]： " KEY_PATH
    KEY_PATH="${KEY_PATH:-$DEFAULT_KEY}"
    log_info "生成新密钥对：${KEY_PATH}"
    ssh-keygen -t rsa -b 4096 -f "$KEY_PATH"
    chmod 600 "$KEY_PATH"
  else
    KEY_PATH="$DEFAULT_KEY"
  fi
else
  log_info "未找到 SSH 密钥对，正在生成..."
  KEY_PATH="$DEFAULT_KEY"
  ssh-keygen -t rsa -b 4096 -f "$KEY_PATH"
  chmod 600 "$KEY_PATH"
  log_info "密钥对已生成：${KEY_PATH}"
fi

echo ""

# --- Step 2: 复制公钥到远程服务器 ---
log_step "Step 2/3：复制公钥到远程服务器"

if command -v ssh-copy-id &>/dev/null; then
  log_info "使用 ssh-copy-id 复制公钥..."

  if [ "$SERVER_PORT" -ne 22 ]; then
    # ssh-copy-id 在不同系统上端口参数不同
    if ssh-copy-id -h 2>&1 | grep -q "\-p"; then
      ssh-copy-id -p "$SERVER_PORT" -i "${KEY_PATH}.pub" "${SERVER_USER}@${SERVER_HOST}" || {
        log_warn "ssh-copy-id 执行失败，尝试手动方式"
        MANUAL_COPY=true
      }
    else
      # 部分系统不支持 -p，改用 -o Port
      ssh-copy-id -o "Port=${SERVER_PORT}" -i "${KEY_PATH}.pub" "${SERVER_USER}@${SERVER_HOST}" || {
        log_warn "ssh-copy-id 执行失败，尝试手动方式"
        MANUAL_COPY=true
      }
    fi
  else
    ssh-copy-id -i "${KEY_PATH}.pub" "${SERVER_USER}@${SERVER_HOST}" || {
      log_warn "ssh-copy-id 执行失败，尝试手动方式"
      MANUAL_COPY=true
    }
  fi
else
  log_warn "未安装 ssh-copy-id，将提供手动复制说明"
  MANUAL_COPY=true
fi

if [ "${MANUAL_COPY:-false}" = true ]; then
  echo ""
  log_warn "请手动执行以下命令将公钥复制到远程服务器："
  echo ""
  echo "--------------------------------------------------"
  # 检查 Windows Git Bash 环境
  if [[ "$(uname)" =~ MINGW|MSYS|CYGWIN ]]; then
    echo "  # Windows (Git Bash) 环境："
    echo "  cat ${KEY_PATH}.pub | ssh ${SERVER_USER}@${SERVER_HOST} -p ${SERVER_PORT} \"mkdir -p ~/.ssh && cat >> ~/.ssh/authorized_keys\""
  else
    echo "  ssh-copy-id -i ${KEY_PATH}.pub -p ${SERVER_PORT} ${SERVER_USER}@${SERVER_HOST}"
  fi
  echo "--------------------------------------------------"
  echo ""

  read -r -p "公钥是否已成功复制到远程服务器？[y/N] " confirm_copy
  if [[ ! "$confirm_copy" =~ ^[Yy] ]]; then
    log_error "公钥复制被跳过。请在复制后重新运行本脚本。"
    exit 1
  fi
fi

echo ""

# --- Step 3: 验证免密登录 ---
log_step "Step 3/3：验证免密登录"

log_info "测试 SSH 免密连接 ${SERVER_USER}@${SERVER_HOST}:${SERVER_PORT}..."

if ssh -o StrictHostKeyChecking=accept-new -o BatchMode=yes -o ConnectTimeout=10 \
  -p "$SERVER_PORT" "${SERVER_USER}@${SERVER_HOST}" "echo '[免密登录成功] 连接正常'" 2>/dev/null; then
  echo ""
  log_info "============================================"
  log_info "  SSH 免密登录配置成功！"
  log_info "============================================"
  echo ""
else
  echo ""
  log_warn "============================================"
  log_warn "  免密登录验证失败"
  log_warn "============================================"
  echo ""
  log_warn "可能的原因："
  log_warn "  1. 公钥尚未正确添加到远程服务器的 ~/.ssh/authorized_keys"
  log_warn "  2. 远程服务器 ~/.ssh 目录权限不正确（应为 700）"
  log_warn "  3. 远程服务器 ~/.ssh/authorized_keys 权限不正确（应为 600）"
  echo ""

  # --- 提供 sshpass 降级方案说明 ---
  echo ""
  log_step "备用方案：sshpass 密码认证配置说明"
  echo ""
  echo "如果暂时无法配置密钥认证，可以使用 sshpass + 环境变量方式："
  echo ""
  echo "  Step 1: 安装 sshpass"
  echo "    # Debian/Ubuntu:"
  echo "    sudo apt-get install sshpass"
  echo ""
  echo "    # CentOS/RHEL:"
  echo "    sudo yum install sshpass"
  echo ""
  echo "    # macOS:"
  echo "    brew install hudochenkov/sshpass/sshpass"
  echo ""
  echo "  Step 2: 设置密码环境变量"
  echo "    export SSHPASS='your_password_here'"
  echo ""
  echo "  Step 3: 运行 upload.sh 时会自动检测 SSHPASS 环境变量"
  echo ""
  log_warn "注意：密码中含有空格会导致 sshpass 失败，建议使用 SSH 密钥认证"
  echo ""

  exit 1
fi

# --- 完成 ---
log_info "配置摘要："
echo "  密钥路径：${KEY_PATH}"
echo "  公钥路径：${KEY_PATH}.pub"
echo "  目标服务器：${SERVER_USER}@${SERVER_HOST}:${SERVER_PORT}"
echo ""
log_info "现在可以直接使用 ./upload.sh 进行免密远程操作了"
