---
name: op-html
category: support
status: active
phase_role: support
description: 确认材料渲染 skill。默认生成 Markdown，仅用户明确要求时才生成 HTML。复用 templates/ 骨架。
version: "4.2.0"
updated_at: 2026-09-14
---

# op-html — 确认材料渲染

## Overview

将阶段产物整理为确认材料：**默认 Markdown 文件**；仅当用户明确要求 HTML 时才转换为 HTML 确认页面。

---

## Quick Reference

| Step | Description |
|------|-------------|
| 选载体 | 默认 md；仅用户明确要求 HTML 才走 HTML 流程 |
| 选骨架 | 见下方骨架选择决策矩阵 |
| 复制 | 完整复制到产物路径 |
| 填充 | 仅替换 `<!-- TODO: ... -->` 标记处的数据 |
| 渲染 | 全部内联 CSS，零 CDN / 零 JS / 零外链字体 |

---

## 骨架选择（HTML 模式）

### 结构选择

| 条件 | 推荐结构 | 适用骨架 |
|------|---------|---------|
| 设计点 ≤ 3 | 单页 | `_plan-confirm` / `_decision-list` / `_archive` |
| 设计点 > 3 | 多 Section | `_confirm-index` + `_section-detail` + `_change-summary` |

### 主题检测

每次生成执行 `bash op-html/scripts/theme-detect.sh` 获取 TEMPLATE：
- `light` → 不加 `-dark` 后缀
- `dark` → 加 `-dark` 后缀

**禁止**询问用户，直接使用检测结果。

---

## 双层模型

| Layer | Content | 说明 |
|-------|---------|------|
| 🟦 System | Phase, task progress, change metadata | 工作流元数据 |
| 🟩 Business | Requirements, design contract, usage stories | 业务内容 |

---

## 设计契约卡片

当 `change.yaml.design_extracted == true` 时，business 渲染必须展示设计契约卡片。

---

## 使用故事卡片

当 plan.md 含「使用故事」章节时，business 渲染必须展示使用故事卡片。

---

## Self-Contained Constraints

1. **Pure HTML + CSS only.** No CDN, no JS, no external fonts.
2. **Self-contained.** Every page is offline-readable.
3. **Open Edge — 仅限 HTML 产物。Markdown 产物禁止打开浏览器。**
   - HTML 模式：生成后自动执行 `start msedge "<path>"`
   - Markdown 模式：**禁止**执行 `start msedge` 或任何浏览器打开命令
4. **防重复打开机制**：读取 `sites/.last-opened` 文件，60 秒内同一 path 跳过。

---

## 运行时资产（v4.1）

产物归位：生成的确认材料站点与 `.last-opened` 状态写入 skill 内 `sites/`（junction 挂载点，实体位于 `.basic/evolved/op-html/sites/`）。`templates/` 骨架是 skill 代码，随仓库分发；`sites/` 是运行产物，**不入 git、不随包分发**。

---

## Red Flags — STOP

| Smell | Action |
|-------|--------|
| 用户未明确要求 HTML 却生成了 HTML | 停止；默认应生成 Markdown |
| CDN or external resource referenced | Replace with inline CSS |
| 没用 templates/ 骨架、从零写 HTML | 停止；复制 templates/ 骨架 |
| 生成时向用户询问"白天还是黑夜" | 停止；应直接使用检测结果 |
| 站点产物写进 skill 目录并入库（`op-html/sites/` 被 git 跟踪） | STOP：`sites/` 是 evolved 挂载点，不入 git |
| **对 Markdown 产物执行浏览器打开** | **STOP：md 产物禁止 `start msedge`；仅 HTML 产物允许** |

---

## Common Mistakes

- **用户未明确要求 HTML 却生成 HTML。** 默认载体是 Markdown。
- **从零写 HTML 而不复用骨架。** 每次都重写 CSS 既浪费 token 又容易配色漂移。
- **黑暗模板不同步更新。** 修改白天模板后必须同步修改对应的 -dark 模板。
- **生成 Markdown 后调 `start msedge` 打开浏览器。** 仅 HTML 产物允许打开浏览器；md 产物跳过（原因：把「仅 HTML 模式」的限定词当成了通用步骤）。

---

## Version

| Field | Value |
|-------|-------|
| Skill | op-html |
| Version | 4.2.0 |
| Updated | 2026-09-14 |
| Key change | v4.2.0: 明确「Markdown 产物禁止打开浏览器」（仅 HTML 产物可 `start msedge`）；v4.1.0: 运行时资产规则（`sites/` 为 evolved 挂载点，不入 git、不随包分发） |
| References | `templates/`（骨架，含 `-dark` 变体）· `templates/README.md`（骨架说明）· `scripts/theme-detect.sh`（主题探测）· `config/theme-prefs.conf`（主题偏好）· `sites-archive-plan.md`（站点归档计划） |
