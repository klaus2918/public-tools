# op-html sites/ 清理清单（dry-run 记录）— 2R3 P2-C 卫生治理

- 日期：2026-08-14
- 执行边界：op-html/sites/（junction 至 `.basic/evolved/op-html/sites/`，git 跟踪 evolved 路径）
- 原则：**移归档区不直接删除；先 dry-run 清单，判定可靠才移动，未判定一律保留**

## 判定规则（与 SKILL.md「sites 生命周期」一致）

1. 归档依据 = 本仓库 `.op/` 变更记录中 `change.yaml phase=archive`（当前仅 3 个：
   `autoplan-confirm-optimize`（2026-07-07）、`op-design-extract-optimize`（2026-08-01）、
   `zcode-op-integrate`（2026-08-04），另见 `.op/index.json archived`）。
2. 页面归属判定三要素，满足其一即可判为「已归档」：
   - 页面目录名 = 归档变更名（精确匹配）；
   - 页面为该归档变更的方案迭代页（同标题 + 同变更目标 + 生成时间在变更窗口内）；
   - 页面路径被归档变更的 `archive-summary.md` 明确引用为产物。
3. 无法判定（无对应归档变更、仅提案/设计草稿、状态快照页、疑似已执行但无归档记录）→ **保留不动，标注「未判定」**。

## 一、已归档（判定可靠，已移入 sites/_archive/）

| # | 页面路径（相对 sites/） | 判定依据 |
|---|------------------------|----------|
| 1 | `op-000/op-design-extract-optimize/` | 精确匹配归档变更 `op-design-extract-optimize`（change.yaml phase=archive，archived_at 2026-08-01，index.json 已入 archived） |
| 2 | `op-000/op-design-extract-optimize-v2/` | 同一归档变更的迭代 v2：标题「需求确认：op-design-extract 体系化优化（v2）」，subtitle 目标项目 001-op-skill、生成时间 2026-07-07 |
| 3 | `op-000/op-design-extract-optimize-v3/` | 同一归档变更的迭代 v3（最终确认版）：标题「op-design-extract 体系化优化（v3）」，生成时间 2026-07-07 |
| 4 | `jcode/cch-gateway/` | 被归档变更 `op-design-extract-optimize/archive-summary.md` 08-01 补充第 7 条明确引用：「jcode 复盘页跟进（`.basic/evolved/op-html/sites/jcode/cch-gateway/index.html`）」 |

移动方式：`sites/<project>/<page>/` → `sites/_archive/<project>/<page>/`，保留相对结构便于还原；不删除。

## 二、未判定（保留不动，共 34 个页面）

### op-000/（18 个）
| 页面 | 说明 |
|------|------|
| `op-000/dark-mode-eval/` | op-html 黑夜模式评估，疑似已落地（templates 已有 -dark 版）但无归档变更记录 |
| `op-000/dark-template-proposal/` | 黑夜模板方案评估，同上 |
| `op-000/isolated-skills-review/` | 孤立 skill 评估（op-docgen/op-demo-k8s），无归档记录 |
| `op-000/md-render-eval/` | Markdown 渲染评估，无归档记录 |
| `op-000/op-001-autoplan-eval/` | op-001-autoplan 评估（评估时间 2026-07-08，晚于 autoplan-confirm-optimize 归档日 07-07），归属后续轮次，无归档记录 |
| `op-000/op-001-autoplan-optimize/` | op-001-autoplan 优化确认（生成 2026-07-08，同上） |
| `op-000/op-html-autoplan-render-fix/` | op-html + autoplan 渲染断层分析，无归档记录 |
| `op-000/op-html-code-optimize/` | op-html 代码展示优化，疑似已落地，无归档记录 |
| `op-000/op-skills-status/` | op 系列 skill 现状快照，无归档记录 |
| `op-000/op-skills-status-v2/` | 现状总览 v2 快照，无归档记录 |
| `op-000/op-worktree-optimize/` | 对应 `.op/changes/op-worktree-optimize`（仅 proposal，无 change.yaml，未归档） |
| `op-000/op-worktree-optimize-v1/` | 同上，迭代 v1 |
| `op-000/self-check-report/` | 体系自检报告，无归档记录 |
| `op-000/theme-ask-bug/` | 主题询问 bug 分析，无归档记录 |
| `op-000/theme-switch-design/` | 全局 theme-prefs.conf 方案，疑似已落地（config/theme-prefs.conf 存在），无归档记录 |
| `op-000/demo-k8s-auth-fix/` | op-demo-k8s 认证修复，疑似已落地（skill 存在），无归档记录 |
| `op-000/demo-k8s-worktree-optimize/` | op-demo-k8s 优化 v2，无归档记录 |
| `op-000/demo-workflow-integration/` | demo 设计规范整合方案 v2，无归档记录 |

### op-skills/（12 个）
| 页面 | 说明 |
|------|------|
| `op-skills/asset-management-design/` | 资产隔离管理设计确认页，对应 d086fcb 已落地但无归档变更记录 |
| `op-skills/asset-symlink-design/` | 符号链接方案执行页，同上 |
| `op-skills/op-browser-v2-bridge-chinese-encoding/` | op-browser v2.1 Bridge 中文编码，无归档记录 |
| `op-skills/op-browser-v2-optimize/` | op-browser v2 优化建议，无归档记录 |
| `op-skills/op-design-extract-v3-upgrade/` | op-design-extract v3.0 升级方案，非 `op-design-extract-optimize`（体系化优化）内容，无归档记录 |
| `op-skills/op-design-extract-v4-learn-generate/` | v4.0 学习与转化能力方案，无归档记录 |
| `op-skills/op-design-extract-v4-system-optimization/` | v4.0 系统优化方案，无归档记录 |
| `op-skills/op-done-step2-optimize/` | op-done Step2 优化确认，无归档记录 |
| `op-skills/op-done-step2-optimize-v2/` | 同上迭代 v2 |
| `op-skills/op-ecosystem-optimize-v1/` | 体系优化评估确认页（07-29），对应后续轮次，无归档记录 |
| `op-skills/op-ecosystem-overview/` | 体系全景快照（07-06），无归档记录 |
| `op-skills/op-ecosystem-status-2026-07-22/` | 体系状态快照（07-22），无归档记录 |

### 其他项目（4 个）
| 页面 | 说明 |
|------|------|
| `001-op-skill/op-html-theme-optimize/` | op-html 主题区间切换优化需求预览，疑似已落地（SKILL.md 已含主题控制），无归档记录 |
| `autoplan-mcp/overview/` | AutoPlan MCP 功能总览，参照页非变更确认页 |
| `op-browser/2026-07-29-optimize/` | op-browser 引擎缺陷修复方案，对应 `.op/changes/op-browser-bridge-optimize`（仅 proposal，未归档） |
| `op-worktree/optimize-suggestions/` | op-worktree 优化建议确认页，对应 `.op/changes/op-worktree-optimize`（仅 proposal，未归档） |

> 合计 18 + 12 + 4 = 34 个未判定，与总页面数 38 − 4（已归档）一致。

## 三、后续建议

- 未判定页面待对应变更在 op 项目仓库完成归档后，按 SKILL.md「sites 生命周期」规则补移入 `_archive/`。
- 机器防线建议见 op-html/SKILL.md「sites 生命周期」与 op-browser/SKILL.md「validate 防线建议」，由主会话在 op-000 validate 落地。

## 自检

- 无 U+FFFD、UTF-8 无 BOM。
- 移动均记录于本清单第一节，未删除任何文件。
