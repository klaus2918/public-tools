#!/bin/bash
set -euo pipefail
# op-html/scripts/theme-detect.sh
# 主题检测脚本 — 每次 op-html 生成时调用
# 读取 theme-prefs.conf + 当前时间，输出推荐的模板
# 用法: bash op-html/scripts/theme-detect.sh
# 输出格式:
#   TEMPLATE=light|dark        # 推荐模板
#   MESSAGE=...                # 时段提示
#
# 时间规则：day_start ≤ 当前时间 < night_start 为白天，其余为黑夜

CONFIG="$(cd "$(dirname "$0")"/.. && pwd)/config/theme-prefs.conf"

# 加载配置（若存在）
[ -f "$CONFIG" ] && source "$CONFIG"

# 默认值
: "${day_start:=08:00}"
: "${night_start:=19:00}"

# --- 时间判断 ---
HOUR=$(date +%H)
MIN=$(date +%M)
NOW_MIN=$((10#$HOUR * 60 + 10#$MIN))

DAY_HH=${day_start%%:*}
DAY_MM=${day_start##*:}
DAY_MIN=$((10#$DAY_HH * 60 + 10#$DAY_MM))

NIGHT_HH=${night_start%%:*}
NIGHT_MM=${night_start##*:}
NIGHT_MIN=$((10#$NIGHT_HH * 60 + 10#$NIGHT_MM))

if [ "$NOW_MIN" -ge "$DAY_MIN" ] && [ "$NOW_MIN" -lt "$NIGHT_MIN" ]; then
  TEMPLATE=light
  MESSAGE="当前 ${HOUR}:${MIN} → 白天时段（${day_start}~${night_start}）"
else
  TEMPLATE=dark
  MESSAGE="当前 ${HOUR}:${MIN} → 黑夜时段（${night_start}~${day_start}）"
fi

# --- 输出 ---
echo TEMPLATE=$TEMPLATE
echo MESSAGE=$MESSAGE
