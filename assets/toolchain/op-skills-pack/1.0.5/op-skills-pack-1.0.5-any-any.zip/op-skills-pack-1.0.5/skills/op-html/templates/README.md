# op-html/templates · HTML 骨架集合（仅 HTML 模式使用）

> **本目录骨架仅在调用方明确要求 HTML 格式时使用。** 默认输出为 Markdown 确认文件，不需要这些模板。

> ⚠️ **本目录是 agent 复制填充的骨架，不是最终 HTML 产物。**
>
> 任何 `op-html/sites/<project>/<change>/` 下的 `index.html` 都不是从这里来的——产物目录由调用方在确认页生成时新建。

## 1. 一句话用法

调用 `op-html` 生成确认页时：

1. **先执行** `bash op-html/scripts/theme-detect.sh` 获取 TEMPLATE（light/dark）
2. 打开 `templates/` 下最贴近当前场景+主题的骨架（如 `_plan-confirm.html` 或 `_plan-confirm-dark.html`）
3. **完整复制**骨架到产物路径 `op-html/sites/<project>/<change>/<file>.html`
4. 仅替换 `<!-- TODO: ... -->` 标记处的占位数据
5. `start msedge <path>` 自动打开（op-html 负责统一打开，不自已再跑）

## 2. 骨架列表

### 按场景

| 骨架 | 适用场景 | 典型产物结构 |
|---|---|---|
| `_plan-confirm.html`（白天版）<br>`_plan-confirm-dark.html`（黑夜版） | feature/complex 方案确认（双 Tab + 6 条左右建议） | `index.html` + `system/index.html` + `business/index.html` |
| `_decision-list.html`（白天版）<br>`_decision-list-dark.html`（黑夜版） | 单页面建议列表（1-6 条建议、无 system 层） | `index.html` 单文件 |
| `_archive.html`（白天版）<br>`_archive-dark.html`（黑夜版） | 归档门户（变更全景统计 + 卡片网格） | `index.html` 单文件 |
| `_confirm-index.html`（白天版）<br>`_confirm-index-dark.html`（黑夜版） | 多 Section 首页（设计点 > 3） | `index.html`（目录页，含进度条 + Section 导航列表 + 状态徽章） |
| `_section-detail.html`（白天版）<br>`_section-detail-dark.html`（黑夜版） | 多 Section 详情页（设计点 > 3） | `sections/NN-xxx.html`（含顶栏 + 内容区 + 确认操作区 + 翻页导航） |
| `_change-summary.html`（白天版）<br>`_change-summary-dark.html`（黑夜版） | 全部确认后的汇总页（设计点 > 3） | `summary.html`（含确认结果表 + 最终改动清单） |
| `business/_index.html`（白天版）<br>`business/_index-dark.html`（黑夜版） | plan-confirm 的 business 层详情页 | `business/index.html` |

### 按主题

| 主题 | 对应骨架 |
|------|---------|
| 白天（`day_start`~`night_start` 时段内） | 不加 `-dark` 后缀的平级骨架 |
| 黑夜（`night_start`~`day_start` 时段内） | 加 `-dark` 后缀的骨架 |

> **黑夜模板约定：** `-dark` 后缀模板与对应白天模板结构完全一致（相同的 TODO 替换位置），仅 CSS 颜色方案不同。修改白天模板时须同步更新对应的 `-dark` 版本。

## 3. 产物结构选择指南

**先选结构，再选骨架。** 根据设计点数量决定使用单页还是多 Section：

| 条件 | 推荐结构 | 适用骨架组 | 产物路径 |
|------|---------|-----------|---------|
| 设计点 ≤ 3 或建议 1-6 条 | 单页 | `_plan-confirm` / `_decision-list` / `_archive` | `index.html` 单文件（或 `+ system/ + business/`） |
| 设计点 > 3 | 多 Section | `_confirm-index` + `_section-detail` × N + `_change-summary` | `index.html` + `sections/NN-xxx.html` + `summary.html` |

- **设计点**：需要用户逐项确认的设计决策点。数量 > 3 时强制启用多 Section 结构，避免单页内容臃肿。
- **Section 拆分**：每 Section 包含 1-3 个设计点，按业务逻辑分组（如"数据库设计"为一个 Section）。
- **翻页导航**：多 Section 详情页底部含 ‹ 上一页 \| 📋 目录 \| 下一页 ›，在填充阶段根据 `sections/` 目录实际文件计算链接。
- **文件命名**：Section 文件名使用 `NN-英文关键词.html`（如 `01-data-model.html`），确保目录按文件名自然排序。

## 4. 设计原则

- **零修改原则**：模板里所有 `<style>`、配色变量、CSS 类都是最终版，agent 不应改写
- **零 CDN 原则**：所有 CSS 内联；无 `<script>`、无外链字体
- **占位标记**：模板中需要替换的位置一律用 `<!-- TODO: <说明> -->` 标注
- **大小收敛**：每个骨架 ≤ 150 行；超 200 行要拆或回退 GREEN

## 5. 维护约定

- 升级模板时同步更新本 README 的"骨架列表"和 op-html/SKILL.md 的"Quick Reference"
- 新增骨架前先确认是否真有调用场景（避免模板膨胀）
- 模板文件命名 `_xxx.html`（下划线开头）以和最终产物 `xxx.html` 区分
- 每创建/修改一个白天版模板，必须同步创建/修改对应的 `-dark` 黑夜版

## 6. 与 op-html/SKILL.md 的关系

- SKILL.md 定义契约（JSON shape、配色原则、技术约束、diagram 约束）
- templates/ 提供骨架（可直接复制的 CSS + HTML 结构）
- 两者版本号同步：升级 SKILL.md 时若影响模板，需同步更新 templates/
