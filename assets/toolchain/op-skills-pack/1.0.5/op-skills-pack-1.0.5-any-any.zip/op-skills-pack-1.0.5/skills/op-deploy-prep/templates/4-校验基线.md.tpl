# {模块名} V{版本} 校验基线（部署后核对表）

> 期望值必须来自源环境实测或按产物实际条数自动生成，**禁止手填**（R9）。
> 生成方式：`gen_idempotency_asserts.py`（按产物实际条数生成断言）或开发库实测核对。

| # | 检查项 | 期望值 | 来源（实测/生成） | 核对方法 |
|---|--------|--------|-------------------|----------|
| 1 | {业务表 1} 列数 | {N} | 开发库实测 | ALL_TAB_COLUMNS COUNT |
| 2 | {业务表 1} 外键 | 0 | 开发库实测 | ALL_CONSTRAINTS |
| 3 | {配置对象 1}（如字典分类） | {N} | 产物实际条数 | COUNT WHERE ... |
| 4 | {配置对象 2}（如菜单） | {N} | 产物实际条数 | COUNT WHERE ... |
| 5 | {配置对象 3}（如按钮） | {N} | 产物实际条数 | COUNT WHERE ... |
| 6 | {预置数据表} | {N} | 产物实际条数 | COUNT |

## 生成与核对方式（R10 核对程序化）

- 幂等断言自动生成：`gen_idempotency_asserts.py --dir={kit_dir}`（杜绝手填期望值）
- SQL vs 源库逐项核对：`check_sql_vs_db.py`（missing/extra/mismatch 三类差异）
- 材料包 vs 开发库一键核对：`check_kit_vs_db.py`（清单驱动，emit-sql → MCP 执行 → 差异清单）

> 规则通用（R9/R10），脚本参考实现路径见 `reuse-sources.yaml` checkers 表；非 OA 域可复刻清单驱动引擎。
