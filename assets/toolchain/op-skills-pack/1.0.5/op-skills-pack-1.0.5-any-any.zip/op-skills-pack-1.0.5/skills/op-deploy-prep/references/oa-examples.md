# OA 领域实现参考（oa-examples）

> 本文件是 op-deploy-prep 通用规则在 OA 域的**样例指针**：只登记引用路径，不复制内容（统一仓库唯一事实源）。
> 通用规则（R1-R14）见 `generic-rules.md`；本文件列出 OA 平台特有的「配置样例」，供按领域套用通用机制时参考。
> 适用判定（通用化边界）：凡依赖平台表名/列名（PT_*/SYS_*/BPM_*）或 OA 业务闭环动机的规则，留在 OA 域；op-deploy-prep 只承载机制/引擎。

## 资产位置

| 资产 | 路径 | 内容 |
|------|------|------|
| oa-deploy-kit 设计资产 | `op-design-extract/shared/oa/database/deploy-kit-config.{md,json}` | OA 部署材料包领域规则主资产 |
| op-oa-workflow 子层（环境内部材料，不随发布包分发） | `op-design-extract/skills/op-oa-workflow/SKILL.md` | 子层 skill：输出产物/模板/工具脚本入口 |
| 子层部署规范视图（同上，环境内部） | `op-design-extract/skills/op-oa-workflow/references/deploy-kit-config.md` | 上述资产的 skill 消费视图 |
| 业务自洽检查（同上，环境内部） | `op-design-extract/skills/op-oa-workflow/references/self-consistency-check.md` | 跨产物一致性五步检查（BPMN 条件↔表单↔字典、状态↔前端 dataCode） |
| 查询入口 | `/op-design-extract query-tags --type=database --domain=oa` | L0 元数据查询 → `disclose --level=2` 读全文 |

## OA 平台特有约定（作为「配置样例」参考，不进通用规则）

| 类别 | 约定 | 通用机制对应 |
|------|------|--------------|
| 平台配置表 | PT_MENU / PT_OPERATION / PT_CATEGORY(ITEM) / SYS_TABLESREMARK / SYS_COLSREMARK / SYS_DEF_TAILORFORM(COL) / SYS_DEF_ACTIVITYFORM(REL) / BPM_FLOW_MODEL_VERSION | R8 幂等三段式、R10 程序化核对（引擎通用，表清单是配置样例） |
| ID 体系 | 三类 19 位 ID（表单/注释/菜单/按钮系 0xxx/1xxx/2xxx 千分区；字典系 15 位日期+4 位序号；预置数据系开发库基线固定值） | R6 环境敏感值标注（ID 为环境实测值须标注替换） |
| 菜单约定 | MENU_CODE `oa-{业务}` 起；SERIAL_NUMBER 必须非空；OPERATION_CODE = MENU_CODE | R6 环境值标注；R9 校验基线期望实测 |
| 字典纪律 | 只建代码实测引用（@Dict/useDict/CATEGORYCONSTNAME 搜索）；设计规划 ≠ 实际引用（unit 计量字典零引用反例） | R9 期望值实测（禁手填） |
| 角色授权 | PT_ROLE_MENU / PT_ROLE_OPERATION 界面配置不产 SQL；BPMN 候选人角色 ID 留空导入后配置 | R4 场景分档（B 档手动维护） |
| 幂等写法 | 配置表 MERGE INTO WHEN NOT MATCHED；数据预置 INSERT WHERE NOT EXISTS；回滚反向 DELETE | R8 幂等三段式、R13 回滚反向覆盖 |

## 已知反例库（OA 域实证，供通用规则校准）

| 反例 | 现象 | 对应通用规则 |
|------|------|--------------|
| 菜单 SERIAL_NUMBER 为空 | Seed 过滤空值 → 前端菜单不显示（2026-07-06 办公用品） | R9 校验基线（期望值实测并核对） |
| unit 计量字典零引用 | 设计规划但代码未引用，字段注释遗留引用 → 不建库留档 | R9 期望值实测（禁手填） |
| LFDJSTATUS 字典凌晨新建 | 提取后隔夜交付，源库新增字典未复检 → 材料包 07 缺口 | R2 基准漂移复查 |
| 回滚漏删菜单 / 条数未同步 | DELETE 集合缺项；注释 342→357、39→43 未更新 | R13 回滚反向覆盖 |
| REQUIRED 误写 / 生成器误删 | 人工核对未查出，脚本核对第二轮才暴露 | R10 核对程序化 |

## 通用脚本参考实现（在 OA 侧，规则通用）

生成器与校验脚本的实际路径见 `reuse-sources.yaml`（generators / checkers 登记）。通用域套用方式：
1. `generic: true` 的脚本（gen_ddl_sql / gen_dict_sql / gen_check_sql / gen_idempotency_asserts / check_files）直接喂本域清单使用。
2. `generic: false` 的脚本（gen_kit_skeleton / check_rollback_coverage / check_sql_vs_db / check_kit_vs_db）内置 OA 清单/产物映射，通用域需按自身产物配置化清单后套用引擎（v1.2.0 计划提升，见 SKILL.md §8）。
