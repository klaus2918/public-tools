-- =====================================================================
-- {模块名} · 数据库变更
-- 适用系统：{系统名}  数据库：{数据库类型（达梦 DM8 Oracle 兼容模式 / 其他）}
-- 数据基准：{源环境}（{schema}，{YYYY-MM-DD} 提取）   ← R1 必填：源环境 + schema + 提取日期
-- 提取到交付间隔超过 1 天必须重跑核对（R2 基准漂移复查）
-- 生成时间：{YYYY-MM-DD}   来源：`1 database-change.md` + `2 setting-change.md`
-- 已核对：脚本列名/列数与开发库表结构完全一致（{核对日期}）
-- 注意：脚本不带模式名，生产执行时使用当前连接默认模式（各环境模式名有差异）   ← R5
-- 建议：生产执行前先运行下方"执行前检查"，确认目标环境是否已存在对象
-- 场景档位：{A 生产全新部署 / B 存量修复（注明触发场景）/ C 开发库专用}   ← R4 必填
-- =====================================================================

-- ---------------------------------------------------------------------
-- 0. 执行前检查（只读，先运行确认目标环境现状；返回 0 行 = 可执行对应节）
-- ---------------------------------------------------------------------
-- 0.1 检查业务表是否已存在
SELECT TABLE_NAME FROM ALL_TABLES WHERE TABLE_NAME IN ('{TABLE_1}','{TABLE_2}');

-- 0.2 检查字典是否已存在
SELECT ID, CONST_NAME FROM {字典表} WHERE CONST_NAME IN ('{DICT_1}','{DICT_2}') AND DEL_STATUS = 0;

-- 0.3 检查菜单是否已存在
SELECT ID, MENU_CODE FROM {菜单表} WHERE MENU_CODE IN ('{MENU_1}','{MENU_2}');

-- 0.4 检查按钮权限是否已存在
SELECT ID, OPERATION_CODE FROM {按钮表} WHERE OPERATION_CODE IN ('{OP_1}','{OP_2}');

-- 说明：若检查已存在，请勿重复执行对应 INSERT（主键冲突报错），比对差异即可。

-- =====================================================================
-- 1. 业务表 DDL（若第 0.1 步检查已存在，跳过本节）
-- =====================================================================
CREATE TABLE {TABLE_1}
(
"ID" NVARCHAR2(50) NOT NULL,
"DEL_STATUS" INTEGER DEFAULT 0 NOT NULL,
"CREATE_UID" VARCHAR2(50),
"CREATE_TIME" TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
"UPDATE_UID" VARCHAR2(50),
"UPDATE_TIME" TIMESTAMP(6) DEFAULT CURRENT_TIMESTAMP,
-- ... 业务字段 ...
NOT CLUSTER PRIMARY KEY("ID")) STORAGE(ON "MAIN", CLUSTERBTR) ;

COMMENT ON TABLE {TABLE_1} IS '{表注释}';
COMMENT ON COLUMN {TABLE_1}."{COL}" IS '{列注释}';
-- ... 全部注释 ...

-- 索引（如需）
CREATE OR REPLACE INDEX IDX_{TABLE_1}_{SUFFIX} ON {TABLE_1}("{COL1}" ASC,"{COL2}" ASC) STORAGE(ON "MAIN", CLUSTERBTR) ;

-- =====================================================================
-- 2. 初始化数据（字典/菜单/权限 INSERT；若检查已存在，跳过对应节）
--    幂等写法：按业务唯一键判断存在再插入，可重复执行   ← R8 幂等三段式
-- =====================================================================
-- 2.1 字典分类（幂等键：{分类表唯一键}，如 CONST_NAME）
INSERT INTO {字典表}("ID", "CONST_NAME", "NAME", "DEL_STATUS", "SORT_INDEX", "CREATE_UID", "UPDATE_UID", "CREATE_TIME", "UPDATE_TIME")
SELECT '{ID}', '{DICT}', '{名称}', 0, 50, '{UID}', '{UID}', SYSTIMESTAMP, SYSTIMESTAMP
WHERE NOT EXISTS (SELECT 1 FROM {字典表} WHERE CONST_NAME = '{DICT}');

-- 2.2 字典项（幂等键：{分组列}+{值码列}，如 CATEGORY_ID + ITEM_CODE）
INSERT INTO {字典项表}("ID", "CATEGORY_ID", "ITEM_CODE", "NAME", "SORT_INDEX", "DEL_STATUS", "CREATE_UID", "UPDATE_UID", "CREATE_TIME", "UPDATE_TIME", "PARENT_ID")
SELECT '{ID}', '{CAT_ID}', '{CODE}', '{名称}', 1, 0, '{UID}', '{UID}', SYSTIMESTAMP, SYSTIMESTAMP, NULL
WHERE NOT EXISTS (SELECT 1 FROM {字典项表} WHERE CATEGORY_ID = '{CAT_ID}' AND ITEM_CODE = '{CODE}');

-- 2.3 菜单（注意 SERIAL_NUMBER 必须非空；MENU_FATHER_ID 为环境值需替换）   ← R6 环境敏感值标注
MERGE INTO {菜单表} T
USING (SELECT '{ID}' AS ID FROM DUAL) S
ON (T.ID = S.ID)
WHEN NOT MATCHED THEN
INSERT (ID, MENU_CODE, MENU_NAME, MENU_TYPE, MENU_FATHER_ID, MENU_MAPPING, MENU_ICON, SORT_INDEX, SERIAL_NUMBER, DEL_STATUS)
VALUES ('{ID}', '{MENU_CODE}', '{菜单名}', NULL, '{FATHER_ID-环境值须替换}', '{MAPPING}', NULL, {SORT}, '{SERIAL_NUMBER}', 0);

-- 2.4 按钮权限（OPERATION_CODE 与菜单同值）
MERGE INTO {按钮表} T
USING (SELECT '{ID}' AS ID FROM DUAL) S
ON (T.ID = S.ID)
WHEN NOT MATCHED THEN
INSERT (ID, OPERATION_CODE, OPERATION_NAME, OPERATION_DESC, MENU_ID, DEL_STATUS, SORT_INDEX)
VALUES ('{ID}', '{OP_CODE}', '查看', '', '{MENU_ID}', 0, 0);

-- =====================================================================
-- 3. 执行后验证（只读，期望值见注释；期望值必须实测/脚本生成，禁止手填）   ← R9
-- =====================================================================
SELECT '表' AS OBJ, COUNT(*) AS CNT FROM ALL_TABLES WHERE TABLE_NAME IN ('{TABLE_1}','{TABLE_2}')
UNION ALL SELECT '字典分类数', COUNT(*) FROM {字典表} WHERE CONST_NAME IN ('{DICT_1}','{DICT_2}')
UNION ALL SELECT '菜单数', COUNT(*) FROM {菜单表} WHERE MENU_CODE IN ('{MENU_1}','{MENU_2}')
UNION ALL SELECT '按钮权限数', COUNT(*) FROM {按钮表} WHERE OPERATION_CODE IN ('{OP_1}','{OP_2}');
-- 期望：表 {N} 张、字典分类 {N}、菜单 {N}、按钮权限 {N}

-- =====================================================================
-- 4. 反向回滚（有损，慎用；按依赖反向删除，DELETE 集合必须 ⊇ 本文件插入键集合）   ← R13
-- =====================================================================
-- 4.1 按钮（按 ID）
DELETE FROM {按钮表} WHERE ID IN ('{ID_1}','{ID_2}');
-- 4.2 菜单（按 ID）
DELETE FROM {菜单表} WHERE ID IN ('{ID_1}','{ID_2}');
-- 4.3 字典项（按分组+值码）
DELETE FROM {字典项表} WHERE CATEGORY_ID = '{CAT_ID}' AND ITEM_CODE IN ('{CODE_1}','{CODE_2}');
-- 4.4 字典分类（按 ID）
DELETE FROM {字典表} WHERE ID IN ('{ID_1}','{ID_2}');
