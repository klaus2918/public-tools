# references 索引

本目录不复制资产内容（统一仓库唯一事实源），仅记录引用路径。

## 通用规则与复用来源（v1.1.0 新增）

| 文件 | 用途 |
|------|------|
| `generic-rules.md` | 通用产物提取规则 R1-R14 详表（组 A 源头可信 / 组 B 产物形态 / 组 C SQL 内容 / 组 D 校验与对账 / 组 E 流程安全），与 SKILL.md §7 红线配合 |
| `reuse-sources.yaml` | 可复用来源登记：设计资产查询入口 + 生成器清单（generic 标记 + schema 契约引用）+ 历史材料包索引（只登记引用路径） |
| `input-schemas.json` | 生成器输入 JSON 契约（列定义 / 字典清单 / MCP 实测 / 检查项 / 材料包元数据与目录），reuse-sources.yaml generators 的 schema 引用目标（2R3 A-05） |
| `kits/` | 历史材料包样例实体（demo-visitor-v9 / demo-office-supply-v1），复用链第③档可消费（2R3 A-04） |
| `oa-examples.md` | OA 领域实现参考（配置样例 / 反例库 / 通用脚本参考实现位置） |

## 关联资产

| 资产 | 路径 | 用途 |
|------|------|------|
| oa-deploy-kit 设计资产 | `op-design-extract/shared/oa/database/deploy-kit-config.{md,json}` | OA 工作流部署材料包领域规则：三档分类（A 生产全新/B 存量修复/C 开发库）、PT_MENU/PT_OPERATION/字典幂等写法、产物提取 SQL、校验基线、已知反例 |
| op-oa-workflow 内置子层（环境内部材料，不随发布包分发） | `op-design-extract/skills/op-oa-workflow/references/deploy-kit-config.md` | 上述资产的 skill 消费视图 |
| op-oa-workflow 生成器/校验脚本（环境内部材料，不随发布包分发） | `op-design-extract/skills/op-oa-workflow/scripts/` | 通用生成器（gen_ddl_sql/gen_dict_sql/gen_check_sql/gen_idempotency_asserts）与校验脚本（check_files/check_rollback_coverage/check_sql_vs_db/check_kit_vs_db），登记于 reuse-sources.yaml |
| op-docgen | `op-docgen/SKILL.md` | 部署说明/运维手册需 DOCX 交付时的可选文档化骨架 |

## 引用方式

- 通用三分类（形态 1 SQL / 2 配置 / 3 手动）：本 skill 的 `templates/` 模板
- 通用产物提取规则（R1-R14）：`generic-rules.md`
- 产物复用（先查再写）：`reuse-sources.yaml` + SKILL.md §9
- OA 工作流模块（表单/BPMN/流程/菜单/按钮/字典）：读取 oa-deploy-kit 资产（两文件相同内容，取 md 人类可读版）
- 查询入口：`/op-design-extract query-tags --type=database --domain=oa`

## 实例（首例验证）

领导日程模块已按本 skill 模板产出完整材料（开发库核对 + 三段式 SQL + 环境差异 + 手动授权）：
- 参考实例文件：`<用户下载目录>\demo\领导日程更新配置\`（生产执行-1-数据库变更.sql、部署指导手册.md）

来访登记 V9 部署材料包（14 文件 + zip + MD5 对账 + 回滚覆盖 + 校验基线）为通用规则 R1-R14 的完整实例，登记于 `reuse-sources.yaml` kits 表，样例实体位于 `kits/demo-visitor-v9/`。
