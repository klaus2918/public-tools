#!/usr/bin/env python
"""op-browser 并发契约演练脚本（v2.5 2R1/2R2 验收辅助）

无浏览器依赖的跨进程演练，验证四类并发基础能力（对应 SKILL.md 并发契约）：
  C1 原子写竞态    —— 无锁并发原子写不产生半写/损坏（_atomic_write_text）
  C2 inc_run_count —— 跨进程锁内读-加-写不丢更新（N 进程 × M 次 = N*M）
  C3 结果隔离      —— 多 run_id 产物互不覆盖（runs/<run_id>/result.json）
  C4 日志互斥      —— 跨进程行级互斥，行完整不交错（write_log 双写路径）

用法：
  python concurrency_check.py                # 默认 6 进程 × 40 次
  python concurrency_check.py --proc 8 --iter 50
  python concurrency_check.py --only 1,3     # 只跑指定检查
  python concurrency_check.py --keep         # 保留临时目录（默认自动清理）

退出码：0 = 全部通过；1 = 存在失败；2 = 参数/环境错误。
"""
import argparse
import json
import multiprocessing as mp
import os
import shutil
import sys
import tempfile
from pathlib import Path

_HERE = Path(__file__).resolve().parent
# 包位置：op-browser/src/op_browser（src 布局）；无则取脚本同级
for _cand in (_HERE.parent / "src", _HERE.parent):
    if (_cand / "op_browser").is_dir():
        sys.path.insert(0, str(_cand))
        break
else:
    sys.stderr.write("找不到 op_browser 包（期望 ../src/op_browser）\n")
    sys.exit(2)


# ── worker（子进程入口，顶层函数保证 Windows spawn 可 pickle） ──

def _worker_c1(pidx: int, iters: int, q):
    """C1：无锁并发原子写同一文件，内容合法 JSON 即可（不要求最终值）。"""
    from op_browser import task_store as ts
    path = ts.task_dir("conc-atomic") / "task.json"
    try:
        for i in range(iters):
            ts._atomic_write_text(
                path,
                json.dumps({"pid": pidx, "seq": i, "payload": "x" * 200}))
        q.put({"ok": True, "pidx": pidx})
    except Exception as e:  # noqa: BLE001
        q.put({"ok": False, "pidx": pidx, "err": repr(e)})


def _worker_c2(pidx: int, iters: int, q):
    """C2：inc_run_count 跨进程增量（锁内读-加-写）。"""
    from op_browser import task_store as ts
    try:
        for _ in range(iters):
            ts.inc_run_count("conc-count")
        q.put({"ok": True, "pidx": pidx})
    except Exception as e:  # noqa: BLE001
        q.put({"ok": False, "pidx": pidx, "err": repr(e)})


def _worker_c3(pidx: int, runs_per_proc: int, q):
    """C3：各进程写各自的 run_id 结果，互不覆盖。"""
    from op_browser import task_store as ts
    try:
        for j in range(runs_per_proc):
            rid = f"run-{pidx:02d}-{j:02d}"
            ts.write_run_result(rid, {"pid": pidx, "j": j})
        q.put({"ok": True, "pidx": pidx})
    except Exception as e:  # noqa: BLE001
        q.put({"ok": False, "pidx": pidx, "err": repr(e)})


def _worker_c4(pidx: int, lines: int, q):
    """C4：write_log 双写路径（run_id 非空），行内容带哨兵。"""
    from op_browser import task_store as ts
    try:
        for i in range(lines):
            ts.write_log("conc-log", "run",
                         f"CK|{pidx}|{i}|END", run_id="run-log-1")
        q.put({"ok": True, "pidx": pidx})
    except Exception as e:  # noqa: BLE001
        q.put({"ok": False, "pidx": pidx, "err": repr(e)})


# ── 检查实现（父进程侧） ──

def _run_procs(worker, nproc: int, args_of, timeout: int = 180):
    """启动 nproc 个进程，收集结果。返回 (ok, results)。"""
    ctx = mp.get_context("spawn")
    q = ctx.Queue()
    procs = [ctx.Process(target=worker, args=(i, *args_of(i)), kwargs={"q": q})
             for i in range(nproc)]
    for p in procs:
        p.start()
    results = []
    for p in procs:
        p.join(timeout)
        if p.is_alive():
            p.terminate()
            results.append({"ok": False, "pidx": -1, "err": "超时"})
    for _ in procs:
        results.append(q.get(timeout=10))
    return all(r["ok"] for r in results), results


def check_c1(ts, nproc, iters):
    """原子写竞态：无锁并发写不产生损坏文件、无 .tmp 残留。"""
    path = ts.task_dir("conc-atomic") / "task.json"
    ok, results = _run_procs(_worker_c1, nproc, lambda i: (iters,))
    if not ok:
        return False, f"子进程失败: {[r for r in results if not r['ok']][:3]}"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:  # noqa: BLE001
        return False, f"最终文件损坏: {e!r}"
    if not (1 <= data["pid"] <= nproc and 0 <= data["seq"] < iters):
        return False, f"内容异常: {data}"
    leftovers = list(path.parent.glob(".task.json.tmp-*"))
    if leftovers:
        return False, f"残留临时文件: {leftovers}"
    return True, f"{nproc} 进程 × {iters} 次并发写, 文件完整"


def check_c2(ts, nproc, iters):
    """inc_run_count：最终计数必须等于 N*M（跨进程不丢更新）。"""
    ok, results = _run_procs(_worker_c2, nproc, lambda i: (iters,))
    if not ok:
        return False, f"子进程失败: {[r for r in results if not r['ok']][:3]}"
    meta = ts.load_task("conc-count")
    expect = nproc * iters
    got = meta.get("run_count")
    if got != expect:
        return False, f"计数丢失: 期望 {expect}, 实际 {got}"
    return True, f"{nproc} 进程 × {iters} 次增量 = {got} ✓"


def check_c3(ts, nproc, runs_per_proc):
    """结果隔离：N×R 个 run_id 各自文件存在且内容为对应进程所写。"""
    ok, results = _run_procs(_worker_c3, nproc, lambda i: (runs_per_proc,))
    if not ok:
        return False, f"子进程失败: {[r for r in results if not r['ok']][:3]}"
    for pidx in range(nproc):
        for j in range(runs_per_proc):
            rid = f"run-{pidx:02d}-{j:02d}"
            data = ts.load_run_result(rid)
            if data.get("pid") != pidx or data.get("j") != j:
                return False, f"{rid} 内容错位: {data}"
    return True, f"{nproc * runs_per_proc} 个 run 产物互不覆盖 ✓"


def check_c4(ts, nproc, lines):
    """日志互斥：行完整（哨兵无截断），总数 = N*K。"""
    ok, results = _run_procs(_worker_c4, nproc, lambda i: (lines,))
    if not ok:
        return False, f"子进程失败: {[r for r in results if not r['ok']][:3]}"
    log = ts.runs_dir("run-log-1", create=False) / "run.log"
    raw = log.read_text(encoding="utf-8")
    rows = [ln for ln in raw.splitlines() if ln]
    expect = nproc * lines
    if len(rows) != expect:
        return False, f"行数: 期望 {expect}, 实际 {len(rows)}"
    bad = [ln for ln in rows
           if not (ln.startswith("[") and "CK|" in ln and ln.endswith("|END"))]
    if bad:
        return False, f"{len(bad)} 行不完整（交错/截断）: {bad[:3]}"
    return True, f"{expect} 行全部完整无交错 ✓"


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--proc", type=int, default=6, help="并发进程数（默认 6）")
    ap.add_argument("--iter", type=int, default=40, help="每进程迭代次数（默认 40）")
    ap.add_argument("--only", default="1,2,3,4", help="只跑指定检查，如 1,3")
    ap.add_argument("--keep", action="store_true", help="保留临时目录")
    args = ap.parse_args()

    if args.proc < 1 or args.iter < 1:
        sys.stderr.write("--proc / --iter 必须 ≥1\n")
        return 2

    # 隔离工作区：TASKS_DIR 必须在 import op_browser 前设置（子进程 spawn 继承）
    workdir = Path(tempfile.mkdtemp(prefix="op_browser_conc_"))
    os.environ["TASKS_DIR"] = str(workdir)
    from op_browser import task_store as ts  # noqa: E402（env 已设）

    only = {int(x) for x in args.only.split(",") if x.strip()}
    checks = {
        1: ("C1 原子写竞态", check_c1, (args.proc, args.iter)),
        2: ("C2 inc_run_count 跨进程计数", check_c2, (args.proc, args.iter)),
        3: ("C3 结果隔离（多 run_id）", check_c3,
            (args.proc, max(3, args.iter // 10))),
        4: ("C4 日志互斥（双写路径）", check_c4,
            (args.proc, max(10, args.iter // 2))),
    }
    failed = []
    print(f"op-browser 并发契约演练  TASKS_DIR={workdir}")
    for num in sorted(checks):
        if num not in only:
            continue
        name, fn, cargs = checks[num]
        try:
            ok, msg = fn(ts, *cargs)
        except Exception as e:  # noqa: BLE001
            ok, msg = False, f"检查异常: {e!r}"
        print(f"  [{num}] {name:<28} {'PASS' if ok else 'FAIL'}  {msg}")
        if not ok:
            failed.append(num)
    print("全部通过 ✓" if not failed else f"失败检查: {failed} ✗")
    if not args.keep:
        shutil.rmtree(workdir, ignore_errors=True)
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
