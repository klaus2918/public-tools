# op-browser 交互经验库 (Experience Library)

> 版本: 1.0.0 | 创建: 2026-09-21 | 适用: op-browser v3.4+

## 定位

经验库是 op-browser 引擎的**元能力层**，提供可复用的页面交互模式（patterns），用于：

1. **快速编排** — 从模式模板生成 `action_detail` 序列，无需从零编写
2. **默认行为** — 引擎按「模拟人工」策略执行，通过点击菜单/按钮导航而非路由直接跳转
3. **知识沉淀** — 积累通用交互经验（表单填写、下拉选择、检索操作等）

## 与引擎的关系

```
flow.json / script.py          ← 固化任务（用户编写或从体验库生成）
  └─ action_detail[]           ← 引擎回放的动作序列
       └─ 体验库模式           ← 提供动作序列模板 + human-like 参数
```

体验库**不侵入**引擎核心，而是：
- 提供模式描述文件（YAML）定义动作序列模板
- 提供 Python 辅助函数（可选）生成标准化 action_detail
- 引擎通过新增的动作类型（`select`/`scroll`/`hover`）直接支持模式所需的基础操作

## 目录结构

```
experience/
├── README.md                    ← 本文件：经验库说明
├── INDEX.md                     ← 模式索引：分类、标签、快速查找
├── patterns/                    ← 模式定义（YAML）
│   ├── form-fill.yaml           ← 表单填写模式
│   ├── dropdown-select.yaml     ← 下拉选择模式
│   ├── search-filter.yaml       ← 检索输入与搜索模式
│   ├── menu-navigate.yaml       ← 菜单导航模式
│   ├── button-action.yaml       ← 按钮操作与确认模式
│   └── table-interact.yaml      ← 表格操作模式
└── generators/                  ← Python 辅助生成器（可选）
    ├── __init__.py
    ├── form_fill.py             ← 表单填写生成器
    ├── dropdown.py              ← 下拉选择生成器
    ├── search.py                ← 检索操作生成器
    ├── menu.py                  ← 菜单导航生成器
    └── common.py                ← 公共工具（human-like 延迟参数等）
```

## 模式文件规范（YAML）

每个模式文件遵循统一结构：

```yaml
id: pattern-unique-id
name: 模式显示名
category: form | dropdown | search | navigation | action | table
version: "1.0.0"
description: 一句话描述模式用途
tags: [标签1, 标签2]

# 适用条件
prerequisites:
  - 条件描述

# 默认参数（用户可覆盖）
defaults:
  param_name: default_value

# human-like 行为参数
human_like:
  typing_delay_ms: [30, 80]     # 打字间隔范围（毫秒）
  click_delay_ms: [100, 300]    # 点击前延迟范围
  wait_after_action_ms: [200, 500]  # 动作后等待范围
  random_jitter: true            # 是否启用随机抖动

# 动作序列模板
actions:
  - type: click | fill | select | scroll | hover | key | wait
    # 定位参数
    selector: ""
    role: ""
    name: ""
    ref: ""
    # 动作参数
    text: ""
    key: ""
    # 条件参数
    optional: false              # 是否可选（失败不中断）
    timeout_ms: 10000
    # 描述
    description: "步骤说明"
```

## 使用方式

### 1. 任务脚本中引用模式

```python
from op_browser.experience.generators.form_fill import generate_form_actions

# 生成表单填写 action_detail 序列
actions = generate_form_actions(
    fields=[
        {"label": "姓名", "value": "张三", "type": "text"},
        {"label": "部门", "value": "技术部", "type": "dropdown"},
        {"label": "备注", "value": "测试数据", "type": "textarea"},
    ],
    submit_button="提交"
)
```

### 2. flow.json 中直接使用模式

```json
{
  "step": "填写登记表",
  "url": "",
  "action_detail": [
    { "type": "hover", "role": "menuitem", "name": "收文管理" },
    { "type": "click", "role": "menuitem", "name": "收文登记" },
    { "type": "wait", "description": "等待表单加载" },
    { "type": "select", "role": "combobox", "name": "来文机关", "value": "市交通局" },
    { "type": "fill", "role": "textbox", "name": "来文标题", "text": "关于加强交通管理的通知" },
    { "type": "click", "role": "button", "name": "提交" }
  ]
}
```

### 3. CLI 命令引用模式（规划中）

```
/op-browser run <task> --pattern form-fill --fields '{"姓名":"张三","部门":"技术部"}'
```

## 设计原则

1. **模拟人工优先** — 默认通过点击、选择、滚动等用户可见操作完成任务，不直接操作 URL 路由
2. **定位链降级** — a11y ref → role+name → CSS selector → 坐标，逐级降级确保兼容性
3. **human-like 延迟** — 打字间隔、点击延迟、动作间等待模拟真实用户节奏
4. **幂等安全** — 同一模式多次执行结果一致
5. **渐进增强** — 基础模式零配置可用，高级参数可按需覆盖
