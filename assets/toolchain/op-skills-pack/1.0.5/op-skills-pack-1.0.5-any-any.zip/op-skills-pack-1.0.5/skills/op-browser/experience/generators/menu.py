"""菜单导航生成器 — 从菜单路径生成 action_detail 序列"""

from typing import List, Dict, Any, Optional
from .common import (
    HumanLikeConfig, build_menu_selectors,
    make_click, make_hover, make_wait, make_key,
)


def generate_menu_actions(
    menu_path: List[Dict[str, str]],
    menu_type: str = "auto",
    trigger_action: Optional[str] = None,
    human_like: Optional[Dict[str, Any]] = None,
) -> List[Dict[str, Any]]:
    """
    生成菜单导航的 action_detail 序列。

    通过点击菜单项逐级导航，而非 URL 直接跳转。

    Args:
        menu_path: 菜单路径 [{ text: "收文管理" }, { text: "收文登记" }]
        menu_type: auto|horizontal|vertical|context|breadcrumb|tab
        trigger_action: click|hover_then_click|null(自动选择)
        human_like: 可选覆盖延迟参数

    Returns:
        action_detail 列表
    """
    cfg = HumanLikeConfig(human_like)
    actions: List[Dict[str, Any]] = []

    actions.append(make_wait(200, "等待菜单区域渲染"))

    # 自动判断触发方式
    use_hover = trigger_action == "hover_then_click" or (
        trigger_action is None and menu_type in ("horizontal", "auto")
    )

    for i, item in enumerate(menu_path):
        text = item.get("text", "")
        selector = item.get("selector")
        is_last = (i == len(menu_path) - 1)
        level_desc = f"第{i + 1}级" if len(menu_path) > 1 else ""

        if not is_last and use_hover:
            # 中间级菜单：悬停展开
            actions.append(make_hover(
                selector=selector, role="menuitem", name=text,
                description=f"{level_desc}悬停展开「{text}」",
            ))
            actions.append(make_wait(
                cfg.random_ms("hover_delay_ms"),
                f"等待「{text}」子菜单展开",
            ))
        else:
            # 叶子级菜单或非 hover 模式：点击
            actions.append(make_click(
                selector=selector, role="menuitem", name=text,
                description=f"{level_desc}点击菜单「{text}」",
            ))
            if not is_last:
                actions.append(make_wait(
                    cfg.random_ms("wait_after_action_ms"),
                    f"等待「{text}」子菜单展开",
                ))

    # 导航完成后等待页面加载
    actions.append(make_wait(
        cfg.random_ms("wait_after_action_ms") + 500,
        "等待目标页面加载完成",
    ))

    return actions


def generate_breadcrumb_actions(
    breadcrumb_text: str,
    human_like: Optional[Dict[str, Any]] = None,
) -> List[Dict[str, Any]]:
    """
    生成面包屑导航的 action_detail 序列。

    Args:
        breadcrumb_text: 面包屑链接文本

    Returns:
        action_detail 列表
    """
    cfg = HumanLikeConfig(human_like)
    actions: List[Dict[str, Any]] = []

    actions.append(make_click(
        role="link", name=breadcrumb_text,
        description=f"点击面包屑「{breadcrumb_text}」",
    ))
    actions.append(make_wait(
        cfg.random_ms("wait_after_action_ms") + 300,
        "等待页面跳转",
    ))

    return actions


def generate_tab_actions(
    tab_text: str,
    human_like: Optional[Dict[str, Any]] = None,
) -> List[Dict[str, Any]]:
    """
    生成标签页导航的 action_detail 序列。

    Args:
        tab_text: 标签页文本

    Returns:
        action_detail 列表
    """
    cfg = HumanLikeConfig(human_like)
    actions: List[Dict[str, Any]] = []

    actions.append(make_click(
        role="tab", name=tab_text,
        description=f"点击标签页「{tab_text}」",
    ))
    actions.append(make_wait(
        cfg.random_ms("wait_after_action_ms"),
        "等待标签页内容加载",
    ))

    return actions
