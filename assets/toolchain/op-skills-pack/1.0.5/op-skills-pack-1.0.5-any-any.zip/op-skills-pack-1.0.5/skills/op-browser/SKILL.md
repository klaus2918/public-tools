---
name: op-browser
category: foundation
description: 浏览器自动化引擎。Bridge 优先策略 + 资源管理 + 并行执行。吸收 webapp-testing。
status: active
phase_role: foundation
version: "3.5.0"
updated_at: 2026-09-21
---

# op-browser v3 — 通用浏览器自动化引擎

## Overview

op 系列的基础能力层。零 LLM/API Key 依赖的确定性回放引擎。

**核心能力：**
- **Bridge 优先策略** — 启动前探测桥接状态，复用已有资源，按需新建，有效管理生命周期
- **并行执行** — 多任务并行回放（Bridge 分组并行 + CDP 多实例并行）
- **项目化管理** — ProjectRegistry + project.yaml + BrowserProjectRunner

**Bridge 优先流程**：
```
探测桥接状态 → 决策：复用 or 新建 → 执行 → 资源管理（清理/监控/协调）
```

**分组命名规则**：禁止使用通用名称（如 Agent、Browser、Test），分组名必须反映实际用途。

> 详细规范见 `references/cdp-adapter.md`、`references/bridge-adapter.md`、`references/project-runner.md`。

---

## When to Use

- 业务 Skill 需要浏览器自动化：`from op_browser import SmartBrowser`
- 用户输入 `/op-browser <task-description>`
- 已有已固化的任务需要执行（`/op-browser run <task-name>`）
- 需要多任务编排（`taskset`）、Bridge/CDP 会话管理、环境诊断（`doctor`）

**Do not use for:** 非浏览器自动化场景；业务逻辑混入引擎层；AI 自主探索未知页面（v2.4 起移除）。

---

## 边界声明（与 webapp-testing 划界）

| 维度 | op-browser | webapp-testing |
|------|-----------|----------------|
| 定位 | 固化流程回放 + 项目化资产（projects/ 体系）+ 生命周期域验证（op-build verify-browser） | 交互式临时测试工具箱（Playwright 本地 web 应用测试） |
| 触发 | 业务 Skill import / `/op-browser <task>`（任务已固化） | 一次性探查/调试本地 web 应用（DOM 检查、截图、console 日志） |
| 资产 | flow.json / script.py / project.yaml（可复用、可回放） | 临时 Playwright 脚本（用完即弃） |
| 执行 | SmartBrowser 引擎（run/taskset/test）+ Bridge/CDP 会话管理 | 原生 Playwright + `webapp-testing/scripts/with_server.py` |

**互不替代**：固化回放与临时调试是两种意图，工具链不同。不得用 op-browser 引擎执行一次性临时脚本，也不得把 webapp-testing 的临时脚本当作固化资产回放。

---

## Quick Reference

| 模式 | 何时使用 | Token 消耗 | 速度 | 适配器策略 |
|------|---------|-----------|------|-----------|
| `run` | 存量任务，固定流程 | 零 | 毫秒级 | CDP 优先（`--adapter bridge` 显式指定时走 Bridge） |
| `taskset` | 多任务编排 | 零 | Sum | 按场景选择 |
| `test` | 项目用例执行 | 零 | 按场景 | 按场景选择 |
| `bridge/*` | 会话管理/诊断 | 零 | 即时 | Bridge |
| `experience` | 交互经验库 | 零 | 即时 | 不依赖适配器（模式定义层） |

### 交互经验库（v3.5）

引擎内置 **Experience Library**，提供 6 类可复用的页面交互模式，模拟人工操作而非 URL 直接跳转：

| 模式 | 用途 | 文件 |
|------|------|------|
| `form-fill` | 表单逐字段填写 | `experience/patterns/form-fill.yaml` |
| `dropdown-select` | 下拉框选择（原生/自定义/级联/可搜索） | `experience/patterns/dropdown-select.yaml` |
| `search-filter` | 检索输入与搜索（简单/高级/条件/日期范围） | `experience/patterns/search-filter.yaml` |
| `menu-navigate` | 菜单导航（顶部/侧边/面包屑/标签页） | `experience/patterns/menu-navigate.yaml` |
| `button-action` | 按钮操作与确认对话框处理 | `experience/patterns/button-action.yaml` |
| `table-interact` | 表格交互（行选择/排序/分页/行操作） | `experience/patterns/table-interact.yaml` |

**核心设计理念**：默认模拟人工 → 通过点击菜单/按钮导航而非路由跳转 → 积累通用元能力快速复用。

详细规范见 `references/experience-library.md`，索引见 `experience/INDEX.md`。

### 适配器选择策略（ModeSelector）

| 模式 | 推荐适配器 | 原因 |
|------|-----------|------|
| run（默认） | CDP 优先 | 零依赖高速执行，无 headless/有界面感知 |
| run 显式 Bridge | `--adapter bridge` 覆盖 | locator 匹配更稳定；默认复用已有分组（同源/同名），无匹配时建议新建待确认 |
| hybrid | CDP（run 场景） | 与 auto 等价；探索场景由调用方传 `adapter='bridge'` |
| 用户强制 | `adapter='bridge'` 参数覆盖 | 精确控制测试方式 |

> Bridge 不可用时自动降级 CDP（不阻塞用户），打印 WARN 提示。

---

## Quick Start（v2.4.1）

```python
# 1. 一键运行已固化任务（截图校验，有 baseline 时自动对比）
from op_browser import SmartBrowser
browser = SmartBrowser()
result = await browser.run("登录流程", verify_mode="screenshot")
print(result.success, result.judge)

# 2. DOM 验证模式（功能测试推荐，无 baseline 也可执行）
result = await browser.run("收文登记测试", verify_mode="dom")
print(result.success, result.data)

# 3. Bridge 快速诊断（3 步确认桥接可用）
/op-browser bridge doctor       # 检查 Bridge 服务+扩展+token
/op-browser bridge status       # 健康检查
/op-browser bridge session <url> --new  # 启动会话（复用/新建）

# 4. 友好 RPC 调用（免手写 JSON，Windows cmd 安全）
/op-browser bridge rpc session.start --url https://example.com --name 业务名
/op-browser bridge rpc page.navigate --url https://example.com/page
/op-browser bridge rpc session.list
```

> **Windows 用户注意**：所有 `bridge rpc` 命令使用 `--key value` 参数格式，无需 JSON 字符串。

---

## CLI 命令（v2.4）

```bash
# 任务执行（确定性回放）
/op-browser run <name> [--project] [--system] [--module] [--adapter] [--new] [--run-id <id>] [--resume] [--force] [--login-account <账号>] [--relogin] [--no-login] [--multi-tab] [--detach] [--keep-session] [--verify-mode <screenshot|dom|auto>]
/op-browser taskset <name1> <name2> [--adapter] [--parallel] [--new] [--project] [--system] [--module] [--run-id "A=rA,B=rB"] [--login-account <账号>] [--relogin] [--no-login] [--multi-tab]

# 任务仓库管理
/op-browser list
/op-browser info <name>
/op-browser delete <name>

# Bridge 诊断（v2 新增）
/op-browser bridge status       # 检查 Bridge 健康
/op-browser bridge doctor       # Bridge 环境诊断
/op-browser bridge groups [--filter <关键词>] [--account <账号>] [--since <分钟>] [--json]
/op-browser bridge cleanup [--name <业务名>] [--all] [--idle] [--since <分钟>] [--account <账号>] [--exclude-running] [--yes]
/op-browser bridge inspect --url <url> [--new] [--name <业务名>]
/op-browser bridge session <url> [--new] [--name <业务名>]
/op-browser bridge rpc <method> [--key value ...]

# E2E 测试（v2 新增）
/op-browser test list [project] [--system] [--module]
/op-browser test <domain> [--case <name>] [--adapter <type>]
/op-browser test result [project]

# run 状态（v2.5 新增：接续与恢复）
/op-browser run status [--task <name>]

# 环境诊断
/op-browser doctor
```

---

## 本地地址识别与分组命名规范（v3.4）

### 本地地址与同源判定

- **本地地址范围**：`localhost`、`0.0.0.0`、`127.0.0.0/8`、RFC1918 私有网段（`10/8`、`172.16/12`、`192.168/16`）、链路本地 `169.254/16`、`LOCAL_IPS` 显式配置项、本机 hostname 解析结果。
- **同源判定**：两端均为本地地址时**只比较端口**（`127.0.0.1:5557` 与 `192.0.2.10:5557` 视为同源，可复用会话/分组）；非本地地址仍按 `scheme + hostname + port` 精确匹配。
- 跨机调试（内网静态 IP 指向本机）时用 `LOCAL_IPS` 显式声明，否则会被判为非本地、无法复用。

### 分组命名规范

- **禁止通用名**：`agent` / `browser` / `test` / `tab` / `page` / `session` / `window` / `group` / `new` / `default` / `debug` / `temp`；分组名必须反映实际业务用途（如 `业务-收文流程`）。
- **长度**：≥ 2 字符。
- 自动生成的名称（由 URL 推导）同样受校验：违规时回退为 `host:port`；无路径时用 `host:port`，有路径时取路径末段（不再返回「业务页面」这类通用名）。
- `#r<run-id>` 后缀与 `🤖` 前缀在校验时自动剥离（不参与业务名校验）。
- 分组名会成为 Chrome tab group 标题：入口（CLI 与适配器）**双层校验**，避免污染用户浏览器视图。

### 连接重试

Bridge `connect()` 最多尝试 **2 次**（间隔 1s）；重试时强制完整探测（health + RPC 并行），覆盖 bridge 短暂断开场景；仍失败返回 `False`（不抛异常，由调用方决定提示）。

### 截图策略

`verify_mode=dom` 时**不拍 final 截图**（规避持续动画页面 `Page.screenshot` 超时），产物以 `dom_checks` 为准；`screenshot` / `auto` 模式维持原行为。与执行约束 `browser_screenshot_read`（默认 `false`）一致。

---

## 环境变量（可选，均有默认值）

| 变量 | 作用 | 默认 |
|------|------|------|
| `BROWSER_HEADLESS` | 无头模式（"true"/"false"） | `false` |
| `BROWSER_CDP_URL` | CDP 地址（指定已有 Chrome） | 自动探测 |
| `BROWSER_DIFF_PASS` | 差异率低于此值判 pass | `0.05` |
| `BROWSER_DIFF_WARN` | 差异率低于此值判 warn，否则 fail | `0.20` |
| `BRIDGE_URL` | Bridge 服务地址 | `http://127.0.0.1:8765` |
| `BROWSER_AGENT_BRIDGE_TOKEN` | Bridge 认证 token（扩展要求时） | 空 |
| `TASKS_DIR` | 任务仓库目录（覆盖默认挂载点） | skill 内挂载点 `op-browser/tasks`（junction → `.basic/evolved/op-browser/tasks`） |
| `OP_BROWSER_PROJECTS_DIR` | 项目资产根目录（覆盖默认挂载点） | skill 内挂载点 `op-browser/projects`（junction → `.basic/evolved/op-browser/projects`） |
| `LOCAL_IPS` | 显式声明的本机地址（逗号分隔），参与本地地址判定 | 空（自动探测：hostname 解析 + loopback） |
| `OP_BROWSER_RUN_STALE_SECONDS` | run 心跳过期阈值（>此值判死进程可接续，v2.5） | `600` |
| `OP_BROWSER_SESSION_RETENTION_SECONDS` | 会话保留期（idle 超此秒数 → reclaimable 可回收，v2.6） | `86400`（24h） |
| `OP_BROWSER_AUTO_CLEANUP` | run 结束后自动回收 reclaimable 会话（v2.6） | `true` |

---

## 依赖（Python 包）

| 包 | 最低版本 | 用途 |
|----|---------|------|
| httpx | >=0.27 | Bridge 适配器 HTTP 调用（`bridge rpc` / session 查询） |
| playwright | >=1.40 | CDP 浏览器自动化（连接与页面操作） |
| Pillow | >=10.0 | 截图处理与 baseline 对比 |

> 与根 `requirements.txt` 声明一致；安装：`py -m pip install -r requirements.txt`。

---

## 校验模式概览（v2.7）

`run()` 新增 `verify_mode` 参数：`"screenshot"`（截图 baseline 对比）、`"dom"`（DOM 断言验证，跳过截图）、`"auto"`（默认，自适应）。功能验证推荐 `dom` 模式，UI 回归用 `screenshot` 模式。详见 `references/project-runner.md`。

---

## Red Flags — STOP

| Smell | Action |
|-------|--------|
| Hard-coded x/y coordinates in script | Use anchor system; coordinates drift |
| Business logic in engine.py | Move to calling business skill |
| Run fails → fake success | 诚实报告错误；无 flow/script 时明确报"任务未固化" |
| 未用 project/system/module 上下文 | v2 支持项目化管理，传参后自动加载 adapter.json |
| 适配器混用导致定位不一致 | run 在 Bridge/CDP 间切换时需确保 fallback 锚点稳定 |
| Bridge 降级后不主动排查 | 降级打印 WARN，应在 `bridge doctor` 检查 Bridge 服务状态 |
| Bridge 模式跳过 session 复用 | 不复用 = 每次重复登录（高频问题） |
| 陈旧 session 堆积 | `bridge groups` 查看，`bridge cleanup` 清理 |
| run 后未回收分组（页签堆积） | v2.6 起 run 后本次新建分组进入保留期（默认 24h），超期自动回收 |
| 引入 LLM/API Key 依赖 | v2.4 明确零外部 Key；需要 AI 探索时用外部工具生成 flow 资产 |

> 完整 Red Flags 与 Common Mistakes 见各 references 文档。

---

## Version

| Field | Value |
|-------|-------|
| Skill | op-browser |
| Version | 3.5.0 |
| Updated | 2026-09-21 |
| Key change | v3.5.0: 交互经验库（Experience Library）— 6 类可复用页面交互模式（表单填写/下拉选择/检索搜索/菜单导航/按钮操作/表格操作）+ Python 生成器；引擎新增 select/scroll/hover/wait 动作类型 + human_like_delay_ms 延迟支持；详见 `references/experience-library.md`；v3.4.0: 采纳包侧 6 个源码文件的缺陷修复与能力增强（`task_store` 的 `Path("")` 真值陷阱导致产物静默落 cwd、`project` 同源路径修复、`engine` dom 模式跳 final 截图 + `duration_ms` 计算、`cli` 分组名早期校验、`project_runner` case→task 映射、`adapter_bridge` 连接重试/本地地址识别/本地同源判定/分组名双层校验）；v3.3.0: 引入 `references/project-assets.md`（项目资产目录/配置/脚本复用，凭据与资产分离改造）；v3.2.0: 引入 `references/login-matching.md`（登录匹配与降级，改造为本仓库机制：CLI 参数 > 项目配置 > 系统适配器 > 自动探测 > 人工兜底 + 凭据安全约束）；v3.1.0: 引入 `references/session-reuse.md`（分组/会话复用判定、保持机制、分组池与复用指标）；v3.0.1: 补依赖声明段（httpx/playwright/Pillow）；v3.0.0: 版本体系归并为 frontmatter 单一事实源 |
| References | references/cdp-adapter.md / references/bridge-adapter.md / references/project-runner.md / references/project-assets.md / references/session-reuse.md / references/login-matching.md / cdp-operations.md / fault-recovery.md / file-upload-injection.md / test-data-management.md / concurrency.md / tab-governance.md / **experience-library.md** |
| Key change | v2.4.1: Bridge 连接加速 + 全局 ModeSelector 复用 + bridge rpc 友好命令；v2.4.2: 引擎缓存；v2.4.3: 边界声明；v2.4.4: validate 防线建议；v2.5.0: 并发隔离专项 + 接续与恢复；v2.6.0: 页签治理专项；v2.7.0: 校验模式专项（verify_mode=dom/screenshot/auto + DOM 断言验证） |
