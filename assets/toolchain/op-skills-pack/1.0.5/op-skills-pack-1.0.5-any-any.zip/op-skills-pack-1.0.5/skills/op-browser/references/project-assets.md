# 项目资产管理

> 位置：`op-browser/references/project-assets.md`
> 用途：说明 `projects/<project>/` 的目录约定、配置文件与脚本复用规则。
> 关联：`references/project-runner.md`（项目/系统/模块执行）、`references/login-matching.md`（登录方式与账号选择）、`skills/op-000/references/isolation-spec.md`（运行资产落点）

## 一、目录结构

```
projects/<project>/
├── project.yaml      # 项目配置（环境、默认账号、登录方式、浏览器配置）
├── accounts.yaml     # 账号索引（username + 角色 + 说明；口令不落此文件）
├── test-data.yaml    # 测试数据（按业务场景组织）
├── scripts/          # 项目级共享脚本（登录、通用操作等）
└── tasks/            # 任务目录
    └── <task-name>/
        ├── task.json
        ├── flow.json
        └── scripts/  # 任务级脚本（一个任务可有多个脚本）
```

> **落点**：`projects/` 是 `skills/op-browser/projects/`（junction 挂载点，实体在 `.basic/evolved/op-browser/projects/`）——运行资产**不入 git、不随包分发**。

## 二、配置文件说明

### 1. project.yaml

内容：项目基本信息（name / id / description）、环境配置（base_url / iam_url / api_base）、默认账号与登录方式、浏览器配置（Bridge 分组、操作规范）。

```yaml
project:
  name: "示例平台"
  id: "demo"
  description: "示例平台自动化资产"

default_account: "admin"
login_method: "no_captcha"      # 与 login-matching.md 的优先级 2 对应

environments:
  dev:
    description: "开发环境"
    base_url: "http://localhost:5557/<app-context>"
    iam_url: "http://192.0.2.10/<iam-context>/loginApp"    # RFC 5737 占位
    api_base: "http://192.0.2.10/<iam-api>"

default_env: "dev"

test_data:
  source: "test-data.yaml"
  auto_load: true
```

### 2. accounts.yaml

内容：账号**索引**（username + 角色 + 说明 + 应用码映射）。**口令不写在本文件**。

```yaml
accounts:
  admin:
    username: "admin"
    description: "示例平台管理员"
    iam_app_code: "<APP_CODE>"
    secret_ref: "env:DEMO_ADMIN_PASSWORD"   # 口令来源：环境变量名（或 local 覆盖文件）

  test_user:
    username: "testuser01"
    description: "测试用户"
    iam_app_code: "<APP_CODE>"
    secret_ref: "env:DEMO_TEST_USER_PASSWORD"
```

> 若项目确有本地明文需求，写入 **本地实例配置**（`accounts.local.yaml`，已被 `.gitignore` 的 `*.local.yaml` 规则排除），不得进入任务资产与提交历史。

### 3. test-data.yaml

内容：按业务场景组织测试数据，支持引用（如发文/收文流程数据）。

```yaml
示例流程:
  basic_info:
    title: "示例标题"
    document_type: "通知"
    urgency: "普通"

users:
  admin:
    name: "管理员"
    department: "办公室"
    role: "admin"
```

> 测试数据中的**业务字段可保留**，但不得包含真实客户信息、真实个人身份或生产数据。

## 三、脚本复用机制

| 层级 | 位置 | 用途 | 示例命名 |
|------|------|------|---------|
| 项目级 | `projects/<project>/scripts/` | 项目内所有任务可复用 | `login-no-captcha.py`、`common-operations.py` |
| 任务级 | `projects/<project>/tasks/<task>/scripts/` | 当前任务专用 | `step1-open-page.py`、`step2-fill-form.py` |

**引用规则**（任务脚本 import 项目级脚本）：

```python
import sys
sys.path.append('../../scripts')       # 指向项目级 scripts/

from login_no_captcha import login     # 项目级脚本以模块名导入

result = login(username, password_from_env, app_code, base_url)
```

> 约定：脚本命名用 `step<N>-<动作>.py`（任务级）/ `<能力>.py`（项目级）；单文件自包含优先，跨脚本复用只走上述 import 路径。

## 四、使用方式

1. **创建项目配置**：以 `projects/template/project.yaml` 为骨架 → `projects/<project>/project.yaml`，填写项目信息、环境、默认账号。
2. **配置账号索引**：在 `accounts.yaml` 登记 username 与角色；口令用 `secret_ref` 指向环境变量或 `accounts.local.yaml`。
3. **组织测试数据**：在 `test-data.yaml` 按业务场景分组填写（占位值起步）。
4. **创建共享脚本**：在 `scripts/` 下新增可复用脚本（保持无副作用、可单独执行）。
5. **创建任务**：`mkdir -p projects/<project>/tasks/<task-name>/scripts`，随后编写 `task.json` / `flow.json`。

## 五、最佳实践

1. **凭据与资产分离**：账号索引入库/入资产，口令只来自环境变量或本地配置（`*.local.yaml`）；**禁止**在 `accounts.yaml`、`task.json`、`flow.json`、`cases.yaml` 中写明文口令。
2. **测试数据按场景组织**：便于引用与维护；`auto_load: true` 时任务启动即加载。
3. **项目级共享脚本**：避免重复实现登录、通用操作。
4. **脚本归位**：一个任务可有多个脚本，全部放在任务目录内，不散落到项目根。
5. **import 规则**：任务脚本只 import 项目级脚本，不反向依赖其它任务。
6. **资产不入库**：`projects/` 是运行时资产，不提交、不随包分发；打包与校验由 `content-check 7.22` 与 `isolation-check.sh` 保障。
