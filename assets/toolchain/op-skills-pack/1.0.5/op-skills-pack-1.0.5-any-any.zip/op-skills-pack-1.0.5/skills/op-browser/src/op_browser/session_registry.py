"""
op_browser / session_registry.py — 会话注册表与生命周期（v2.6 页签治理）

管理 tasks/sessions_index.json（会话注册表）：记录每个 Agent session 的
登录账号、归属任务、生命周期状态、最后活跃时间、租约身份（#r 后缀）。
跨进程安全：复用 task_store 的 _file_lock + _atomic_write_text。

页签治理专项（op-browser-tab-governance，GREEN D1-D3）：
- 状态机：unknown → open/running → idle → reclaimable → gone
  - open/running：run 执行中（心跳新鲜，绝不回收）
  - idle：run 结束保留，可被下次 run 复用（免重新登录）
  - reclaimable：idle 且 last_active_at 距今超过保留期 → 回收候选
  - gone：已关闭（显式清理 / 自动回收 / 用户手关）
- 账号感知：account / account_confirmed 供 session_decision 复用决策
  （同账号复用 > 异账号同 tab 重登 > 拒绝异 tab）
- 保留期回收：超保留期 → reclaimable → 自动回收（run 后钩子）或
  显式 `bridge cleanup --idle`；`--keep-session` 逃生门
- unknown（注册表无记录）绝不自动回收（避免误伤用户手动打开的 tab）

保留期/回收开关（环境变量）：
- OP_BROWSER_SESSION_RETENTION_SECONDS  保留期秒数（默认 86400 = 24h）
- OP_BROWSER_AUTO_CLEANUP               run 后自动回收开关（默认 true）
"""
import json
import os
from datetime import datetime, timezone
from pathlib import Path

from . import task_store as store
from .task_store import _atomic_write_text, _file_lock

# 保留期：idle 会话超过该秒数 → reclaimable（可回收）
SESSION_RETENTION_SECONDS = float(
    os.environ.get("OP_BROWSER_SESSION_RETENTION_SECONDS", "86400"))
# run 结束后是否自动顺带回收 reclaimable 会话（默认开，幂等）
AUTO_CLEANUP = os.environ.get("OP_BROWSER_AUTO_CLEANUP", "true").lower() in (
    "1", "true", "yes", "on")

# 注册表状态值
ST_OPEN = "open"
ST_RUNNING = "running"
ST_IDLE = "idle"
ST_RECLAIMABLE = "reclaimable"
ST_GONE = "gone"
# 注册表无记录的会话（旧会话 / 外部创建）→ 不参与账号匹配与自动回收
ST_UNKNOWN = "unknown"


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sessions_index_path() -> Path:
    """tasks/sessions_index.json（与 runs_index.json 同级）。"""
    return store.tasks_root() / "sessions_index.json"


def load_sessions() -> list[dict]:
    """读全量注册表。缺失/损坏返回 []（兜底，不崩溃）。"""
    p = sessions_index_path()
    if not p.exists():
        return []
    try:
        with open(p, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except Exception:
        return []


def save_sessions(recs: list[dict]) -> None:
    """原子写注册表（文件锁 + 临时文件 os.replace）。"""
    p = sessions_index_path()
    with _file_lock(p):
        _atomic_write_text(
            p, json.dumps(recs, ensure_ascii=False, indent=2))


def get_session(session_id: str) -> dict | None:
    """按 session_id 查记录。"""
    return next((r for r in load_sessions()
                 if r.get("session_id") == session_id), None)


def upsert_session(rec: dict) -> dict:
    """按 session_id 新增或替换记录（保留原 created_at）。"""
    sid = rec.get("session_id", "")
    if not sid:
        return rec
    recs = load_sessions()
    exist = next((r for r in recs if r.get("session_id") == sid), None)
    if exist:
        rec.setdefault("created_at", exist.get("created_at", ""))
    else:
        rec.setdefault("created_at", _now_iso())
        rec.setdefault("last_active_at", _now_iso())
        rec.setdefault("status", ST_OPEN)
    recs = [r for r in recs if r.get("session_id") != sid]
    recs.append(rec)
    save_sessions(recs)
    return rec


def delete_session(session_id: str) -> bool:
    """删除记录。返回是否存在。"""
    recs = load_sessions()
    n = len(recs)
    recs = [r for r in recs if r.get("session_id") != session_id]
    if len(recs) == n:
        return False
    save_sessions(recs)
    return True


def touch_active(session_id: str, **kw) -> dict | None:
    """标记活跃（status=idle/running + last_active_at=now + 附加字段）。"""
    rec = get_session(session_id)
    if not rec:
        return None
    status = kw.pop("status", ST_IDLE)
    rec["status"] = status
    rec["last_active_at"] = _now_iso()
    rec.update(kw)
    upsert_session(rec)
    return rec


def mark_reclaimable(session_id: str) -> dict | None:
    """标记可回收（idle 超保留期后由扫描调用）。"""
    return touch_active(session_id, status=ST_RECLAIMABLE)


def reclaimable_ids(retention_seconds: float | None = None,
                    now=None) -> list[str]:
    """返回当前可回收的 session_id 列表（idle 且超保留期）。

    安全闸（GREEN D8）：
    - running / interrupted 状态永不进入回收候选（心跳由 run_state 判定）
    - resumable=True 永不回收（接续 A 档依赖会话存活）
    - unknown（注册表无记录）由调用方跳过（不在此过滤）
    """
    threshold = (retention_seconds if retention_seconds is not None
                 else SESSION_RETENTION_SECONDS)
    now = now or datetime.now(timezone.utc)
    out = []
    for r in load_sessions():
        status = r.get("status", ST_UNKNOWN)
        if status not in (ST_IDLE, ST_RECLAIMABLE):
            continue
        if r.get("resumable"):
            continue
        if r.get("lease_run_id"):
            continue  # 租约会话：仅显式清理（避免误伤并行/命名 run 现场）
        last = r.get("last_active_at", "")
        if not last:
            continue
        try:
            age = (now - datetime.fromisoformat(last)).total_seconds()
        except (ValueError, TypeError):
            continue
        if age >= threshold:
            out.append(r["session_id"])
    return out


def is_running_heartbeat_fresh(session_id: str) -> bool:
    """通过 run_state 心跳判定会话关联 run 是否仍存活（回收闸）。

    会话的 lease_run_id / task 关联 run_state；心跳新鲜 = 距现在
    < RUN_STALE_SECONDS → 视为执行中，绝不回收。
    """
    from . import run_state as rs
    rec = get_session(session_id)
    if not rec:
        return False
    run_id = rec.get("lease_run_id") or ""
    if not run_id:
        return False
    st = rs.load_run_state(run_id)
    if not st:
        return False
    if st.get("status") in ("running", "interrupted"):
        hb = st.get("heartbeat_at", "")
        if hb:
            try:
                age = (datetime.now()
                       - datetime.fromisoformat(hb)).total_seconds()
                return age < rs.RUN_STALE_SECONDS
            except (ValueError, TypeError):
                return False
    return False
