"""
op_browser — 通用浏览器自动化引擎 v2。

v2 新增组件:
- BrowserAdapter / CDPAdapter / BridgeAdapter — 双适配器架构
- ModeSelector — 适配器策略引擎
- ProjectRegistry / BrowserProjectRunner — 项目化管理

用法:
    from op_browser import SmartBrowser

    # v1 向后兼容
    browser = SmartBrowser()
    result = await browser.run("收文提取")

    # v2 项目上下文
    result = await browser.run("收文提取", project="demo-project",
                                system="demo-project-pc", module="incoming-doc")

    # v2 Bridge 适配器
    result = await browser.run("收文提取", adapter="bridge")
"""
from .engine import SmartBrowser, BrowserResult, Config
from .mode_selector import ModeSelector

# v2 新导出
from .base import BrowserAdapter, ActionResult, NavigationInfo, ElementInfo, A11yNode
from .adapter_cdp import CDPAdapter
from .adapter_bridge import BridgeAdapter
from .project import ProjectRegistry
from .project_runner import BrowserProjectRunner

__all__ = [
    # 引擎
    "SmartBrowser",
    "BrowserResult",
    "Config",

    # v2 适配器
    "BrowserAdapter",
    "ActionResult",
    "NavigationInfo",
    "ElementInfo",
    "A11yNode",
    "CDPAdapter",
    "BridgeAdapter",
    "ModeSelector",

    # v2 项目管理
    "ProjectRegistry",
    "BrowserProjectRunner",
]
