"""
op_browser / adapter_cdp.py — CDP 适配器（BrowserAdapter 实现）

包装 CDPClient 实现 BrowserAdapter 接口。CDPClient 自身不改动，零风险。
对 Bridge 独有方法（click_by_locator / accessibility_tree）提供 fallback 链：
click_by_locator → text selector → CSS selector → click_xy
"""
import json, re
from typing import Any

from .base import (
    BrowserAdapter, ActionResult, NavigationInfo,
    ElementInfo, A11yNode,
)
from . import cdputil


# tag 白名单校验（P2-22：防选择器注入）
_TAG_RE = re.compile(r"^[a-zA-Z][\w-]*$")


class CDPAdapter(BrowserAdapter):
    """CDP 适配器，包装 CDPClient 实现 BrowserAdapter 接口。"""

    @property
    def name(self) -> str:
        return "cdp"

    def __init__(self, cdp_url: str | None = None, headless: bool = False):
        self._client = cdputil.CDPClient()
        self._cdp_url = cdp_url
        self._headless = headless
        self._session_id: str = ""
        self._connected = False

    # ── 生命周期 ───────────────────────────────────────────────

    async def connect(self, **kwargs) -> bool:
        try:
            cdp_url = kwargs.get("cdp_url", self._cdp_url)
            headless = kwargs.get("headless", self._headless)
            await self._client.connect(cdp_url=cdp_url, headless=headless)
            self._connected = True
            return True
        except Exception as e:
            self._connected = False
            return False

    async def close(self):
        await self._client.close()
        self._connected = False

    async def is_connected(self) -> bool:
        return self._connected and self._client.connected

    # ── 会话管理 ───────────────────────────────────────────────

    async def start_session(self, url: str = "") -> str:
        self._session_id = f"cdp_{id(self)}"
        if url:
            await self._client.goto(url)
        return self._session_id

    async def close_session(self, session_id: str):
        self._session_id = ""
        await self._client.close()

    # ── 导航 ───────────────────────────────────────────────

    async def goto(self, url: str) -> NavigationInfo:
        await self._client.goto(url)
        info = await self._client.page_info()
        return NavigationInfo(
            url=info.get("url", url),
            title=info.get("title", ""),
        )

    async def wait_for_load(self, timeout: float = 15.0) -> bool:
        return await self._client.wait_for_load(timeout)

    # ── 元素操作 ───────────────────────────────────────────────

    async def click(self, selector: str) -> ActionResult:
        try:
            await self._client.click(selector)
            return ActionResult(success=True)
        except Exception as e:
            return ActionResult(success=False, error=str(e))

    async def click_by_locator(self, role: str, name: str) -> ActionResult:
        """按 role/name 定位点击（CDP fallback 链）。

        Fallback 链：
        1. 尝试 text 选择器
        2. 尝试 CSS 选择器
        3. 尝试坐标点击（页面内查找文本坐标）
        """
        # fallback 1: text 选择器
        try:
            await self._client.click(f"text={name}")
            return ActionResult(success=True)
        except Exception:
            pass

        # fallback 2: CSS 选择器（含 role 映射）
        try:
            css_map = {"button": "button", "link": "a", "textbox": "input,textarea"}
            css = css_map.get(role, "")
            if css:
                await self._client.click(css)
                return ActionResult(success=True)
        except Exception:
            pass

        # fallback 3: 页面内查找文本并坐标点击
        try:
            # P2-22：name 经 json.dumps 嵌入（单引号/反斜杠/中文 \uXXXX 均安全）
            js_expr = (f"(() => {{const el=[...document.querySelectorAll('*')]"
                       f".find(e=>e.textContent?.trim()==={json.dumps(name)});"
                       f"if(!el)return null;const r=el.getBoundingClientRect();"
                       f"return {{x:r.left+r.width/2,y:r.top+r.height/2}};}})()")
            pos = await self._client.js(js_expr)
            if pos and pos.get("x"):
                await self._client.click_xy(pos["x"], pos["y"])
                return ActionResult(success=True)
        except Exception:
            pass

        return ActionResult(success=False, error=f"未找到 role={role} name={name}")

    async def fill(self, selector: str, text: str) -> ActionResult:
        try:
            await self._client.fill(selector, text)
            return ActionResult(success=True)
        except Exception as e:
            return ActionResult(success=False, error=str(e))

    async def fill_by_locator(self, role: str, name: str, text: str) -> ActionResult:
        """按 role/name 定位输入框并填入（CDP fallback 链）。

        Fallback 链：
        1. 按 role 映射的 CSS 选择器
        2. 页面内按 aria-label / placeholder / name 属性匹配并注入值
           （React 兼容：原型 setter + input/change 事件）
        """
        # fallback 1: CSS 选择器（含 role 映射）
        try:
            css_map = {"textbox": "input,textarea",
                       "combobox": "select,input",
                       "searchbox": "input"}
            css = css_map.get(role, "input,textarea")
            await self._client.fill(css, text)
            return ActionResult(success=True)
        except Exception:
            pass

        # fallback 2: 属性匹配 + 原型 setter 注入（P2-22：json.dumps 防注入）
        try:
            js_expr = (
                "(() => {const el=[...document.querySelectorAll("
                "'input,textarea,select')].find(e => "
                "(e.getAttribute('aria-label') || e.placeholder || e.name || '')"
                f".includes({json.dumps(name)}));"
                "if (!el) return false;"
                "const proto = el instanceof HTMLTextAreaElement "
                "? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;"
                "const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;"
                f"if (setter) setter.call(el, {json.dumps(text)});"
                "else el.value = " + json.dumps(text) + ";"
                "el.dispatchEvent(new Event('input', {bubbles: true}));"
                "el.dispatchEvent(new Event('change', {bubbles: true}));"
                "return true;})()"
            )
            ok = await self._client.js(js_expr)
            if ok:
                return ActionResult(success=True)
        except Exception:
            pass

        return ActionResult(
            success=False,
            error=f"未找到输入框 role={role} name={name}",
        )

    async def type_text(self, text: str) -> ActionResult:
        try:
            await self._client.type_text(text)
            return ActionResult(success=True)
        except Exception as e:
            return ActionResult(success=False, error=str(e))

    async def press_key(self, key: str) -> ActionResult:
        try:
            await self._client.press_key(key)
            return ActionResult(success=True)
        except Exception as e:
            return ActionResult(success=False, error=str(e))

    # ── 内容提取 ───────────────────────────────────────────────

    async def read_text(self, selector: str = "") -> str:
        if selector:
            return await self._client.text(selector) or ""
        return await self._client.js("document.body.innerText") or ""

    async def accessibility_tree(self) -> list[A11yNode]:
        """CDP 模式通过 JS 获取简化版无障碍树。"""
        try:
            raw = await self._client.js("""
            (() => {
                function walk(node, depth=0) {
                    if (depth > 5) return null;
                    const role = node.getAttribute?.('role') ||
                        (node.tagName === 'A' ? 'link' :
                         node.tagName === 'BUTTON' ? 'button' :
                         node.tagName === 'INPUT' ? 'textbox' :
                         node.tagName === 'IMG' ? 'img' : '');
                    const name = node.getAttribute?.('aria-label') ||
                        node.textContent?.trim()?.slice(0, 100) || '';
                    const result = {role, name, children: []};
                    for (const child of node.children || []) {
                        const c = walk(child, depth+1);
                        if (c && (c.role || c.name)) result.children.push(c);
                    }
                    return result;
                }
                return walk(document.body)?.children || [];
            })()
            """)
            return self._dicts_to_a11y(raw or [])
        except Exception:
            return []

    def _dicts_to_a11y(self, dicts: list[dict]) -> list[A11yNode]:
        """将 JS 返回的 dict 列表转为 A11yNode 列表。"""
        result = []
        for d in dicts:
            node = A11yNode(
                role=d.get("role", ""),
                name=d.get("name", ""),
                attributes={k: d[k] for k in d if k not in ("role", "name", "children")},
                children=self._dicts_to_a11y(d.get("children", [])),
            )
            result.append(node)
        return result

    async def query_elements(self, **criteria) -> list[ElementInfo]:
        """按条件查询元素。"""
        tag = criteria.get("tag", "")
        # P2-22：tag 白名单校验，防选择器注入
        if tag and not _TAG_RE.match(str(tag)):
            raise ValueError(f"非法 tag: {tag!r}（仅允许字母开头的标识符）")
        js = "document.querySelectorAll('*')"
        if tag:
            js = f"document.querySelectorAll('{tag}')"

        raw = await self._client.js(f"""
        (() => {{
            const els = {js};
            return Array.from(els).slice(0, 20).map(el => ({{
                tag_name: el.tagName?.toLowerCase() || '',
                text: (el.textContent || '').trim().slice(0, 100),
                selector: el.id ? '#'+el.id : '',
                x: (el.getBoundingClientRect?.().left ?? 0),
                y: (el.getBoundingClientRect?.().top ?? 0),
            }}));
        }})()
        """)
        return [ElementInfo(**item) for item in (raw or [])]

    async def execute_js(self, expression: str) -> Any:
        return await self._client.js(expression)

    # ── 截图 ───────────────────────────────────────────────

    async def screenshot(self, full_page: bool = False, out_path: str = "") -> str:
        if full_page:
            return await self._client.screenshot_full(path=out_path or None)
        return await self._client.screenshot(path=out_path or None)

    # ── 等待 ───────────────────────────────────────────────

    async def wait_for_selector(self, selector: str, timeout: float = 10.0) -> bool:
        return await self._client.wait_for_selector(selector, timeout)

    async def wait_for_text(self, text: str, timeout: float = 10.0) -> bool:
        try:
            result = await self._client.js(
                f"document.body.innerText.includes({json.dumps(text)})"
            )
            return bool(result)
        except Exception:
            return False

    # ── 标签页 ─────────────────────────────────────────────

    async def new_tab(self, url: str = "about:blank") -> str:
        await self._client.new_tab(url)
        return f"tab_{id(self)}"

    async def close_tab(self, tab_id: str = ""):
        await self._client.close_tab()

    async def list_tabs(self) -> list[dict]:
        pages = getattr(self._client, "_context", None)
        if pages and pages.pages:
            return [{"url": p.url, "title": p.title or ""} for p in pages.pages]
        return []
