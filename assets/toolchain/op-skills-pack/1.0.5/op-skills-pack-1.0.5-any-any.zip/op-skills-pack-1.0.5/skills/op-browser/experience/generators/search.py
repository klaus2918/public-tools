"""检索操作生成器 — 从搜索条件生成 action_detail 序列"""

from typing import List, Dict, Any, Optional
from .common import (
    HumanLikeConfig, build_label_selectors,
    make_click, make_fill, make_select, make_key, make_wait,
    match_search_placeholder,
)


def generate_search_actions(
    keyword: str = "",
    mode: str = "simple",
    search_input: Optional[Dict[str, str]] = None,
    search_button: Optional[Dict[str, str]] = None,
    trigger: Optional[str] = None,
    conditions: Optional[List[Dict[str, Any]]] = None,
    human_like: Optional[Dict[str, Any]] = None,
) -> List[Dict[str, Any]]:
    """
    生成检索操作的 action_detail 序列。

    Args:
        keyword: 搜索关键词
        mode: simple|keyword|advanced|filter|date_range
        search_input: 搜索框定位 { label, selector }
        search_button: 搜索按钮定位 { text, selector, role, name }
        trigger: button|enter|null(使用默认)
        conditions: 高级检索条件 [{ label, value, field_type }]
        human_like: 可选覆盖延迟参数

    Returns:
        action_detail 列表
    """
    cfg = HumanLikeConfig(human_like)
    actions: List[Dict[str, Any]] = []

    actions.append(make_wait(200, "等待搜索区域渲染"))

    if mode == "simple":
        _gen_simple_search(actions, keyword, search_input, search_button, cfg)

    elif mode == "keyword":
        _gen_keyword_search(actions, keyword, search_input, cfg)

    elif mode == "advanced":
        _gen_advanced_search(actions, conditions or [], keyword, search_input, search_button, cfg)

    elif mode == "filter":
        _gen_filter_search(actions, conditions or [], search_button, cfg)

    elif mode == "date_range":
        _gen_date_range_search(actions, conditions or [], search_button, cfg)

    # 搜索后等待结果
    actions.append(make_wait(cfg.random_ms("wait_after_action_ms") + 300, "等待搜索结果加载"))

    return actions


def _gen_simple_search(actions, keyword, search_input, search_button, cfg):
    """简单搜索：输入 → 点击搜索按钮"""
    input_label = (search_input or {}).get("label", "搜索")
    input_selector = (search_input or {}).get("selector")

    actions.append(make_click(
        selector=input_selector, role="textbox", name=input_label,
        description=f"点击搜索框「{input_label}」",
    ))
    if keyword:
        actions.append(make_fill(
            selector=input_selector, text=keyword,
            description=f"输入搜索关键词「{keyword}」",
        ))

    # 点击搜索按钮
    btn_text = (search_button or {}).get("name", (search_button or {}).get("text", "搜索"))
    btn_selector = (search_button or {}).get("selector")
    actions.append(make_click(
        selector=btn_selector, role="button", name=btn_text,
        description=f"点击搜索按钮「{btn_text}」",
    ))


def _gen_keyword_search(actions, keyword, search_input, cfg):
    """关键词搜索：输入 → 回车"""
    input_label = (search_input or {}).get("label", "搜索")
    input_selector = (search_input or {}).get("selector")

    actions.append(make_click(
        selector=input_selector, role="textbox", name=input_label,
        description=f"点击搜索框「{input_label}」",
    ))
    if keyword:
        actions.append(make_fill(
            selector=input_selector, text=keyword,
            description=f"输入关键词「{keyword}」",
        ))
    actions.append(make_key("Enter", "按回车执行搜索"))


def _gen_advanced_search(actions, conditions, keyword, search_input, search_button, cfg):
    """高级检索：可展开区域 → 多条件填写 → 查询"""
    # 如果有展开按钮，先展开
    expand_btn = (search_button or {}).get("expand_text", "高级检索")
    if expand_btn:
        actions.append(make_click(
            role="button", name=expand_btn,
            description=f"点击展开「{expand_btn}」区域",
        ))
        actions.append(make_wait(300, "等待检索区域展开"))

    # 逐个填写检索条件
    for cond in conditions:
        cond_label = cond.get("label", "")
        cond_value = cond.get("value", "")
        cond_type = cond.get("field_type", "text")
        _gen_condition_input(actions, cond_label, cond_value, cond_type, cfg)

    # 点击查询按钮
    btn_text = (search_button or {}).get("name", (search_button or {}).get("text", "查询"))
    btn_selector = (search_button or {}).get("selector")
    actions.append(make_click(
        selector=btn_selector, role="button", name=btn_text,
        description=f"点击查询按钮「{btn_text}」",
    ))


def _gen_filter_search(actions, conditions, search_button, cfg):
    """条件筛选：逐个设置筛选项 → 查询"""
    for cond in conditions:
        cond_label = cond.get("label", "")
        cond_value = cond.get("value", "")
        cond_type = cond.get("field_type", "select")

        if cond_type == "select":
            actions.append(make_click(
                role="combobox", name=cond_label,
                description=f"点击筛选项「{cond_label}」",
            ))
            actions.append(make_wait(200, "等待选项展开"))
            actions.append(make_click(
                role="option", name=cond_value,
                description=f"选择「{cond_value}」",
            ))
            actions.append(make_wait(cfg.random_ms("wait_after_action_ms"), "等待筛选生效"))

        elif cond_type == "checkbox":
            actions.append(make_click(
                role="checkbox", name=cond_value,
                description=f"勾选「{cond_value}」",
            ))

    btn_text = (search_button or {}).get("name", (search_button or {}).get("text", "查询"))
    actions.append(make_click(
        role="button", name=btn_text,
        description=f"点击查询按钮「{btn_text}」",
    ))


def _gen_date_range_search(actions, conditions, search_button, cfg):
    """日期范围检索"""
    for cond in conditions:
        cond_label = cond.get("label", "")
        cond_value = cond.get("value", "")

        if cond_type == "date":
            actions.append(make_click(
                role="textbox", name=cond_label,
                description=f"点击日期框「{cond_label}」",
            ))
            actions.append(make_fill(
                text=cond_value,
                description=f"输入日期「{cond_value}」",
            ))
            actions.append(make_key("Escape", "关闭日期面板"))

        elif cond_type == "date_range":
            # 尝试拆分日期范围 "2026-01-01~2026-09-21"
            parts = cond_value.split("~") if "~" in cond_value else [cond_value, ""]
            actions.append(make_click(
                role="textbox", name=f"{cond_label}开始",
                description=f"点击开始日期「{cond_label}」",
            ))
            actions.append(make_fill(text=parts[0], description=f"输入开始日期"))
            actions.append(make_key("Escape", "关闭日期面板"))
            if len(parts) > 1 and parts[1]:
                actions.append(make_click(
                    role="textbox", name=f"{cond_label}结束",
                    description=f"点击结束日期",
                ))
                actions.append(make_fill(text=parts[1], description="输入结束日期"))
                actions.append(make_key("Escape", "关闭日期面板"))

    btn_text = (search_button or {}).get("name", (search_button or {}).get("text", "查询"))
    actions.append(make_click(
        role="button", name=btn_text,
        description=f"点击查询按钮「{btn_text}」",
    ))


def _gen_condition_input(actions, label, value, field_type, cfg):
    """为单个检索条件生成输入动作"""
    if field_type == "select":
        actions.append(make_click(
            role="combobox", name=label,
            description=f"点击条件「{label}」",
        ))
        actions.append(make_wait(200, "等待选项"))
        actions.append(make_click(role="option", name=value, description=f"选择「{value}」"))
    elif field_type == "date":
        actions.append(make_click(role="textbox", name=label, description=f"点击日期「{label}」"))
        actions.append(make_fill(text=value, description=f"输入日期「{value}」"))
        actions.append(make_key("Escape", "关闭日期面板"))
    else:
        actions.append(make_click(role="textbox", name=label, description=f"点击「{label}」"))
        actions.append(make_fill(text=value, description=f"输入「{value}」"))
