# op-browser 并发契约（v2.5）

> 配套 SKILL.md「并发契约」章节的专文：锁机制细则、原子写约定、run_id 规范、
> 产物目录、接续与恢复、向后兼容矩阵。供排查与扩展引用。

## 1. 锁机制细则

### 1.1 三层锁

| 锁 | 实现 | 粒度 | 用途 |
|----|------|------|------|
| 文件写锁 `_file_lock` | msvcrt.locking（Windows）/ 进程内退避 | 单文件 | task.json/flow/script/baselines/result/log 跨进程写互斥 |
| 缓存锁 `_CACHE_LOCK` | threading.Lock | 进程内 | _TASK_CACHE 线程安全（LRU/mtime 语义不变） |
| resume 互斥锁 `.resume.lock` | O_CREAT\|O_EXCL + 陈旧兜底 | 单 run | 防双进程同时接续同一 run |

锁序：`_FILE_LOCK` → `_CACHE_LOCK`（无环：写路径锁内不触碰缓存，用 `_read_task_uncached`）。

### 1.2 msvcrt 文件锁要点

- 锁文件：与目标文件同目录的 `<name>.lock`（同卷、不污染目标目录结构）
- **常驻不删除**：删除会造成 ABA 竞态（A 持锁时 B 删锁、C 新建并持锁 → A/C 同时持锁）
- 进程崩溃自动释放（句柄关闭），无陈旧锁问题
- 锁区域：文件第 0 字节（空文件先写入 1 字节 `\0`）
- 非阻塞 + 重试：`LK_NBLCK` 失败 sleep 0.05s 重试，默认超时 10s 抛 TimeoutError（诚实报错）
- **平台**：msvcrt 仅 Windows；其他平台 `_HAS_MSVCRT=False` 退化为纯进程内锁

### 1.3 原子写约定

- 临时文件：`<dir>/.<name>.tmp-<pid>-<tid>`（同目录保证同卷，os.replace 原子）
- Windows 读方默认共享打开目标（无 FILE_SHARE_DELETE）时 replace 可能 EACCES(13)：
  已实现 ≤1s 短重试（sleep 0.02s）消除
- 进程崩溃残留 `.tmp-*`：下次写覆盖（同 pid 复用）或 finally 清理

## 2. run_id 规范与产物目录

### 2.1 run_id

- 格式：`run-YYYYmmdd-HHMMSS-xxxx`（`new_run_id()`，4 hex 随机）
- 合法性：`^[A-Za-z0-9._-]{1,80}$`（`_safe_run_id` 校验，防路径穿越）
- 全局唯一（时间戳 + 随机）；**不含任务名**（防中文/穿越）
- `run_id_short` = 尾部 4 hex，用于会话名后缀 `{任务名}#r{短标识}`

### 2.2 产物布局

```
tasks/runs/<run_id>/
├── meta.json        # task/adapter/judge/success/project/system/module/时间
├── result.json      # BrowserResult 序列化（含 data/extra，extra 透传 run_id）
├── run_state.json   # 断点状态（next_step/heartbeat/step_checks/results/warnings）
├── run.log          # 本 run 全量日志（write_log run_id= 双写）
├── taskset.log      # 编排日志（write_taskset_log run_id=）
└── shots/           # step_XX.png / final.png
```

### 2.3 新旧文件回退

| 场景 | 路径 |
|------|------|
| 无 run_id（旧调用方） | `tasks/_test_results.json` / `tasks/taskset.log` / `%TEMP%\op_browser_shots\*` |
| run_id 非空 | `tasks/runs/<run_id>/result.json` 等 |
| `load_test_results()` 无参 | runs/ 最新（目录字典序=时间序）优先，回退旧文件 |

## 3. 接续与恢复（三档）

| 档位 | 语义 | 关键机制 |
|------|------|---------|
| A 会话级 | 复用 Bridge 分组/tab | `find_or_create_session(name="{任务名}#r{短标识}", exclusive=True)`；`_names_match(strict=True)` 仅全等；`_parse_run_name` 解析 `#r` 后缀 |
| B 任务级 | 断点续跑 | `run_state.json.next_step`；每步原子落盘；断点前 step_checks/results 恢复；`flow_fingerprint`（steps+url_resolution sha256）防资产变更 |
| C run 级 | 命名空间复用 | resume 复用同一 `runs/<run_id>/`；`run status` 发现（stale = running 且心跳 >600s） |

### 3.1 resume 会话绑定

1. 优先 `attach_session(run_state.session_id)` 直连（最快最准）
2. 失效 → `find_or_create_session(allow_new=False, exclusive=True)` strict 名字兜底
3. 仍不命中 → 报"会话已失效"，**绝不静默新建分组**（防串线）

### 3.2 互斥与安全闸

- `.resume.lock` O_EXCL 抢占；陈旧锁（mtime >600s）删除重抢
- stale 阈值 `OP_BROWSER_RUN_STALE_SECONDS`（默认 600）
- interrupted 显式可恢复；新鲜 running 不可恢复（防双进程接续）；
  failed 需 `--force`；completed 步骤已全跑完时 `--force` 仍会报「无可续步骤」

### 3.3 CDP 尽力续跑

CDP 每 run 新浏览器（无持久页面状态），接续降级为脚本级：`resume_ctx={"next_step": N}`
注入脚本命名空间，脚本可选 `run(client, resume_ctx=None)` 自行决定跳过前置步骤。
**仅当步骤 URL/动作幂等时可跳过**；默认建议 CDP 场景直接重跑。

## 4. 向后兼容矩阵（要点）

| 项 | 改动后 | 兼容措施 |
|----|--------|---------|
| `SmartBrowser.run(name, ...)` | 追加 `run_id/lease/resume/force` 关键字（默认旧行为） | run_id 空 = 不建 runs/、截图走 %TEMP% |
| `taskset(names, sequential=True)` | 顺序分支零改动 | 不透传 lease/run_id |
| `taskset(..., sequential=False)` | 并行守卫（allow_new 强制）+ 自动 run_id | 返回类型/顺序不变 |
| `run`/`taskset` CLI | 新增 `--parallel/--new/--run-id/--resume/--force/--project/...` | 缺省路径与旧行为一致 |
| `write_test_results(results)` | 新增 `run_id=""` 关键字 | 旧调用写旧文件 |
| `load_test_results()` | 无参 = 最新（runs 优先 + 旧文件回退） | 顺序场景读到同一数据 |
| `save_task/save_flow/.../update_task` | 内部原子写+锁，签名不变 | 调用方零改动 |
| `BrowserAdapter.screenshot` | 抽象加 `out_path=""` | 默认空 = 旧默认路径 |
| `Config` 类属性 | → property（环境变量运行时生效） | setter 兼容外部赋值，默认值全同 |
| `ModeSelector.resolve` | 加 `lease/force_recheck` 关键字 | 管理命令路径行为不变 |

## 5. 已知限制

- 同源不同账号勿并行（Chrome storage 级共享）；`verify.account_key` 配置化兜底（默认关闭）
- 同一任务名并行 run：计数安全，但资产固化（写）与回放应错开
- 锁文件常驻（<10B，gitignore 覆盖）；跨进程锁仅 Windows
