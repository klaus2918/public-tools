# 交互经验库规范 (Experience Library)

> 版本: 1.0.0 | 创建: 2026-09-21 | 补充 SKILL.md | 适用: op-browser v3.5+

## 1. 定位

经验库是 op-browser 引擎的 **元能力层**，提供可复用的页面交互模式（patterns），用于：

1. **快速编排** — 从模式模板生成 `action_detail` 序列，无需从零编写
2. **默认行为** — 引擎按「模拟人工」策略执行，通过点击菜单/按钮导航而非路由直接跳转
3. **知识沉淀** — 积累通用交互经验（表单填写、下拉选择、检索操作等）

**核心设计原则**：默认模拟人工操作 → 通过点击菜单、按钮等进行页面操作 → 而不是通过路由直接切换。

## 2. 与引擎的关系

```
experience/generators/*.py     ← Python 辅助生成器（可选）
  └─ 生成 action_detail[]     ← 引擎回放的动作序列
       └─ engine._replay_action()  ← 支持 click/fill/type/key/select/scroll/hover/wait
            └─ human_like_delay_ms  ← 动作间自动 sleep（v3.5 新增）
```

体验库 **不侵入** 引擎核心，而是：
- 提供模式描述文件（YAML）定义动作序列模板
- 提供 Python 辅助函数生成标准化 `action_detail`
- 引擎通过新增动作类型（`select`/`scroll`/`hover`/`wait`）直接支持模式所需的基础操作
- 引擎通过 `human_like_delay_ms` 字段支持动作间仿人工延迟

## 3. 目录结构

```
experience/
├── README.md                    ← 经验库总体说明
├── INDEX.md                     ← 模式索引：分类、标签、快速查找
├── patterns/                    ← 模式定义（YAML）
│   ├── form-fill.yaml           ← 表单填写模式
│   ├── dropdown-select.yaml     ← 下拉选择模式
│   ├── search-filter.yaml       ← 检索输入与搜索模式
│   ├── menu-navigate.yaml       ← 菜单导航模式
│   ├── button-action.yaml       ← 按钮操作与确认模式
│   └── table-interact.yaml      ← 表格操作模式
└── generators/                  ← Python 辅助生成器
    ├── __init__.py
    ├── common.py                ← 公共工具（HumanLikeConfig、选择器工具、action 构造器）
    ├── form_fill.py             ← 表单填写生成器
    ├── dropdown.py              ← 下拉选择生成器
    ├── search.py                ← 检索操作生成器
    └── menu.py                  ← 菜单导航生成器
```

## 4. 引擎新动作类型（v3.5）

| 动作类型 | 说明 | 定位方式 | 参数 |
|---------|------|---------|------|
| `select` | 选择下拉选项 | selector / role+name | `value`: 选项值 |
| `scroll` | 页面/元素滚动 | selector（可选） | `direction`: up/down/left/right, `amount`: 像素 |
| `hover` | 鼠标悬停 | selector / role+name | — |
| `wait` | 显式等待 | — | `wait_ms`: 等待毫秒数 |
| `human_like_delay_ms` | 动作前延迟（适用于所有动作） | — | 毫秒数（随机范围由生成器设定） |

### 降级策略

新动作类型内置适配器降级：
- **select**：adapter 无 `select_option` → 降级 click(value)
- **scroll**：adapter 无 `scroll_by` → 降级 `page.evaluate("window.scrollBy(...)")`
- **hover**：adapter 无 `hover` → 降级 `page.hover(selector)`

## 5. Human-Like 参数体系

| 参数 | 范围 (ms) | 说明 | 应用场景 |
|------|-----------|------|----------|
| `typing_delay_ms` | [20, 80] | 打字间隔（每个字符） | fill/type 动作 |
| `click_delay_ms` | [80, 300] | 点击前延迟 | click 动作 |
| `hover_delay_ms` | [200, 500] | 悬停展开等待 | hover 动作 |
| `wait_after_action_ms` | [150, 600] | 动作后等待 | 所有动作后 |
| `thinking_pause_ms` | [500, 1500] | 字段间"思考"停顿 | form-fill 字段间 |
| `confirm_pause_ms` | [500, 1000] | 确认前停顿 | button-action 确认前 |
| `level_gap_ms` | [300, 800] | 级联下拉层级间等待 | dropdown cascading |

延迟通过两种方式应用：
1. **YAML 模式定义**：`human_like` 字段声明延迟范围
2. **action_detail**：`human_like_delay_ms` 字段由 `generators/common.py` 的 `HumanLikeConfig.random_ms()` 生成

## 6. 模式文件规范（YAML）

```yaml
id: pattern-unique-id
name: 模式显示名
category: form | dropdown | search | navigation | action | table
version: "1.0.0"
description: 一句话描述
tags: [标签]

prerequisites: []          # 前置条件
defaults: {}               # 默认参数
human_like: {}             # 仿人工延迟参数
actions: []                # 标准动作序列模板
parameters: {}             # 参数化接口定义
selector_priority: []      # 选择器优先级链
validation: {}             # 校验规则
```

## 7. Python 生成器 API

```python
# 表单填写
from experience.generators.form_fill import generate_form_actions
actions = generate_form_actions(fields=[...], submit_button={...})

# 下拉选择
from experience.generators.dropdown import generate_dropdown_actions
actions = generate_dropdown_actions(target={...}, value="选项文本")

# 检索操作
from experience.generators.search import generate_search_actions
actions = generate_search_actions(keyword="关键词", mode="simple")

# 菜单导航
from experience.generators.menu import generate_menu_actions
actions = generate_menu_actions(menu_path=[{text: "一级"}, {text: "二级"}])
```

## 8. 约束与红线

| 约束 | 说明 |
|------|------|
| 体验库不侵入引擎核心 | 模式定义层，不修改引擎执行逻辑 |
| 不引入 LLM/API 依赖 | 纯确定性生成，零 Token 消耗 |
| 模式文件 YAML 格式 | 人类可读、可版本控制 |
| 生成器可选 | 不强制使用，可在 flow.json 中直接编写 action_detail |
| adapter 降级优先 | 新动作类型必须有降级路径 |
