# CDP 操作参考

> 通用 CDP（Chrome DevTools Protocol）操作模式。
> 对应 `cdputil.py` 中封装的高层 API，本文档解释"什么时候用什么、为什么"。

---

## 1. 标签页管理

```python
client = CDPClient()
await client.connect(cdp_url=URL)

# 当前标签页信息
info = await client.page_info()
# → {url, title, w, h, sx, sy, pw, ph}

# 打开新标签页
await client.new_tab("https://example.com")

# 关闭当前标签页
await client.close_tab()
```

**关键点**：
- `page_info()` 返回当前标签页的 URL、标题、视口尺寸、滚动位置、页面尺寸
- 新标签页创建后自动成为当前页
- 浏览器 CDP target ID 在浏览器重启后会变化，连接时自动获取

---

## 2. 截图

```python
# 视口截图（默认）
path = await client.screenshot()

# 全页截图（含滚动区域）
path = await client.screenshot_full()
```

**对比**：

| 类型 | 适用场景 | 文件大小 | 差异对比适用性 |
|------|---------|---------|--------------|
| 视口截图 | 日常校验、AI 视觉理解 | 较小 | ✅ 推荐基线 |
| 全页截图 | 完整页面归档 | 较大 | ⚠️ 动态区域多易误报 |

**校验规则**（与 `snapshot.py` 对应）：
- `<5%` 差异 → pass
- `5%~20%` → warn（告警但继续）
- `>=20%` → fail（v2.4 无 AI 自愈，返回失败由人工排查后重固化）

---

## 3. 点击操作

```python
# 元素选择器点击（Playwright 标准）
await client.click("button.submit")

# 坐标点击（穿透 iframe / Shadow DOM / 跨域）
await client.click_xy(350, 280)

# 按键
await client.press_key("Enter")
await client.press_key("Tab")
await client.press_key("Escape")
```

**选择策略**：

| 场景 | 推荐方式 | 原因 |
|------|---------|------|
| 元素有明确 selector | `click(selector)` | Playwright 自动等待、滚动到视口 |
| 元素在 iframe 内 | `click_xy(x, y)` | CDP 合成器级，天然穿透 iframe |
| 元素被 Shadow DOM 包裹 | `click_xy(x, y)` | 同上 |
| 跨域 iframe | `click_xy(x, y)` | 坐标点击不依赖 DOM 访问 |
| 无可见几何的元素 | `click(selector)` | 坐标无法定位零尺寸元素 |

**优先策略**：先尝试 `click(selector)`，回退到 `click_xy()`。`cdputil.py` 提供两种方法，调用方自己决定。

---

## 4. 文本输入

```python
# 方式一：框架感知输入（推荐，触发 input/change 事件）
await client.fill("input#title", "值内容")

# 方式二：原始 CDP 输入（绕过框架，适合不可控输入框）
await client.type_text("值内容")

# 方式三：按键组合
await client.press_key("Backspace")
```

| 方式 | 触发 Vue v-model | 触发 React onChange | 适用 |
|------|-----------------|-------------------|------|
| `fill()` | ✅ | ✅ | 常规表单输入 |
| `type_text()` | ❌ | ❌ | 无框架的 input、验证码输入框 |
| `press_key()` | 取决于框架 | 取决于框架 | 快捷键、组合键 |

**常见陷阱**：
- 只设置 DOM value 不触发 `input` 事件 → Vue/React 不会感知值变化
- `fill()` 内部已处理 clear + 触发事件 + dispatchEvent，一行搞定
- 复杂的富文本编辑器可能需用 `js()` 直接调用编辑器 API

---

## 5. JavaScript 执行

```python
# 获取值
title = await client.js("document.title")
text = await client.text("div.content")
attr = await client.attr("a.link", "href")

# 执行复杂表达式
result = await client.js("JSON.stringify({a: 1, b: 2})")

# 等待元素出现
found = await client.wait_for_selector("div.loaded", timeout=5.0)
```

**限定**：
- `js()` 返回的值必须是可 JSON 序列化的
- 如需操作不可序列化的 DOM 对象，用 `text()`/`attr()`
- `wait_for_selector()` 适用于 SPA 异步渲染场景

---

## 6. 等待与时机

```python
# 等待页面完全加载（networkIdle）
await client.wait_for_load()

# 等待元素出现（SPA 异步渲染）
found = await client.wait_for_selector("div.content", timeout=10.0)

# 固定等待（最后手段）
await client.wait(1.0)
```

**等待策略优先级**：
1. ✅ `wait_for_load()` — 页面/路由切换后最常用
2. ✅ `wait_for_selector()` — 目标元素出现即可，不等所有资源
3. ⚠️ `wait()` — 仅当前两种不适用时使用

---

## 7. 连接管理

```python
# 连接已有 Chrome（优先）
client = CDPClient()
await client.connect(cdp_url="ws://127.0.0.1:9222/...")

# 自动发现（扫描 9222/9223/9224）
client = CDPClient()
await client.connect()  # 自动 find_cdp_url()

# 启动新浏览器（无已有 Chrome 时）
client = CDPClient()
await client.connect()  # 无 CDP URL → 自动启动 playwright chromium
```

**连接逻辑**（cdputil.py 内置）：
1. 传入 `cdp_url` → 直接 connect_over_cdp
2. 不传 → 自动扫描 9222/9223/9224 端口发现已有 Chrome
3. 没发现 → 启动新的 Playwright Chromium

---

## 8. run 模式中的 CDP 使用

在 `SmartBrowser.run()` 内部，CDP 的使用方式是：

```
engine.run() → 加载 tasks/<任务名>/script.py
              → 传入 CDPClient 实例
              → script.py 调用 client.click/fill/js 等
              → 截图校验 → 返回结果
```

业务 Skill **不需要**直接使用 CDPClient。业务 Skill 的代码里只有：

```python
from op_browser import SmartBrowser
result = await SmartBrowser().run("任务名")
```

CDPClient 是引擎内部层，不是业务层的 API。
