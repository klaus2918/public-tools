"""
op_browser / project_runner.py — BrowserProjectRunner

项目级 E2E 测试执行器。
按 project/system/module 三层上下文加载 system-adapter，将 cases.yaml 中的场景
映射到固化任务（flow/script）并回放执行。
"""
from .project import ProjectRegistry
from .engine import SmartBrowser
from . import task_store as store


class BrowserProjectRunner:
    """项目级 E2E 测试执行器。

    用法:
        runner = BrowserProjectRunner(projects_dir="projects/")
        cases = await runner.list_cases("demo-project", "demo-project-pc", "party-group-topic")
        result = await runner.run_case("demo-project", "demo-project-pc", "party-group-topic")
    """

    def __init__(self, projects_dir: str | None = None,
                 browser: SmartBrowser | None = None):
        self.registry = ProjectRegistry(projects_dir)
        self._browser = browser or SmartBrowser()

    async def list_cases(self, project: str, system: str = "",
                         module: str = "") -> list[dict]:
        """列出指定上下文下的可用测试场景。

        返回: [{"name", "description", "path", "has_spec", "has_data"}, ...]
        """
        if module:
            modules = await self.registry.get_modules(project, system)
            # 有 cases.yaml 时返回 case 级执行清单（唯一执行源）
            cases_meta = await self.registry.load_cases(project, system, module)
            if cases_meta:
                mod = next((m for m in modules if m["name"] == module), {})
                return [
                    {
                        "name": c["id"],
                        "description": c["name"],
                        "path": mod.get("path", ""),
                        "has_spec": mod.get("has_spec", False),
                        "has_data": mod.get("has_data", False),
                        "task": c["task"],
                        "pending": c["pending"],
                        "adapter": c["adapter"],
                    }
                    for c in cases_meta
                ]
            cases = []
            for m in modules:
                if m["name"] == module or not module:
                    cases.append({
                        "name": m["name"],
                        "description": "",
                        "path": m["path"],
                        "has_spec": m.get("has_spec", False),
                        "has_data": m.get("has_data", False),
                    })
            return cases
        elif system:
            modules = await self.registry.get_modules(project, system)
            return [
                {
                    "name": m["name"],
                    "description": "",
                    "path": m["path"],
                    "has_spec": m.get("has_spec", False),
                    "has_data": m.get("has_data", False),
                }
                for m in modules
            ]
        else:
            # 列出项目下所有系统的所有模块
            systems = await self.registry.get_systems(project)
            cases = []
            for s in systems:
                for m in s.get("modules", []):
                    cases.append({
                        "name": m["name"],
                        "system": s["name"],
                        "path": m["path"],
                        "has_spec": m.get("has_spec", False),
                        "has_data": m.get("has_data", False),
                    })
            return cases

    async def run_case(self, project: str, system: str,
                       module: str, adapter: str = "",
                       case_name: str = "") -> dict:
        """执行单个测试场景。

        流程:
        1. 加载 system-adapter → 环境配置/路由/按钮别名
        2. case_name 命中 cases.yaml 时映射到固化任务与适配器（未命中诚实报错）
        3. 注入 adapter 配置到浏览器上下文
        4. 回放固化任务（flow/script）并截图校验
        5. 返回结果

        参数:
            project: 项目名
            system: 系统名
            module: 模块名
            adapter: 适配器偏好（空 = 自动选择）
            case_name: 场景名（空 = 执行模块全部场景）
        """
        # 1. 加载系统上下文
        ctx = await self.registry.resolve_case(project, system, module)

        # 1b. case_name 命中 cases.yaml 时，按 case 映射到固化任务与适配器
        task_name = module
        if case_name:
            cases = await self.registry.load_cases(project, system, module)
            if cases:
                hit = next((c for c in cases
                            if c["id"] == case_name or c["name"] == case_name), None)
                if hit is None:
                    available = "、".join(c["id"] for c in cases)
                    return {
                        "project": project, "system": system, "module": module,
                        "success": False,
                        "error": f"用例「{case_name}」不存在。可用: {available}",
                        "judge": "skip", "diff_rate": 0.0, "adapter": "",
                    }
                if hit["pending"]:
                    return {
                        "project": project, "system": system, "module": module,
                        "success": False,
                        "error": (f"用例「{case_name}」映射任务「{hit['task']}」未固化"
                                  "（cases.yaml 标注 pending）。请先固化后回填 task 字段。"),
                        "judge": "skip", "diff_rate": 0.0, "adapter": "",
                    }
                task_name = hit["task"]
                if hit["adapter"]:
                    adapter = hit["adapter"]

        # 1c. 任务就绪校验：未固化时给出清晰报错（指向固化工具链）
        meta = store.load_task(task_name)
        if meta.get("status") != "ready":
            return {
                "project": project,
                "system": system,
                "module": module,
                "success": False,
                "error": (
                    f"用例映射任务「{task_name}」未就绪（状态: {meta.get('status')}）。"
                    "请先固化该任务（flow/script 资产就绪，或调用固化工具链）再执行 test。"
                ),
                "judge": "skip",
                "diff_rate": 0.0,
                "adapter": "",
            }

        # 2. 执行
        result = await self._browser.run(
            name=task_name,
            project=project,
            system=system,
            module=module,
            adapter=adapter,
        )

        return {
            "project": project,
            "system": system,
            "module": module,
            "success": result.success,
            "data": result.data,
            "judge": getattr(result, "judge", "?"),
            "diff_rate": getattr(result, "diff_rate", 0.0),
            "adapter": getattr(result, "adapter", ""),
        }

    async def run_module(self, project: str, system: str,
                         module: str, adapter: str = "") -> list[dict]:
        """执行某模块的全部场景。

        cases.yaml 的 case 级清单（含 task 字段）：run_case 按 case_name
        解析映射任务；模块级清单（无 cases.yaml，name 即模块名）：维持
        原 module 位传参。
        """
        cases = await self.list_cases(project, system, module)
        results = []
        for case in cases:
            if case.get("task") is not None:
                r = await self.run_case(project, system, module, adapter,
                                        case["name"])
            else:
                r = await self.run_case(project, system, case["name"], adapter)
            results.append(r)
        return results

    async def run_all(self, project: str) -> list[dict]:
        """执行指定项目下所有场景。"""
        results = []
        systems = await self.registry.get_systems(project)
        for s in systems:
            for m in s.get("modules", []):
                r = await self.run_module(project, s["name"], m["name"])
                results.extend(r)
        return results

    async def test_run(self, domain: str, case: str = "",
                       adapter: str = "") -> list[dict]:
        """通用的 test 入口：domain 支持 project/system/module 格式。

        示例:
            test_run("demo-project")                  → 项目级
            test_run("demo-project/demo-project-pc")         → 系统级
            test_run("demo-project/demo-project-pc/topic")   → 模块级
        """
        parts = domain.split("/")
        results: list[dict] = []
        if len(parts) == 1:
            results = await self.run_all(parts[0])
        elif len(parts) == 2:
            systems = await self.registry.get_systems(parts[0])
            for s in systems:
                if s["name"] == parts[1]:
                    for m in s.get("modules", []):
                        r = await self.run_module(parts[0], parts[1], m["name"], adapter)
                        results.extend(r)
                    break
        else:
            if case:
                results = [await self.run_case(
                    parts[0], parts[1], parts[2], adapter, case)]
            else:
                results = await self.run_module(
                    parts[0], parts[1], parts[2], adapter)
        # 落盘最近一次测试结果（供 CLI test result 查询）
        store.write_test_results(results)
        return results
