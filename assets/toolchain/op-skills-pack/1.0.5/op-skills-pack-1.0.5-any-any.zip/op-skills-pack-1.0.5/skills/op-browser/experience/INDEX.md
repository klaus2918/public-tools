# op-browser 交互经验库索引 (Experience Library Index)
#
> 版本: 1.0.0 | 创建: 2026-09-21 | 适用: op-browser v3.4+

## 经验库概览

经验库提供 6 类可复用的页面交互模式（patterns），覆盖 Web 应用最常见的操作场景：

| # | 模式 ID | 名称 | 分类 | 文件 | 核心能力 |
|---|---------|------|------|------|----------|
| 1 | `form-fill` | 表单填写 | form | `patterns/form-fill.yaml` | 逐字段填写、多控件类型、提交校验 |
| 2 | `dropdown-select` | 下拉选择 | dropdown | `patterns/dropdown-select.yaml` | 原生/自定义/级联/可搜索下拉 |
| 3 | `search-filter` | 检索输入与搜索 | search | `patterns/search-filter.yaml` | 简单/高级/条件组合/日期范围检索 |
| 4 | `menu-navigate` | 菜单导航 | navigation | `patterns/menu-navigate.yaml` | 顶部/侧边/右键/面包屑/标签页导航 |
| 5 | `button-action` | 按钮操作与确认 | action | `patterns/button-action.yaml` | 按钮点击、确认对话框、结果校验 |
| 6 | `table-interact` | 表格操作 | table | `patterns/table-interact.yaml` | 行选择、行操作、排序、分页、展开 |

## 按场景速查

### 表单类操作
- **填写文本输入** → `form-fill` (field_type: text)
- **填写密码框** → `form-fill` (field_type: password)
- **填写多行文本** → `form-fill` (field_type: textarea)
- **勾选复选框** → `form-fill` (field_type: checkbox)
- **选择单选按钮** → `form-fill` (field_type: radio)
- **选择下拉框** → `form-fill` (field_type: dropdown/combobox) 或独立使用 `dropdown-select`
- **填写日期** → `form-fill` (field_type: date) 或 `search-filter` (mode: date_range)
- **提交表单** → `button-action` (scenario: submit)

### 查询类操作
- **简单搜索** → `search-filter` (mode: simple)
- **回车搜索** → `search-filter` (mode: keyword)
- **高级检索（多条件）** → `search-filter` (mode: advanced)
- **下拉筛选** → `search-filter` (mode: filter)
- **日期范围筛选** → `search-filter` (mode: date_range)
- **表格内搜索** → `table-interact` (operation: search)

### 导航类操作
- **点击顶部菜单** → `menu-navigate` (menu_type: horizontal)
- **点击侧边菜单** → `menu-navigate` (menu_type: vertical)
- **面包屑返回** → `menu-navigate` (menu_type: breadcrumb)
- **切换标签页** → `menu-navigate` (menu_type: tab)

### 数据表格操作
- **选择行** → `table-interact` (operation: select_row)
- **编辑行** → `table-interact` (operation: row_action, action: edit)
- **删除行** → `table-interact` (operation: row_action, action: delete)
- **查看详情** → `table-interact` (operation: row_action, action: view)
- **列排序** → `table-interact` (operation: sort)
- **翻页** → `table-interact` (operation: paginate)

### 确认与反馈
- **点击按钮** → `button-action` (scenario: custom)
- **确认操作** → `button-action` (scenario: confirm)
- **取消/关闭** → `button-action` (scenario: cancel)
- **处理弹窗确认** → `button-action` (confirm_dialog)

## 模式组合示例

### 示例：收文登记完整流程
```yaml
steps:
  - pattern: menu-navigate
    menu_path: [{ text: "收文管理" }, { text: "收文登记" }]
  - pattern: form-fill
    fields:
      - { label: "来文机关", value: "市交通局", field_type: dropdown }
      - { label: "文件标题", value: "关于XX的函", field_type: text }
      - { label: "收文日期", value: "2026-09-21", field_type: date }
      - { label: "备注", value: "请尽快处理", field_type: textarea }
    submit_button: { text: "保存" }
  - pattern: button-action
    scenario: submit
    button: { text: "确定" }
```

### 示例：查询列表数据
```yaml
steps:
  - pattern: menu-navigate
    menu_path: [{ text: "数据中心" }, { text: "数据列表" }]
  - pattern: search-filter
    mode: advanced
    keyword: "市交通局"
    conditions:
      - { label: "状态", value: "已办结", field_type: select }
      - { label: "日期", value: "2026-01-01~2026-09-21", field_type: date_range }
    search_button: { text: "查询" }
  - pattern: table-interact
    operation: row_action
    row: { text: "市交通局" }
    action: view
```

## 引擎扩展动作

体验库依赖以下引擎新增动作类型（v3.5+）：

| 动作 | 说明 | 引擎支持 |
|------|------|----------|
| `select` | 选择下拉选项（native select / custom） | v3.5 新增 |
| `scroll` | 页面/元素滚动 | v3.5 新增 |
| `hover` | 鼠标悬停（触发 tooltip / 子菜单） | v3.5 新增 |
| `click` | 点击元素 | 已有 |
| `fill` | 填入文本 | 已有 |
| `type` | 直接键入 | 已有 |
| `key` | 键盘按键 | 已有 |
| `wait` | 等待 | v3.5 新增 |

## Human-like 参数说明

所有模式均内置 `human_like` 参数，模拟人工操作节奏：

| 参数 | 范围 (ms) | 说明 |
|------|-----------|------|
| `typing_delay_ms` | [20, 80] | 打字间隔（每个字符） |
| `click_delay_ms` | [80, 300] | 点击前延迟 |
| `wait_after_action_ms` | [150, 600] | 动作后等待 |
| `hover_delay_ms` | [200, 500] | 悬停展开等待 |
| `thinking_pause_ms` | [500, 1500] | 字段间"思考"停顿 |

## 文件结构
```
experience/
├── README.md                  ← 经验库总体说明
├── INDEX.md                   ← 本文件：模式索引与速查
├── patterns/                  ← 模式定义（YAML）
│   ├── form-fill.yaml
│   ├── dropdown-select.yaml
│   ├── search-filter.yaml
│   ├── menu-navigate.yaml
│   ├── button-action.yaml
│   └── table-interact.yaml
└── generators/                ← Python 辅助生成器（可选）
    ├── __init__.py
    ├── common.py              ← 公共工具（延迟参数等）
    ├── form_fill.py
    ├── dropdown.py
    ├── search.py
    └── menu.py
```
