# Bridge 适配器详细规范

> 本文档是 op-browser Bridge 适配器的完整技术规范，SKILL.md 的补充文档。

---

## Python API（Bridge 相关）

### 强制用 Bridge（a11y 定位更稳定）

```python
from op_browser import SmartBrowser

browser = SmartBrowser()
result = await browser.run("发文拟稿", adapter="bridge")
```

### BrowserResult Bridge 字段

```python
result.adapter      # "bridge"
result.a11y_tree    # accessibility tree（仅 Bridge 分支填充）
```

---

## Bridge 桥接加速说明（v2.4.1）

### 连接加速

| 场景 | v2.4.0 耗时 | v2.4.1 耗时 | 优化 |
|------|------------|------------|------|
| 首次 run | ~8s（串行 5s+3s） | ~2s（并行 2s） | 4x |
| 后续 run（同进程） | ~8s（每次重连） | ~50ms（快路径 health 1s） | 160x |
| session 查询 | ~50-100ms（O(n) 全量） | ~5ms（缓存命中） | 10-20x |
| HTTP 连接 | ~200ms（TCP 新建） | ~0ms（连接池复用） | ∞ |

### 关键改动

- `connect()` 并行化：health 和 RPC 探测通过 `asyncio.gather` 同时执行
- 快路径：首次完整探测后，后续仅 health 确认（1s 超时，实际 < 5ms）
- 超时缩短：全局 30s→10s，health 5s→2s，RPC 3s→2s
- session 缓存：`list_session_details()` 结果 TTL 5s 缓存
- 全局 ModeSelector：`_shared_bridge` 类级单例，跨 CLI 命令复用连接池

---

## 会话与页签生命周期（v2.6 页签治理）

> 配套专文：`references/tab-governance.md`（生命周期细则 / 账号切换时序 /
> 回收判定 / CDP 与 Bridge 双模式差异 / 兼容矩阵）。

### 规则适用范围（三档）

- **档位 1 全局**（所有路径适用）：同会话单页签默认；run 后回收；
  保留期可配置；`--keep-session` 逃生门。
- **档位 2 顺序路径**（仅 `exclusive=False`）：账号感知复用与页签内重登。
  规则正文均以「仅限非 exclusive 顺序路径」为前置。
- **档位 3 exclusive 路径**（一行不改，显式豁免）：每 run 独立分组/tab、
  `#r` 身份、exclusive strict 全等、同源不复用、接续 attach 原样保留；
  页签治理不改变并发契约（concurrency.md）的隔离语义。

### 1. 默认策略：同会话单页签

一个 run 的默认执行模型是一个会话一个页签；flow/script 内跨步骤导航
一律在当前 tab 内 `goto` 完成（不因换步骤/换 URL 新建 tab）。需要多页签
必须显式声明（`--multi-tab` / flow `tab_policy.multi_tab`）；未声明时
脚本自由 `new_tab` 仅记 WARN 不阻断（兼容存量脚本）。

### 2. 页签复用规则

A 页签处理完需要 B，就在 A 页签内继续 B（导航/重登），不新建 C。
会话级复用由 `find_or_create_session` 保证（同源/同名 + alive）；
run 级不复用 tab。

### 3. 账号切换规范（页签内重登，仅限非 exclusive 顺序路径）

同一会话内切换账号：传 `--login-account <账号> --relogin`，`ensure_login`
在当前 tab 内注入新 token 并复验，不新建 tab。前置条件：项目 adapter.json
配置 `login.verify.account_key` 以启用账号比对（未配置打 WARN 提示，
不阻断）。并行/命名 run 的 `#r` 会话内不做跨账号重登（隔离限制
「同源不同账号勿并行」）。

### 4. run 后回收

run 结束时引擎记录本次会话归属并标记 `idle`；本次新建的分组/页签进入
保留期（默认 `OP_BROWSER_SESSION_RETENTION_SECONDS=86400`，24h），保留期内
可被后续 run 复用（免重新登录），超保留期自动回收（`OP_BROWSER_AUTO_CLEANUP`
默认 true）；复用的既有分组永不回收；`--keep-session` 显式跳过回收。
可接续 run（interrupted / 新鲜 running / resumable）的会话永不回收，
保证接续 A 档不失效。

### 5. 多页签显式例外（唯一例外）

任务资产声明 `tabs: multi`（flow.json 顶层）或 CLI `--multi-tab` 时，
允许会话内新建多个页签；例外下页签可随会话一并回收（不逐个管理）；
`--detach` 显式许可遗弃（展示过程专用），遗弃 tab 标记 `detached`
跳过常规回收，由后续显式清理归属。

### 6. 自动清理

`bridge cleanup` 默认只清陈旧空壳（不变）；`--idle` 加清超保留期存活
分组（reclaimable）；`--since <分钟>` 按最后活跃过滤；`--account <账号>`
按账号过滤；`--exclude-running`（默认 True）跳过可接续/心跳新鲜的
`#r` 会话；`--all` 仍为连存活一起清的显式确认路径。自动回收只针对
「引擎创建的分组」（注册表有记录），`unknown`（注册表无记录）会话
永不自动回收——避免误伤用户手动打开的 tab。

---

## Bridge CLI 命令详解

```bash
# Bridge 诊断
/op-browser bridge status       # 检查 Bridge 健康
/op-browser bridge doctor       # Bridge 环境诊断

# 分组管理
/op-browser bridge groups [--filter <关键词>] [--account <账号>] [--since <分钟>] [--json]
/op-browser bridge cleanup [--name <业务名>] [--all] [--idle] [--since <分钟>] [--account <账号>] [--exclude-running] [--yes]

# 会话与检查
/op-browser bridge inspect --url <url> [--new] [--name <业务名>]
/op-browser bridge session <url> [--new] [--name <业务名>]

# 友好 RPC 调用（免手写 JSON，Windows cmd 安全）
/op-browser bridge rpc session.start --url https://example.com --name 业务名
/op-browser bridge rpc page.navigate --url https://example.com/page
/op-browser bridge rpc session.list
```

> `--new`：无可复用分组时允许自动新建（跳过 CLI 交互确认）；有匹配分组仍照常复用。
> 不传 `--new` 时，默认优先复用已有分组（URL 同源或业务名匹配）；无可复用分组时
> CLI 交互询问是否新建，API 调用返回 `action="suggest_new"` 的决策由调用方确认。
>
> **分组名支持中文**：新建/复用均可传 `--name 业务名`（engine 的 run 会自动
> 用任务名作为业务名）。RPC body 以 `\uXXXX` 转义传输，免疫 Native Messaging
> 中文截断乱码；名字匹配自动剥离扩展的 🤖 前缀。
>
> **分组有效管理**：`bridge groups` 查询全部分组（🟢存活 / ⚪陈旧空壳），
> `bridge cleanup` 默认只清陈旧空壳（安全），`--name` 按业务名清理，
> `--all` 连存活分组一起清理（需二次确认）。注意：扩展侧的 `session.stop`
> 对已无 tab 的空壳分组会报 `tabs.ungroup` 错误，空壳记录无法经 RPC 删除，
> 属于扩展限制（不影响复用决策，决策会标记 stale 并跳过）。

### 标准操作流程（Bridge 模式）

每次使用 Bridge 前，建议走以下三步：

```
Step 1: bridge doctor    → 检查 Bridge 服务+扩展+token
Step 2: bridge status    → 确认桥接健康
Step 3: bridge session   → 启动/复用会话 → 操作页面
```

```bash
# 完整示例
/op-browser bridge doctor        # 1. 诊断
/op-browser bridge status        # 2. 确认健康
/op-browser bridge rpc session.start --url http://example.com --name 业务名  # 3. 启动
/op-browser bridge rpc page.navigate --url http://example.com/login
```

---

## Windows 环境常见问题（FAQ）

### 1. 命令行参数传递

**问题**：Windows cmd 下单引号 `'...'` 不被识别为字符串定界符，JSON 参数拆分。
**解决**：使用 `bridge rpc` 子命令（`--key value` 格式，无需 JSON 字符串）：

```bash
# 错误：Windows cmd 下单引号无效
browser_bridge_client.py rpc session.start '{"url":"http://..."}'

# 正确：用 --key value 格式
/op-browser bridge rpc session.start --url http://example.com --name 业务名
```

### 2. 忘记 justification 被拒绝

**问题**：安全机制要求每次 bash 调用附带 `justification` 参数。
**解决**：通过 `op-browser` CLI 调用（内部已处理），或手动调用时显式添加 `justification`。

### 3. Bridge 连接失败

```bash
# 一键诊断
/op-browser bridge doctor

# 排障步骤
1. 打开 Chrome 扩展 Side Panel → Start Bridge
2. 检查扩展是否安装（chrome://extensions）
3. 检查 Token 文件（~/.browser-agent-bridge.env）
4. 重启 Bridge 扩展
```

### 4. 中文编码问题

Native Messaging 在 Windows GBK 环境下传输中文可能乱码。
- 用 `click_by_ref(ref_id)` 按 ref 编号操作（纯 ASCII）
- 用 CSS 属性选择器 `[data-key="OA_XXX"]` 绕过中文文本
- 用 `adapter="cdp"` 避开 Bridge（CDP 无中文编码问题）

### 5. 工具选择

统一使用 `/op-browser` CLI 入口，不使用 curl / urllib / browser_bridge_client.py 等手动工具。
`bridge rpc` 支持所有 RPC 方法，无需手写 JSON。

---

## Bridge 相关 Red Flags

| Smell | Action |
|-------|--------|
| Bridge 降级后不主动排查 | 降级打印 WARN，应在 `bridge doctor` 检查 Bridge 服务状态 |
| Bridge 中文 locator 失败 | locator.click/dom.click 含中文参数在 Windows GBK 环境可能乱码 → 用 `click_by_ref()` 按 ref 编号操作，或 CSS 属性选择器绕过 |
| Bridge 模式跳过 session 复用 | run 时 Bridge 自动检查已有 session；v2.2 匹配维度为 URL 同源 + 业务名（去 🤖 前缀），且只复用有存活 tab 的分组；不复用 = 每次重复登录（高频问题） |
| Bridge 默认自动新建分组 | v2.2 起默认不新建：`find_or_create_session(allow_new=False)` 无匹配时返回 `suggest_new` 决策，CLI 交互确认或显式 `--new`/`allow_new=True` 后才创建 |
| 陈旧 session 堆积 | tab 关闭后 session 变空壳（`tabIds=[]`），无法复用也不再匹配；决策会标记为 stale 并跳过，可在 `bridge groups` 中查看，`bridge cleanup` 尝试清理（空壳受扩展限制无法 RPC 删除，需扩展侧增强 `session.stop` 容错或新增 `session.delete`） |
| run 后未回收分组（页签堆积） | v2.6 起 run 后本次新建分组进入保留期（默认 24h），超期自动回收；`--keep-session` 显式保留；`bridge cleanup --idle` 手动兜底。遗留会话堆积 = 未治理（旧行为） |
| 每次登录重新打开新页签 | 单页签默认 + 会话复用（同源/同名/账号感知）；`--multi-tab` 仅显式声明时用 |
| 不同账号开新分组导致堆积 | 页签内重登：`--login-account <账号> --relogin`（仅限非 exclusive 顺序路径）；建议配置 `login.verify.account_key` 自动比对 |
| 回收误关执行中的并行会话 | `cleanup`/自动回收只处理 completed/failed 且超保留期会话；`--exclude-running` 默认 True；running/interrupted/resumable 永不回收 |

---

## Bridge 相关 Common Mistakes

- **Windows 控制台 emoji 编码.** CLI 入口已强制 stdout 为 UTF-8。调用方自写脚本若 print 含 emoji 的结果/日志到默认 GBK 控制台，仍会 UnicodeEncodeError——设 PYTHONUTF8=1 或 `sys.stdout.reconfigure(encoding="utf-8")`。
- **Bridge 中文参数编码.** Native Messaging 在 Windows GBK 环境下传输中文可能乱码。`locator.click`/`dom.click` 含中文 name 时可能失败。解决方案：① 用 `adapter="cdp"` 避开 Bridge；② 用 `click_by_ref(ref_id)` 按无障碍树 ref 编号操作；③ 用 CSS 属性选择器 `[data-key="OA_XXX"]` 绕过中文文本。
- **分组管理.** v2.3 提供 `bridge groups`（查询，🟢/⚪ 标记存活与陈旧）与 `bridge cleanup`（清理，默认只清陈旧空壳，`--name` 按业务名，`--all` 全清需确认）。空壳分组无法经 RPC 删除（扩展 `session.stop` 对空 `tabIds` 报错），若堆积过多建议扩展侧加 `session.delete`。
- **Bridge 模式 run 不复用 session.** 旧代码中 Bridge run 直接 `goto(url)` 每次都打开全新 session，导致重复登录。v2.1.0 修复：`engine.py` Bridge 路径已接入 `find_or_create_session()`，同域名自动复用已有分组。v2.2.0 进一步：默认不自动新建，无匹配时返回 `suggest_new`（CLI 交互确认或 `--new` 显式新建）；按业务名（去 🤖 前缀）也能复用已有分组。如果你使用的 CLI/代码未走引擎路径，需调用 `adapter.find_or_create_session(url, name=业务名)`。
