"""
op_browser / task_store.py — 任务仓库读写

管理 tasks/ 目录下的任务数据：
- task.json（元数据）
- flow.json（锚点序列，v2: a11y 锚点优先）
- script.py（CDP 执行脚本）
- baselines/（基线截图，v2: 每步独立基线）
- logs/（运行日志）
- runs/<run_id>/（v2.5 并行/归档：一次运行的产物命名空间）
"""
import contextlib
import json
import os
import re
import secrets
import shutil
import threading
import time
import traceback
from collections import OrderedDict
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

try:
    import msvcrt
    _HAS_MSVCRT = True
except ImportError:  # 非 Windows：跨进程锁降级为进程内锁
    msvcrt = None
    _HAS_MSVCRT = False


# 进程内写锁：update_task 读-改-写与 write_log 追加共用。
# 保护多线程库调用场景（单线程 asyncio 内同步代码天然原子，锁零开销）。
_FILE_LOCK = threading.Lock()


# ── 任务文件内存缓存（v2.4.1：run 重复加载 task/flow/script 3 次磁盘 I/O → 命中缓存跳过）
# key = (name, kind)，value = (解析结果, mtime)；mtime 变化自动失效（文件被外部修改时防陈旧）。
# 容量上限 16，超限按 LRU 逐出最久未用项（OrderedDict.move_to_end 维护访问顺序）。
_TASK_CACHE: "OrderedDict[tuple[str, str], tuple[Any, float]]" = OrderedDict()
_TASK_CACHE_MAX = 16
# v2.5: _TASK_CACHE 专用锁（与 _FILE_LOCK 分离；锁序 _FILE_LOCK → _CACHE_LOCK，无环）
_CACHE_LOCK = threading.Lock()


def _cache_get(name: str, kind: str, path: Path, loader: Callable[[], Any]) -> Any:
    """带 mtime 失效的读缓存（线程安全，v2.5 全程持 _CACHE_LOCK）。

    文件不存在/mtime 变化/缓存未命中时调用 loader 重建。
    """
    with _CACHE_LOCK:
        if not path.exists():
            _TASK_CACHE.pop((name, kind), None)  # 防幽灵缓存
            return loader()
        try:
            mtime = path.stat().st_mtime
        except OSError:
            return loader()
        key = (name, kind)
        cached = _TASK_CACHE.get(key)
        if cached is not None and cached[1] == mtime:
            _TASK_CACHE.move_to_end(key)  # LRU：命中即移到末尾
            return cached[0]
        val = loader()
        if len(_TASK_CACHE) >= _TASK_CACHE_MAX:
            _TASK_CACHE.popitem(last=False)  # 逐出最久未用
        _TASK_CACHE[key] = (val, mtime)
        return val


def _cache_drop(name: str, kind: str = "") -> None:
    """失效缓存（线程安全）。kind 为空时清空该任务全部缓存条目。"""
    with _CACHE_LOCK:
        if kind:
            _TASK_CACHE.pop((name, kind), None)
        else:
            for key in [k for k in _TASK_CACHE if k[0] == name]:
                _TASK_CACHE.pop(key, None)


def invalidate_cache(name: str = "") -> None:
    """公开失效入口：清空指定任务（或全部）的文件缓存，供外部 refresh 调用。"""
    with _CACHE_LOCK:
        if name:
            for key in [k for k in _TASK_CACHE if k[0] == name]:
                _TASK_CACHE.pop(key, None)
        else:
            _TASK_CACHE.clear()


# ── 跨进程文件锁 + 原子写（v2.5 并发安全基础）────────────────────

def _lock_path_for(path: Path) -> Path:
    """锁文件：与目标文件同目录的 `<name>.lock`（同卷、不污染目标目录结构）。"""
    return path.with_name(path.name + ".lock")


@contextlib.contextmanager
def _file_lock(path: Path, timeout: float = 10.0):
    """跨进程文件锁（Windows msvcrt.locking 非阻塞 + 重试）。

    锁序（全模块唯一，防死锁）：进程内 `_FILE_LOCK` → 跨进程 msvcrt 锁。
    锁文件常驻不删除（防 ABA：A 持锁时 B 删除锁文件、C 新建并持锁 → A/C 同时持锁）；
    进程崩溃时操作系统自动释放锁（句柄关闭），无陈旧锁问题。
    非 Windows 平台（无 msvcrt）退化为纯进程内锁。
    """
    lock_path = _lock_path_for(path)
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with _FILE_LOCK:  # msvcrt 同进程第二句柄会锁冲突，进程内先串行
        f = open(lock_path, "a+b")
        try:
            if _HAS_MSVCRT:
                if f.seek(0, os.SEEK_END) == 0:
                    f.write(b"\0")
                    f.flush()
                f.seek(0)
                deadline = time.monotonic() + timeout
                while True:
                    try:
                        msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
                        break
                    except OSError:
                        if time.monotonic() > deadline:
                            raise TimeoutError(
                                f"获取文件锁超时: {lock_path}（> {timeout}s）")
                        time.sleep(0.05)
            yield
        finally:
            if _HAS_MSVCRT:
                try:
                    f.seek(0)
                    msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
                except OSError:
                    pass
            f.close()


def _atomic_write_bytes(path: Path, data: bytes):
    """原子写（字节）：同目录临时文件 + os.replace（同卷保证 replace 原子）。"""
    tmp = path.with_name(f".{path.name}.tmp-{os.getpid()}-{threading.get_ident()}")
    try:
        with open(tmp, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        # Windows：读方以默认共享打开目标文件时（无 FILE_SHARE_DELETE），
        # os.replace 可能抛 PermissionError(13)。写写已由 _file_lock 互斥，
        # 此处仅与"无锁读方"的短暂打开窗口竞争——短重试即可消除。
        deadline = time.monotonic() + 1.0
        while True:
            try:
                os.replace(tmp, path)  # 原子替换，读方不会看到半截 JSON
                break
            except PermissionError:
                if time.monotonic() > deadline:
                    raise
                time.sleep(0.02)
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass


def _atomic_write_text(path: Path, content: str, encoding: str = "utf-8"):
    """原子写（文本）。"""
    _atomic_write_bytes(path, content.encode(encoding))


# 默认项目根目录（可被环境变量 TASKS_DIR 覆盖）
# 路径优先级：环境变量 > skill 内 junction 挂载点（自动创建，绝不写 skill 实体目录）
_SKILL_ROOT = Path(__file__).resolve().parent.parent.parent  # src/op_browser/ → op-browser/

# skill 内 junction 挂载点（op-browser/tasks → .basic/evolved/op-browser/tasks）
# skill 无感：无论从哪个端调用，该路径都是 skill 相对路径，junction 自动映射到实际存储
_EVOLVED_TASKS = _SKILL_ROOT / "tasks"  # op-browser/tasks/

# 最终有效根目录
# 注意：不能用 Path("") 的真值判断——Path("") 即 Path(".")，真值为 True 且
# 当前目录永远存在，会导致环境变量未设置时 TASKS_ROOT 静默落 cwd（产物漂移根因）
_env_tasks = os.environ.get("TASKS_DIR", "").strip()
TASKS_ROOT = Path(_env_tasks) if _env_tasks else None
if TASKS_ROOT is None or not TASKS_ROOT.exists():
    # 环境变量未设置或路径不存在 → 使用 skill 内 junction 挂载点（自动创建）
    # 绝不 fallback 到 skill 自带 assets/（junction = 仓库，写入污染仓库）
    try:
        _EVOLVED_TASKS.mkdir(parents=True, exist_ok=True)
        TASKS_ROOT = _EVOLVED_TASKS
    except OSError:
        raise FileNotFoundError(
            "op-browser 运行时目录无法创建（junction 挂载点不存在）："
            f"{_EVOLVED_TASKS}\n"
            "请设置 TASKS_DIR 环境变量指向有效目录，"
            "或确保 skill 内 junction 挂载点已初始化（op-000 打包脚本自动建，"
            "手动建也可）"
        )


def tasks_root() -> Path:
    """获取任务仓库根目录。"""
    TASKS_ROOT.mkdir(parents=True, exist_ok=True)
    return TASKS_ROOT


# ── run 产物命名空间（v2.5：并行/归档）──────────────────────────

_RUNS_DIR = "runs"  # 固定前缀目录，list_tasks 据此跳过
_RUN_ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,80}$")


def _safe_run_id(run_id: str) -> str:
    """run_id 合法性校验（防路径穿越）。非法抛 ValueError。"""
    if not _RUN_ID_RE.match(run_id):
        raise ValueError(
            f"非法 run_id: {run_id!r}（仅允许字母数字 . _ -，≤80 字符）")
    return run_id


def new_run_id(prefix: str = "run") -> str:
    """生成一次运行的命名空间标识：{prefix}-YYYYmmdd-HHMMSS-xxxx。

    唯一性由时间戳 + 2 字节随机（secrets，标准库）保证；不含任务名（防中文/穿越）。
    """
    return (f"{prefix}-{datetime.now().strftime('%Y%m%d-%H%M%S')}-"
            f"{secrets.token_hex(2)}")


def run_id_short(run_id: str) -> str:
    """取 run_id 尾部短标识（供会话名后缀，如 '任务A#rab12'）。"""
    return run_id.rsplit("-", 1)[-1] if "-" in run_id else run_id[:8]


def runs_dir(run_id: str = "", create: bool = True) -> Path:
    """runs/ 产物目录。

    run_id 为空返回 runs/ 根（不创建）；非空创建 runs/<run_id>/shots/。
    布局：runs/<run_id>/{meta.json, result.json, run.log, taskset.log, shots/}
    """
    d = tasks_root() / _RUNS_DIR
    if not run_id:
        return d
    d = d / _safe_run_id(run_id)
    if create:
        d.mkdir(parents=True, exist_ok=True)
        (d / "shots").mkdir(parents=True, exist_ok=True)
    return d


def write_run_meta(run_id: str, meta: dict) -> str:
    """写 run 元数据（原子写 + 文件锁）。返回路径。"""
    path = runs_dir(run_id) / "meta.json"
    meta["run_id"] = run_id
    with _file_lock(path):
        _atomic_write_text(path, json.dumps(meta, ensure_ascii=False, indent=2))
    return str(path)


def write_run_result(run_id: str, result: dict) -> str:
    """写 run 结果（原子写 + 文件锁）。返回路径。"""
    path = runs_dir(run_id) / "result.json"
    with _file_lock(path):
        _atomic_write_text(path, json.dumps(result, ensure_ascii=False, indent=2))
    return str(path)


def load_run_result(run_id: str) -> dict:
    """读指定 run 的结果。不存在/损坏返回 {}。"""
    path = runs_dir(run_id, create=False) / "result.json"
    if not path.exists():
        return {}
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def task_dir(name: str, create: bool = True) -> Path:
    """获取任务目录。

    create=False 时只返回路径，不创建（查询类操作避免幽灵目录）。
    """
    d = tasks_root() / name
    if not create:
        return d
    d.mkdir(parents=True, exist_ok=True)
    (d / "baselines").mkdir(exist_ok=True)
    (d / "logs").mkdir(exist_ok=True)
    return d


# ── task.json 读写 ─────────────────────────────────────────

def load_task(name: str) -> dict:
    """读取任务元数据（内存缓存 + mtime 失效）。不存在则返回默认值。"""
    path = task_dir(name, create=False) / "task.json"

    def _load() -> dict:
        with open(path, encoding="utf-8") as f:
            return json.load(f)

    if not path.exists():
        return {
            "name": name,
            "description": "",
            "status": "unknown",
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            "run_count": 0,
        }
    return _cache_get(name, "task", path, _load)


def save_task(name: str, meta: dict):
    """保存任务元数据（跨进程锁 + 原子写，写后失效缓存）。"""
    meta["updated_at"] = datetime.now().isoformat()
    path = task_dir(name) / "task.json"
    with _file_lock(path):
        _atomic_write_text(path, json.dumps(meta, ensure_ascii=False, indent=2))
    _cache_drop(name, "task")


def _read_task_uncached(path: Path, name: str) -> dict:
    """锁内直读磁盘（绕过 _TASK_CACHE）：读-改-写必须基于磁盘最新值，
    否则本进程缓存旧值会覆盖另一进程刚写入的更新（丢失更新）。"""
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return {  # 与 load_task 的合成默认一致
            "name": name, "description": "", "status": "unknown",
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(), "run_count": 0,
        }


def update_task(name: str, **kwargs):
    """更新任务元数据的指定字段（跨进程读-改-写原子，防计数丢失）。

    锁内不调用 save_task（避免嵌套持锁死锁），内联原子写；
    锁内不读缓存（_read_task_uncached），保证跨进程不丢更新。

    注意：kwargs 是「最终值」语义；跨进程并发下基于旧值计算的字段
    （如 run_count）应改用 inc_run_count（锁内读-改-写）。
    """
    path = task_dir(name) / "task.json"
    with _file_lock(path):
        meta = _read_task_uncached(path, name)
        meta.update(kwargs)
        meta["updated_at"] = datetime.now().isoformat()
        _atomic_write_text(path, json.dumps(meta, ensure_ascii=False, indent=2))
    _cache_drop(name, "task")


def inc_run_count(name: str, by: int = 1) -> int:
    """锁内读-加-写 run_count，返回新值（v2.5：跨进程并发不丢更新）。

    与 update_task 不同：增量计算在锁内完成，调用方无需先读。
    两个进程各 50 次 → 最终 100（判定标准 6）。
    """
    path = task_dir(name) / "task.json"
    with _file_lock(path):
        meta = _read_task_uncached(path, name)
        meta["run_count"] = meta.get("run_count", 0) + by
        meta["updated_at"] = datetime.now().isoformat()
        _atomic_write_text(path, json.dumps(meta, ensure_ascii=False, indent=2))
    _cache_drop(name, "task")
    return meta["run_count"]


# ── flow.json 读写（锚点序列） ────────────────────────────────

def load_flow(name: str) -> dict | None:
    """读取锚点序列（内存缓存 + mtime 失效）。不存在返回 None。"""
    path = task_dir(name, create=False) / "flow.json"
    if not path.exists():
        return None

    def _load() -> dict:
        with open(path, encoding="utf-8") as f:
            return json.load(f)

    return _cache_get(name, "flow", path, _load)


def save_flow(name: str, flow: dict):
    """保存锚点序列（跨进程锁 + 原子写，写后失效缓存）。"""
    path = task_dir(name) / "flow.json"
    with _file_lock(path):
        _atomic_write_text(path, json.dumps(flow, ensure_ascii=False, indent=2))
    _cache_drop(name, "flow")


# ── script.py 读写 ─────────────────────────────────────────

def load_script(name: str) -> str | None:
    """读取 CDP 确定性脚本（内存缓存 + mtime 失效）。不存在返回 None。"""
    path = task_dir(name, create=False) / "script.py"
    if not path.exists():
        return None
    return _cache_get(name, "script", path, lambda: path.read_text(encoding="utf-8"))


def save_script(name: str, code: str):
    """保存 CDP 确定性脚本（跨进程锁 + 原子写，写后失效缓存）。"""
    path = task_dir(name) / "script.py"
    with _file_lock(path):
        _atomic_write_text(path, code)
    _cache_drop(name, "script")


# ── 基线管理 ─────────────────────────────────────────────

def baseline_dir(name: str) -> Path:
    """获取基线目录。"""
    d = task_dir(name) / "baselines"
    d.mkdir(exist_ok=True)
    return d


def save_baseline_screenshot(name: str, filepath: str, step_index: int = 0):
    """保存基线截图到任务目录（原子复制：copy2 到同目录临时文件 → os.replace）。"""
    dest = baseline_dir(name) / f"screenshot_{step_index:02d}.png"
    with _file_lock(dest):
        tmp = dest.with_name(f".{dest.name}.tmp-{os.getpid()}")
        shutil.copy2(filepath, tmp)
        os.replace(tmp, dest)
    return str(dest)


def load_baseline_screenshot(name: str, step_index: int = 0) -> str | None:
    """读取基线截图路径。"""
    dest = task_dir(name, create=False) / "baselines" / f"screenshot_{step_index:02d}.png"
    return str(dest) if dest.exists() else None


# ── 日志 ─────────────────────────────────────────────────

def log_dir(name: str) -> Path:
    """获取日志目录。"""
    d = task_dir(name) / "logs"
    d.mkdir(exist_ok=True)
    return d


def write_log(name: str, log_type: str, content: str, run_id: str = ""):
    """追加日志（跨进程行级互斥）。log_type: run / taskset / 其他自定义类型。

    run_id 非空时双写 runs/<run_id>/run.log（并行/归档场景隔离，不交错）。
    """
    today = datetime.now().strftime("%Y-%m-%d")
    path = log_dir(name) / f"{today}-{log_type}.log"
    timestamp = datetime.now().strftime("%H:%M:%S")
    line = f"[{timestamp}] {content}\n"
    with _file_lock(path):
        with open(path, "a", encoding="utf-8") as f:
            f.write(line)
    if run_id:
        rpath = runs_dir(run_id) / "run.log"
        with _file_lock(rpath):
            with open(rpath, "a", encoding="utf-8") as f:
                f.write(line)


def write_taskset_log(content: str, run_id: str = ""):
    """taskset 编排日志（跨进程行级互斥）。

    run_id 非空 → runs/<run_id>/taskset.log（并行/归档场景）；
    run_id 为空 → tasks_root()/taskset.log（旧位置兼容，行为不变）。

    不走 write_log（避免创建 tasks/taskset/ 幽灵目录污染任务仓库）。
    """
    path = runs_dir(run_id) / "taskset.log" if run_id else tasks_root() / "taskset.log"
    timestamp = datetime.now().strftime("%H:%M:%S")
    with _file_lock(path):
        with open(path, "a", encoding="utf-8") as f:
            f.write(f"[{timestamp}] {content}\n")


_SENSITIVE_RE = re.compile(
    r"(token|password|passwd|secret|api[_-]?key|authorization|auth)\s*[=: ]\s*"
    r"(?:Bearer\s+)?['\"]?[A-Za-z0-9._\-]{6,}['\"]?",
    re.IGNORECASE)
_MAX_TRACEBACK = 4000


def _mask_sensitive(text: str) -> str:
    """日志脱敏：凭据形如 token=xxx / password: xxx / api_key=xxx 打码为 <masked>。"""
    return _SENSITIVE_RE.sub(lambda m: f"{m.group(1)}=<masked>", text)


def write_error_log(name: str, log_type: str, error: Exception):
    """记录异常日志（含堆栈，脱敏 + 截断防膨胀）。"""
    write_log(name, log_type, f"❌ 错误: {_mask_sensitive(str(error))}")
    tb = traceback.format_exc()
    if len(tb) > _MAX_TRACEBACK:
        tb = tb[:_MAX_TRACEBACK] + "\n...(堆栈截断)"
    write_log(name, log_type, _mask_sensitive(tb))


# ── 测试结果持久化 ───────────────────────────────────────

def write_test_results(results: list[dict], run_id: str = "") -> str:
    """持久化测试结果，返回文件路径。

    run_id 为空 → 写旧位置 _test_results.json（向后兼容，行为不变）；
    run_id 非空 → 写 runs/<run_id>/result.json（并行不覆盖，原子写 + 锁）。
    """
    payload = {
        "time": datetime.now().isoformat(timespec="seconds"),
        "run_id": run_id,
        "results": results,
    }
    path = runs_dir(run_id) / "result.json" if run_id \
        else tasks_root() / "_test_results.json"
    with _file_lock(path):
        _atomic_write_text(path, json.dumps(payload, ensure_ascii=False, indent=2))
    return str(path)


def _latest_run_result_file() -> Path | None:
    """runs/ 下最新的 result.json：run_id 前缀含时间戳，目录字典序即时间序。"""
    root = tasks_root() / _RUNS_DIR
    if not root.exists():
        return None
    for d in sorted(root.iterdir(), reverse=True):
        if d.is_dir() and (d / "result.json").exists():
            return d / "result.json"
    return None


def load_test_results(run_id: str = "") -> dict:
    """读取测试结果。

    run_id 为空 → 「最新」：runs/ 下最新 run 的 result.json 优先，
        无则回退旧 _test_results.json（旧资产兼容）；
    run_id 指定 → runs/<run_id>/result.json，不存在返回 {}。
    损坏文件返回 {}（与现状一致）。
    """
    if run_id:
        path = runs_dir(run_id, create=False) / "result.json"
    else:
        path = _latest_run_result_file() or tasks_root() / "_test_results.json"
    if not path.exists():
        return {}
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


# ── 任务列表 ─────────────────────────────────────────────

def list_tasks() -> list[dict]:
    """列出所有任务及其状态。"""
    root = tasks_root()
    if not root.exists():
        return []
    results = []
    for d in sorted(root.iterdir()):
        if not d.is_dir() or d.name == _RUNS_DIR:  # v2.5: 跳过 runs/ 运行时产物目录
            continue
        meta = load_task(d.name)
        results.append({
            "name": d.name,
            "description": meta.get("description", ""),
            "status": meta.get("status", "unknown"),
            "run_count": meta.get("run_count", 0),
            "created_at": meta.get("created_at", ""),
            "updated_at": meta.get("updated_at", ""),
        })
    return results


def delete_task(name: str) -> bool:
    """删除任务目录。返回是否成功。"""
    d = task_dir(name, create=False)
    if d.exists():
        shutil.rmtree(d)
        _cache_drop(name)  # 删除后失效全部缓存
        return True
    return False


def rename_task(old_name: str, new_name: str) -> bool:
    """重命名任务。返回是否成功。"""
    old = task_dir(old_name, create=False)
    new = tasks_root() / new_name
    if not old.exists() or new.exists():
        return False
    old.rename(new)
    # 同步 task.json 中的 name 字段（update_task 不接受 name 关键字）
    meta = load_task(new_name)
    meta["name"] = new_name
    save_task(new_name, meta)
    _cache_drop(old_name)  # 旧名缓存失效
    _cache_drop(new_name)
    return True
