"""
op_browser / adapter_bridge.py — Bridge RPC 适配器（BrowserAdapter 实现）

通过 HTTP/WS 调用 browser-agent-bridge 的 RPC 服务。
连接失败时返回 connect() == False。

v2.4.1 优化：connect 并行化+短超时+快路径；session 缓存 TTL 5s。
"""
import asyncio, base64, ipaddress, json, os, socket, tempfile, time, urllib.parse
from pathlib import Path
from typing import Any

import httpx

from .base import (
    BrowserAdapter, ActionResult, NavigationInfo,
    ElementInfo, A11yNode,
)


# 截图缓存目录：弃用 tempfile.mktemp（TOCTOU 竞态），固定目录复用
SHOT_DIR = Path(tempfile.gettempdir()) / "op_browser_shots"
SHOT_DIR.mkdir(parents=True, exist_ok=True)


class BridgeAdapter(BrowserAdapter):
    """Bridge RPC 适配器，封装对 browser-agent-bridge 的 HTTP 调用。

    bridge 服务地址默认 http://127.0.0.1:8765，可用 BRIDGE_URL 环境变量覆盖。
    """

    @property
    def name(self) -> str:
        return "bridge"

    @property
    def base_url(self) -> str:
        """Bridge 服务地址（供诊断展示）。"""
        return self._base_url

    def __init__(self, bridge_url: str = "", token: str = ""):
        # BRIDGE_URL 环境变量可覆盖默认地址（默认 http://127.0.0.1:8765）
        self._base_url = (bridge_url or os.environ.get("BRIDGE_URL")
                          or "http://127.0.0.1:8765").rstrip("/")
        self._client = httpx.AsyncClient(timeout=10.0)  # v2.4.1: 30s -> 10s
        self._session_id: str = ""
        self._tab_id: str = ""
        self._connected = False
        self._full_connect_done = False  # v2.4.1: 快路径标记
        self._token = token or self._load_token()
        self._req_id = 0  # JSON-RPC 2.0 请求 ID 计数器
        # v2.4.1: session 缓存
        self._session_cache: list[dict] | None = None
        self._session_cache_at: float = 0.0
        self._session_cache_ttl: float = 5.0

    @staticmethod
    def _load_token() -> str:
        """按 browser_bridge_client 同优先级加载 token。"""
        token = os.environ.get("BROWSER_AGENT_BRIDGE_TOKEN", "")
        if not token:
            env_file = Path.home() / ".browser-agent-bridge.env"
            if env_file.exists():
                try:
                    for line in env_file.read_text(encoding="utf-8").splitlines():
                        if line.startswith("BROWSER_AGENT_BRIDGE_TOKEN="):
                            token = line.split("=", 1)[1].strip("'\"")
                            break
                except Exception:
                    pass
        return token

    # ── RPC 调用 ───────────────────────────────────────────────

    def _with_tab(self, params: dict) -> dict:
        """为 page/locator/dom 方法自动注入当前 session 的 tabId。"""
        if "tabId" in params:
            return params
        if self._tab_id and self._tab_id.isdigit():
            params["tabId"] = int(self._tab_id)
        return params

    async def _ensure_token(self) -> str:
        """确保 token 已加载，重试失败时返回空字符串。"""
        if self._token:
            return self._token
        self._token = self._load_token()
        return self._token

    async def _rpc(self, method: str, **params) -> dict:
        """调用 Bridge RPC 接口（JSON-RPC 2.0 协议）。

        健壮性（P2-18）：防御性 JSON 解析（非 JSON body 不崩溃）；
        带 token 的 401/403 清 token 重载后重试一次（原实现只对无 token 重试）；
        认证失败/HTTP >=400/RPC error 均抛带上下文的 RuntimeError。
        中文安全：body 显式 ensure_ascii=True 序列化，中文以 \\uXXXX 转义
        传输（纯 ASCII 字节流）。Native Messaging 宿主按字符数计算长度
        前缀，直接发送 UTF-8 多字节中文可能截断乱码（Windows GBK 环境
        下尤为明显），转义后免疫该问题，JSON 解析端自动还原中文。
        """
        await self._ensure_token()
        headers = {"content-type": "application/json"}
        if self._token:
            headers["authorization"] = f"Bearer {self._token}"
        self._req_id += 1

        def _body() -> str:
            return json.dumps(
                {"jsonrpc": "2.0", "id": self._req_id,
                 "method": method, "params": params},
                ensure_ascii=True,
            )

        async def _post() -> dict:
            """单次 POST + 防御性解析。非 JSON body 返回错误上下文。"""
            try:
                resp = await self._client.post(
                    f"{self._base_url}/rpc",
                    content=_body(),
                    headers=headers,
                )
                try:
                    data = resp.json()
                except ValueError:
                    # 非 JSON body：保留 HTTP 状态码，如实上报（P3-7）
                    return {"status": resp.status_code,
                            "error": f"RPC 响应非 JSON (HTTP {resp.status_code}): "
                                     f"{resp.text[:200]}"}
                return {"status": resp.status_code, "data": data}
            except Exception as e:
                return {"status": 0, "error": f"RPC 请求异常: {e}"}

        first = await _post()

        # 401/403（auth 问题）：清 token 重载后重试一次（无论是否带 token）
        if first.get("status") in (401, 403):
            self._token = ""
            await self._ensure_token()
            if self._token:
                headers["authorization"] = f"Bearer {self._token}"
                self._req_id += 1
                first = await _post()

        status = first.get("status", 0)
        if status in (401, 403):
            raise RuntimeError(
                f"Bridge RPC 认证失败 HTTP {status}（token 无效或缺失）")
        if status >= 400:
            raise RuntimeError(
                f"Bridge RPC HTTP {status}: {str(first.get('data', first.get('error')))[:200]}")
        if first.get("error"):
            raise RuntimeError(f"Bridge RPC 请求失败: {first['error']}")

        data = first.get("data") or {}
        if not isinstance(data, dict):
            raise RuntimeError(
                f"Bridge RPC 响应格式异常: 期望 JSON 对象，"
                f"实际 {type(data).__name__}: {str(data)[:200]}")
        if data.get("error"):
            raise RuntimeError(f"Bridge RPC 错误: {data['error']}")
        return data.get("result", {})

    # ── 生命周期 ───────────────────────────────────────────────

    async def _try_connect(self, force_full: bool = False) -> bool:
        """单次连接尝试：快路径（light health）+ 完整探测（health+RPC 并行）。

        force_full=True 跳过快路径直接完整探测。
        返回 True=连接成功，False=本次尝试失败（不抛异常）。
        """
        # 快路径：已有完整探测记录，仅 light health 确认
        if self._full_connect_done and not force_full:
            try:
                resp = await self._client.get(
                    f"{self._base_url}/health", timeout=1.0)
                if resp.status_code == 200:
                    self._connected = True
                    return True
            except Exception:
                pass
            # health 失败 -> 降级完整探测
            self._full_connect_done = False

        try:
            async def _health_check():
                try:
                    resp = await self._client.get(
                        f"{self._base_url}/health", timeout=2.0)
                    if resp.status_code != 200:
                        return {"ok": False, "error": f"HTTP {resp.status_code}"}
                    data = resp.json()
                    data.setdefault("ok", True)
                    return data
                except Exception as e:
                    return {"ok": False, "error": str(e)}

            async def _rpc_check():
                return await self.check_rpc(timeout=2.0)

            # 并行执行 health + RPC 探测
            health_task = asyncio.create_task(_health_check())
            rpc_task = asyncio.create_task(_rpc_check())
            health, rpc = await asyncio.gather(health_task, rpc_task)

            if not health.get("ok", False):
                self._connected = False
                return False
            if health.get("authRequired") and not self._token:
                self._connected = False
                return False
            if not rpc.get("rpc_ok"):
                self._connected = False
                return False
            self._connected = True
            self._full_connect_done = True
            return True
        except Exception:
            self._connected = False
            return False

    async def connect(self, **kwargs) -> bool:
        """建立连接：并行 /health + RPC 探测；快路径复用已有探测结果。

        v2.4.1: health 和 RPC 并行执行（原串行 5s+3s），默认超时 2s；
        首次完整探测后，后续仅 health 确认（1s 超时），
        health 失败时降级到完整探测（如 bridge 重启）。
        v3.7: 自动重试——最多 2 次尝试，间隔 1s，覆盖 bridge 短暂断开场景。
        """
        force_full = kwargs.get("force_full", False)
        max_attempts = 2

        for attempt in range(max_attempts):
            if await self._try_connect(force_full=force_full):
                return True
            # 非最后一次尝试：等待 1s 后重试
            if attempt < max_attempts - 1:
                await asyncio.sleep(1.0)
                # 重试时强制完整探测（快路径已证不可用）
                force_full = True

        self._connected = False
        return False

    async def close(self):
        await self._client.aclose()
        self._connected = False

    async def is_connected(self) -> bool:
        try:
            resp = await self._client.get(f"{self._base_url}/health", timeout=3.0)
            return resp.status_code == 200
        except Exception:
            return False

    # ── 会话管理 ───────────────────────────────────────────────

    def _session_name_from_url(self, url: str) -> str:
        """从 URL 提取业务分组名。

        优先级：路径末段 > host:port > host > 未知站点。
        避免返回通用名称（如"业务页面"），确保反映实际用途。
        """
        try:
            from urllib.parse import urlparse
            u = urlparse(url)
            host = u.hostname or ""
            # 从路径取最后一段有意义的模块名
            parts = [p for p in u.path.split("/") if p]
            if parts:
                return f"{host}/{parts[-1]}" if host else parts[-1]
            # 无路径时用 host:port 标识具体站点
            if host and u.port:
                return f"{host}:{u.port}"
            return host or "未知站点"
        except Exception:
            return url[:40] or "未知站点"

    async def _list_sessions(self) -> list[dict]:
        """列出 bridge 上所有 Agent-managed session。"""
        try:
            result = await self._rpc("session.list")
            return result.get("sessions", [])
        except Exception:
            return []

    async def _get_session(self, session_id: str) -> dict | None:
        """获取单个 session 详情。"""
        try:
            result = await self._rpc("session.get", sessionId=session_id)
            return result.get("session")
        except Exception:
            return None

    async def list_session_details(self, force_refresh: bool = False) -> list[dict]:
        """列出全部 session 的完整详情（含 tabs/存活状态），用于查询与清理。

        v2.4.1: 缓存 TTL 5s，连续调用避免重复全量 RPC 查询。
        返回 [{
            sessionId, name, groupId, mainTabId, tabIds, urls,
            alive: 是否有存活 tab（陈旧 session 为 False）,
            createdAt, updatedAt
        }, ...]"""
        # 缓存命中
        now = time.monotonic()
        if (not force_refresh
                and self._session_cache is not None
                and now - self._session_cache_at < self._session_cache_ttl):
            return self._session_cache

        details = await self._list_session_details_impl()
        self._session_cache = details
        self._session_cache_at = now
        return details

    async def _list_session_details_impl(self) -> list[dict]:
        """全量查询 session 详情（原 list_session_details 体）。

        v2.6 页签治理：按 sessionId 关联会话注册表（session_registry），
        输出扩展字段 account / status / last_active_at / reclaimable /
        lease_run_id。注册表无记录的会话标记 status="unknown"
        （不参与账号匹配与自动回收，避免误伤用户手动打开的 tab）。
        """
        from . import session_registry as sr
        reg_map = {r.get("session_id"): r for r in sr.load_sessions()}
        details = []
        for s in await self._list_sessions():
            sid = s.get("id", "")
            try:
                result = await self._rpc("session.get", sessionId=sid)
            except Exception:
                continue
            detail = result.get("session")
            if not detail:
                continue
            tabs = result.get("tabs", [])
            tab_ids = detail.get("tabIds") or []
            if not tab_ids:
                # 兼容旧扩展：无 tabIds 时退化为 mainTabId
                main_tab = detail.get("mainTabId") or s.get("mainTabId") or ""
                tab_ids = [main_tab] if main_tab else []
            main_tab = detail.get("mainTabId") or s.get("mainTabId") or ""
            reg = reg_map.get(sid, {})
            last_active = reg.get("last_active_at", "")
            status = reg.get("status", sr.ST_UNKNOWN)
            reclaimable = False
            if status == sr.ST_IDLE and last_active:
                try:
                    from datetime import datetime, timezone
                    age = (datetime.now(timezone.utc)
                           - datetime.fromisoformat(last_active)).total_seconds()
                    reclaimable = age >= sr.SESSION_RETENTION_SECONDS
                except (ValueError, TypeError):
                    reclaimable = False
            details.append({
                "sessionId": sid,
                "name": detail.get("name", s.get("name", "")),
                "groupId": detail.get("groupId", 0),
                "mainTabId": str(main_tab) if main_tab else "",
                "tabIds": [str(t) for t in tab_ids],
                "urls": [t.get("url", "") for t in tabs],
                "alive": bool(tab_ids),
                # v2.6 页签治理扩展字段
                "account": reg.get("account", ""),
                "account_confirmed": bool(reg.get("account_confirmed", False)),
                "status": status,
                "reclaimable": reclaimable,
                "last_active_at": last_active,
                "lease_run_id": reg.get("lease_run_id", ""),
                "resumable": bool(reg.get("resumable", False)),
                "createdAt": detail.get("createdAt", s.get("createdAt", "")),
                "updatedAt": detail.get("updatedAt", s.get("updatedAt", "")),
            })
        return details

    # ── 本地地址识别 ───────────────────────────────────────────

    _local_ips_cache: set[str] | None = None  # 类级缓存，进程生命周期不变

    @classmethod
    def _is_local_host(cls, host: str) -> bool:
        """判定主机名/IP 是否为本地地址。

        本地地址范围：
        - localhost、0.0.0.0
        - 127.0.0.0/8（loopback）
        - RFC1918 私有网段（10.0.0.0/8、172.16.0.0/12、192.168.0.0/16）
        - 链路本地（169.254.0.0/16）
        - LOCAL_IPS 环境变量显式配置的地址
        - 本机 hostname 解析到的地址（含非 RFC1918 的静态 IP）
        """
        if not host or host in ("localhost", "0.0.0.0"):
            return True
        try:
            addr = ipaddress.ip_address(host)
            return (addr.is_loopback or addr.is_private
                    or addr.is_link_local or addr.is_unspecified
                    or host in cls._get_local_ips())
        except ValueError:
            # 非法 IP 字符串，尝试按主机名解析
            return host in cls._get_local_ips()

    @classmethod
    def _get_local_ips(cls) -> set[str]:
        """获取本机所有 IP 地址（含 LOCAL_IPS 环境变量配置）。

        来源：
        1. LOCAL_IPS 环境变量（逗号分隔，如 "<LAN_IP_1>,<LAN_IP_2>"）
        2. socket.getaddrinfo(本机hostname) 解析到的 IPv4 地址
        结果缓存到类级变量，进程生命周期不变。
        """
        if cls._local_ips_cache is not None:
            return cls._local_ips_cache
        ips: set[str] = set()
        # 1. 环境变量显式配置
        env_ips = os.environ.get("LOCAL_IPS", "")
        if env_ips:
            for part in env_ips.split(","):
                part = part.strip()
                if part:
                    ips.add(part)
        # 2. 本机 hostname 自动发现
        try:
            hostname = socket.gethostname()
            for info in socket.getaddrinfo(hostname, None, socket.AF_INET):
                ips.add(info[4][0])
        except Exception:
            pass
        # 兜底：loopback 始终包含
        ips.add("127.0.0.1")
        cls._local_ips_cache = ips
        return ips

    def _same_origin(self, url1: str, url2: str) -> bool:
        """判断两个 URL 是否同源（本地地址统一视为同源）。

        v3.7: 实现 SKILL.md 本地地址识别规则——
        两个 URL 均为本地地址 + 同端口 → 同源（忽略 scheme/hostname 差异）。
        非本地地址仍按 scheme+hostname+port 精确匹配。
        """
        try:
            from urllib.parse import urlparse
            u1, u2 = urlparse(url1), urlparse(url2)
            h1, h2 = u1.hostname or "", u2.hostname or ""
            p1, p2 = u1.port, u2.port
            # 两端均为本地地址：仅比较端口
            if self._is_local_host(h1) and self._is_local_host(h2):
                return p1 == p2
            # 非本地：scheme + hostname + port 精确匹配
            return (u1.scheme, h1, p1) == (u2.scheme, h2, p2)
        except Exception:
            return url1 == url2

    # ── 禁止的通用分组名 ───────────────────────────────────────
    _BANNED_GROUP_NAMES: set[str] = {
        "agent", "browser", "test", "tab", "page", "session",
        "window", "group", "new", "default", "debug", "temp",
    }

    @staticmethod
    def validate_group_name(name: str) -> str:
        """校验分组名是否符合命名规范。

        规则（SKILL.md）：禁止通用名称（Agent/Browser/Test 等），
        分组名必须反映实际用途。
        返回归一化后的名称；违规抛出 ValueError。
        """
        if not name or not name.strip():
            raise ValueError("分组名不能为空")
        # 剥离 run 标识（#rabc12）再校验业务名部分
        biz = name.split("#r")[0].strip() if "#r" in name else name.strip()
        # 剥离 🤖 前缀
        if biz.startswith("🤖"):
            biz = biz[1:].strip()
        low = biz.lower()
        if low in BridgeAdapter._BANNED_GROUP_NAMES:
            raise ValueError(
                f"分组名「{biz}」是通用名称，禁止使用；"
                f"请使用能反映实际业务用途的名称"
            )
        if len(biz) < 2:
            raise ValueError(
                f"分组名「{biz}」过短（至少 2 字符），请使用更有意义的名称"
            )
        return name.strip()

    @staticmethod
    def _norm_session_name(s: str) -> str:
        """归一化分组名：去掉扩展的 🤖 前缀与首尾空白。

        Bridge 扩展会给 session 名自动加 "🤖 " 前缀（实测确认），
        比较业务名时必须先剥离，否则永远匹配不上。
        """
        if not s:
            return ""
        s = s.strip()
        if s.startswith("🤖"):
            s = s[1:].strip()
        return s

    @staticmethod
    def _names_match(a: str, b: str, strict: bool = False) -> bool:
        """判断两个归一化业务名是否指向同一分组。

        完全相等为强匹配；一方包含另一方时要求短名不少于 2 字符，
        避免 "议题" 这种过短名字误匹配多个业务分组。

        strict=True：仅完全相等（归一化后）算匹配——用于带 run 标识（#r）
            的并行会话，杜绝 "任务A#rab12" 与 "任务A#rab34" 互相接续
            （旧逻辑 len>=2 时 "任务A#rab1" in "任务A#rab12" 为 True）。
        strict=False：旧逻辑（相等或互相包含），仅用于无 run 标识的 legacy
            会话，保持向后兼容。
        """
        a, b = a.strip(), b.strip()
        if not a or not b:
            return False
        if strict:
            return a == b
        if a == b:
            return True
        if len(a) < 2 or len(b) < 2:
            return False
        return a in b or b in a

    @staticmethod
    def _parse_run_name(s: str) -> str:
        """从会话名解析 run 短标识。格式 `{业务名}#r{短标识}`，无 #r 返回 ''。
        例：_parse_run_name("测试A#rab12") -> "ab12"
        """
        if "#r" not in s:
            return ""
        return s.split("#r", 1)[1].strip()

    async def attach_session(self, session_id: str,
                             tab_id: int | str | None = None) -> bool:
        """附着到已有 session。"""
        session = await self._get_session(session_id)
        if not session:
            return False
        self._session_id = session_id
        self._tab_id = str(tab_id if tab_id is not None
                          else session.get("mainTabId", ""))
        return True

    async def session_decision(self, url: str = "", name: str = "",
                               exclusive: bool = False,
                               account: str = "",
                               account_unknown: bool = False) -> dict:
        """返回当前环境诊断 + 复用/新建决策（不修改状态）。

        v2.2 匹配维度扩展：
        - originMatch：目标 URL 与分组内任一 tab 同域名+端口（原逻辑）
        - nameMatch：目标业务名与分组名（去 🤖 前缀）相等或互相包含
        - alive：分组仍有存活 tab（tabIds 非空），无存活 tab 的陈旧
          session 不参与复用，避免接续到已关闭的分组
        复用优先取 originMatch，其次 nameMatch。

        v2.5 exclusive=True（并行/命名 run）：禁用同源复用，nameMatch 仅
        strict 全等（#r 身份分组）——保证 A/B 各自接续自己的会话、同源站点
        不复用对方新建分组。顺序路径 exclusive=False 走原逻辑，零变化。

        v2.6 account（页签治理 D4，仅顺序路径生效）：
        - account="" 时行为与现状完全一致（零变化）。
        - account=期望：候选排序追加账号维度（accountMatch 优先）。
          - 同账号（account_confirmed 且相等）→ 复用（最高优先）
          - account_confirmed=false（旧/无登录会话）→ 复用 + 复用后登录校正
          - 异账号命中 main_tab → 复用 + relogin_required=true（同 tab 重登）
          - 异账号命中非 main_tab → 拒绝复用（skipped_reason=...，防串号）
        - exclusive=True 时不引入账号维度（并行隔离红线）。
        """
        health = await self.check_health()
        norm_name = self._norm_session_name(name)
        candidates = []
        for s in await self.list_session_details():
            urls = s["urls"]
            sname = self._norm_session_name(s["name"])
            account_confirmed = bool(s.get("account_confirmed", False))
            s_account = s.get("account", "")
            account_match = False
            relogin_required = False
            skipped_reason = ""
            if (not exclusive and account and account_confirmed
                    and s_account and s_account != account):
                # 异账号：仅允许复用 main_tab（同 tab 内重登），
                # 非 main_tab 拒绝（防串号）
                if s["tabIds"] and s["mainTabId"] and (
                        s["mainTabId"] in s["tabIds"]):
                    relogin_required = True
                else:
                    skipped_reason = "account_mismatch_secondary_tab"
            elif (not exclusive and account and account_confirmed
                    and s_account == account):
                account_match = True
            if exclusive:
                # 并行模式：同源不复用（判定标准 2），名字仅 strict 全等
                origin_match = False
                name_match = bool(norm_name) and self._names_match(
                    norm_name, sname, strict=True)
            else:
                origin_match = bool(url) and any(
                    self._same_origin(url, u) for u in urls
                    if u and u != "about:blank")
                name_match = bool(norm_name) and self._names_match(
                    norm_name, sname)
            candidates.append({
                "sessionId": s["sessionId"],
                "name": s["name"],
                "groupId": s["groupId"],
                "mainTabId": s["mainTabId"],
                "tabIds": s["tabIds"],
                "urls": urls,
                "originMatch": origin_match,
                "nameMatch": name_match,
                "alive": s["alive"],
                "accountMatch": account_match,
                "account": s_account,
                "account_confirmed": account_confirmed,
                "relogin_required": relogin_required,
                "skipped_reason": skipped_reason,
                "matched": origin_match or name_match,  # 向后兼容旧字段
            })
        candidates.sort(
            key=lambda c: (c["alive"], c["accountMatch"],
                           c["originMatch"], c["nameMatch"]),
            reverse=True)
        best = None
        for c in candidates:
            if not c["alive"] or not c["matched"]:
                continue
            if c["skipped_reason"]:
                continue
            if account and c["account_confirmed"] and not c["accountMatch"]:
                # 异账号：仅 relogin_required（main_tab）可复用
                if not c["relogin_required"]:
                    continue
            best = c
            break
        return {
            "healthy": health.get("ok", health.get("healthy", False)),
            "authRequired": health.get("authRequired"),
            "extensionReady": health.get("extensionReady"),
            "existingCount": len(candidates),
            "aliveCount": sum(1 for c in candidates if c["alive"]),
            "staleCount": sum(1 for c in candidates if not c["alive"]),
            "accountMatchCount": sum(1 for c in candidates
                                     if c["accountMatch"]),
            "candidates": candidates,
            "reuse": best,
            "newName": name or self._session_name_from_url(url),
        }

    async def find_or_create_session(self, url: str = "",
                                      name: str = "",
                                      allow_new: bool = False,
                                      exclusive: bool = False,
                                      account: str = "",
                                      account_unknown: bool = False) -> tuple[str, dict]:
        """查找已有可用 session，无匹配时按 allow_new 决定是否新建。

        v2.2 默认不新建（allow_new=False）：
        - 复用规则：URL 同域名+端口优先，其次业务名匹配；仅复用有存活
          tab 的分组
        - 无匹配且 allow_new=False 时返回 ("", decision)，
          decision["action"] == "suggest_new"，并附 suggestedName，
          由调用方确认后才允许新建（显式 allow_new=True）
        v2.5 exclusive：透传 session_decision（并行/命名 run 身份隔离）
        v2.6 account：透传 session_decision（页签治理账号感知复用）

        返回 (session_id, decision_info)。
        """
        # 早期校验：禁止通用分组名（仅新建路径需要，复用不校验）
        if name:
            self.validate_group_name(name)
        decision = await self.session_decision(
            url, name, exclusive=exclusive,
            account=account, account_unknown=account_unknown)
        reuse = decision.get("reuse")
        if reuse:
            self._session_id = reuse["sessionId"]
            self._tab_id = str(reuse["mainTabId"])
            decision["action"] = "reuse"
            if reuse.get("relogin_required"):
                decision["relogin_required"] = True
            return self._session_id, decision

        # 没有可复用的，新建
        new_name = name or decision.get("newName", "")
        # 校验自动生成的分组名（用户显式传入的已在入口校验）
        if not name and new_name:
            try:
                self.validate_group_name(new_name)
            except ValueError:
                # 自动生成的名称违规时，用 URL host:port 作为兜底
                from urllib.parse import urlparse as _up
                _u = _up(url)
                _host = _u.hostname or "未知"
                _port = _u.port
                new_name = f"{_host}:{_port}" if _port else _host
        decision["suggestedName"] = new_name
        if not allow_new:
            decision["action"] = "suggest_new"
            return "", decision
        sid = await self.start_session(url, name=new_name)
        decision["action"] = "new"
        decision["createdName"] = new_name
        return sid, decision

    async def start_session(self, url: str = "", name: str = "") -> str:
        """新建 Bridge session。

        name 会作为 Chrome tab group 的标题，建议使用业务名。
        校验分组名：禁止通用名称，必须反映实际用途。
        """
        if name:
            self.validate_group_name(name)
        params = {"url": url, "active": True}
        if name:
            params["name"] = name
        result = await self._rpc("session.start", **params)
        # Bridge 协议返回嵌套结构：{session: {id, mainTabId, ...}, tab: {...}}
        session = result.get("session", result)
        tab = result.get("tab", {})
        self._session_id = session.get("sessionId", session.get("id", ""))
        self._tab_id = str(tab.get("tabId", tab.get("id",
                          session.get("mainTabId", ""))))
        return self._session_id

    async def close_session(self, session_id: str):
        await self._rpc("session.stop",
                        sessionId=session_id or self._session_id,
                        closeTabs=True)
        self._session_id = ""
        self._tab_id = ""

    async def cleanup_sessions(self, *, stale_only: bool = True,
                               close_tabs: bool = True,
                               names: list[str] | None = None,
                               idle: bool = False,
                               exclude_running: bool = True) -> dict:
        """清理分组（查询管理的核心写操作）。

        参数:
            stale_only: 只清理无存活 tab 的陈旧分组（默认 True）。
                陈旧分组 = session 元数据还在但 tab 已全部关闭，
                Chrome 分组已解散，属于孤儿记录，可安全删除。
            close_tabs: 清理时是否关闭存活分组内的标签页。
                True = 连标签页一起关（彻底移除）；False = 仅解散分组。
            names: 可选，只清理名字匹配这些业务名的分组（去 🤖 前缀）。
            idle: v2.6 页签治理（D7）：额外清理「存活但超保留期
                （reclaimable）」的分组（默认 False = 保持旧语义只清陈旧）。
            exclude_running: v2.6（D8）：跳过可接续（resumable）/心跳新鲜
                的会话（默认 True，防误关执行中的 run）。

        返回 {"cleaned": [被清理的 sessionId...],
              "skipped": [跳过未清理的 {sessionId, name, reason}...]}
        """
        from . import session_registry as sr
        cleaned: list[str] = []
        skipped: list[dict] = []
        for s in await self.list_session_details():
            sid = s["sessionId"]
            name = s["name"]
            reason = ""
            if exclude_running:
                if s.get("resumable"):
                    reason = "可接续 run 的会话，跳过（接续 A 档依赖）"
                elif s.get("lease_run_id") and sr.is_running_heartbeat_fresh(
                        sid):
                    reason = "运行中（心跳新鲜），跳过"
            if not reason and stale_only and not idle and s["alive"]:
                reason = "分组仍有存活标签页，跳过（避免误删）"
            elif not reason and idle and s["alive"] and not s.get(
                    "reclaimable") and not s.get("status") in (sr.ST_UNKNOWN,):
                # --idle：只清超保留期存活分组；unknown（无注册表）不自动清
                reason = "分组存活但未超保留期，跳过（--idle 仅清 reclaimable）"
            elif not reason and s.get("status") == sr.ST_UNKNOWN and not stale_only:
                reason = "注册表无记录（用户手动/外部创建），跳过自动清理"
            elif names:
                matched = any(
                    self._names_match(self._norm_session_name(n),
                                      self._norm_session_name(name))
                    for n in names if n)
                if not matched:
                    reason = "名字不匹配"
            if reason:
                skipped.append({"sessionId": sid, "name": name,
                                "reason": reason})
                continue
            try:
                await self._rpc("session.stop",
                                sessionId=sid, closeTabs=close_tabs)
                cleaned.append(sid)
                sr.delete_session(sid)  # v2.6：清理后注销注册表（失败不阻断）
            except Exception as e:
                skipped.append({"sessionId": sid, "name": name,
                                "reason": f"清理失败: {e}"})
        return {"cleaned": cleaned, "skipped": skipped}

    async def check_health(self) -> dict:
        """检查 Bridge 服务健康状态。"""
        try:
            resp = await self._client.get(f"{self._base_url}/health", timeout=5.0)
            if resp.status_code != 200:
                return {"ok": False, "error": f"HTTP {resp.status_code}"}
            data = resp.json()
            data.setdefault("ok", True)
            return data
        except Exception as e:
            return {"ok": False, "error": str(e)}

    async def check_rpc(self, timeout: float = 3.0) -> dict:
        """分层诊断的 RPC 层：短超时探测 session.list，确认 JSON-RPC 链路可用。

        与 check_health（/health 静态端点）互补：/health 只证明 HTTP 服务存活，
        本方法证明 RPC 协议链路（宿主→扩展）实际可调用。四类真实故障
        （宿主断链 / 扩展崩溃 / token 无效 / 协议不匹配）在此暴露。
        """
        await self._ensure_token()
        headers = {"content-type": "application/json"}
        if self._token:
            headers["authorization"] = f"Bearer {self._token}"
        self._req_id += 1
        body = json.dumps(
            {"jsonrpc": "2.0", "id": self._req_id,
             "method": "session.list", "params": {}},
            ensure_ascii=True,
        )
        try:
            resp = await self._client.post(
                f"{self._base_url}/rpc", content=body, headers=headers,
                timeout=timeout,
            )
            data = resp.json()
        except Exception as e:
            return {"rpc_ok": False, "error": str(e)}
        if resp.status_code in (401, 403):
            return {"rpc_ok": False,
                    "error": f"认证失败 HTTP {resp.status_code}（token 无效或缺失）"}
        if data.get("error"):
            return {"rpc_ok": False, "error": f"RPC 错误: {data['error']}"}
        sessions = data.get("result", {}).get("sessions", [])
        return {"rpc_ok": True, "sessions": len(sessions) if isinstance(sessions, list) else 0}

    # ── 导航 ───────────────────────────────────────────────

    async def goto(self, url: str) -> NavigationInfo:
        result = await self._rpc("page.navigate",
                                 **self._with_tab({"url": url}))
        return NavigationInfo(
            url=result.get("url", url),
            title=result.get("title", ""),
        )

    async def wait_for_load(self, timeout: float = 15.0) -> bool:
        result = await self._rpc("page.waitForLoad",
                                 **self._with_tab({}))
        return result.get("success", False)

    # ── 元素操作 ───────────────────────────────────────────────

    async def click(self, selector: str) -> ActionResult:
        try:
            result = await self._rpc("dom.click",
                                     **self._with_tab({"selector": selector}))
            return ActionResult(success=result.get("success", True))
        except Exception as e:
            return ActionResult(success=False, error=str(e))

    async def click_by_ref(self, ref: str) -> ActionResult:
        """按无障碍树 ref 编号点击，绕过中文编码问题。

        Bridge 的 Native Messaging 在 Windows GBK 环境下传输中文可能乱码。
        ref 编号纯 ASCII，免疫于编码问题。
        """
        try:
            selector = f'[ref="{ref}"], [data-automation-ref="{ref}"], [data-ref="{ref}"]'
            return await self.click(selector)
        except Exception as e:
            return ActionResult(success=False, error=str(e))

    async def click_by_locator(self, role: str, name: str) -> ActionResult:
        """按 role/name 定位点击（Bridge 核心能力）。

        name 含中文时可能因 Native Messaging 编码问题失败；
        失败时建议降级为 click_by_ref()。
        """
        try:
            params = self._safe_locator(role=role, name=name)
            result = await self._rpc("locator.click",
                                     **self._with_tab(params))
            return ActionResult(success=result.get("success", True))
        except Exception as e:
            return ActionResult(success=False, error=str(e))

    @staticmethod
    def _safe_locator(**params) -> dict:
        """对含中文的 locator 参数做编码保护。

        Native Messaging 在 Windows GBK 环境下传输中文可能乱码。
        对 name/text/label/placeholder 等含中文可能的字段做转义。
        """
        safe = dict(params)
        for k in ("name", "text", "label", "placeholder"):
            if k in safe and isinstance(safe[k], str) and any(ord(c) > 127 for c in safe[k]):
                safe[k] = urllib.parse.quote(safe[k])
        return safe

    async def fill(self, selector: str, text: str) -> ActionResult:
        """按 CSS 选择器填值。"""
        try:
            params = {"role": "", "name": "", "text": text}
            if selector:
                params["selector"] = selector
            result = await self._rpc("locator.fill",
                                     **self._with_tab(params))
            return ActionResult(success=result.get("success", True))
        except Exception as e:
            return ActionResult(success=False, error=str(e))

    async def fill_by_locator(self, role: str, name: str,
                              text: str) -> ActionResult:
        """按 role/name 定位填值（中文走编码保护）。"""
        try:
            params = self._safe_locator(role=role, name=name, text=text)
            result = await self._rpc("locator.fill",
                                     **self._with_tab(params))
            return ActionResult(success=result.get("success", True))
        except Exception as e:
            return ActionResult(success=False, error=str(e))

    async def type_text(self, text: str) -> ActionResult:
        try:
            result = await self._rpc("computer.type",
                                     **self._with_tab({"text": text}))
            return ActionResult(success=result.get("success", True))
        except Exception as e:
            return ActionResult(success=False, error=str(e))

    async def press_key(self, key: str) -> ActionResult:
        try:
            result = await self._rpc("computer.key",
                                     **self._with_tab({"key": key}))
            return ActionResult(success=result.get("success", True))
        except Exception as e:
            return ActionResult(success=False, error=str(e))

    # ── 内容提取 ───────────────────────────────────────────────

    async def read_text(self, selector: str = "") -> str:
        params = self._with_tab({})
        if selector:
            params["selector"] = selector
        result = await self._rpc("page.readText", **params)
        return result.get("text", "")

    async def accessibility_tree(self, tab_id: int = 0,
                                  max_nodes: int = 1000) -> list[A11yNode]:
        """获取无障碍树（Bridge 独有能力，返回丰富的 a11y 树）。

        Bridge 协议返回扁平 nodes 列表（ref/role/name/text/bounds）。
        """
        params = self._with_tab({"maxNodes": max_nodes})
        if tab_id:
            params["tabId"] = tab_id
        result = await self._rpc("page.accessibilityTree", **params)
        # Bridge 协议字段名是 nodes（非 tree）
        raw = result.get("nodes", result.get("tree", []))
        return self._nodes_to_a11y(raw)

    def _nodes_to_a11y(self, nodes: list[dict]) -> list[A11yNode]:
        """Bridge 扁平 nodes 格式转 A11yNode。

        Bridge 协议返回扁平列表，每个节点含 ref/tag/role/name/text/bounds。
        """
        return [
            A11yNode(
                role=n.get("role", ""),
                name=n.get("name", n.get("text", "")),
                attributes={k: n[k] for k in n
                            if k not in ("role", "name", "text", "children")},
                children=self._nodes_to_a11y(n["children"])
                    if n.get("children") else [],
            )
            for n in nodes
        ]

    async def query_elements(self, **criteria) -> list[ElementInfo]:
        result = await self._rpc("dom.query",
                                 **self._with_tab(criteria))
        return [
            ElementInfo(**item) for item in result.get("elements", [])
        ]

    async def execute_js(self, expression: str) -> Any:
        result = await self._rpc("page.executeJavaScript",
                                 **self._with_tab({"script": expression}))
        return result.get("value")

    # ── 截图 ───────────────────────────────────────────────

    async def screenshot(self, full_page: bool = False, out_path: str = "") -> str:
        """截取当前 tab 截图。

        out_path 为空 → SHOT_DIR/bridge_shot.png（旧行为兼容）；
        非空 → 目录自动创建 + 临时文件 + os.replace 原子写（并行读方不读半截）。
        """
        result = await self._rpc("page.screenshot",
                                 **self._with_tab({"format": "png"}))
        # Bridge 返回 base64 图片，存为文件返回路径
        img_data = result.get("data", "")
        if not img_data:
            return ""
        path = out_path or str(SHOT_DIR / "bridge_shot.png")
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        tmp = str(Path(path).with_name(f".{Path(path).name}.tmp-{os.getpid()}"))
        with open(tmp, "wb") as f:
            f.write(base64.b64decode(img_data))
        os.replace(tmp, path)
        return path

    # ── 等待 ───────────────────────────────────────────────

    async def wait_for_selector(self, selector: str, timeout: float = 10.0) -> bool:
        result = await self._rpc("page.waitForSelector",
                                 **self._with_tab({"selector": selector,
                                                   "timeoutMs": int(timeout * 1000)}))
        return result.get("found", False)

    async def wait_for_text(self, text: str, timeout: float = 10.0) -> bool:
        try:
            page_text = await self.read_text()
            return text in page_text
        except Exception:
            return False

    # ── 标签页 ─────────────────────────────────────────────

    async def new_tab(self, url: str = "about:blank") -> str:
        result = await self._rpc("tabs.create", url=url)
        self._tab_id = str(result.get("tabId", result.get("id", "")))
        return self._tab_id

    async def close_tab(self, tab_id: str = ""):
        await self._rpc("tabs.close",
                        tabId=int(tab_id or self._tab_id))

    async def list_tabs(self) -> list[dict]:
        """列出当前 session 的标签页（P2-19 修复：原把 tabId 当 groupId 查询）。"""
        result = await self._rpc("tabs.list", **self._with_tab({}))
        return result.get("tabs", [])
