"""表单填写生成器 — 从字段定义生成 action_detail 序列"""

from typing import List, Dict, Any, Optional
from .common import (
    HumanLikeConfig, build_label_selectors,
    make_click, make_fill, make_select, make_hover,
    make_wait, make_key,
)


def generate_form_actions(
    fields: List[Dict[str, Any]],
    submit_button: Optional[Dict[str, str]] = None,
    human_like: Optional[Dict[str, Any]] = None,
) -> List[Dict[str, Any]]:
    """
    生成表单填写的 action_detail 序列。

    Args:
        fields: 字段列表，每项包含：
            - label: 字段标签（用于定位）
            - value: 要填入的值
            - field_type: text|textarea|password|dropdown|combobox|checkbox|radio|date (默认 text)
            - selector: 可选，CSS/XPath 选择器
            - clear_first: 可选，是否先清空
        submit_button: 可选，提交按钮 { text: "提交" } 或 { selector: "..." }
        human_like: 可选，覆盖默认延迟参数

    Returns:
        action_detail 列表
    """
    cfg = HumanLikeConfig(human_like)
    actions: List[Dict[str, Any]] = []

    # 等待表单渲染
    actions.append(make_wait(300, "等待表单渲染完成"))

    for field in fields:
        label = field.get("label", "")
        value = field.get("value", "")
        field_type = field.get("field_type", "text")
        selector = field.get("selector")
        clear_first = field.get("clear_first")

        # 生成字段操作序列
        field_actions = _generate_field_actions(
            label=label, value=value, field_type=field_type,
            selector=selector, clear_first=clear_first, cfg=cfg,
        )
        actions.extend(field_actions)

        # 字段间"思考"停顿
        pause_ms = cfg.random_ms("thinking_pause_ms")
        actions.append(make_wait(pause_ms, "模拟人工思考停顿"))

    # 提交
    if submit_button:
        btn_text = submit_button.get("text")
        btn_selector = submit_button.get("selector")
        if btn_text:
            actions.append(make_click(
                role="button", name=btn_text,
                description=f"点击提交按钮「{btn_text}」",
            ))
        elif btn_selector:
            actions.append(make_click(
                selector=btn_selector,
                description="点击提交按钮",
            ))
        # 提交后等待
        actions.append(make_wait(500, "等待提交结果"))

    return actions


def _generate_field_actions(
    label: str, value: str, field_type: str,
    selector: Optional[str], clear_first: Optional[bool],
    cfg: HumanLikeConfig,
) -> List[Dict[str, Any]]:
    """为单个字段生成操作序列"""
    actions: List[Dict[str, Any]] = []
    desc_label = label or "目标字段"

    if field_type in ("text", "textarea", "password"):
        # 文本类：点击 → 可选清空 → 填写
        click_action = _make_field_click(label, selector, f"点击{desc_label}")
        actions.append(click_action)
        if clear_first:
            actions.append(make_key("Control+a", f"全选{desc_label}内容"))
            actions.append(make_key("Backspace", f"清空{desc_label}"))
        actions.append(make_fill(
            selector=selector, text=value,
            description=f"填写{desc_label}：{value}",
        ))

    elif field_type == "dropdown":
        # 下拉选择：点击展开 → 点击选项
        actions.append(make_click(
            selector=selector, role="combobox", name=label,
            description=f"点击下拉框「{desc_label}」展开",
        ))
        actions.append(make_wait(cfg.random_ms("wait_after_action_ms"), "等待下拉面板展开"))
        actions.append(make_click(
            role="option", name=value,
            description=f"选择选项「{value}」",
        ))

    elif field_type == "combobox":
        # 可搜索下拉：点击 → 输入 → 等待筛选 → 选择
        actions.append(make_click(
            selector=selector, role="combobox", name=label,
            description=f"点击组合框「{desc_label}」",
        ))
        actions.append(make_fill(
            selector=selector, text=value,
            description=f"输入筛选关键词「{value}」",
        ))
        actions.append(make_wait(500, "等待筛选结果"))
        actions.append(make_click(
            role="option", name=value,
            description=f"选择匹配项「{value}」",
        ))

    elif field_type == "checkbox":
        # 复选框：先检查当前状态再点击
        actions.append(make_click(
            selector=selector, role="checkbox", name=label,
            description=f"切换复选框「{desc_label}」",
        ))

    elif field_type == "radio":
        # 单选按钮
        actions.append(make_click(
            selector=selector, role="radio", name=value or label,
            description=f"选择单选项「{value or desc_label}」",
        ))

    elif field_type == "date":
        # 日期：点击 → 输入日期值
        actions.append(make_click(
            selector=selector, role="textbox", name=label,
            description=f"点击日期框「{desc_label}」",
        ))
        actions.append(make_fill(
            selector=selector, text=value,
            description=f"输入日期「{value}」",
        ))
        actions.append(make_key("Escape", "关闭日期面板"))

    return actions


def _make_field_click(label: str, selector: Optional[str], description: str):
    """为字段生成点击动作，优先 selector → label"""
    if selector:
        return make_click(selector=selector, description=description)
    # 使用 label 定位策略
    selectors = build_label_selectors(label) if label else []
    if selectors:
        return make_click(selector=selectors[0], description=description)
    # 回退到 role+name
    return make_click(role="textbox", name=label, description=description)
