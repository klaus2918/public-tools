# 文件上传注入法（DataTransfer）— op-browser 桥接测试经验

> 来源：办公用品批量导入桥接测试（2026-08-04）
> 适用：Bridge 会话中绕过系统文件对话框，直接向 `<input type=file>` 注入本地文件

## 场景
批量导入等业务使用 `<input type=file>`（如 el-upload）选择 Excel 文件；桥接环境无法弹出 OS 文件对话框。

## 注入脚本（page.executeJavaScript）
```js
(() => {
  const b64 = "<文件base64>"; // python 端 base64 编码后拼入
  const bin = atob(b64);
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  const f = new File([arr], "导入.xlsx", { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
  const dt = new DataTransfer();
  dt.items.add(f);
  const input = document.querySelector(".el-dialog input[type=file]"); // 目标 input
  input.files = dt.files;
  input.dispatchEvent(new Event("change", { bubbles: true })); // 触发 el-upload change
  return "OK:" + input.files.length;
})()
```

## 要点
- 文件内容用 base64 注入，避免跨进程文件路径问题
- 必须 dispatch `change`（bubbles）事件，el-upload 监听 change 收集文件
- 目标 input 选择器：弹窗内用 `.el-dialog input[type=file]` 限定范围（页面可能有多个上传）
- DataTransfer 构造 File 对象不依赖 OS 文件系统，桥接环境可用

## 配套经验
- 勾选 el-table 自定义勾选列：点击 `.el-table__body .el-checkbox`（无表头全选时逐行点）
- 复合 PowerShell 命令（分号/管道混合）常被本机策略拦截，拆成简单命令执行
- Bridge 操作 DOM 优先 execute_js；click_by_ref 的 `[ref=]` CSS 在 DOM 无 ref 属性时会失败
