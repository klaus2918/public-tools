"""
op_browser / engine.py — SmartBrowser 引擎 v2

核心调度器，实现三模式（v2.4 起剔除 LLM/API Key 依赖，纯确定性执行）：
- run()      🟦 确定性回放 → 截图校验（支持 CDP/Bridge 双适配器）
- taskset()  🟣 多任务编排（顺序/并行）
- bridge/cdp 管理、项目路由、doctor 环境诊断

设计原则：零外部 Key。探索固化（explore/repair 的 AI 部分）已移除，
flow/script 资产由项目资产或外部工具准备，引擎只做确定性回放与诚实报错。
"""
import asyncio, os, time
from datetime import datetime
from typing import Any, Callable

from . import cdputil, task_store as store, snapshot, run_state
from .mode_selector import ModeSelector


# ── 全局默认配置 ─────────────────────────────────────────────

class Config:
    """op_browser 配置。环境变量运行时生效（v2.5 起不再导入期固化）。

    类属性 → property：每次访问读取环境变量，支持按测试切换 headless/CDP_URL；
    setter 存实例级覆盖值（兼容「外部赋值」用法，读取行为等价）。
    默认值与原类属性完全一致（顺序场景零行为变化）。
    """

    @property
    def HEADLESS(self) -> bool:
        if "HEADLESS" in self.__dict__:
            return self.__dict__["HEADLESS"]
        return os.environ.get("BROWSER_HEADLESS", "false").lower() == "true"

    @HEADLESS.setter
    def HEADLESS(self, v: bool):
        self.__dict__["HEADLESS"] = bool(v)

    @property
    def CDP_URL(self) -> str | None:
        if "CDP_URL" in self.__dict__:
            return self.__dict__["CDP_URL"]
        return os.environ.get("BROWSER_CDP_URL", None)

    @CDP_URL.setter
    def CDP_URL(self, v: str | None):
        self.__dict__["CDP_URL"] = v

    @property
    def DIFF_PASS(self) -> float:
        if "DIFF_PASS" in self.__dict__:
            return self.__dict__["DIFF_PASS"]
        return float(os.environ.get("BROWSER_DIFF_PASS", "0.05"))  # <5% 通过

    @DIFF_PASS.setter
    def DIFF_PASS(self, v: float):
        self.__dict__["DIFF_PASS"] = float(v)

    @property
    def DIFF_WARN(self) -> float:
        if "DIFF_WARN" in self.__dict__:
            return self.__dict__["DIFF_WARN"]
        return float(os.environ.get("BROWSER_DIFF_WARN", "0.20"))  # <20% 告警

    @DIFF_WARN.setter
    def DIFF_WARN(self, v: float):
        self.__dict__["DIFF_WARN"] = float(v)


# ── 结果类型 ─────────────────────────────────────────────────

class BrowserResult:
    """浏览器操作的结果（v2 扩展版）。"""
    def __init__(self, success: bool = True, data: Any = None,
                 screenshot: str | None = None, diff_rate: float = 0.0,
                 judge: str = "pass", duration_ms: float = 0.0,
                 error: str | None = None, extra: dict | None = None,
                 # v2 新增字段（均有默认值，向后兼容）
                 adapter: str = "",
                 a11y_tree: list | None = None,
                 what_changed: dict | None = None,
                 a11y_diff: dict | None = None,
                 element_refs: list[str] | None = None,
                 # v2.7 新增字段
                 verify_mode: str = "auto"):
        self.success = success
        self.data = data
        self.screenshot = screenshot
        self.diff_rate = diff_rate
        self.judge = judge          # pass / warn / fail
        self.duration_ms = duration_ms
        self.error = error
        self.extra = extra or {}
        # v2 扩展
        self.adapter = adapter
        self.a11y_tree = a11y_tree or []
        self.what_changed = what_changed or {}
        self.a11y_diff = a11y_diff or {}
        self.element_refs = element_refs or []
        # v2.7
        self.verify_mode = verify_mode

    def __bool__(self): return self.success
    def __repr__(self): return (f"<BrowserResult success={self.success} "
                                f"judge={self.judge} diff={self.diff_rate:.1%}"
                                f" adapter={self.adapter}>")


# ── SmartBrowser 引擎（v2） ──────────────────────────────────

class SmartBrowser:
    """智能浏览器自动化引擎 v2。

    v2 新增功能:
    - 双适配器（CDP/Bridge），ModeSelector 自动选择
    - 项目化管理（project/system/module 三层上下文）
    - 锚点系统升级：a11y → text → structure → layout → screenshot
    - 每步截图校验（非仅 step 0）
    """

    def __init__(self, config: Config | None = None,
                 adapter: str = "",
                 mode_selector: ModeSelector | None = None):
        """初始化引擎。

        参数:
            config: 配置对象（None 用默认 Config）
            adapter: 默认适配器偏好（""=auto, "cdp", "bridge"）
            mode_selector: 适配器策略引擎（None 时自动创建）
        """
        self.cfg = config or Config()
        self._adapter_name = adapter
        self._mode_selector = mode_selector or ModeSelector(default_mode="auto")
        # v2.4.1：project_context 实例级缓存（(project, system, module) → ctx），
        # 同 session 内项目配置不变，重复 run 跳过磁盘扫描 + YAML 解析。
        self._project_cache: dict[tuple[str, str, str], dict] = {}

    # ── 适配器解析 ───────────────────────────────────────────

    async def _resolve_adapter(self, mode: str = "",
                                adapter_hint: str = "",
                                lease: bool = False,
                                force_recheck: bool = False) -> tuple[str, Any]:
        """解析适配器。

        参数:
            mode: 操作模式（run/taskset）
            adapter_hint: 用户偏好（""/cdp/bridge）
            lease: per-run 租约（并行/命名 run：Bridge 独立实例）
            force_recheck: 跳过 Bridge TTL 缓存现场判定（run 判定点用）

        返回: (适配器名称, BrowserAdapter 实例)
        """
        hint = adapter_hint or self._adapter_name
        return await self._mode_selector.resolve(
            mode=mode, adapter_hint=hint or None,
            lease=lease, force_recheck=force_recheck,
        )

    # ── 项目上下文缓存 ──────────────────────────────────────────────────

    async def _load_project_context(self, project: str,
                                    system: str = "",
                                    module: str = "") -> dict:
        """加载项目上下文（实例级缓存）。

        键 = (project, system, module) 三元组；缓存命中直接返回。
        外部变更项目文件后调用 invalidate_project_cache() 清空。
        """
        key = (project, system, module)
        if key in self._project_cache:
            return self._project_cache[key]
        from .project import ProjectRegistry
        reg = ProjectRegistry()
        ctx = await reg.resolve_case(project, system, module)
        self._project_cache[key] = ctx
        return ctx

    def invalidate_project_cache(self) -> None:
        """清空项目上下文缓存（项目文件变更后调用）。"""
        self._project_cache.clear()


    # ── run ───────────────────────────────────────────────
    async def run(self, name: str,
                  headless: bool | None = None,
                  project: str = "",
                  system: str = "",
                  module: str = "",
                  adapter: str = "",
                  allow_new: bool = False,
                  login_account: str = "",
                  relogin: bool = False,
                  no_login: bool = False,
                  lease: bool = False,
                  run_id: str = "",
                  resume: bool = False,
                  force: bool = False,
                  multi_tab: bool = False,
                  detach_after: bool = False,
                  keep_session: bool = False,
                  verify_mode: str = "auto") -> BrowserResult:
        """🟦 确定性执行：运行已固化的任务。

        参数:
            name: 任务名称
            headless: 是否无头
            project: 项目名（可选，加载 adapter.json）
            system: 系统名（可选）
            module: 模块名（可选）
            adapter: 适配器偏好（""=auto, "cdp", "bridge"）
            allow_new: Bridge 模式无可复用分组时是否允许自动新建。
                False（默认）= 返回建议新建的待确认结果，不创建分组；
                True = 调用方已确认，直接新建。
            login_account: 登录注入账号（覆盖 login.account，白名单校验）
            relogin: 跳过登录态校验强制重注入（token 失效兜底）
            no_login: 任务级豁免登录注入（任务资产自带登录流程时用）
            lease: v2.5 per-run 租约（并行/命名 run）：
                Bridge 用独立适配器实例（隔离 _session_id/_tab_id）、
                会话名带 #r 身份后缀 + exclusive 全等匹配；CDP 开独立标签页。
            run_id: v2.5 一次运行的命名空间（产物归 runs/<run_id>/）。
                空 = 旧行为（不建 runs/、截图走 %TEMP% 默认路径）。
            resume: v2.5 接续已有 run（缺省 run_id 取该任务最近可恢复 run）。
                会话级接续（复用分组/tab）+ 任务级续跑（跳过已完成步骤）+
                run 级命名空间复用（产物继续追加）。
            force: resume 时允许接续 completed/failed 的 run（重接会话续跑）。
            multi_tab: v2.6 页签治理（D6）：显式声明允许 run 内创建辅助
                页签（默认 False = 单会话单页签，跨步骤在当前 tab goto）。
            detach_after: v2.6：multi_tab 下允许 run 结束后遗弃辅助页签
                （展示过程专用；默认 False = 用完即关）。
            keep_session: v2.6 页签治理（D1）：跳过保留期自动回收，
                本次会话显式永久保留（默认 False）。

        verify_mode: str, optional
            校验模式（v2.7）:
            - "auto"（默认）: 有 baseline 截图时走 screenshot，无 baseline 时走 dom
            - "screenshot": 截图 baseline 对比（原行为）
            - "dom": DOM 断言验证，跳过截图比对，使用 script.py 中的 DOM 检查结果

        返回:
            BrowserResult(success=..., data=..., judge=..., adapter=..., verify_mode=...)
        """
        start = time.time()
        if lease and not run_id:
            run_id = store.new_run_id()  # 租约必有命名空间（产物隔离前提）
        meta = store.load_task(name)

        # 检查任务状态
        if meta.get("status") != "ready":
            msg = (f"任务 '{name}' 尚未就绪（状态: {meta.get('status')}）。"
                   f"任务需先固化（flow/script 就绪）才能回放。")
            # 任务不存在（load_task 返回合成默认 meta）时不写日志，避免创建幽灵目录；
            # 任务存在但未就绪时才记录，便于排查固化缺失。
            if (store.task_dir(name, create=False) / "task.json").exists():
                store.write_log(name, "run", f"❌ {msg}")
            return BrowserResult(False, error=msg)

        # ── v2.5 2R2: resume 解析（接续已有 run）──
        resume_state = None
        if resume:
            if not run_id:
                rec = run_state.find_resumable_run(name)
                if not rec:
                    return BrowserResult(
                        False,
                        error="无可恢复的 run（无 interrupted/stale run），请直接 run")
                run_id = rec["run_id"]
            resume_state = run_state.load_run_state(run_id)
            if not resume_state:
                return BrowserResult(
                    False, error=f"run {run_id} 状态不存在，无法接续")
            if not force and not run_state.is_resumable(resume_state):
                return BrowserResult(
                    False,
                    error=f"run {run_id} 不可恢复（status="
                          f"{resume_state.get('status')}）。如需强制接续请加 --force")
            flow0 = store.load_flow(name)
            if flow0 and resume_state.get("flow_fp") and \
                    run_state.flow_fingerprint(flow0) != resume_state["flow_fp"]:
                return BrowserResult(
                    False, error="flow.json 已变更（指纹不符），拒绝接续，请重跑")
            lease = True  # resume 强制租约（独立实例 + #r 身份会话 + 产物归档）

        # 选择适配器
        actual_adapter_name, actual_adapter = await self._resolve_adapter(
            mode="run", adapter_hint=adapter,
            lease=lease, force_recheck=True,  # run 是判定点：每 run 独立探测
        )
        shot_dir = store.runs_dir(run_id) / "shots" if run_id else None
        store.write_log(name, "run", f"🔌 适配器: {actual_adapter_name}")

        script = store.load_script(name)
        if not script:
            msg = f"任务 '{name}' 缺少 script.py。请先固化任务（生成 flow/script 资产）。"
            store.write_log(name, "run", f"❌ {msg}")
            return BrowserResult(False, error=msg)

        # 如果有项目上下文，加载 adapter.json
        project_context = {}
        if project:
            # v2.4.1: 实例级缓存，同 session 内重复 run 跳过磁盘扫描
            project_context = await self._load_project_context(
                project, system or "", module or "")
            store.write_log(name, "run",
                            f"📂 项目上下文: {project}/{system}/{module}")

        store.write_log(name, "run", f"🟦 开始执行 (适配器: {actual_adapter_name})")

        # ── v2.5 2R2: 接续互斥锁（防双进程接续同一 run）──
        resume_locked = False
        if resume_state:
            if not run_state.acquire_resume_lock(run_id):
                return BrowserResult(
                    False,
                    error=f"run {run_id} 正在被其他进程接续（.resume.lock 存在）")
            resume_locked = True
            store.write_log(name, "run",
                            f"♻️ 接续 run {run_id}（从 next_step="
                            f"{resume_state.get('next_step', 0)} 续跑）",
                            run_id=run_id)

        if actual_adapter_name == "cdp":
            client = cdputil.CDPClient()
            try:
                await client.connect(
                    cdp_url=self.cfg.CDP_URL,
                    headless=headless if headless is not None else self.cfg.HEADLESS,
                    isolated=lease,  # v2.5: 并行/命名 run 开独立标签页
                )

                # v2.5 2R2: CDP run 状态（尽力续跑：脚本经 resume_ctx 决策断点）
                now_iso = datetime.now().isoformat(timespec="seconds")
                if resume_state:
                    cd = resume_state
                    cd.update({"status": "running", "heartbeat_at": now_iso,
                               "updated_at": now_iso})
                else:
                    cd = {
                        "run_id": run_id, "task": name, "status": "running",
                        "adapter": "cdp", "session_id": "", "session_name": "",
                        "flow_fp": "", "steps_count": 0, "next_step": 0,
                        "step_checks": [], "results": [], "warnings": [],
                        "heartbeat_at": now_iso, "created_at": now_iso,
                        "updated_at": now_iso,
                    }
                if run_id:
                    run_state.save_run_state(run_id, cd)

                # 登录注入（demo-project 专项，配置即开关；无 login 块/裸 run 零路径）
                if project_context and not no_login:
                    from .login_inject import ensure_login, LoginInjectError
                    try:
                        li = await ensure_login(
                            client, project_context,
                            account=login_account, force=relogin,
                            resolve_url=lambda u: self.resolve_step_url(
                                u, project_context, "project"))
                        if li.get("action") == "inject":
                            store.write_log(
                                name, "run",
                                f"🔐 登录注入: account={li.get('account')} "
                                f"token={li.get('token_masked', '')}")
                            self._reg_upsert_bridge(
                                actual_adapter, sid, name, project_context,
                                account=li.get("account", ""),
                                account_confirmed=True, run_id=run_id,
                                lease=lease)
                        elif li.get("action") == "skip_logged_in":
                            store.write_log(name, "run",
                                            "🔐 登录态已就绪，跳过注入")
                            self._reg_upsert_bridge(
                                actual_adapter, sid, name, project_context,
                                account=login_account or "",
                                account_confirmed=False, run_id=run_id,
                                lease=lease)
                    except LoginInjectError as e:
                        store.write_log(name, "run", f"❌ {e}")
                        return BrowserResult(False, error=str(e),
                                             adapter=actual_adapter_name)

                # v2.7: 根据 verify_mode 选择校验方式
                shot_steps = []
                dom_checks = []
                resolved_verify = verify_mode
                if resolved_verify == 'auto':
                    has_baseline = store.load_baseline_screenshot(name, 0) is not None
                    resolved_verify = 'screenshot' if has_baseline else 'dom'
                    store.write_log(name, 'run',
                                    f'verify_mode=auto -> {resolved_verify} '
                                    f'(baseline={"有" if has_baseline else "无"})')

                async def _verify_step(i: int):
                    if run_id:
                        cd["next_step"] = i + 1
                        cd["heartbeat_at"] = datetime.now().isoformat(timespec="seconds")
                        run_state.save_run_state(run_id, cd)
                    if resolved_verify == 'dom':
                        store.write_log(name, 'run',
                                        f'步骤{i}: dom 模式跳过截图比对')
                    else:
                        baseline = store.load_baseline_screenshot(name, i)
                        if baseline:
                            step_shot = (
                                await client.screenshot(
                                    path=str(shot_dir / f"step_{i:02d}.png"))
                                if shot_dir else await client.screenshot())
                            step_diff = snapshot.compare_images(step_shot, baseline)
                            step_judge = snapshot.judge_diff(
                                step_diff["diff_rate"],
                                pass_th=self.cfg.DIFF_PASS,
                                warn_th=self.cfg.DIFF_WARN,
                            )
                            shot_steps.append({
                                "step": i,
                                "judge": step_judge,
                                "diff_rate": step_diff["diff_rate"],
                            })
                            store.write_log(
                                name, "run",
                                f"📊 步骤{i} 校验: {step_judge} "
                                f"(差异率 {step_diff['diff_rate']:.1%})")

                data = await self._exec_script(client, name, script,
                                               on_step=_verify_step,
                                               project_context=project_context,
                                               resume_ctx=({
                                                   "next_step": resume_state.get(
                                                       "next_step", 0)
                                               } if resume_state else None))

                # 整体校验（根据 verify_mode 选择方式）
                # dom 模式不拍 final 截图（跳过截图比对 + 规避持续动画页
                # Page.screenshot 等动画结束导致的超时），产物以 dom_checks 为准
                if resolved_verify == 'dom':
                    shot = None
                    store.write_log(name, "run", "dom 模式跳过 final 截图")
                else:
                    shot = (await client.screenshot(path=str(shot_dir / "final.png"))
                            if shot_dir else await client.screenshot())
                baseline = None if resolved_verify == 'dom' else store.load_baseline_screenshot(name, 0)
                diff_result = None
                judge = "warn"
                if resolved_verify == 'dom':
                    dom_checks = data.get("dom_checks", []) if isinstance(data, dict) else []
                    if dom_checks:
                        failed = [c for c in dom_checks if not c.get("passed", True)]
                        if not failed:
                            judge = "pass"
                            store.write_log(name, "run",
                                            f"✅ DOM 校验通过 ({len(dom_checks)} 项断言)")
                        else:
                            judge = "fail"
                            store.write_log(name, "run",
                                            f"❌ DOM 校验失败 ({len(failed)}/{len(dom_checks)} 项)")
                    else:
                        store.write_log(name, "run",
                                        "⚠️ dom 模式但 script.py 未输出 dom_checks（judge=warn）")
                elif baseline:
                    diff_result = snapshot.compare_images(shot, baseline)
                    judge = snapshot.judge_diff(
                        diff_result["diff_rate"],
                        pass_th=self.cfg.DIFF_PASS,
                        warn_th=self.cfg.DIFF_WARN,
                    )
                    store.write_log(name, "run",
                                    f"📊 截图校验: {judge} "
                                    f"(差异率 {diff_result['diff_rate']:.1%})")
                elif shot_steps:
                    judge = self._worst_judge(s["judge"] for s in shot_steps)
                    store.write_log(name, "run",
                                    "⚠️ 无整体基线，以逐步校验结果为准")
                else:
                    store.write_log(name, "run",
                                    "⚠️ 无基线截图，未执行校验（judge=warn）")
                result = BrowserResult(
                    success=(judge != "fail"),
                    data=data,
                    screenshot=shot,
                    diff_rate=diff_result["diff_rate"] if diff_result else 0.0,
                    judge=judge,
                    duration_ms=(time.time() - start) * 1000,
                    adapter=actual_adapter_name,
                    verify_mode=resolved_verify,
                    extra={"step_checks": shot_steps} if shot_steps else (
                        {"dom_checks": dom_checks} if dom_checks else {}),
                )
                self._finalize_run(run_id, name, result, project,
                                   system, module, start)

                # v2.4：无 AI 自愈。校验失败时诚实返回失败结果，
                # 由调用方决定重跑或重新固化任务资产。
                if judge == "fail":
                    if diff_result:
                        result.error = (
                            "截图校验失败（差异率 "
                            f"{diff_result['diff_rate']:.1%}）。"
                            "v2.4 无 AI 自愈：请检查页面是否变更，"
                            "或重新固化任务资产后重试。"
                        )
                    elif dom_checks:
                        failed = [c for c in dom_checks if not c.get("passed", True)]
                        result.error = (
                            "DOM 校验失败（"
                            f"{len(failed)}/{len(dom_checks)} 项断言未通过）。"
                            "请检查 script.py 中的 DOM 断言逻辑。"
                        )

                return result

            except Exception as e:
                elapsed = (time.time() - start) * 1000
                store.write_error_log(name, "run", e)
                if run_id:
                    run_state.mark_run_status(run_id, "failed", error=str(e))
                result = BrowserResult(False, error=str(e),
                                       duration_ms=elapsed,
                                       adapter=actual_adapter_name)
                self._finalize_run(run_id, name, result, project,
                                   system, module, start)
                return result

            finally:
                await client.close()
                if resume_locked:
                    run_state.release_resume_lock(run_id)

        else:
            # Bridge 模式
            lease_adapter = actual_adapter if lease else None  # 租约实例需释放
            try:
                flow = store.load_flow(name)
                if not flow:
                    return BrowserResult(False, error="flow.json 不存在")

                # ♻️ 复用已有 session（免重复登录）
                steps_list = flow.get("steps", [])
                url_resolution = flow.get("url_resolution", "")
                first_url = steps_list[0].get("url", "") if steps_list else ""
                first_url = self.resolve_step_url(
                    first_url, project_context, url_resolution)
                if first_url:
                    # 传任务名作为业务分组名：既用于名字匹配复用已有分组，
                    # 也用于新建时生成中文分组名（增强交互体验）。
                    # v2.5 lease：会话名带 #r{run_id_short} 身份后缀 + exclusive
                    # 全等匹配——并行 A/B 各自独立分组、同源不复用、接续不串线。
                    if resume_state and resume_state.get("session_id"):
                        # 接续：优先按 session_id 直连（最快最准），
                        # 失效时 strict 名字兜底（绝不静默新建新分组，防串线）
                        if await actual_adapter.attach_session(
                                resume_state["session_id"]):
                            sid = resume_state["session_id"]
                            decision = {
                                "action": "reuse",
                                "reuse": {
                                    "name": resume_state.get(
                                        "session_name", name),
                                    "groupId": "",
                                },
                            }
                            store.write_log(
                                name, "run",
                                f"♻️ 接续会话(by session_id): {sid}",
                                run_id=run_id)
                        else:
                            sid, decision = await actual_adapter.find_or_create_session(
                                first_url,
                                name=f"{name}#r{store.run_id_short(run_id)}",
                                allow_new=False, exclusive=True)
                            if decision.get("action") != "reuse":
                                msg = ("会话已失效（分组被清理/浏览器关闭）。"
                                       "请用 bridge groups 确认，"
                                       "或放弃接续重跑。")
                                store.write_log(name, "run", f"❌ {msg}",
                                                run_id=run_id)
                                return BrowserResult(
                                    False, error=msg, adapter="bridge",
                                    extra={"run_id": run_id})
                            store.write_log(
                                name, "run",
                                f"♻️ 接续会话(by name): {sid}",
                                run_id=run_id)
                    else:
                        # v2.6 页签治理（D4）：顺序路径传期望账号做感知复用；
                        # lease/exclusive 路径不透传（并行隔离红线）。
                        expect_account = ""
                        if not lease:
                            expect_account = (login_account
                                             or ((project_context or {})
                                                 .get("adapter", {})
                                                 .get("login", {})
                                                 .get("account", ""))
                                             or "")
                        sid, decision = await actual_adapter.find_or_create_session(
                            first_url,
                            name=(f"{name}#r{store.run_id_short(run_id)}"
                                  if lease else name),
                            allow_new=allow_new,
                            exclusive=lease,
                            account=expect_account)
                    if decision.get("relogin_required"):
                        # 异账号命中 main_tab：复用 + 同 tab 强制重登（D4/D5）
                        store.write_log(
                            name, "run",
                            "🔁 复用会话但账号不符 → 同 tab 内重登",
                            run_id=run_id)
                        relogin = True
                    action = decision.get("action", "new")
                    if action == "reuse":
                        reuse = decision.get("reuse", {})
                        reuse_name = reuse.get("name", "?")
                        store.write_log(name, "run",
                            f"♻️ 复用已有分组: {reuse_name} "
                            f"(group={reuse.get('groupId')})")
                    elif action == "suggest_new":
                        suggested = decision.get("suggestedName", "?")
                        msg = (f"无可用复用的已有分组，建议新建分组「{suggested}」。"
                               f"确认后请以 allow_new=True（CLI: --new）重试。")
                        store.write_log(name, "run", f"🆕 {msg}")
                        return BrowserResult(
                            False,
                            error="无可复用分组，等待确认后新建",
                            adapter="bridge",
                            extra={"suggest_new": decision, "suggestedName": suggested},
                        )
                    else:
                        store.write_log(name, "run",
                            f"🆕 新建分组: {decision.get('createdName', '?')}")
                    store.write_log(
                        name, "run",
                        f"🔌 session={sid} "
                        f"tab={getattr(actual_adapter, '_tab_id', '')} "
                        f"run_id={run_id}",
                        run_id=run_id)
                else:
                    await actual_adapter.connect()

                # 登录注入（Bridge 路径：分组复用/新建后、回放前）
                if project_context and not no_login:
                    from .login_inject import ensure_login, LoginInjectError
                    try:
                        li = await ensure_login(
                            actual_adapter, project_context,
                            account=login_account, force=relogin,
                            resolve_url=lambda u: self.resolve_step_url(
                                u, project_context, "project"))
                        if li.get("action") == "inject":
                            store.write_log(
                                name, "run",
                                f"🔐 登录注入: account={li.get('account')} "
                                f"token={li.get('token_masked', '')}")
                        elif li.get("action") == "skip_logged_in":
                            store.write_log(name, "run",
                                            "🔐 登录态已就绪，跳过注入")
                    except LoginInjectError as e:
                        store.write_log(name, "run", f"❌ {e}")
                        return BrowserResult(False, error=str(e),
                                             adapter="bridge")

                # v2.5 2R2: run 状态（断点/心跳/校验历史，原子落盘）
                now_iso = datetime.now().isoformat(timespec="seconds")
                if resume_state:
                    st = resume_state
                    st.update({"status": "running", "heartbeat_at": now_iso,
                               "updated_at": now_iso})
                else:
                    st = {
                        "run_id": run_id, "task": name, "status": "running",
                        "adapter": "bridge",
                        "session_id": sid if first_url else "",
                        "session_name": (f"{name}#r{store.run_id_short(run_id)}"
                                         if lease else name),
                        "flow_fp": run_state.flow_fingerprint(flow) if flow else "",
                        "steps_count": len(steps_list), "next_step": 0,
                        "step_checks": [], "results": [], "warnings": [],
                        "heartbeat_at": now_iso, "created_at": now_iso,
                        "updated_at": now_iso,
                    }
                if run_id:
                    run_state.save_run_state(run_id, st)

                # 断点续跑：跳过已完成步骤，断点前校验结果恢复（不重截图/不重校验）
                start_idx = 0
                results = []
                all_warnings: list[str] = []
                shot_steps = []
                if resume_state:
                    start_idx = resume_state.get("next_step", 0)
                    if start_idx >= len(steps_list):
                        return BrowserResult(
                            False, error="run 已完成或断点越界，无可续步骤",
                            adapter="bridge", extra={"run_id": run_id})
                    results = list(resume_state.get("results", []))
                    all_warnings = list(resume_state.get("warnings", []))
                    shot_steps = list(resume_state.get("step_checks", []))

                # v2.4: 动作回放（P1-2 修复：不再只 goto，回放 action_detail/action）
                try:
                    for idx in range(start_idx, len(steps_list)):
                        if run_id:
                            run_state.mark_run_status(
                                run_id, "running", next_step=idx,
                                heartbeat_at=datetime.now().isoformat(
                                    timespec="seconds"))
                        step = steps_list[idx]
                        step_result = await self._replay_step(
                            actual_adapter, step,
                            project_context=project_context,
                            resolution=url_resolution,
                        )
                        results.append(step_result)
                        all_warnings.extend(step_result.get("warnings", []))

                        # P1-3: Bridge 逐步截图校验（与 CDP 分支对齐）
                        baseline = store.load_baseline_screenshot(name, idx)
                        if baseline:
                            step_shot = (
                                await actual_adapter.screenshot(
                                    out_path=str(shot_dir / f"step_{idx:02d}.png"))
                                if shot_dir else await actual_adapter.screenshot())
                            step_diff = snapshot.compare_images(step_shot, baseline)
                            step_judge = snapshot.judge_diff(
                                step_diff["diff_rate"],
                                pass_th=self.cfg.DIFF_PASS,
                                warn_th=self.cfg.DIFF_WARN,
                            )
                            shot_steps.append({
                                "step": idx,
                                "judge": step_judge,
                                "diff_rate": step_diff["diff_rate"],
                            })
                            store.write_log(
                                name, "run",
                                f"📊 步骤{idx} 校验: {step_judge} "
                                f"(差异率 {step_diff['diff_rate']:.1%})")

                        if run_id:
                            st = run_state.load_run_state(run_id) or st
                            st.update({
                                "next_step": idx + 1,
                                "heartbeat_at": datetime.now().isoformat(
                                    timespec="seconds"),
                                "results": results,
                                "step_checks": shot_steps,
                                "warnings": all_warnings,
                                "updated_at": datetime.now().isoformat(
                                    timespec="seconds"),
                            })
                            run_state.save_run_state(run_id, st)
                except KeyboardInterrupt:
                    if run_id:
                        run_state.mark_run_status(
                            run_id, "interrupted",
                            next_step=idx,  # 当前步骤未完成，从该步续
                            heartbeat_at=datetime.now().isoformat(
                                timespec="seconds"))
                    raise

                for w in all_warnings:
                    store.write_log(name, "run", f"⚠️ {w}")

                # 截图校验（整体 + 步骤聚合，与 CDP 分支一致）
                shot = (await actual_adapter.screenshot(
                            out_path=str(shot_dir / "final.png"))
                        if shot_dir else await actual_adapter.screenshot())
                baseline = store.load_baseline_screenshot(name, 0)
                diff_result = None
                judge = "warn"
                if baseline:
                    diff_result = snapshot.compare_images(shot, baseline)
                    judge = snapshot.judge_diff(
                        diff_result["diff_rate"],
                        pass_th=self.cfg.DIFF_PASS,
                        warn_th=self.cfg.DIFF_WARN,
                    )
                    store.write_log(name, "run",
                                    f"📊 截图校验: {judge} "
                                    f"(差异率 {diff_result['diff_rate']:.1%})")
                elif shot_steps:
                    # 无整体基线但有步骤基线 → 以最差步骤判定为准
                    judge = self._worst_judge(s["judge"] for s in shot_steps)
                    store.write_log(name, "run",
                                    "⚠️ 无整体基线，以逐步校验结果为准")
                else:
                    # 无基线 → 降级 warn，不静默 pass
                    store.write_log(name, "run",
                                    "⚠️ 无基线截图，未执行校验（judge=warn）")

                # P1-1: 步骤校验聚合到最终判定
                if shot_steps:
                    step_worst = self._worst_judge(s["judge"] for s in shot_steps)
                    judge = self._worst_judge([judge, step_worst])
                    if step_worst == "fail":
                        store.write_log(
                            name, "run",
                            "📊 存在步骤校验失败，最终判定为 fail")

                # 获取 a11y 树
                a11y_tree = await actual_adapter.accessibility_tree()

                if run_id:
                    run_state.mark_run_status(
                        run_id, "completed", next_step=len(steps_list),
                        judge=judge,
                        heartbeat_at=datetime.now().isoformat(
                            timespec="seconds"))

                store.inc_run_count(name)
                elapsed = (time.time() - start) * 1000

                result = BrowserResult(
                    success=(judge != "fail"),
                    data=results,
                    screenshot=shot,
                    diff_rate=diff_result["diff_rate"] if diff_result else 0.0,
                    judge=judge,
                    duration_ms=elapsed,
                    adapter="bridge",
                    a11y_tree=[t.to_dict() for t in a11y_tree],
                    extra={"action_warnings": all_warnings,
                           **({"step_checks": shot_steps} if shot_steps else {})},
                )
                self._finalize_run(run_id, name, result, project,
                                   system, module, start)
                # v2.6 页签治理：run 后标记 idle + 保留期自动回收
                if first_url and sid:
                    await self._post_run_gc(
                        actual_adapter, sid, name, project_context,
                        success=(judge != "fail"), run_id=run_id,
                        lease=lease, keep_session=keep_session)
                return result

            except Exception as e:
                elapsed = (time.time() - start) * 1000
                store.write_error_log(name, "run", e)  # 与 CDP 分支对称
                if run_id:
                    run_state.mark_run_status(run_id, "failed", error=str(e))
                result = BrowserResult(False, error=str(e),
                                       duration_ms=elapsed, adapter="bridge")
                self._finalize_run(run_id, name, result, project,
                                   system, module, start)
                if first_url and sid:
                    await self._post_run_gc(
                        actual_adapter, sid, name, project_context,
                        success=False, run_id=run_id,
                        lease=lease, keep_session=keep_session)
                return result
            finally:
                if lease_adapter is not None:
                    # 只关闭本租约实例的连接池；Bridge 服务端 session 由扩展侧保活
                    await lease_adapter.close()
                if resume_locked:
                    run_state.release_resume_lock(run_id)

    async def _exec_script(self, client: cdputil.CDPClient,
                            name: str, script: str,
                            on_step: Callable[[int], Any] | None = None,
                            project_context: dict | None = None,
                            resume_ctx: dict | None = None) -> Any:
        """执行任务的 CDP 脚本。

        参数:
            on_step: 每完成一步导航/动作后回调(step_index)，
                供调用方在逐步执行后立即截图校验（P0 修复：不再统一截最终页）。
            project_context: 项目上下文（resolve_case 结果，含 adapter 配置）。
                注入脚本命名空间为 `project` 变量，供脚本消费 baseUrl/routes 等。
                无项目上下文时为 {}，脚本需自行容错（向后兼容）。
            resume_ctx: v2.5 2R2 接续上下文（{"next_step": N}），注入脚本命名空间
                为 `resume_ctx` 变量。脚本契约（可选）：run(client, resume_ctx=None)，
                自行决定是否跳过前置步骤（CDP 尽力续跑）。
        """
        script_path = store.task_dir(name, create=False) / "script.py"

        # 无 script 时回退 flow 导航（仅此场景回退；脚本存在但失败 → 诚实报错）
        if not script:
            flow = store.load_flow(name)
            if not flow:
                raise RuntimeError("flow.json 也不存在")

            results = []
            url_resolution = flow.get("url_resolution", "")
            for i, step in enumerate(flow.get("steps", [])):
                url = step.get("url", "")
                url = self.resolve_step_url(url, project_context or {},
                                            url_resolution)
                if url:
                    await client.goto(url)
                    await client.wait_for_load()
                if on_step:
                    await on_step(i)
                results.append({"url": url or "about:blank"})

            return results

        # 脚本存在：编译/执行失败 → 诚实抛错（不再静默回退 flow）
        local_vars = {
            "client": client,
            "asyncio": asyncio,
            "project": project_context or {},
            "resume_ctx": resume_ctx or {},
        }
        exec(compile(script, str(script_path), "exec"), local_vars)
        if "run" not in local_vars:
            raise RuntimeError(
                f"script.py 未定义 run(client) 函数（任务 {name}）。"
                "请修正脚本资产后重试。")
        result = await local_vars["run"](client)
        if on_step:
            await on_step(0)  # 脚本执行完统一回调一次（脚本自管流程）
        return result

    def _finalize_run(self, run_id: str, name: str, result: BrowserResult,
                      project: str, system: str, module: str,
                      started_at: float) -> None:
        """v2.5：run_id 非空时归档 run 产物（meta/result + 透传 run_id）。

        空 run_id（顺序旧路径）直接返回，零行为变化。
        """
        if not run_id:
            return
        store.write_run_meta(run_id, {
            "task": name,
            "adapter": result.adapter,
            "judge": result.judge,
            "success": result.success,
            "project": project, "system": system, "module": module,
            "started_at": datetime.now().isoformat(timespec="seconds"),
            "finished_at": datetime.now().isoformat(timespec="seconds"),
            "duration_ms": result.duration_ms,
        })
        store.write_run_result(run_id, {
            "success": result.success,
            "judge": result.judge,
            "diff_rate": result.diff_rate,
            "adapter": result.adapter,
            "error": result.error,
            "duration_ms": result.duration_ms,
            "data": result.data,
            "extra": result.extra,
        })
        result.extra["run_id"] = run_id  # BrowserResult.extra 透传（CLI/test 查询消费）

    # ── v2.6 页签治理（会话注册表 / 保留期回收）──────────────

    @staticmethod
    def _reg_upsert_bridge(adapter, sid: str, name: str,
                           project_context: dict | None,
                           *, account: str = "",
                           account_confirmed: bool = False,
                           run_id: str = "", lease: bool = False) -> None:
        """回填会话注册表（记录账号/归属/租约身份/状态）。失败不阻断。"""
        try:
            from . import session_registry as sr
            group_id = getattr(adapter, "_session_id", "") or ""
            sr.upsert_session({
                "session_id": sid,
                "name": name,
                "group_id": group_id,
                "main_tab_id": str(getattr(adapter, "_tab_id", "")),
                "tab_ids": [],
                "urls": [],
                "account": account,
                "account_confirmed": account_confirmed,
                "task": name,
                "project": (project_context or {}).get("project", ""),
                "status": sr.ST_RUNNING,
                "lease_run_id": run_id if lease else "",
                "resumable": False,
            })
        except Exception:
            pass

    async def _post_run_gc(self, adapter, sid: str, name: str,
                           project_context: dict | None,
                           *, success: bool, run_id: str,
                           lease: bool, keep_session: bool) -> None:
        """run 后置清理（GREEN D7）：标记 idle + 保留期自动回收。

        - 本次会话标记 idle + last_active_at=now（保留期内可复用免重登）
        - keep_session=True：标记后跳过自动回收（显式永久保留）
        - 自动回收（OP_BROWSER_AUTO_CLEANUP=true 默认）：回收
          reclaimable 且非当前会话、非 running/interrupted 的会话
        - 失败不阻断主流程（finally 兜底语义）
        """
        try:
            from . import session_registry as sr
            if sid:
                if keep_session:
                    sr.touch_active(sid, status=sr.ST_IDLE)
                else:
                    sr.touch_active(sid, status=sr.ST_IDLE)
            if not sr.AUTO_CLEANUP or keep_session:
                return
            # 只回收「本次新建且超保留期」之外的 reclaimable 会话：
            # 跳过当前 run 关联（避免刚 idle 即被回收）
            for r_sid in sr.reclaimable_ids():
                if r_sid == sid:
                    continue
                if sr.is_running_heartbeat_fresh(r_sid):
                    continue
                if adapter and hasattr(adapter, "cleanup_sessions"):
                    await adapter.cleanup_sessions(
                        stale_only=False, close_tabs=True, names=None)
                    sr.delete_session(r_sid)
        except Exception:
            pass

    # ── 动作回放（P1-2）──────────────────────────────────

    @staticmethod
    def resolve_step_url(url: str, project_context: dict,
                         resolution: str) -> str:
        """opt-in 步骤 URL 解析（P1-3b）：flow 声明 url_resolution=project 时，
        相对 URL 用 adapter 的 baseUrl(+fe_base_prefix) 拼接；绝对 URL 或
        未声明维持原样。adapter 配置缺失时回退原 URL（不臆造）。"""
        if not resolution or resolution != "project" or not url:
            return url
        if url.startswith(("http://", "https://", "about:", "data:")):
            return url
        adapter = (project_context or {}).get("adapter", {}) or {}
        overlay = (adapter.get("environmentOverlays") or {}).get("dev", {}) or {}
        base = overlay.get("baseUrl") or adapter.get("baseUrl") or ""
        if not base:
            return url
        base = base.rstrip("/")
        prefix = adapter.get("fe_base_prefix") or ""
        if prefix:
            if url.startswith(prefix):
                return f"{base}{url}"
            base = f"{base}/{prefix.lstrip('/')}"
        return f"{base}/{url.lstrip('/')}"

    @staticmethod
    def _worst_judge(judges) -> str:
        """多个判定取最差（fail > warn > pass），供整体/逐步校验聚合。"""
        rank = {"pass": 0, "warn": 1, "fail": 2}
        worst = "pass"
        for j in judges:
            if rank.get(j, 1) > rank.get(worst, 1):
                worst = j
        return worst

    async def _replay_step(self, adapter: Any, step: dict,
                           project_context: dict | None = None,
                           resolution: str = "") -> dict:
        """回放单步：goto（有 url）→ wait_for_load → 逐个执行 actions。

        actions 来源：step.action_detail（SKILL.md 字段名）或 step.action（兼容键）。
        解析失败（未知动作类型/字段错误）→ 诚实报错（raise ValueError），不静默跳过；
        执行失败（元素未找到等）→ 记 warn 不阻断，由截图判据兜底。
        无 actions 的旧 flow 维持 goto-only（向后兼容）。
        """
        url = step.get("url", "")
        url = self.resolve_step_url(url, project_context or {}, resolution)
        result: dict = {"url": url or "about:blank", "actions": [], "warnings": []}
        if url:
            await adapter.goto(url)
            await adapter.wait_for_load()

        actions = step.get("action_detail") or step.get("action")
        if not actions:
            return result
        if not isinstance(actions, list):
            raise ValueError(f"action_detail 必须是列表，实际 {type(actions).__name__}")

        for i, act in enumerate(actions):
            if not isinstance(act, dict):
                raise ValueError(f"action_detail[{i}] 必须是对象，实际 {type(act).__name__}")
            atype = act.get("type", "?")
            try:
                await self._replay_action(adapter, act)
                result["actions"].append({"type": atype, "ok": True})
            except ValueError:
                # schema 不认识 → 诚实报错，不静默跳过
                raise
            except Exception as e:
                # 执行失败 → warn 不阻断，由截图判据兜底
                result["warnings"].append(f"action[{i}] {atype} 执行失败: {e}")
                result["actions"].append({"type": atype, "ok": False})
        return result

    async def _replay_action(self, adapter: Any, act: dict) -> None:
        """执行单个动作。支持动作类型：
        click — ref → selector → role+name
        fill  — selector → role+name
        type  — 直接键入
        key   — 按键
        select — 选择下拉选项（v3.5）
        scroll — 页面/元素滚动（v3.5）
        hover  — 鼠标悬停（v3.5）
        wait   — 显式等待（v3.5）
        human-like 延迟：动作间按 act 中 human_like_delay_ms 字段自动 sleep。
        未知类型 raise ValueError。"""
        import asyncio, random as _rnd

        # ── human-like 延迟（动作前） ──
        delay_ms = act.get("human_like_delay_ms")
        if delay_ms and delay_ms > 0:
            await asyncio.sleep(delay_ms / 1000.0)

        atype = act.get("type", "")
        if atype == "click":
            ref = act.get("ref", "")
            selector = act.get("selector", "")
            role = act.get("role", "")
            name = act.get("name", "")
            if ref:
                r = await adapter.click_by_ref(str(ref))
                if not r.success:
                    raise RuntimeError(f"click_by_ref({ref}) 失败: {r.error}")
            elif selector:
                r = await adapter.click(str(selector))
                if not r.success:
                    raise RuntimeError(f"click({selector}) 失败: {r.error}")
            elif role and name:
                r = await adapter.click_by_locator(str(role), str(name))
                if not r.success:
                    raise RuntimeError(f"click_by_locator({role},{name}) 失败: {r.error}")
            else:
                raise ValueError("click 动作缺少定位信息（ref/selector/role+name 至少其一）")
        elif atype == "fill":
            text = str(act.get("text", ""))
            selector = act.get("selector", "")
            role = act.get("role", "")
            name = act.get("name", "")
            if selector:
                r = await adapter.fill(str(selector), text)
            elif role and name:
                r = await adapter.fill_by_locator(str(role), str(name), text)
            else:
                raise ValueError("fill 动作缺少定位信息（selector 或 role+name）")
            if not r.success:
                raise RuntimeError(f"fill 失败: {r.error}")
        elif atype == "type":
            r = await adapter.type_text(str(act.get("text", "")))
            if not r.success:
                raise RuntimeError(f"type_text 失败: {r.error}")
        elif atype == "key":
            r = await adapter.press_key(str(act.get("key", "")))
            if not r.success:
                raise RuntimeError(f"press_key 失败: {r.error}")
        elif atype == "select":
            # v3.5: 选择下拉选项 — 支持 selector / role+name / value 定位
            value = str(act.get("value", ""))
            selector = act.get("selector", "")
            role = act.get("role", "")
            name = act.get("name", "")
            if hasattr(adapter, "select_option"):
                if selector:
                    r = await adapter.select_option(str(selector), value)
                elif role and name:
                    r = await adapter.select_option_by_locator(str(role), str(name), value)
                else:
                    raise ValueError("select 动作缺少定位信息（selector 或 role+name）")
                if not r.success:
                    raise RuntimeError(f"select({value}) 失败: {r.error}")
            else:
                # 降级：尝试通过 fill + click 组合实现
                if selector:
                    await adapter.click(str(selector))
                elif role and name:
                    await adapter.click_by_locator(str(role), str(name))
                await asyncio.sleep(0.3)
                try:
                    r = await adapter.click(str(f"text='{value}'"))
                    if not r.success:
                        raise RuntimeError(f"select 降级 click({value}) 失败: {r.error}")
                except Exception:
                    raise RuntimeError(f"select 失败: adapter 无 select_option 方法且降级 click 无效")
        elif atype == "scroll":
            # v3.5: 滚动 — direction: up/down/left/right, amount: px, selector: 可选目标元素
            direction = act.get("direction", "down")
            amount = int(act.get("amount", 300))
            selector = act.get("selector", "")
            delta_x, delta_y = 0, 0
            if direction == "down":
                delta_y = amount
            elif direction == "up":
                delta_y = -amount
            elif direction == "right":
                delta_x = amount
            elif direction == "left":
                delta_x = -amount
            if hasattr(adapter, "scroll_by"):
                if selector:
                    r = await adapter.scroll_by(str(selector), delta_x, delta_y)
                else:
                    r = await adapter.scroll_by(None, delta_x, delta_y)
                if not r.success:
                    raise RuntimeError(f"scroll({direction},{amount}) 失败: {r.error}")
            elif hasattr(adapter, "page"):
                # CDP 适配器降级：直接操作 page
                await adapter.page.evaluate(f"window.scrollBy({delta_x}, {delta_y})")
            else:
                raise RuntimeError("scroll 失败: adapter 无 scroll_by/page 方法")
        elif atype == "hover":
            # v3.5: 鼠标悬停 — 定位链与 click 一致
            selector = act.get("selector", "")
            role = act.get("role", "")
            name = act.get("name", "")
            if hasattr(adapter, "hover"):
                if selector:
                    r = await adapter.hover(str(selector))
                elif role and name:
                    r = await adapter.hover_by_locator(str(role), str(name))
                else:
                    raise ValueError("hover 动作缺少定位信息（selector 或 role+name）")
                if not r.success:
                    raise RuntimeError(f"hover 失败: {r.error}")
            elif hasattr(adapter, "page"):
                # 降级：使用 page hover
                locator_str = selector or f"[role='{role}']"
                try:
                    await adapter.page.hover(locator_str)
                except Exception as e:
                    raise RuntimeError(f"hover 降级失败: {e}")
            else:
                raise RuntimeError("hover 失败: adapter 无 hover/page 方法")
        elif atype == "wait":
            # v3.5: 显式等待
            wait_ms = int(act.get("wait_ms", 300))
            await asyncio.sleep(wait_ms / 1000.0)
        else:
            raise ValueError(f"未知动作类型: {atype!r}（支持 click/fill/type/key/select/scroll/hover/wait）")

    # ── taskset ───────────────────────────────────────────

    async def taskset(self, names: list[str],
                      sequential: bool = True,
                      stop_on_fail: bool = True,
                      adapter: str = "",
                      allow_new: bool = False,
                      project: str = "", system: str = "", module: str = "",
                      login_account: str = "", relogin: bool = False,
                      no_login: bool = False,
                      run_id_map: dict | None = None) -> list[BrowserResult]:
        """🟣 多任务编排：顺序或并行执行多个任务。

        参数:
            names: 任务名称列表
            sequential: True=顺序执行, False=并行执行
            stop_on_fail: 顺序模式下失败是否停止后续
            adapter: 适配器偏好
            allow_new: Bridge 模式无可复用分组时是否允许自动新建
            project/system/module/login_account/relogin/no_login:
                v2.5 透传至每个 run（修复 taskset 不带项目上下文的缺口）
            run_id_map: v2.5 2R2 任务名 → run_id 映射（并行时优先使用；
                缺省自动生成）。供 CLI taskset --run-id "A=rA,B=rB" 使用。

        v2.5 并行（sequential=False）守卫：
            - allow_new=True 必须显式给出（并行 run 无法在编排中等待用户确认）
            - 每个 run 自动 lease=True + 独立 run_id（Bridge 租约 / CDP isolated /
              runs/ 产物命名空间，杜绝假并行）

        返回:
            [BrowserResult, ...]
        """
        results = []
        store.write_taskset_log(f"🟣 开始任务编排: {', '.join(names)}")

        if sequential:
            for name in names:
                result = await self.run(name, adapter=adapter,
                                        allow_new=allow_new,
                                        project=project, system=system,
                                        module=module,
                                        login_account=login_account,
                                        relogin=relogin, no_login=no_login)
                results.append(result)
                store.write_taskset_log(
                    f"  {'✅' if result.success else '❌'} {name}: {result.judge}")
                if not result.success and stop_on_fail:
                    store.write_taskset_log(f"⛔ 因 {name} 失败，停止后续任务")
                    break
        else:
            if not allow_new:
                raise ValueError(
                    "并行执行（sequential=False）要求 allow_new=True：并行 run "
                    "需各自新建/复用独立分组，无法在编排中等待用户确认。"
                    "请传 allow_new=True（CLI: --new）后重试。")
            # 并行守卫：每个 run 强制 lease + 自动 run_id（产物/会话/页面隔离）
            run_id_map = run_id_map or {}
            run_ids = [run_id_map.get(n) or store.new_run_id() for n in names]
            tasks = [
                self.run(name, adapter=adapter, allow_new=True,
                         project=project, system=system, module=module,
                         login_account=login_account, relogin=relogin,
                         no_login=no_login, lease=True, run_id=rid)
                for name, rid in zip(names, run_ids)
            ]
            results = await asyncio.gather(*tasks)
            for name, rid, r in zip(names, run_ids, results):
                store.write_taskset_log(
                    f"  {'✅' if r.success else '❌'} {name}: {r.judge} "
                    f"run_id={rid}")

        return results

    # ── 便捷方法 ─────────────────────────────────────────


    # ── 辅助方法 ─────────────────────────────────────────




    # ── Bridge 辅助 ──────────────────────────────────────

    async def bridge_health(self) -> dict:
        """检查 Bridge 服务健康状态。"""
        return await self._mode_selector.check_bridge_health()

    async def session_cleanup(self, **kwargs) -> dict:
        """清理 Bridge 分组（委托 BridgeAdapter.cleanup_sessions）。

        参数透传：stale_only / close_tabs / names。
        """
        _, adapter = await self._resolve_adapter(mode="run",
                                                  adapter_hint="bridge")
        return await adapter.cleanup_sessions(**kwargs)

    async def list_sessions(self) -> list[dict]:
        """列出全部 Bridge 分组详情（含 v2.6 页签治理扩展字段）。"""
        _, adapter = await self._resolve_adapter(mode="run",
                                                  adapter_hint="bridge")
        return await adapter.list_session_details(force_refresh=True)

    # ── 静态信息方法 ─────────────────────────────────────

    @staticmethod
    def list_tasks() -> list[dict]:
        return store.list_tasks()

    @staticmethod
    def task_info(name: str) -> dict:
        return store.load_task(name)

    @staticmethod
    def delete_task(name: str) -> bool:
        return store.delete_task(name)
