"""
op_browser / snapshot.py — 截图校验与基线对比

负责：
- 两张截图的像素差异率计算
- 基线截图管理（保存、加载）
"""
from PIL import Image, ImageChops


# ── 像素对比 ─────────────────────────────────────────────

def compare_images(path_a: str, path_b: str) -> dict:
    """对比两张截图，返回差异信息。

    返回:
        {
            "diff_rate": float,       # 差异像素占比（0.0 ~ 1.0）
            "diff_pixels": int,       # 差异像素数
            "total_pixels": int,      # 总像素数
            "same_size": bool,        # 尺寸是否一致
        }
    """
    img_a = Image.open(path_a).convert("RGB")
    img_b = Image.open(path_b).convert("RGB")

    total = img_a.size[0] * img_a.size[1]

    # 如果尺寸不同，缩放到同一尺寸再比
    if img_a.size != img_b.size:
        same_size = False
        # 缩放到较小的那个
        min_w = min(img_a.width, img_b.width)
        min_h = min(img_a.height, img_b.height)
        img_a = img_a.resize((min_w, min_h))
        img_b = img_b.resize((min_w, min_h))
        total = min_w * min_h
    else:
        same_size = True

    # 逐像素对比
    diff = ImageChops.difference(img_a, img_b)
    bbox = diff.getbbox()

    if bbox:
        # 有差异区域
        diff_pixels = sum(
            1 for pixel in diff.getdata()
            if pixel != (0, 0, 0)
        )
        diff_rate = diff_pixels / total if total > 0 else 0.0

    else:
        diff_pixels = 0
        diff_rate = 0.0

    return {
        "diff_rate": diff_rate,
        "diff_pixels": diff_pixels,
        "total_pixels": total,
        "same_size": same_size,
    }


# ── 校验判定 ─────────────────────────────────────────────

def judge_diff(diff_rate: float,
               pass_th: float = 0.05, warn_th: float = 0.20) -> str:
    """根据差异率给出判定。

    参数:
        pass_th: 低于此差异率判定 pass（默认 5%）
        warn_th: 低于此差异率判定 warn，否则 fail（默认 20%）
    """
    if diff_rate < pass_th:
        return "pass"
    elif diff_rate < warn_th:
        return "warn"
    else:
        return "fail"
