"""下拉选择生成器 — 从目标值生成 action_detail 序列"""

from typing import List, Dict, Any, Optional
from .common import (
    HumanLikeConfig, build_label_selectors,
    make_click, make_fill, make_select, make_wait,
)


def generate_dropdown_actions(
    target: Dict[str, Any],
    value: str,
    value_type: str = "text",
    dropdown_type: str = "auto",
    human_like: Optional[Dict[str, Any]] = None,
) -> List[Dict[str, Any]]:
    """
    生成下拉选择的 action_detail 序列。

    Args:
        target: 下拉框定位 { label, selector, role, name }
        value: 要选择的选项文本或 value
        value_type: text|value|index — 匹配方式
        dropdown_type: auto|native|custom|cascading|searchable
        human_like: 可选覆盖延迟参数

    Returns:
        action_detail 列表
    """
    cfg = HumanLikeConfig(human_like)
    actions: List[Dict[str, Any]] = []
    label = target.get("label", "")
    selector = target.get("selector")

    actions.append(make_wait(200, "等待下拉框可交互"))

    if dropdown_type == "native":
        # 原生 <select>：直接设置 value
        actions.append(make_select(
            selector=selector, role="listbox", name=label,
            value=value,
            description=f"选择「{label}」→「{value}」",
        ))
        actions.append(make_wait(cfg.random_ms("wait_after_action_ms"), "等待选择生效"))

    elif dropdown_type == "searchable":
        # 可搜索下拉：点击 → 输入 → 等待 → 选择
        actions.append(make_click(
            selector=selector, role="combobox", name=label,
            description=f"点击可搜索下拉框「{label}」",
        ))
        actions.append(make_wait(cfg.random_ms("wait_after_action_ms"), "等待展开"))
        actions.append(make_fill(
            selector=selector, text=value,
            description=f"输入筛选「{value}」",
        ))
        actions.append(make_wait(500, "等待筛选结果"))
        _append_option_click(actions, value, value_type, cfg)

    elif dropdown_type == "cascading":
        # 级联下拉：由调用方传入 levels，此处仅生成单级操作
        actions.append(make_click(
            selector=selector, role="combobox", name=label,
            description=f"点击下拉框「{label}」",
        ))
        actions.append(make_wait(cfg.random_ms("wait_after_action_ms"), "等待展开"))
        _append_option_click(actions, value, value_type, cfg)
        actions.append(make_wait(cfg.random_ms("level_gap_ms"), "等待下级加载"))

    else:
        # auto / custom：点击 → 等待 → 选择选项
        actions.append(make_click(
            selector=selector, role="combobox", name=label,
            description=f"点击下拉框「{label}」",
        ))
        actions.append(make_wait(cfg.random_ms("wait_after_action_ms"), "等待下拉面板渲染"))
        _append_option_click(actions, value, value_type, cfg)

    return actions


def _append_option_click(
    actions: List[Dict[str, Any]],
    value: str, value_type: str, cfg: HumanLikeConfig,
):
    """追加选项点击动作"""
    if value_type == "index":
        actions.append(make_click(
            selector=f".ant-select-item:nth-child({int(value) + 1})",
            description=f"点击第 {value} 个选项",
        ))
    elif value_type == "value":
        actions.append(make_click(
            selector=f"option[value='{value}']",
            description=f"选择 value='{value}'",
        ))
    else:
        # 默认按文本匹配
        actions.append(make_click(
            role="option", name=value,
            description=f"点击选项「{value}」",
        ))
    actions.append(make_wait(cfg.random_ms("wait_after_action_ms"), "等待选择生效"))


def generate_cascading_actions(
    levels: List[Dict[str, str]],
    human_like: Optional[Dict[str, Any]] = None,
) -> List[Dict[str, Any]]:
    """
    生成级联下拉的完整 action_detail 序列。

    Args:
        levels: [{ label: "省份", value: "浙江省" }, { label: "城市", value: "杭州市" }]
        human_like: 可选覆盖延迟参数

    Returns:
        action_detail 列表
    """
    cfg = HumanLikeConfig(human_like)
    actions: List[Dict[str, Any]] = []

    for i, level in enumerate(levels):
        level_actions = generate_dropdown_actions(
            target={"label": level.get("label", "")},
            value=level.get("value", ""),
            dropdown_type="cascading" if i < len(levels) - 1 else "auto",
            human_like=human_like,
        )
        actions.extend(level_actions)

    return actions
