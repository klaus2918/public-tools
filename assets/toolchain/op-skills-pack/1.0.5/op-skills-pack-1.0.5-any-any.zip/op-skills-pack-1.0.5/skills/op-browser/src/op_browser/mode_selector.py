"""
op_browser / mode_selector.py — ModeSelector 适配器策略引擎

按场景自动推荐适配器，支持 auto/cdp/bridge/hybrid 四种模式。
Bridge 不可用时自动降级 CDP。
"""
from __future__ import annotations
import asyncio
import logging
import time
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from .base import BrowserAdapter


logger = logging.getLogger(__name__)


class ModeSelector:
    """适配器策略引擎。

    按操作模式和配置自动选择最优 BrowserAdapter。
    用户可通过 adapter 参数强制指定适配器。

    v2.4.1: BridgeAdapter 通过类级 _shared_bridge 实现进程级复用，
    即使多次创建 ModeSelector 实例也共享同一连接池和 session 缓存。

    策略表:
        auto/run  → CDP 优先（零依赖高速执行）
        bridge    → Bridge（a11y 稳定定位；不可用时降级 CDP）
        cdp       → 强制 CDP
        hybrid    → 与 auto 等价（run 场景 CDP；探索场景由调用方传 adapter="bridge"）
    """

    MODE_AUTO = "auto"       # 自动选择
    MODE_CDP = "cdp"         # 强制 CDP
    MODE_BRIDGE = "bridge"   # 强制 Bridge
    MODE_HYBRID = "hybrid"   # 探索用 Bridge，执行用 CDP

    _shared_bridge: "BridgeAdapter | None" = None  # v2.4.1: 类级共享单例

    def __init__(self, cdp_adapter: "BrowserAdapter | None" = None,
                 bridge_adapter: "BrowserAdapter | None" = None,
                 default_mode: str = MODE_AUTO):
        self._cdp = cdp_adapter
        self._bridge = bridge_adapter or ModeSelector._shared_bridge
        self._default_mode = default_mode
        # Bridge 可用性缓存：TTL 30s，避免进程内永久缓存导致
        # Bridge 恢复/崩溃后长期使用过期结论
        self._bridge_available: bool | None = None
        self._bridge_checked_at: float = 0.0
        self._bridge_check_lock = asyncio.Lock()
        self._bridge_ttl = 30.0

    async def resolve(self, mode: str | None = None,
                      adapter_hint: str | None = None,
                      lease: bool = False,
                      force_recheck: bool = False) -> tuple[str, "BrowserAdapter"]:
        """解析适配器选择。

        参数:
            mode: 操作模式（auto/cdp/bridge/hybrid 或 run）
            adapter_hint: 用户偏好的适配器名（cdp/bridge）
            lease: True = per-run 租约（并行/命名 run 用）：
                Bridge 分支创建独立 BridgeAdapter 实例（隔离 _session_id/_tab_id），
                复用可用性探测缓存；CDP 分支由调用方透传 isolated。
            force_recheck: True = 跳过 Bridge 可用性 TTL 缓存现场判定
                （run 是测试判定点，每次独立；管理命令保持缓存）。

        返回:
            (实际适配器名称, BrowserAdapter 实例)

        优先级: adapter_hint > mode 策略 > default_mode
        """
        # 1. 用户强制指定
        if adapter_hint:
            if adapter_hint == self.MODE_BRIDGE:
                if lease:
                    leased = await self._acquire_bridge_lease()
                    if leased:
                        return leased
                    # Bridge 不可用，降级并打印 WARN
                    logger.warning("⚠️ [ModeSelector] Bridge 不可用，降级到 CDP")
                    return (self.MODE_CDP, await self._resolve_cdp())
                adapter = await self._resolve_bridge()
                if adapter:
                    return (self.MODE_BRIDGE, adapter)
                # Bridge 不可用，降级并打印 WARN
                logger.warning("⚠️ [ModeSelector] Bridge 不可用，降级到 CDP")
                return (self.MODE_CDP, await self._resolve_cdp())

            elif adapter_hint == self.MODE_CDP:
                return (self.MODE_CDP, await self._resolve_cdp())

        # 2. 按操作模式策略选择
        actual_mode = mode or self._default_mode or self.MODE_AUTO

        if actual_mode == self.MODE_BRIDGE:
            if lease:
                leased = await self._acquire_bridge_lease()
                if leased:
                    return leased
                logger.warning("⚠️ [ModeSelector] Bridge 不可用，降级到 CDP")
                return (self.MODE_CDP, await self._resolve_cdp())
            adapter = await self._resolve_bridge()
            if adapter:
                return (self.MODE_BRIDGE, adapter)
            logger.warning("⚠️ [ModeSelector] Bridge 不可用，降级到 CDP")
            return (self.MODE_CDP, await self._resolve_cdp())

        elif actual_mode == self.MODE_CDP:
            return (self.MODE_CDP, await self._resolve_cdp())

        elif actual_mode == self.MODE_HYBRID:
            # hybrid 模式默认返回 CDP（run 场景），explore 由调用方传 adapter="bridge"
            return (self.MODE_CDP, await self._resolve_cdp())

        else:  # auto/run
            # auto/run：CDP 优先（高速执行）
            return (self.MODE_CDP, await self._resolve_cdp())

    async def _resolve_cdp(self) -> "BrowserAdapter":
        """获取 CDPAdapter 实例（懒加载）。"""
        if self._cdp is None:
            from .adapter_cdp import CDPAdapter
            self._cdp = CDPAdapter()
        if not await self._cdp.is_connected():
            await self._cdp.connect()
        return self._cdp

    async def _resolve_bridge(self,
                              force_recheck: bool = False) -> "BrowserAdapter | None":
        """获取 BridgeAdapter 实例（懒加载 + 可用性检查，TTL 缓存 30s）。

        v2.4.1: 若首次创建，同时赋值给类级 _shared_bridge 实现进程级复用。
        v2.5: force_recheck=True 时跳过 TTL 现场判定（并行/测试场景每 run 独立）。"""
        if self._bridge is None:
            from .adapter_bridge import BridgeAdapter
            self._bridge = BridgeAdapter()
            ModeSelector._shared_bridge = self._bridge  # 更新类级共享引用

        # 可用性检查（TTL 缓存；到期复查。防抖：并发 resolve 只探测一次）
        async with self._bridge_check_lock:
            now = time.monotonic()
            if (force_recheck or self._bridge_available is None
                    or now - self._bridge_checked_at > self._bridge_ttl):
                self._bridge_available = await self._bridge.connect()
                self._bridge_checked_at = now

        return self._bridge if self._bridge_available else None

    async def _acquire_bridge_lease(self) -> tuple[str, "BrowserAdapter"] | None:
        """per-run Bridge 租约：独立实例（隔离 _session_id/_tab_id/_session_cache），
        复用 ModeSelector 的可用性探测（TTL 30s + 防抖锁 + light health 快路径）。

        返回 (MODE_BRIDGE, 独立 BridgeAdapter)；失败返回 None（调用方降级 CDP）。
        """
        from .adapter_bridge import BridgeAdapter
        adapter = BridgeAdapter()
        try:
            async with self._bridge_check_lock:  # 复用防抖锁：并发租约串行探测
                now = time.monotonic()
                ttl_fresh = (self._bridge_available is not None
                             and now - self._bridge_checked_at <= self._bridge_ttl)
                if ttl_fresh:
                    # 共享结论新鲜：租约实例标记已有探测结论 → connect 走 light health
                    adapter._full_connect_done = True
                    ok = await adapter.connect()
                else:
                    ok = await adapter.connect(force_full=True)
                    self._bridge_available = ok
                    self._bridge_checked_at = now
            if ok:
                return (self.MODE_BRIDGE, adapter)
        except Exception:
            ok = False
        await adapter.close()
        return None

    async def check_bridge_health(self) -> dict:
        """检查 Bridge 服务健康状态（分层：/health + RPC 探测）。"""
        if self._bridge is None:
            from .adapter_bridge import BridgeAdapter
            self._bridge = BridgeAdapter()

        try:
            data = await self._bridge.check_health()
            data.setdefault("url", self._bridge.base_url)
            # /health 契约字段为 ok，cli 消费 healthy → 规范化
            data.setdefault("healthy", bool(data.get("ok", True)))
            # RPC 层探测：/health 正常不代表 RPC 链路可用
            rpc = await self._bridge.check_rpc(timeout=3.0)
            data["rpc_ok"] = rpc.get("rpc_ok", False)
            if not rpc.get("rpc_ok"):
                data["rpc_error"] = rpc.get("error", "RPC 探测失败")
            return data
        except Exception as e:
            return {"healthy": False, "url": self._bridge.base_url,
                    "error": str(e)}
