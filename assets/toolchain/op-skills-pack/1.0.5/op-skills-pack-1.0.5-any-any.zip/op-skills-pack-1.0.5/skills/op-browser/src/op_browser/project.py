"""
op_browser / project.py — ProjectRegistry 项目注册表

自动扫描 projects/ 目录，构建 project→system→module 三层索引。
所有方法按需懒加载，不占用日常上下文。
"""
import json, os, re
from pathlib import Path
from typing import Any


# 内置极简 YAML 子集解析器：仅在 pyyaml 未安装时启用。
# 本项目 project.yaml 是自己生成的受控资产（键值/缩进 map/列表/flow 数组），
# 该子集足以覆盖；解析失败时给出明确提示，不静默返回空。
_SIMPLE_SCALAR = re.compile(r"^([^:#][^:]*?)\s*:\s*(.*)$")


def _split_comment(line: str) -> str:
    """去掉行内注释（# 前有空格才算注释），保留引号内的 #。"""
    in_s = in_d = False
    for i, ch in enumerate(line):
        if ch == "'" and not in_d:
            in_s = not in_s
        elif ch == '"' and not in_s:
            in_d = not in_d
        elif ch == "#" and not in_s and not in_d:
            prev = line[i - 1] if i > 0 else ""
            if prev.isspace() or i == 0:
                return line[:i].rstrip()
    return line.rstrip()


def _parse_scalar(raw: str) -> Any:
    raw = raw.strip()
    if raw == "" or raw.lower() == "null":
        return None
    if (raw.startswith('"') and raw.endswith('"')) or \
       (raw.startswith("'") and raw.endswith("'")):
        return raw[1:-1]
    low = raw.lower()
    if low == "true":
        return True
    if low == "false":
        return False
    try:
        return int(raw)
    except ValueError:
        pass
    try:
        return float(raw)
    except ValueError:
        pass
    return raw


def _parse_flow(raw: str) -> list[Any]:
    """解析 flow 风格列表 [a, b, c]。"""
    inner = raw.strip()[1:-1]
    if not inner.strip():
        return []
    return [_parse_scalar(x) for x in inner.split(",") if x.strip()]


def _parse_block(lines: list[tuple[int, str]], idx: int,
                 indent: int) -> tuple[dict, int]:
    """解析缩进块为 dict。lines 已按 (缩进, 内容) 预处理。"""
    obj: dict[str, Any] = {}
    while idx < len(lines):
        ind, content = lines[idx]
        if ind < indent:
            break
        if ind > indent:
            raise ValueError(f"非预期缩进: {content!r}")
        if content.startswith("- "):
            raise ValueError(f"列表项未缩进到键下: {content!r}")
        m = _SIMPLE_SCALAR.match(content)
        if not m:
            raise ValueError(f"无法解析行: {content!r}")
        key, rest = m.group(1).strip(), m.group(2).strip()
        idx += 1
        if rest.startswith("["):
            obj[key] = _parse_flow(rest)
        elif rest:
            obj[key] = _parse_scalar(rest)
        else:
            # 空值键：后续缩进行可能是 "- " 列表 或 嵌套 map
            if idx < len(lines) and lines[idx][0] > indent:
                if lines[idx][1].startswith("- "):
                    items, idx = _parse_list(lines, idx, lines[idx][0])
                    obj[key] = items
                else:
                    child, idx = _parse_block(lines, idx, lines[idx][0])
                    obj[key] = child
            else:
                obj[key] = None
    return obj, idx


def _parse_list(lines: list[tuple[int, str]], idx: int,
                indent: int) -> tuple[list[Any], int]:
    """解析 "- " 列表块（缩进为 indent 的行）。返回 (列表, 下一个未消费下标)。"""
    items: list[Any] = []
    while idx < len(lines) and lines[idx][0] == indent and \
            lines[idx][1].startswith("- "):
        c2 = lines[idx][1]
        if c2 == "-":
            items.append(None)
            idx += 1
        else:
            item_rest = c2[2:].strip()
            m2 = _SIMPLE_SCALAR.match(item_rest)
            if not m2:
                items.append(_parse_scalar(item_rest))
                idx += 1
                continue
            # "- key: value" 形式：一律按 map 条目解析
            key = m2.group(1).strip()
            rest2 = m2.group(2).strip()
            if rest2:
                item: dict[str, Any] = {key: _parse_scalar(rest2)}
                nidx = idx + 1
            else:
                item = {key: None}
                nidx = idx + 1
            # 合并后续更深缩进行（该项的子字段）
            if nidx < len(lines) and lines[nidx][0] > indent:
                child, nidx = _parse_block(lines, nidx, lines[nidx][0])
                item.update(child)
            items.append(item)
            idx = nidx
    return items, idx


def _simple_yaml_load(text: str) -> dict:
    """极简 YAML 子集解析：键值 map、缩进嵌套、- 列表、[a,b] flow。"""
    raw_lines = []
    for line in text.splitlines():
        line = _split_comment(line)
        if not line.strip():
            continue
        raw_lines.append((len(line) - len(line.lstrip()), line.strip()))
    if not raw_lines:
        return {}
    obj, _ = _parse_block(raw_lines, 0, raw_lines[0][0])
    return obj or {}


def _load_project_yaml(path: Path) -> dict:
    """读取 project.yaml：优先 pyyaml，缺失时用内置子集解析。"""
    with open(path, encoding="utf-8") as f:
        text = f.read()
    try:
        import yaml  # type: ignore
        return yaml.safe_load(text) or {}
    except ImportError:
        pass
    try:
        return _simple_yaml_load(text)
    except Exception as e:
        raise RuntimeError(
            f"{path} 解析失败（未安装 pyyaml，内置解析器也无法处理）: {e}"
            "。执行: pip install pyyaml"
        ) from e


class ProjectRegistry:
    """项目注册表。

    用法:
        reg = ProjectRegistry(projects_dir)
        projects = await reg.list_projects()
        project = await reg.get_project("demo-project")
        systems = await reg.get_systems("demo-project")
    """

    def __init__(self, projects_dir: str | Path | None = None):
        """初始化注册表。

        projects_dir: projects/ 根目录。默认按 OP_BROWSER_PROJECTS_DIR
        环境变量查找，未设置时使用 skill 内 junction 挂载点（自动创建），
        绝不 fallback 到 skill 目录（junction = 仓库，写入污染仓库），
        也不依赖 cwd 相对路径。
        """
        if projects_dir:
            self._root = Path(projects_dir)
        else:
            env_dir = os.environ.get("OP_BROWSER_PROJECTS_DIR", "")
            if env_dir:
                self._root = Path(env_dir)
            else:
                # 路径优先级：环境变量 > skill 内 junction 挂载点（自动创建）
                skill_root = Path(__file__).resolve().parent.parent.parent
                evolved_dir = skill_root / "projects"  # op-browser/projects → .basic/evolved/op-browser/projects
                try:
                    evolved_dir.mkdir(parents=True, exist_ok=True)
                    self._root = evolved_dir
                except OSError:
                    raise FileNotFoundError(
                        "op-browser 项目资产目录无法创建（junction 挂载点不存在）："
                        f"{evolved_dir}\n"
                        "请设置 OP_BROWSER_PROJECTS_DIR 环境变量指向有效目录，"
                        "或确保 skill 内 junction 挂载点已初始化"
                    )
        self._projects: dict[str, dict] = {}
        self._loaded = False

    def _ensure_loaded(self):
        """懒加载：扫描 projects/ 目录构建索引。"""
        if self._loaded:
            return
        if self._root.exists():
            for proj_dir in self._root.iterdir():
                if not proj_dir.is_dir() or proj_dir.name.startswith("_"):
                    continue
                proj_yaml = proj_dir / "project.yaml"
                if proj_yaml.exists():
                    info = _load_project_yaml(proj_yaml)
                else:
                    info = {"name": proj_dir.name}
                self._projects[proj_dir.name] = {
                    "path": str(proj_dir),
                    **info,
                    "systems": self._scan_systems(proj_dir),
                }
        self._loaded = True

    def _scan_systems(self, proj_dir: Path) -> list[dict]:
        """扫描项目下的系统目录。"""
        sys_dir = proj_dir / "systems"
        if not sys_dir.exists():
            return []
        systems = []
        for sd in sorted(sys_dir.iterdir()):
            if not sd.is_dir() or sd.name.startswith("_"):
                continue
            adapter_json = sd / "_shared" / "adapter.json"
            adapter = {}
            if adapter_json.exists():
                try:
                    with open(adapter_json, encoding="utf-8") as f:
                        adapter = json.load(f)
                except Exception:
                    pass
            modules = self._scan_modules(sd)
            systems.append({
                "name": sd.name,
                "path": str(sd),
                "adapter": adapter,
                "modules": modules,
            })
        return systems

    def _scan_modules(self, sys_dir: Path) -> list[dict]:
        """扫描系统下的业务模块。"""
        mod_dir = sys_dir / "modules"
        if not mod_dir.exists():
            return []
        modules = []
        for md in sorted(mod_dir.iterdir()):
            if not md.is_dir() or md.name.startswith("_"):
                continue
            spec = md / "test-spec.md"
            data_file = md / "test-data.md"
            cases_file = md / "cases.yaml"
            modules.append({
                "name": md.name,
                "path": str(md),
                "has_spec": spec.exists(),
                "has_data": data_file.exists(),
                "has_cases": cases_file.exists(),
                "versions": sorted(
                    [v.name for v in md.iterdir() if v.is_dir() and v.name.startswith("v")]
                ),
            })
        return modules

    # ── 公开 API ───────────────────────────────────────────────

    async def list_projects(self) -> list[dict]:
        """列出所有项目。"""
        self._ensure_loaded()
        return [
            {"name": k, "systems": len(v.get("systems", [])),
             "display_name": v.get("display_name", k)}
            for k, v in self._projects.items()
        ]

    async def get_project(self, name: str) -> dict | None:
        """获取项目详情。"""
        self._ensure_loaded()
        return self._projects.get(name)

    async def get_systems(self, project: str) -> list[dict]:
        """获取项目下的系统列表。"""
        proj = await self.get_project(project)
        return proj.get("systems", []) if proj else []

    async def get_system(self, project: str, system: str) -> dict | None:
        """获取系统详情（含 adapter）。"""
        systems = await self.get_systems(project)
        for s in systems:
            if s["name"] == system:
                return s
        return None

    async def get_modules(self, project: str, system: str) -> list[dict]:
        """获取系统下的模块清单。"""
        sys_info = await self.get_system(project, system)
        return sys_info.get("modules", []) if sys_info else []

    async def load_system_adapter(self, project: str, system: str) -> dict:
        """加载系统的 adapter.json。"""
        sys_info = await self.get_system(project, system)
        if sys_info:
            return sys_info.get("adapter", {})
        return {}

    async def resolve_case(self, project: str, system: str,
                           module: str = "") -> dict:
        """完整上下文解析：返回项目+系统+模块的结构化信息和配置。"""
        result = {"project": project}
        proj = await self.get_project(project)
        if proj:
            result["project_info"] = proj
        sys_info = await self.get_system(project, system)
        if sys_info:
            result["system"] = sys_info["name"]
            result["adapter"] = sys_info.get("adapter", {})
            result["path"] = sys_info["path"]
            if module:
                for m in sys_info.get("modules", []):
                    if m["name"] == module:
                        result["module"] = m
                        break
        return result

    async def load_cases(self, project: str, system: str,
                         module: str) -> list[dict] | None:
        """加载模块的 cases.yaml 执行清单（唯一执行源，零 Key 确定性）。

        cases.yaml 与 test-spec.md 双源约定：cases.yaml 为机器可读执行清单，
        test-spec.md 仅人工参考文档。返回 [{id, name, task, pending, adapter}]；
        无 cases.yaml 或解析失败返回 None（调用方维持模块级行为）。
        """
        sys_info = await self.get_system(project, system)
        if not sys_info:
            return None
        path = Path(sys_info["path"]) / "modules" / module / "cases.yaml"
        if not path.exists():
            return None
        try:
            data = _simple_yaml_load(path.read_text(encoding="utf-8"))
        except Exception:
            return None
        cases = data.get("cases") if isinstance(data, dict) else None
        if not isinstance(cases, list):
            return None
        result = []
        for c in cases:
            if not isinstance(c, dict) or not c.get("id"):
                continue
            task = str(c.get("task", ""))
            pending = task.startswith("pending:")
            result.append({
                "id": str(c["id"]),
                "name": str(c.get("name", c["id"])),
                "task": task[8:] if pending else task,
                "pending": pending,
                "adapter": str(c.get("adapter", "")),
            })
        return result or None
