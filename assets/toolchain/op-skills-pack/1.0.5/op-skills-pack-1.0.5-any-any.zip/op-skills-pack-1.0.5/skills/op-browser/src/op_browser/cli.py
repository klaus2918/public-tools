#!/usr/bin/env python3
"""
op_browser CLI — 通过 /op_browser 命令调用。

用法:
    python op_browser [run|taskset|list|info|delete|bridge|test|doctor] <参数>

环境变量:
    BROWSER_CDP_URL    浏览器 CDP URL
    BROWSER_HEADLESS   是否无头 (true/false)
    TASKS_DIR          任务仓库路径
"""
import asyncio, sys, json
from pathlib import Path

# Windows 控制台默认 GBK，CLI 输出的 emoji 状态符（✅❌⬜🔄🔧）会触发 UnicodeEncodeError。
# 强制 stdout/stderr 为 UTF-8，保证任意 Windows 控制台下都能正常输出。
try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except (AttributeError, ValueError):
    pass

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from op_browser import SmartBrowser
from op_browser.mode_selector import ModeSelector

# v2.4.1: 全局 ModeSelector 实例，跨多次 CLI 命令复用适配器连接
_global_mode_selector: ModeSelector | None = None


def print_result(result):
    """友好打印执行结果。"""
    status = "✅" if result.success else "❌"
    print(f"\n{status} 结束: success={result.success}")
    if hasattr(result, "verify_mode") and result.verify_mode:
        print(f"   校验模式: {result.verify_mode}")
    if hasattr(result, "judge") and result.judge:
        print(f"   校验: {result.judge}")
    if hasattr(result, "diff_rate"):
        print(f"   差异率: {result.diff_rate:.1%}")
    if hasattr(result, "duration_ms") and result.duration_ms:
        print(f"   耗时: {result.duration_ms:.0f}ms")
    if hasattr(result, "adapter") and result.adapter:
        print(f"   适配器: {result.adapter}")
    if result.error:
        print(f"   错误: {result.error}")
    if result.data:
        print(f"   数据: {json.dumps(result.data, ensure_ascii=False, indent=2)[:500]}")

    extra = getattr(result, "extra", {})
    if extra:
        for k, v in extra.items():
            print(f"   {k}: {v}")


def _confirm_suggest(result) -> bool:
    """若结果是"建议新建分组"待确认，向用户交互确认。

    返回 True 表示用户同意新建（调用方应以 allow_new=True 重试）。
    """
    extra = getattr(result, "extra", {}) or {}
    if not extra.get("suggest_new"):
        return False
    suggested = (extra.get("suggestedName")
                 or extra.get("suggest_new", {}).get("suggestedName", "?"))
    ans = _input(f"未找到可复用的已有分组，建议新建「{suggested}」。是否新建? (y/N): ")
    if not ans:
        return False
    return ans.strip().lower() in ("y", "yes")


def _input(prompt: str = "") -> str:
    """input() 的 EOFError 安全封装。

    管道/自动化（stdin 非终端）下 input() 抛 EOFError，
    统一返回空串而非崩溃（与 bridge session/cleanup/inspect 既有处理语义一致）。
    """
    try:
        return input(prompt)
    except EOFError:
        return ""


async def main():
    args = sys.argv[1:]
    if not args or args[0] in ("-h", "--help"):
        print(__doc__)
        return

    cmd = args[0]
    global _global_mode_selector
    if _global_mode_selector is None:
        _global_mode_selector = ModeSelector()
    browser = SmartBrowser(mode_selector=_global_mode_selector)

    if cmd == "run":
        raw_name = args[1] if len(args) > 1 else ""
        if raw_name == "status":
            # v2.5 2R2: run status [name] — 列出 run 状态（含可接续标记）
            from op_browser import run_state as rs
            task = _get_opt(args, "--task", "")
            recs = rs.list_runs(task=task)
            if not recs:
                print("(无 run 记录)")
                return
            for r in recs:
                mark = {"completed": "✅", "interrupted": "⏸",
                        "running": "▶", "failed": "❌"}.get(
                    r.get("status"), "⬜")
                st = r.get("status", "?")
                if r.get("resumable"):
                    st = f"{st}（可接续）"
                print(f"  {mark} {r.get('run_id', '?'):<32s} "
                      f"task={r.get('task', '?'):<12s} {st} "
                      f"hb={r.get('heartbeat_at', '')[:19]}")
            return
        name = raw_name or _input("任务名称: ")
        project = _get_opt(args, "--project", "")
        system = _get_opt(args, "--system", "")
        module = _get_opt(args, "--module", "")
        adapter = _get_opt(args, "--adapter", "")
        allow_new = "--new" in args
        login_account = _get_opt(args, "--login-account", "")
        relogin = "--relogin" in args
        no_login = "--no-login" in args
        run_id = _get_opt(args, "--run-id", "")  # v2.5: 命名 run（身份会话+产物归档）
        resume = "--resume" in args  # v2.5 2R2: 接续已有 run
        force = "--force" in args
        multi_tab = "--multi-tab" in args  # v2.6 页签治理
        detach_after = "--detach" in args
        keep_session = "--keep-session" in args
        verify_mode = _get_opt(args, "--verify-mode", "auto")
        result = await browser.run(name, project=project, system=system,
                                    module=module, adapter=adapter,
                                    allow_new=allow_new,
                                    login_account=login_account,
                                    relogin=relogin, no_login=no_login,
                                    lease=bool(run_id), run_id=run_id,
                                    resume=resume, force=force,
                                    multi_tab=multi_tab,
                                    detach_after=detach_after,
                                    keep_session=keep_session,
                                    verify_mode=verify_mode)
        if not allow_new and _confirm_suggest(result):
            result = await browser.run(name, project=project, system=system,
                                       module=module, adapter=adapter,
                                       allow_new=True,
                                       login_account=login_account,
                                       relogin=relogin, no_login=no_login,
                                       lease=bool(run_id), run_id=run_id,
                                       resume=resume, force=force,
                                       multi_tab=multi_tab,
                                       detach_after=detach_after,
                                       keep_session=keep_session,
                                       verify_mode=verify_mode)
        print_result(result)

    elif cmd == "taskset":
        # 过滤 --key 与 --key value（避免把 --adapter 等当任务名）
        raw_names = [a for a in args[1:] if not a.startswith("-")]
        names = raw_names if raw_names else _input("任务名(逗号分隔): ").split(",")
        names = [n.strip() for n in names if n.strip()]
        adapter = _get_opt(args, "--adapter", "")
        sequential = "--parallel" not in args  # v2.5: 缺省顺序（兼容现状）
        allow_new = "--new" in args
        project = _get_opt(args, "--project", "")
        system = _get_opt(args, "--system", "")
        module = _get_opt(args, "--module", "")
        login_account = _get_opt(args, "--login-account", "")
        relogin = "--relogin" in args
        no_login = "--no-login" in args
        # v2.5 2R2: taskset --run-id "任务A=rA,任务B=rB" 指定 run_id 映射
        run_id_map = {}
        rid_opt = _get_opt(args, "--run-id", "")
        if rid_opt:
            for pair in rid_opt.split(","):
                if "=" in pair:
                    k, v = pair.split("=", 1)
                    run_id_map[k.strip()] = v.strip()
        try:
            results = await browser.taskset(
                names, sequential=sequential, adapter=adapter,
                allow_new=allow_new, project=project, system=system,
                module=module, login_account=login_account,
                relogin=relogin, no_login=no_login,
                run_id_map=run_id_map)
        except ValueError as e:  # 并行守卫提示
            print(f"❌ {e}")
            return
        for i, r in enumerate(results):
            n = names[i] if i < len(names) else f"#{i}"
            status = "✅" if r.success else "❌"
            rid = (r.extra or {}).get("run_id", "")
            print(f"{status} {n}: {r.judge if hasattr(r,'judge') else '?'}  "
                  f"adapter={getattr(r,'adapter','')}"
                  + (f" run_id={rid}" if rid else ""))

    elif cmd == "list":
        tasks = SmartBrowser.list_tasks()
        if not tasks:
            print("(无任务)")
        for t in tasks:
            st = {"ready": "✅", "unknown": "⬜"}.get(t["status"], "⬜")
            print(f"  {st} {t['name']:20s} run={t['run_count']:3d}  "
                  f"{t.get('description','')[:40]}")

    elif cmd == "info":
        name = args[1] if len(args) > 1 else _input("任务名称: ")
        meta = SmartBrowser.task_info(name)
        print(json.dumps(meta, ensure_ascii=False, indent=2))

    elif cmd == "delete":
        name = args[1] if len(args) > 1 else _input("任务名称: ")
        confirm = _input(f"确认删除任务 '{name}'? (y/N): ")
        if confirm.strip().lower() in ("y", "yes"):
            SmartBrowser.delete_task(name)
            print(f"已删除 {name}")
        else:
            print("已取消")

    elif cmd == "run_auto":
        print("❌ run_auto 已移除（v2.4 起无 AI 探索/自愈）。"
              "请先固化任务资产，再使用 run 命令。")
        return

    # ── 环境诊断 ──────────────────────────────────────────

    elif cmd == "doctor":
        """前置环境检查：依赖 / Bridge / CDP / 环境变量。"""
        import importlib.util
        from op_browser.engine import Config

        ok_all = True

        def _check(name: str, ok: bool, hint: str = ""):
            nonlocal ok_all
            if not ok:
                ok_all = False
            print(f"  {'✅' if ok else '❌'} {name}"
                  + (f"  ← {hint}" if hint and not ok else ""))

        print("🔍 op-browser 环境诊断...")

        # 1. Python 依赖（零 LLM/API Key 依赖）
        cfg = Config()
        for pkg in ("playwright", "httpx", "PIL"):
            _check(f"依赖 {pkg}", importlib.util.find_spec(pkg) is not None,
                   f"pip install {pkg.replace('_', '-')}")

        # 2. 环境变量（只报告是否设置，不打印值）
        envs = ("BROWSER_CDP_URL", "TASKS_DIR", "BRIDGE_URL",
                "BROWSER_AGENT_BRIDGE_TOKEN")
        import os
        for e in envs:
            _check(f"环境变量 {e}", bool(os.environ.get(e)), "未设置")

        # 3. Bridge 健康
        health = await browser.bridge_health()
        h_ok = health.get("healthy", False)
        _check("Bridge 服务", h_ok, health.get("error", "http://127.0.0.1:8765 不可达"))
        if h_ok:
            print(f"      host={health.get('hostReady')} "
                  f"ext={health.get('extensionReady')} "
                  f"v{health.get('extensionVersion', '?')} "
                  f"auth_required={health.get('authRequired')}")
            if health.get("rpc_ok") is not None:
                _check("Bridge RPC 链路",
                       health.get("rpc_ok", False),
                       health.get("rpc_error", "RPC 探测失败"))

        # 4. CDP 端口
        import urllib.request
        cdp_ok = False
        for port in (9222, 9223, 9224):
            try:
                with urllib.request.urlopen(
                        f"http://127.0.0.1:{port}/json/version", timeout=1) as r:
                    ver = json.loads(r.read()).get("Browser", "?")
                    print(f"  ✅ CDP 端口 {port}: {ver}")
                    cdp_ok = True
                    break
            except Exception:
                continue
        if not cdp_ok:
            ok_all = False
            print("  ❌ CDP 端口 9222/9223/9224 未监听（需 Chrome --remote-debugging-port）")

        print()
        if ok_all:
            print("✅ 环境就绪")
        else:
            print("⚠️ 存在缺失项，请按上方 ❌ 提示处理（或 /op-browser bridge doctor 排查 Bridge）")

    # ── Bridge 命令集 ──────────────────────────────────────

    elif cmd == "bridge":
        sub = args[1] if len(args) > 1 else "status"

        if sub == "status":
            health = await browser.bridge_health()
            status = "✅ 正常" if health.get("healthy") else "❌ 不可用"
            print(f"Bridge 服务: {status}")
            print(f"  地址: {health.get('url', '未知')}")
            if health.get("error"):
                print(f"  错误: {health['error']}")

        elif sub == "session":
            url = args[2] if len(args) > 2 else "about:blank"
            allow_new = "--new" in args
            name = _get_opt(args, "--name", "")
            # 早期校验分组名
            if name:
                from op_browser.adapter_bridge import BridgeAdapter as _BA
                try:
                    _BA.validate_group_name(name)
                except ValueError as e:
                    print(f"❌ 分组名校验失败: {e}")
                    return
            print(f"启动/复用 Bridge 会话: {url}")
            # 直接用 BridgeAdapter，确定性执行
            from op_browser.adapter_bridge import BridgeAdapter
            from op_browser.engine import BrowserResult
            adapter = BridgeAdapter()
            ok = await adapter.connect()
            if ok:
                # 1. 环境诊断
                decision = await adapter.session_decision(url)
                print(f"  环境: healthy={decision['healthy']} "
                      f"ext={decision['extensionReady']} "
                      f"auth={decision['authRequired']} "
                      f"现有 session={decision['existingCount']} "
                      f"(存活 {decision.get('aliveCount', '?')} / "
                      f"陈旧 {decision.get('staleCount', '?')})")
                # 2. 复用或新建
                sid, info = await adapter.find_or_create_session(
                    url, name=name, allow_new=allow_new)
                action = info.get("action")
                if action == "suggest_new":
                    suggested = info.get("suggestedName", "?")
                    print(f"  ⏸ 未找到可复用的已有分组，建议新建「{suggested}」")
                    if not allow_new:
                        ans = _input(f"  是否新建分组「{suggested}」? (y/N): ")
                        if ans.strip().lower() in ("y", "yes"):
                            sid, info = await adapter.find_or_create_session(
                                url, name=name, allow_new=True)
                            action = info.get("action")
                        else:
                            await adapter.close()
                            result = BrowserResult(
                                False, error="用户拒绝新建分组，未执行")
                            print_result(result)
                            return
                if action == "reuse":
                    reuse = info["reuse"]
                    print(f"  ✅ 复用已有 session: {reuse['name']} "
                          f"(id={reuse['sessionId'][:12]}, "
                          f"group={reuse['groupId']}, tab={reuse['mainTabId']})")
                else:
                    print(f"  ✅ 新建 session: {info.get('createdName')} "
                          f"(id={sid[:12]}, tab={adapter._tab_id})")
                tree = await adapter.accessibility_tree()
                print(f"  a11y 节点: {len(tree)}")
                result = BrowserResult(True, adapter="bridge",
                                       a11y_tree=tree)
            else:
                result = BrowserResult(False,
                    error="Bridge 连接失败（检查 token / extension）")
            print_result(result)

        elif sub == "doctor":
            print("🔍 Bridge 环境诊断...")
            health = await browser.bridge_health()
            h = health.get("healthy", False)
            print(f"  host:    {'✅' if health.get('hostReady') else '❌'}")
            print(f"  ext:     {'✅' if health.get('extensionReady') else '❌'} "
                  f"v{health.get('extensionVersion', '?')}")
            print(f"  auth:    {'✅' if health.get('authConfigured') else '❌'} "
                  f"required={health.get('authRequired')}")
            rpc_ok = health.get("rpc_ok")
            print(f"  rpc:     {'✅' if rpc_ok else '❌'} "
                  f"{health.get('rpc_error', 'session.list 探测')}")
            # 检查 token 文件
            from pathlib import Path
            env = Path.home() / ".browser-agent-bridge.env"
            print(f"  token:   {'✅ 文件存在' if env.exists() else '❌ 缺失'}")
            print(f"  连接:    {'✅' if h else '❌'} "
                  f"{health.get('url', 'http://127.0.0.1:8765')}")
            if not h:
                print("\n  排障建议:")
                if not health.get("extensionReady"):
                    print("  1. 扩展未连接 → 打开扩展 Side Panel → Start Bridge")
                    print("  2. 扩展未安装 → chrome://extensions 加载")
                if health.get("authRequired") and not env.exists():
                    print("  3. 缺 token → 运行 install-native-host-win.ps1")

        elif sub == "groups":
            """查询所有 Agent 分组（含存活/陈旧状态），支撑复用决策。"""
            filter_kw = _get_opt(args, "--filter", "")
            acct_kw = _get_opt(args, "--account", "")     # v2.6 页签治理
            since_kw = _get_opt(args, "--since", "")      # v2.6: 最近 N 分钟活跃
            as_json = "--json" in args                    # v2.6: 机器可读
            details = await browser.list_sessions()
            if filter_kw:
                details = [d for d in details
                           if filter_kw in d.get("name", "")
                           or filter_kw in " ".join(d.get("urls", []))]
            if acct_kw:
                details = [d for d in details
                           if acct_kw in d.get("account", "")]
            if since_kw:
                try:
                    from datetime import datetime, timezone
                    cut = (datetime.now(timezone.utc).timestamp()
                           - int(since_kw) * 60)
                    details = [d for d in details
                               if d.get("last_active_at")
                               and datetime.fromisoformat(
                                   d["last_active_at"]).timestamp() >= cut]
                except (ValueError, TypeError):
                    print(f"⚠️ --since 需要分钟数（收到 {since_kw!r}）")
                    return
            if not details:
                print("(无分组)")
            else:
                alive = sum(1 for d in details if d.get("alive"))
                stale = len(details) - alive
                reclaimable = sum(1 for d in details
                                  if d.get("reclaimable"))
                print(f"分组总数 {len(details)}（存活 {alive} / 陈旧 {stale}"
                      f" / 可回收 {reclaimable}）"
                      f"{'  过滤: ' + filter_kw if filter_kw else ''}")
                for d in details:
                    mark = "🟢" if d.get("alive") else "⚪"
                    detach_mark = "📌" if "detached" in str(
                        d.get("purpose", "")) else ""
                    urls = " ".join(u for u in d.get("urls", [])
                                    if u and u != "about:blank") or "(无标签页)"
                    acct = d.get("account", "") or "?"
                    status = d.get("status", "unknown")
                    if d.get("reclaimable"):
                        status = "reclaimable"
                    print(f"  {mark}{detach_mark} {d.get('name', '?'):<24s} "
                          f"acct={acct:<12s} {status:<12s} "
                          f"group={d.get('groupId')} "
                          f"tabs={len(d.get('tabIds', []))}  {urls[:44]}")
                if as_json:
                    import json as _json
                    print(_json.dumps(details, ensure_ascii=False,
                                      indent=2))

        elif sub == "cleanup":
            """清理分组：默认只清陈旧（无存活 tab）分组；--name 指定业务名；
            --yes 跳过确认；v2.6 新增 --idle（清超保留期存活分组）/
            --since <分钟>（按最后活跃过滤）/ --account <账号> /
            --exclude-running（默认 True，跳过执行中的 #r 会话）。"""
            stale_only = "--all" not in args
            auto_yes = "--yes" in args
            idle_ok = ("--idle" in args or "--all" in args)   # v2.6
            exclude_running = "--exclude-running" not in args  # 默认 True
            acct_kw = _get_opt(args, "--account", "")
            since_kw = _get_opt(args, "--since", "")
            names = []
            n = _get_opt(args, "--name", "")
            if n:
                names = [x.strip() for x in n.split(",") if x.strip()]
            from op_browser.adapter_bridge import BridgeAdapter
            details = await browser.list_sessions()
            target = []
            for d in details:
                if acct_kw and acct_kw not in d.get("account", ""):
                    continue
                if since_kw:
                    try:
                        from datetime import datetime, timezone
                        last = d.get("last_active_at", "")
                        if not last:
                            continue
                        age = (datetime.now(timezone.utc)
                               - datetime.fromisoformat(last)).total_seconds()
                        if age < int(since_kw) * 60:
                            continue
                    except (ValueError, TypeError):
                        continue
                if exclude_running and d.get("resumable"):
                    # 可接续 run 的会话跳过（接续 A 档依赖会话存活）
                    continue
                if names:
                    dname = BridgeAdapter._norm_session_name(d.get("name", ""))
                    if any(BridgeAdapter._names_match(k, dname) for k in names):
                        target.append(d)
                elif stale_only and not idle_ok:
                    if not d.get("alive"):
                        target.append(d)
                elif idle_ok:
                    if not d.get("alive") or d.get("reclaimable"):
                        target.append(d)
                else:
                    target.append(d)
            if not target:
                print("没有可清理的分组")
                return
            print("以下分组将被清理：")
            for d in target:
                mark = "🟢" if d.get("alive") else "⚪"
                acct = d.get("account", "") or "?"
                print(f"  {mark} {d.get('name', '?'):<28s} "
                      f"acct={acct:<12s} "
                      f"id={d.get('sessionId', '')[:12]} "
                      f"tabs={len(d.get('tabIds', []))}")
            if not auto_yes:
                ans = _input(f"确认清理 {len(target)} 个分组? (y/N): ")
                if ans.strip().lower() not in ("y", "yes"):
                    print("已取消")
                    return
            result = await browser.session_cleanup(
                stale_only=stale_only, close_tabs=True, names=names or None,
                idle=idle_ok, exclude_running=exclude_running)
            cleaned = result.get("cleaned", [])
            skipped = result.get("skipped", [])
            print(f"✅ 已清理 {len(cleaned)} 个分组")
            for s in skipped:
                print(f"  ⏭ {s.get('name', '?')}: {s.get('reason', '')}")

        elif sub == "inspect":
            url = _get_opt(args, "--url", "")
            if url:
                allow_new = "--new" in args
                name = _get_opt(args, "--name", "")
                # 早期校验分组名
                if name:
                    from op_browser.adapter_bridge import BridgeAdapter as _BA
                    try:
                        _BA.validate_group_name(name)
                    except ValueError as e:
                        print(f"❌ 分组名校验失败: {e}")
                        return
                print(f"查看页面无障碍结构: {url}")
                from op_browser.adapter_bridge import BridgeAdapter
                adapter = BridgeAdapter()
                ok = await adapter.connect()
                if ok:
                    # 1. 环境诊断
                    decision = await adapter.session_decision(url)
                    print(f"  环境: healthy={decision['healthy']} "
                          f"现有 session={decision['existingCount']} "
                          f"(存活 {decision.get('aliveCount', '?')} / "
                          f"陈旧 {decision.get('staleCount', '?')})")
                    # 2. 复用或新建
                    sid, info = await adapter.find_or_create_session(
                        url, name=name, allow_new=allow_new)
                    action = info.get("action")
                    if action == "suggest_new":
                        suggested = info.get("suggestedName", "?")
                        print(f"  ⏸ 未找到可复用的已有分组，建议新建「{suggested}」")
                        if not allow_new:
                            ans = _input(f"  是否新建分组「{suggested}」? (y/N): ")
                            if ans.strip().lower() in ("y", "yes"):
                                sid, info = await adapter.find_or_create_session(
                                    url, name=name, allow_new=True)
                                action = info.get("action")
                            else:
                                await adapter.close()
                                print("❌ 用户拒绝新建分组，已退出")
                                return
                    if action == "reuse":
                        reuse = info["reuse"]
                        print(f"  ✅ 复用已有 session: {reuse['name']} "
                              f"(id={reuse['sessionId'][:12]}, tab={reuse['mainTabId']})")
                    else:
                        print(f"  ✅ 新建 session: {info.get('createdName')} "
                              f"(id={sid[:12]}, tab={adapter._tab_id})")
                    # 轮询等待页面加载（最多 10 秒）
                    import asyncio
                    for _ in range(20):
                        text = await adapter.read_text()
                        if text.strip():
                            break
                        await asyncio.sleep(0.5)
                    tree = await adapter.accessibility_tree()
                    print(json.dumps([t.to_dict() for t in tree[:5]],
                                     ensure_ascii=False, indent=2))
                    await adapter.close()
                else:
                    print("❌ Bridge 不可用")
            else:
                print("用法: bridge inspect --url <url>")

        elif sub == "click-ref":
            """按 ref 编号点击，绕过中文编码问题。"""
            ref = args[2] if len(args) > 2 else ""
            if not ref:
                print("用法: bridge click-ref <ref_id>")
                return
            from op_browser.adapter_bridge import BridgeAdapter
            adapter = BridgeAdapter()
            if not await adapter.connect():
                print("❌ Bridge 不可用")
                return
            # click-ref 是显式操作命令，无业务上下文，允许直接新建
            await adapter.find_or_create_session(allow_new=True)
            result = await adapter.click_by_ref(ref)
            if result.success:
                print(f"✅ click_by_ref({ref}) 成功")
            else:
                print(f"❌ click_by_ref({ref}) 失败: {result.error}")
            await adapter.close()

        elif sub == "rpc":
            """v2.4.1: 友好 RPC 调用（--key value 免手写 JSON）。"""
            method = args[2] if len(args) > 2 else _input("RPC 方法: ")
            rpc_params = {}
            i = 3
            while i < len(args):
                if args[i].startswith("--") and i + 1 < len(args):
                    key = args[i].lstrip("-")
                    val = args[i + 1]
                    if val.lower() == "true": val = True
                    elif val.lower() == "false": val = False
                    elif val.isdigit(): val = int(val)
                    rpc_params[key] = val
                    i += 2
                else:
                    i += 1
            from op_browser.adapter_bridge import BridgeAdapter
            adapter = BridgeAdapter()
            if not await adapter.connect():
                print("❌ Bridge 不可用（先运行 /op-browser bridge doctor 检查）")
                return
            try:
                result = await adapter._rpc(method, **rpc_params)
                print(json.dumps(result, ensure_ascii=False, indent=2))
            except Exception as e:
                print(f"❌ RPC 失败: {e}")
            await adapter.close()

        else:
            print("用法: bridge [status|session|groups|cleanup|doctor|inspect|click-ref|rpc]")

    # ── E2E 测试命令 ───────────────────────────────────────

    elif cmd == "test":
        sub = args[1] if len(args) > 1 else "list"
        adapter = _get_opt(args, "--adapter", "")

        if sub == "list":
            project = args[2] if len(args) > 2 else ""
            system = _get_opt(args, "--system", "")
            module = _get_opt(args, "--module", "")
            from op_browser.project_runner import BrowserProjectRunner
            runner = BrowserProjectRunner(browser=browser)
            cases = await runner.list_cases(project, system, module)
            if not cases:
                print("(无可用测试场景)")
            for c in cases:
                spec = "📄" if c.get("has_spec") else "⬜"
                print(f"  {spec} {c.get('system','')+'/' if c.get('system') else ''}{c['name']}")

        elif sub == "result":
            project = args[2] if len(args) > 2 else ""
            from op_browser import task_store as store
            data = store.load_test_results()
            if not data or not data.get("results"):
                print("(暂无测试结果，先执行 /op-browser test <domain> 再查询)")
            else:
                results = data["results"]
                if project:
                    results = [r for r in results
                               if r.get("project") == project]
                print(f"📋 最近一次测试结果（{data.get('time', '?')}，"
                      f"{len(results)} 条）")
                for r in results:
                    status = "✅" if r.get("success") else "❌"
                    judge = r.get("judge", "?")
                    print(f"  {status} {r.get('project','?')}/"
                          f"{r.get('system','?')}/{r.get('module','?')} "
                          f"judge={judge} adapter={r.get('adapter','')}")
                    if r.get("error"):
                        print(f"      ↳ {r['error'][:120]}")

        else:
            # test <domain> [--case <name>] [--adapter <type>]
            domain = sub
            case_name = _get_opt(args, "--case", "")
            from op_browser.project_runner import BrowserProjectRunner
            runner = BrowserProjectRunner(browser=browser)
            results = await runner.test_run(domain, case_name, adapter)
            for r in results:
                status = "✅" if r.get("success") else "❌"
                print(f"  {status} {r.get('module','')}: judge={r.get('judge','?')} "
                      f"adapter={r.get('adapter','')}")

    else:
        # 任务名直跑（无任务名则提示）
        tasks = SmartBrowser.list_tasks()
        task_names = [t["name"] for t in tasks]
        if cmd in task_names:
            result = await browser.run(cmd)
        else:
            print(f"❌ 未识别的命令或任务: {cmd}\n"
                  f"可用命令: run / taskset / list / info / delete / bridge / test / doctor\n"
                  f"（AI 探索 explore/repair 已移除：op-browser 不再需要 LLM API Key）")
            return
        print_result(result)


def _get_opt(args: list[str], key: str, default: str = "") -> str:
    """解析 --key value 格式的参数。"""
    for i, a in enumerate(args):
        if a == key and i + 1 < len(args):
            return args[i + 1]
    return default


if __name__ == "__main__":
    asyncio.run(main())
