# op-browser 经验库公共模块
#
# 提供 human-like 延迟参数、选择器工具函数等，
# 供 generators/ 下各生成器模块复用。

import random
from typing import List, Tuple, Optional, Dict, Any


# ──────────────────────────────────────────────
# Human-Like 延迟参数
# ──────────────────────────────────────────────

class HumanLikeConfig:
    """默认的仿人工延迟参数配置"""

    DEFAULTS = {
        "typing_delay_ms": (30, 80),
        "click_delay_ms": (100, 300),
        "hover_delay_ms": (200, 500),
        "wait_after_action_ms": (200, 500),
        "thinking_pause_ms": (500, 1500),
        "confirm_pause_ms": (500, 1000),
        "level_gap_ms": (300, 800),
    }

    def __init__(self, overrides: Optional[Dict[str, Any]] = None):
        self._config = dict(self.DEFAULTS)
        if overrides:
            self._config.update(overrides)

    def get(self, key: str) -> Tuple[int, int]:
        return self._config.get(key, (100, 300))

    def random_ms(self, key: str) -> int:
        low, high = self.get(key)
        return random.randint(low, high)

    def to_dict(self) -> Dict[str, Any]:
        return dict(self._config)


# ──────────────────────────────────────────────
# 选择器优先级工具
# ──────────────────────────────────────────────

def build_label_selectors(label: str) -> List[str]:
    """根据标签文本生成优先级选择器列表（label → placeholder → name → aria-label）"""
    return [
        f"label:has-text('{label}') + input",
        f"label:has-text('{label}') input",
        f"[placeholder*='{label}']",
        f"[name*='{label}']",
        f"[aria-label*='{label}']",
    ]


def build_button_selectors(text: str) -> List[str]:
    """根据按钮文本生成优先级选择器列表"""
    return [
        f"button:has-text('{text}')",
        f"[role='button']:has-text('{text}')",
        f"input[type='button'][value='{text}']",
        f"a:has-text('{text}')",
    ]


def build_menu_selectors(text: str) -> List[str]:
    """根据菜单项文本生成优先级选择器列表"""
    return [
        f"[role='menuitem']:has-text('{text}')",
        f"[role='treeitem']:has-text('{text}')",
        f"a:has-text('{text}')",
        f"span:has-text('{text}')",
    ]


def build_row_selectors(text: str = None, index: int = None,
                        column_value: str = None) -> List[str]:
    """生成表格行定位选择器"""
    selectors = []
    if text:
        selectors.append(f"tr:has-text('{text}')")
    if column_value:
        selectors.append(f"tr:has(td:has-text('{column_value}'))")
    if index is not None:
        selectors.append(f"tbody tr:nth-child({index + 1})")
    return selectors


# ──────────────────────────────────────────────
# Action Detail 生成器
# ──────────────────────────────────────────────

def make_click(selector: str = None, role: str = None, name: str = None,
               description: str = "", optional: bool = False,
               timeout_ms: int = 10000) -> Dict[str, Any]:
    """生成一个 click action_detail"""
    action: Dict[str, Any] = {"type": "click"}
    if selector:
        action["selector"] = selector
    if role:
        action["role"] = role
    if name:
        action["name"] = name
    if description:
        action["description"] = description
    if optional:
        action["optional"] = True
    action["timeout_ms"] = timeout_ms
    return action


def make_fill(selector: str = None, role: str = None, name: str = None,
              text: str = "", description: str = "",
              timeout_ms: int = 10000) -> Dict[str, Any]:
    """生成一个 fill action_detail"""
    action: Dict[str, Any] = {"type": "fill", "text": text}
    if selector:
        action["selector"] = selector
    if role:
        action["role"] = role
    if name:
        action["name"] = name
    if description:
        action["description"] = description
    action["timeout_ms"] = timeout_ms
    return action


def make_select(selector: str = None, role: str = None, name: str = None,
                value: str = "", description: str = "",
                timeout_ms: int = 10000) -> Dict[str, Any]:
    """生成一个 select action_detail（引擎 v3.5 新动作）"""
    action: Dict[str, Any] = {"type": "select", "value": value}
    if selector:
        action["selector"] = selector
    if role:
        action["role"] = role
    if name:
        action["name"] = name
    if description:
        action["description"] = description
    action["timeout_ms"] = timeout_ms
    return action


def make_hover(selector: str = None, role: str = None, name: str = None,
               description: str = "", timeout_ms: int = 10000) -> Dict[str, Any]:
    """生成一个 hover action_detail（引擎 v3.5 新动作）"""
    action: Dict[str, Any] = {"type": "hover"}
    if selector:
        action["selector"] = selector
    if role:
        action["role"] = role
    if name:
        action["name"] = name
    if description:
        action["description"] = description
    action["timeout_ms"] = timeout_ms
    return action


def make_scroll(direction: str = "down", amount: int = 300,
                selector: str = None,
                description: str = "") -> Dict[str, Any]:
    """生成一个 scroll action_detail（引擎 v3.5 新动作）"""
    action: Dict[str, Any] = {
        "type": "scroll",
        "direction": direction,
        "amount": amount,
    }
    if selector:
        action["selector"] = selector
    if description:
        action["description"] = description
    return action


def make_key(key: str = "", description: str = "") -> Dict[str, Any]:
    """生成一个 key action_detail"""
    action: Dict[str, Any] = {"type": "key", "key": key}
    if description:
        action["description"] = description
    return action


def make_wait(wait_ms: int = 300, description: str = "") -> Dict[str, Any]:
    """生成一个 wait action_detail"""
    action: Dict[str, Any] = {"type": "wait", "wait_ms": wait_ms}
    if description:
        action["description"] = description
    return action


# ──────────────────────────────────────────────
# 搜索按钮文本变体匹配
# ──────────────────────────────────────────────

SEARCH_BUTTON_TEXTS = [
    "搜索", "查询", "检索", "查找", "筛选", "确定", "Search", "Query", "Find", "Filter"
]

PLACEHOLDER_KEYWORDS = [
    "请输入", "搜索", "检索", "关键字", "关键词", "Search", "请输入关键词",
    "请输入关键字", "请输入搜索", "请输入查询"
]


def match_search_button(text: str) -> bool:
    """判断文本是否是常见的搜索按钮文本"""
    return any(variant in text for variant in SEARCH_BUTTON_TEXTS)


def match_search_placeholder(text: str) -> bool:
    """判断文本是否是常见的搜索框 placeholder"""
    return any(variant in text for variant in PLACEHOLDER_KEYWORDS)
