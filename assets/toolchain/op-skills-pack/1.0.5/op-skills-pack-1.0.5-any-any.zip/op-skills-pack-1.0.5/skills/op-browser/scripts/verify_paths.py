from pathlib import Path

skill_root = Path("F:\\Note\\op-skills\\op-browser").resolve()
skill_assets = skill_root / "assets" / "tasks"
evolved_tasks = skill_root.parent / ".basic" / "evolved" / "op-browser" / "tasks"

print("=== task_store.py 路径验证 ===")
print(f"skill_root:     {skill_root}")
print(f"skill_assets:   {skill_assets}")
print(f"assets exists:  {skill_assets.exists()}")
print(f"evolved_tasks:  {evolved_tasks}")
print(f"evolved exists: {evolved_tasks.exists()}")

print()
print("=== project.py 路径验证 ===")
evolved_projects = skill_root.parent / ".basic" / "evolved" / "op-browser" / "projects"
print(f"evolved_projects:      {evolved_projects}")
print(f"evolved_projects exists: {evolved_projects.exists()}")
print(f"skill_assets_projects: {skill_root / 'assets' / 'projects'}")
print(f"assets_projects exists: {(skill_root / 'assets' / 'projects').exists()}")
