"""
op_browser / run_state.py — run 状态持久化与接续恢复（v2.5 2R2）

管理 runs/<run_id>/run_state.json（断点/心跳/校验历史）与
tasks/runs_index.json（run 注册表，发现与 stale 识别）。

接续三档语义（与 design-B 一致）：
- A 会话级：复用已有 Bridge 分组/tab（会话名 #r 身份后缀 + strict 全等）
- B 任务级：run_state.next_step 断点续跑，跳过已完成步骤，断点前校验保留
- C run 级：复用同一 runs/<run_id>/ 命名空间，产物继续追加

依赖 task_store 的 runs_dir/_file_lock/_atomic_write_text（跨进程安全）。
"""
import json
import os
import time
from datetime import datetime
from pathlib import Path

from . import task_store as store
from .task_store import _atomic_write_text, _file_lock, runs_dir

# stale 阈值：running 且 heartbeat 距今超过该秒数 → 视为死进程，可恢复
RUN_STALE_SECONDS = float(
    os.environ.get("OP_BROWSER_RUN_STALE_SECONDS", "600"))

# 可进入接续的状态（completed/failed 不可恢复，除非 --force）
_RESUMABLE_STATUS = ("running", "interrupted")


# ── run_state.json 读写 ───────────────────────────────────

def run_state_path(run_id: str) -> Path:
    """runs/<run_id>/run_state.json。"""
    return runs_dir(run_id) / "run_state.json"


def load_run_state(run_id: str) -> dict | None:
    """读 run 状态。不存在/损坏返回 None。"""
    p = run_state_path(run_id)
    if not p.exists():
        return None
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def save_run_state(run_id: str, state: dict) -> Path:
    """原子写 run 状态（临时文件 + os.replace，进程被杀时最新断点仍有效）。

    写后同步注册表 runs_index.json（原子写 + 锁，失败不阻断主流程）。
    """
    p = run_state_path(run_id)
    with _file_lock(p):
        _atomic_write_text(p, json.dumps(state, ensure_ascii=False, indent=2))
    _touch_index(state)
    return p


def mark_run_status(run_id: str, status: str, **kw) -> dict:
    """便捷更新状态字段并落盘。"""
    st = load_run_state(run_id) or {"run_id": run_id}
    st["status"] = status
    st["updated_at"] = datetime.now().isoformat(timespec="seconds")
    st.update(kw)
    save_run_state(run_id, st)
    return st


def flow_fingerprint(flow: dict) -> str:
    """flow 资产指纹：steps + url_resolution 的 sha256 前 16 位。

    resume 前校验：flow 资产变更后拒绝接续（断点语义失效风险）。
    """
    import hashlib
    data = json.dumps({
        "steps": flow.get("steps", []),
        "url_resolution": flow.get("url_resolution", ""),
    }, ensure_ascii=False, sort_keys=True)
    return f"sha256:{hashlib.sha256(data.encode('utf-8')).hexdigest()[:16]}"


def is_resumable(st: dict) -> bool:
    """接续判定：interrupted 显式可恢复；running 且 heartbeat 过期视为死进程。

    running 且 heartbeat 新鲜（< RUN_STALE_SECONDS）→ 疑似仍在执行，
    返回 False（防双进程接续同一 run）。
    """
    if not st:
        return False
    status = st.get("status")
    if status == "interrupted":
        return True
    if status == "running":
        hb = st.get("heartbeat_at", "")
        if not hb:
            return False
        try:
            age = (datetime.now() - datetime.fromisoformat(hb)).total_seconds()
        except (ValueError, TypeError):
            return False
        return age > RUN_STALE_SECONDS
    return False


# ── run 注册表 runs_index.json（发现与 stale 识别）────────────

def _index_path() -> Path:
    return store.tasks_root() / "runs_index.json"


def _touch_index(state: dict) -> None:
    """run_state 变更时同步注册表。失败不阻断主流程（读方有兜底扫描）。"""
    try:
        recs = _load_index()
        run_id = state.get("run_id", "")
        recs = [r for r in recs if r.get("run_id") != run_id]
        recs.append({
            "run_id": run_id,
            "task": state.get("task", ""),
            "status": state.get("status", ""),
            "heartbeat_at": state.get("heartbeat_at", ""),
            "created_at": state.get("created_at", ""),
            "updated_at": state.get("updated_at", ""),
        })
        p = _index_path()
        with _file_lock(p):
            _atomic_write_text(p, json.dumps(recs, ensure_ascii=False, indent=2))
    except Exception:
        pass


def _load_index() -> list[dict]:
    p = _index_path()
    if not p.exists():
        return []
    try:
        with open(p, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except Exception:
        return []


def list_runs(task: str = "") -> list[dict]:
    """列出 run 记录（注册表 + 兜底扫描 runs/*/run_state.json 补齐孤儿）。

    每条含 resumable 标记（供 run status / find_resumable_run 消费）。
    """
    recs = _load_index()
    known = {r.get("run_id") for r in recs}
    root = store.runs_dir()
    if root.exists():
        for d in root.iterdir():
            if not d.is_dir():
                continue
            if d.name not in known and (d / "run_state.json").exists():
                st = load_run_state(d.name)
                if st:
                    recs.append({
                        "run_id": d.name,
                        "task": st.get("task", ""),
                        "status": st.get("status", ""),
                        "heartbeat_at": st.get("heartbeat_at", ""),
                        "created_at": st.get("created_at", ""),
                        "updated_at": st.get("updated_at", ""),
                    })
    for r in recs:
        r["resumable"] = is_resumable(r)
    if task:
        recs = [r for r in recs if r.get("task") == task]
    recs.sort(key=lambda r: r.get("created_at", ""), reverse=True)
    return recs


def find_resumable_run(task: str) -> dict | None:
    """该任务最近一次可恢复 run（interrupted / stale-running）。"""
    for r in list_runs(task=task):
        if r.get("resumable"):
            return r
    return None


# ── resume 互斥锁（防双进程接续同一 run）────────────────────

def acquire_resume_lock(run_id: str) -> bool:
    """抢占 run 级接续锁（O_CREAT|O_EXCL 原子创建 + 陈旧兜底）。

    陈旧判定：锁文件 mtime 超过 RUN_STALE_SECONDS → 视为死锁删除重抢。
    """
    lock = runs_dir(run_id) / ".resume.lock"
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, f"pid={os.getpid()} at={time.time()}".encode("utf-8"))
        os.close(fd)
        return True
    except FileExistsError:
        try:
            if time.time() - lock.stat().st_mtime > RUN_STALE_SECONDS:
                lock.unlink(missing_ok=True)
                return acquire_resume_lock(run_id)
        except OSError:
            pass
        return False


def release_resume_lock(run_id: str) -> None:
    """释放接续锁（run 完成/失败/异常路径 finally 调用）。"""
    lock = runs_dir(run_id) / ".resume.lock"
    try:
        lock.unlink(missing_ok=True)
    except OSError:
        pass
