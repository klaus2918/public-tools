"""
op_browser / cdputil.py — CDP 工具函数封装

基于 Playwright async API 的浏览器控制层。
提供低级 CDP 命令和高级操作（点击、填表、截图），
供 engine.py 的 run 模式使用。
"""
import asyncio, base64, json, os, tempfile, urllib.request
from pathlib import Path
from typing import Any

from playwright.async_api import async_playwright


# 截图缓存目录：固定目录复用，避免每次截图 mkdtemp 泄漏目录
SHOT_DIR = Path(tempfile.gettempdir()) / "op_browser_shots"
SHOT_DIR.mkdir(parents=True, exist_ok=True)


# ── Chrome 远程调试端口自动发现 ────────────────────────────────

async def find_cdp_url() -> str | None:
    """扫描常见端口，自动发现 Chrome 的远程调试 WebSocket URL。"""
    for port in (9222, 9223, 9224):
        try:
            resp = await asyncio.wait_for(
                asyncio.get_event_loop().run_in_executor(
                    None,
                    lambda p=port: urllib.request.urlopen(
                        f"http://127.0.0.1:{p}/json/version", timeout=1
                    ).read(),
                ),
                timeout=2,
            )
            data = json.loads(resp)
            url = data.get("webSocketDebuggerUrl")
            if url:
                return url
        except Exception:
            continue
    return None


# ── CDP 客户端 ─────────────────────────────────────────────────

class CDPClient:
    """浏览器 CDP 客户端。

    提供两种控制方式：
    - 高层 API（click, fill, goto, screenshot）— 基于 Playwright
    - 原始 CDP（cdp() 方法）— 供特殊场景使用
    """

    def __init__(self):
        self._pw = None
        self._browser = None
        self._context = None
        self._page = None
        self._cdp = None  # CDPSession
        self._connected = False
        self._owns_page = False  # v2.5: isolated 模式新建的标签页由本 client 负责关闭

    # ── 连接 ─────────────────────────────────────────────────

    async def connect(self, cdp_url: str | None = None, headless: bool = False,
                      isolated: bool = False):
        """连接到浏览器。

        参数:
            cdp_url: 已有 Chrome 的 CDP WebSocket URL
                     None 时自动发现（优先）或启动新浏览器
            headless: 启动新浏览器时为无头模式
            isolated: True（并行/命名 run）时 attach 已有浏览器将新建独立标签页，
                页面操作面隔离（判定标准 3）；False（顺序）保持原 attach 行为。

        P2-21：单次 start（不再递归 connect，避免覆盖 self._pw 泄漏 Playwright）；
        任一分支失败统一释放资源并置空字段后抛错。
        """
        self._owns_page = False
        try:
            self._pw = await async_playwright().start()
            # 无 cdp_url 时先尝试自动发现，发现即复用（不再递归 connect）
            if not cdp_url:
                cdp_url = await find_cdp_url()

            if cdp_url:
                self._browser = await self._pw.chromium.connect_over_cdp(cdp_url)
                ctxs = self._browser.contexts
                if isolated:
                    # 页面隔离：新建独立标签页（_owns_page 标记，close 时自关）
                    self._context = (ctxs[0] if ctxs
                                     else await self._browser.new_context())
                    self._page = await self._context.new_page()
                    self._owns_page = True
                elif ctxs and ctxs[0].pages:
                    self._page = ctxs[0].pages[0]  # 顺序模式原行为：复用既有页面
                    self._context = ctxs[0]
                else:
                    ctx = ctxs[0] if ctxs else await self._browser.new_context()
                    self._page = (ctxs[0].pages[0] if (ctxs and ctxs[0].pages)
                                  else await ctx.new_page())
                    self._context = ctx
            else:
                # 未发现 → 启动新浏览器
                self._browser = await self._pw.chromium.launch(
                    headless=headless,
                    args=["--start-maximized"],
                )
                self._context = await self._browser.new_context(no_viewport=True)
                self._page = await self._context.new_page()

            try:
                self._cdp = await self._page.context.new_cdp_session(self._page)
            except Exception:
                self._cdp = None  # 部分浏览器可能不支持 CDPSession

            self._connected = True
            return self
        except Exception as e:
            # 失败统一释放资源并置空字段（防半初始化状态残留）
            try:
                if self._browser is not None:
                    await self._browser.close()
            except Exception:
                pass
            try:
                if self._pw is not None:
                    await self._pw.stop()
            except Exception:
                pass
            self._browser = None
            self._context = None
            self._page = None
            self._cdp = None
            self._pw = None
            self._connected = False
            raise

    @property
    def page(self):
        return self._page

    @property
    def connected(self) -> bool:
        return self._connected

    # ── 原始 CDP ────────────────────────────────────────────

    async def cdp(self, method: str, **params) -> dict[str, Any]:
        """发送原始 CDP 命令。"""
        if not self._cdp:
            raise RuntimeError("CDP session 未初始化，无法发送原始命令")
        return await self._cdp.send(method, params)

    # ── 页面导航 ────────────────────────────────────────────

    async def goto(self, url: str, timeout: float = 30.0):
        """导航到 URL。"""
        await self._page.goto(url, timeout=timeout * 1000, wait_until="domcontentloaded")

    async def page_info(self) -> dict:
        """获取当前页面信息。"""
        return json.loads(await self._page.evaluate(
            "JSON.stringify({url:location.href,title:document.title,"
            "w:innerWidth,h:innerHeight,sx:scrollX,sy:scrollY,"
            "pw:document.documentElement.scrollWidth,"
            "ph:document.documentElement.scrollHeight})"
        ))

    # ── 点击 ────────────────────────────────────────────────

    async def click(self, selector: str, **kwargs):
        """Playwright 标准的元素点击。"""
        await self._page.click(selector, **kwargs)

    async def click_xy(self, x: float, y: float, button: str = "left", clicks: int = 1):
        """基于 CDP 的坐标点击（穿透 iframe / Shadow DOM）。"""
        await self.cdp(
            "Input.dispatchMouseEvent",
            type="mousePressed", x=x, y=y, button=button, clickCount=clicks,
        )
        await self.cdp(
            "Input.dispatchMouseEvent",
            type="mouseReleased", x=x, y=y, button=button, clickCount=clicks,
        )

    # ── 输入 ────────────────────────────────────────────────

    async def fill(self, selector: str, text: str, clear: bool = True):
        """填表（触发框架事件）。"""
        if clear:
            await self._page.fill(selector, "")
        await self._page.fill(selector, text)

    async def type_text(self, text: str):
        """通过 CDP 输入文本（绕过框架，适合不可控输入框）。"""
        await self.cdp("Input.insertText", text=text)

    async def press_key(self, key: str):
        """按键（Enter / Tab / Escape 等）。"""
        await self._page.keyboard.press(key)

    # ── 提取 ────────────────────────────────────────────────

    async def js(self, expression: str) -> Any:
        """执行 JavaScript，返回值。"""
        return await self._page.evaluate(expression)

    async def text(self, selector: str) -> str | None:
        """获取元素的文本内容。"""
        el = await self._page.query_selector(selector)
        return await el.inner_text() if el else None

    async def attr(self, selector: str, name: str) -> str | None:
        """获取元素属性。"""
        el = await self._page.query_selector(selector)
        return await el.get_attribute(name) if el else None

    # ── 截图 ────────────────────────────────────────────────

    async def screenshot(self, path: str | None = None) -> str:
        """截取当前视口截图。

        返回: 截图文件路径
        path 为空 → SHOT_DIR/shot.png（旧行为兼容）；非空 → 自动建目录后写入。
        """
        path = path or str(SHOT_DIR / "shot.png")
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        await self._page.screenshot(path=path, full_page=False)
        return path

    async def screenshot_full(self, path: str | None = None) -> str:
        """截取完整页面截图（含滚动区域）。"""
        path = path or str(SHOT_DIR / "shot_full.png")
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        await self._page.screenshot(path=path, full_page=True)
        return path

    # ── 等待 ────────────────────────────────────────────────

    async def wait(self, seconds: float = 1.0):
        await asyncio.sleep(seconds)

    async def wait_for_selector(self, selector: str, timeout: float = 10.0) -> bool:
        """等待元素出现。返回是否存在。"""
        try:
            await self._page.wait_for_selector(selector, timeout=timeout * 1000)
            return True
        except Exception:
            return False

    async def wait_for_load(self, timeout: float = 15.0) -> bool:
        """等待页面完全加载。"""
        try:
            await self._page.wait_for_load_state("networkidle", timeout=timeout * 1000)
            return True
        except Exception:
            return False

    # ── 标签页 ──────────────────────────────────────────────

    async def new_tab(self, url: str = "about:blank"):
        """打开新标签页。"""
        p = await self._context.new_page()
        if url != "about:blank":
            await p.goto(url)
        self._page = p
        try:
            self._cdp = await self._context.new_cdp_session(self._page)
        except Exception:
            self._cdp = None

    async def close_tab(self):
        """关闭当前标签页。"""
        p = self._page
        pages = self._context.pages
        if len(pages) > 1:
            idx = pages.index(p)
            await p.close()
            self._page = pages[0] if idx == 0 else pages[idx - 1]
        else:
            await p.close()

    # ── 清理 ────────────────────────────────────────────────

    async def close(self):
        """关闭所有连接。"""
        # v2.5: isolated 模式先关闭自己创建的标签页（不碰 attach 的既有页面）
        if getattr(self, "_owns_page", False) and self._page is not None:
            try:
                if not self._page.is_closed():
                    await self._page.close()
            except Exception:
                pass
            self._page = None
        if self._pw:
            await self._pw.stop()
            self._pw = None
        self._connected = False
