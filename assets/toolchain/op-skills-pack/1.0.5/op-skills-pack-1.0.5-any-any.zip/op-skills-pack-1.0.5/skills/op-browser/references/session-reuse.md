# 会话复用机制

> 位置：`op-browser/references/session-reuse.md`
> 用途：说明分组/会话的复用判定、保持与超时管理，供 `run` / `taskset` / `test` 复用登录态时参照。
> 关联：`references/bridge-adapter.md`（Bridge 分组）、`references/concurrency.md`（并发与资源）、`references/login-matching.md`（登录方式匹配）

## 一、复用流程

```
开始执行浏览器操作
  │
  ├─ 1. 检查当前任务历史分组（browser-groups.json）
  │     ├─ 有历史分组 → 步骤 2
  │     └─ 无历史分组 → 新建分组
  │
  ├─ 2. 检查分组存活状态
  │     ├─ 存活 → 步骤 3
  │     └─ 已失效 → 新建分组
  │
  ├─ 3. 检查会话有效性（URL 同源判定）
  │     ├─ 同源 → 步骤 4
  │     └─ 不同源 → 新建分组
  │
  ├─ 4. 检查会话状态（页面可访问 + 登录态有效）
  │     ├─ 有效 → 复用会话
  │     └─ 失效 → 重新登录
  │
  └─ 5. 复用并更新分组最后使用时间
```

## 二、会话有效性检测

### 1. URL 同源判定

**规则**：**端口相同**的本地地址视为同源。

| 地址类型 | 示例 | 判定 |
|----------|------|------|
| `127.0.0.0/8` | `127.0.0.1`、`127.0.0.2` | 本地 |
| `localhost` | `localhost` | 本地 |
| 内网网段 | `192.168.x.x`、`10.x.x.x` | 本地 |
| `0.0.0.0` | `0.0.0.0` | 本地 |

**复用规则**：

- `127.0.0.1:5557` 与 `192.0.2.10:5557` → **可复用**（同端口）
- `127.0.0.1:5557` 与 `127.0.0.1:8080` → **不可复用**（不同端口）

### 2. 页面可访问性检测

```javascript
// 页面可访问：标题存在且非错误页
(function() {
  try {
    var title = document.title || '';
    if (/404|500|错误|Error/i.test(title)) return false;
    return true;
  } catch (e) {
    return false;
  }
})()
```

### 3. 登录态有效性检测

```javascript
// 登录态有效：任一通道命中即视为已登录
(function() {
  if (document.querySelector('.user-info, .username, [class*=user]')) return true;
  if (localStorage.getItem('sessionId') || sessionStorage.getItem('sessionId')) return true;
  if (document.cookie.indexOf('sessionId') >= 0 || document.cookie.indexOf('token') >= 0) return true;
  return false;
})()
```

> 判定顺序：先看 DOM 用户信息，再看存储，最后看 Cookie；三者均未命中才判失效（避免误判导致重复登录）。

## 三、会话保持机制

### 1. 分组生命周期

```yaml
# project.yaml
browser:
  bridge_group:
    reuse_policy: "same_origin"   # 复用策略
    session_timeout: 3600         # 会话超时（秒）
    keep_alive_interval: 300      # 心跳间隔（秒）
```

**超时处理**：

- 会话超时 → 自动重新登录
- 心跳失败 → 标记会话失效
- 分组失效 → 清理并新建

### 2. 心跳检测

```javascript
// 心跳（按 keep_alive_interval 触发）
(function() {
  var xhr = new XMLHttpRequest();
  xhr.open('GET', '/api/heartbeat', false);
  xhr.send();
  return xhr.status === 200;
})()
```

### 3. 会话续期

- 操作前检测会话有效性
- 即将过期时自动续期
- 续期失败 → 重新登录（并记录一次「非预期重登」，用于复用率统计）

## 四、复用优化

### 1. 智能分组选择

优先顺序：最近使用 → 同 URL → 同角色（账号）。

### 2. 分组池管理

```yaml
# project.yaml
browser:
  bridge_group:
    pool_size: 5            # 最大分组数
    cleanup_policy: "lru"   # lru（最近最少使用）| fifo
```

**清理逻辑**：超过 `pool_size` → 清理最旧分组；分组失效 → 立即清理；任务结束 → 按配置决定是否清理。

### 3. 会话共享（多任务同登录态）

- 使用**相同分组名**复用同一登录态；分组名约定 `<project>-<env>-<role>`（如 `<demo>-dev-admin`）
- 分组生命周期由**最后一个使用它的任务**管理（先结束的任务不主动回收）

## 五、验证复用效果

| 指标 | 目标 | 验证方法 |
|------|------|----------|
| 会话复用率 | > 80% | 复用次数 / 总操作次数 |
| 登录次数减少 | > 50% | 对比优化前后登录次数 |
| 执行时间减少 | > 30% | 对比优化前后执行时间 |

**步骤**：执行相同操作多次 → 记录复用情况 → 统计登录次数与耗时 → 对比优化前后。
