"""
op_browser / base.py — BrowserAdapter 抽象基类

定义所有浏览器操作的统一接口。所有方法均为 async，调用方不关心底层是 CDP 还是 Bridge。
新增适配器只需继承 BrowserAdapter 并实现全部抽象方法。
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


# ── 数据类 ─────────────────────────────────────────────────────

@dataclass
class ActionResult:
    """操作结果。"""
    success: bool = True
    error: str | None = None
    data: Any = None


@dataclass
class NavigationInfo:
    """导航信息。"""
    url: str = ""
    title: str = ""
    status_code: int = 200
    error: str | None = None


@dataclass
class ElementInfo:
    """元素信息。"""
    tag_name: str = ""
    text: str = ""
    selector: str = ""
    x: float = 0.0
    y: float = 0.0
    width: float = 0.0
    height: float = 0.0
    attributes: dict = field(default_factory=dict)
    a11y_role: str = ""
    a11y_name: str = ""


@dataclass
class A11yNode:
    """无障碍树节点。"""
    role: str = ""
    name: str = ""
    children: list["A11yNode"] = field(default_factory=list)
    attributes: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "role": self.role,
            "name": self.name,
            "attributes": self.attributes,
            "children": [c.to_dict() for c in self.children],
        }


# ── 适配器抽象基类 ─────────────────────────────────────────────

class BrowserAdapter(ABC):
    """浏览器适配器抽象基类。

    所有浏览器操作抽象为统一接口：
    - 生命周期：connect / close
    - 会话管理：start_session / close_session
    - 导航：goto / wait_for_load
    - 元素操作：click / click_by_locator / fill / type_text / press_key
    - 内容提取：read_text / accessibility_tree / query_elements / execute_js
    - 截图：screenshot
    - 等待：wait_for_selector / wait_for_text
    - 标签页：new_tab / close_tab / list_tabs

    注：accessibility_tree 和 click_by_locator 在 CDP 模式下通过 fallback 链实现，
    Bridge 模式下直接调用 RPC。
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """适配器名称：'cdp' / 'bridge'。"""
        ...

    # ── 生命周期 ───────────────────────────────────────────

    @abstractmethod
    async def connect(self, **kwargs) -> bool:
        """建立连接。返回是否成功。"""
        ...

    @abstractmethod
    async def close(self):
        """关闭连接释放资源。"""
        ...

    # ── 会话管理 ───────────────────────────────────────────

    @abstractmethod
    async def start_session(self, url: str = "") -> str:
        """启动新浏览器会话/标签页，返回 session_id。"""
        ...

    @abstractmethod
    async def close_session(self, session_id: str):
        """关闭指定会话。"""
        ...

    # ── 导航 ───────────────────────────────────────────────

    @abstractmethod
    async def goto(self, url: str) -> NavigationInfo:
        """导航到 URL。返回导航信息。"""
        ...

    @abstractmethod
    async def wait_for_load(self, timeout: float = 15.0) -> bool:
        """等待页面加载完成。"""
        ...

    # ── 元素操作 ───────────────────────────────────────────

    @abstractmethod
    async def click(self, selector: str) -> ActionResult:
        """CSS 选择器点击。"""
        ...

    @abstractmethod
    async def click_by_locator(self, role: str, name: str) -> ActionResult:
        """按 role/name 定位点击（Bridge 核心能力，CDP 走 fallback 链）。"""
        ...

    @abstractmethod
    async def fill(self, selector: str, text: str) -> ActionResult:
        """CSS 选择器填表。"""
        ...

    @abstractmethod
    async def type_text(self, text: str) -> ActionResult:
        """焦点元素输入文本（绕过框架）。"""
        ...

    @abstractmethod
    async def press_key(self, key: str) -> ActionResult:
        """按键操作（Enter / Tab / Escape 等）。"""
        ...

    # ── 内容提取 ───────────────────────────────────────────

    @abstractmethod
    async def read_text(self, selector: str = "") -> str:
        """读取页面/元素文本。selector 为空时返回页面全部可见文本。"""
        ...

    @abstractmethod
    async def accessibility_tree(self) -> list[A11yNode]:
        """获取无障碍树。Bridge 模式返回丰富树，CDP 模式返回简化版本。"""
        ...

    @abstractmethod
    async def query_elements(self, **criteria) -> list[ElementInfo]:
        """按条件查询元素。支持 tag/class/role/name/text 等筛选。"""
        ...

    @abstractmethod
    async def execute_js(self, expression: str) -> Any:
        """执行 JS 表达式并返回值。"""
        ...

    # ── 截图 ───────────────────────────────────────────────

    @abstractmethod
    async def screenshot(self, full_page: bool = False, out_path: str = "") -> str:
        """截取当前视口截图。返回截图文件路径。

        out_path: 指定输出路径；为空时使用适配器默认缓存路径
            （%TEMP%\\op_browser_shots\\*，保持旧行为）。
            v2.5: run_id 场景由调用方（engine）传入 runs/<run_id>/shots/ 路径。
        """
        ...

    # ── 等待 ───────────────────────────────────────────────

    @abstractmethod
    async def wait_for_selector(self, selector: str, timeout: float = 10.0) -> bool:
        """等待元素出现。返回是否存在。"""
        ...

    @abstractmethod
    async def wait_for_text(self, text: str, timeout: float = 10.0) -> bool:
        """等待文本出现。返回是否找到。"""
        ...

    # ── 标签页 ─────────────────────────────────────────────

    @abstractmethod
    async def new_tab(self, url: str = "about:blank") -> str:
        """打开新标签页，返回 tab_id。"""
        ...

    @abstractmethod
    async def close_tab(self, tab_id: str = ""):
        """关闭标签页。tab_id 为空时关闭当前标签页。"""
        ...

    @abstractmethod
    async def list_tabs(self) -> list[dict]:
        """列出所有标签页信息。"""
        ...

    # ── 连接状态 ───────────────────────────────────────────

    @abstractmethod
    async def is_connected(self) -> bool:
        """检查连接是否正常。"""
        ...
