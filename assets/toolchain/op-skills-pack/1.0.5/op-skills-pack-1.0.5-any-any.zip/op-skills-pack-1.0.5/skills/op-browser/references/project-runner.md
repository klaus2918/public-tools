# 项目化管理详细规范

> 本文档是 op-browser 项目化管理（ProjectRegistry + BrowserProjectRunner）的完整技术规范，SKILL.md 的补充文档。

---

## 项目化管理概述

v2 支持 `project/system/module` 三层上下文管理，通过 `project.yaml` 索引项目，
`adapter.json` 配置系统适配器，模块目录存放 test-spec/test-data 资产。

---

## 目录结构

```
projects/<project>/
├── project.yaml              # 项目索引（名称、描述、系统列表）
└── systems/<system>/         # 系统适配器
    ├── _shared/adapter.json  # 结构化配置（baseUrl/fe_base_prefix/routes/buttonAliases 等）
    └── modules/              # 业务模块
         ├── <module>/        # 完整模块（test-spec/test-data）
         └── <module>/        # 骨架模块（仅有目录结构）
```

**示例（demo-project 项目）：**

```
projects/demo-project/
├── project.yaml              # 项目索引
└── systems/demo-project-pc/        # 系统适配器
    ├── _shared/adapter.json  # 结构化配置
    └── modules/              # 业务模块
         ├── party-group-topic/    # 完整（test-spec/test-data）
         ├── incoming-doc/        # 骨架
         ├── outgoing-doc/        # 骨架
         └── supervision/         # 骨架
```

---

## ProjectRegistry

项目注册表负责发现和加载 `projects/` 下的项目资产。

### 项目发现

- 扫描 `OP_BROWSER_PROJECTS_DIR`（默认 `./projects`）下的目录
- 每个目录必须包含 `project.yaml` 才被视为有效项目
- `project.yaml` 包含项目元数据（名称、描述、系统列表）

### project.yaml 结构

```yaml
name: demo-project
description: 示例综合管理平台
systems:
  - name: demo-project-pc
    description: PC 端系统
    base_url: http://example.com
```

### adapter.json 结构

`systems/<system>/_shared/adapter.json` 是系统级适配器配置：

```json
{
  "baseUrl": "http://example.com",
  "fe_base_prefix": "/app",
  "routes": {
    "login": "/login",
    "home": "/home"
  },
  "buttonAliases": {
    "提交": "#submit-btn",
    "保存": ".save-btn"
  },
  "login": {
    "verify": {
      "account_key": "username"
    }
  }
}
```

字段说明：
- `baseUrl`：系统基础 URL
- `fe_base_prefix`：前端路由前缀（拼接相对 URL 时使用）
- `routes`：命名路由映射
- `buttonAliases`：按钮别名映射（中文名 → CSS 选择器）
- `login.verify.account_key`：登录态账号比对字段（启用账号感知复用）

---

## BrowserProjectRunner

项目运行器负责在项目上下文中执行任务。

### 上下文加载

当 `run()` 传入 `project/system/module` 参数时：
1. `ProjectRegistry` 查找对应项目
2. 加载 `systems/<system>/_shared/adapter.json`
3. 将配置注入 `project` 变量（脚本可消费）
4. 定位模块目录下的 test-spec/test-data 资产

### 脚本内 project 变量

CDP 脚本（script.py）执行时，引擎把 `resolve_case` 结果注入命名空间为
`project` 变量（含 `adapter` 配置：baseUrl/fe_base_prefix/routes/buttonAliases 等），
脚本可据此消费项目配置；未传 project/system/module 时为 `{}`，脚本需自行容错。

### 使用示例

```python
from op_browser import SmartBrowser

browser = SmartBrowser()
result = await browser.run(
    "收文登记测试",
    project="demo-project",
    system="demo-project-pc",
    module="incoming-doc",
)
# 自动加载 projects/demo-project/systems/demo-project-pc/_shared/adapter.json
```

### 步骤 URL 解析（opt-in）

flow.json 顶层声明 `url_resolution: project` 后，
相对 URL（如 `/login`）用项目 adapter 的 baseUrl(+fe_base_prefix) 拼接；
绝对 URL 或未声明时维持原样（向后兼容）。项目根可经 `OP_BROWSER_PROJECTS_DIR`
环境变量指定，未设置时回退当前工作目录 `projects/`。

---

## 校验模式（v2.7）

### verify_mode 参数

`run()` 方法新增 `verify_mode` 参数，控制校验方式：

| 模式 | 说明 | 适用场景 |
|------|------|---------|
| `"screenshot"` | 截图 baseline 对比（原行为），每步截图与基线比较，diff_rate < pass_th → pass | 固化流程回放、UI 回归测试 |
| `"dom"` | DOM 断言验证，跳过截图比对，改为执行 script.py/flow.json 中的 verify 断言（文本匹配、元素计数、可见性检查） | 功能验证（verify-browser）、无 baseline 的任务 |
| `"auto"`（默认） | 自适应：有 baseline 截图 → screenshot 模式；无 baseline → dom 模式 | 通用场景 |

### DOM 断言定义

script.py 中通过 `page.locator().count()` / `is_visible()` / `inner_text()` 等 API 检查页面状态，并将结果写入 `result.extra["dom_checks"]`。引擎自动聚合所有 DOM 断言结果给出 `judge`：
- 全部通过 → judge = "pass"
- 部分失败 → judge = "fail"（错误信息汇总到 result.error）

flow.json 支持顶层 `verify` 字段定义断言列表（v2.7）：
```json
{"verify": [{"type": "text", "selector": "text=预期文本", "assert": "exists"}, {"type": "count", "selector": "tr.data-row", "assert": {"min": 1}}]}
```

### 命令行
```bash
/op-browser run 任务A --verify-mode dom
/op-browser run 任务B --verify-mode screenshot   # 显式截图校验
```

### 最佳实践
- **功能验证 / verify-browser**：使用 `verify_mode="dom"`，在 script.py 中编写 DOM 断言
- **UI 回归 / 像素级对比**：使用 `verify_mode="screenshot"`，需要 pre-baseline 截图
- **混合**：先用 dom 模式通过功能验证，再用 screenshot 模式回归截图的场景，分两次 run

---

## validate 防线建议（P2-C 卫生治理，v2.4.4）

以下为 **op-000 validate 检查项建议**（仅建议，落地由主会话在 op-000 脚本中实施，本 skill 不自行修改 op-000）：

| 检查项 | 判定 | 处置 |
|--------|------|------|
| op-browser 目录无未跟踪 `tmp_*.py` | `git status --ignored` 中出现 `tmp_*.py` 即残留 | 直接删除（gitignore 第 26 行 `tmp_*.py` 已覆盖，属工作区清理，不影响跟踪文件） |
| 无游离日志/临时文件（`*.log`、`_*.py`、`*.tmp`） | 目录内出现未跟踪临时文件 | 人工确认后删除，或归入对应产物目录 |
| op-html sites/ 无游离文件 | 除 `<project>/<page>/` 与 `_archive/` 外出现散落文件 | 按 op-html「sites 生命周期」dry-run 流程处理 |

> 2026-08-14 P2-C 实际清理：删除 7 个 `tmp_*.py`（tmp_login_test.py / tmp_pubkey.py / tmp_test0001_perm.py / tmp_test0001_perms.py / tmp_test0001_routes.py / tmp_test0001_routes2.py / tmp_test0001_routes3.py），无跟踪文件受影响。
