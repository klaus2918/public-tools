# -*- coding: utf-8 -*-
"""
op_browser / login_inject.py — 登录注入（demo-project 专项，配置即开关）

针对"配置了 adapter.login 且 login.enabled==true"的项目做 token 注入：
1. 登录态校验（URL 判据 + storage 判据，verify.mode 组合）
2. 未登录 → 取 token（token_source=api 免验证码登录 / env 环境变量直供）
3. goto 同源页面 → 写 storage → reload → 复验

设计原则（23-login-inject-design §4.4 三重隔离）：
- 配置即开关：无 login.enabled==true 的项目（如 verify-pc）→ 零代码路径
- 上下文即隔离：裸 run（无 project_context）→ 不触发
- 凭据安全：密码/token 不落盘、日志只打前 8 字符
"""
from __future__ import annotations

import json, logging, os
from typing import Any

logger = logging.getLogger(__name__)


class LoginInjectError(RuntimeError):
    """登录注入失败统一异常类型（engine 钩子捕获后诚实返回）。"""


# ── 配置加载 ─────────────────────────────────────────────

def load_login_config(project_context: dict | None) -> dict | None:
    """取 adapter.login；enabled!=true 或缺失 → None（配置即开关）。"""
    if not project_context:
        return None
    adapter = (project_context.get("adapter") or {})
    login = adapter.get("login") or {}
    if not login.get("enabled"):
        return None
    # 注入 auth 兜底引用（login 缺省字段从 auth 取；不污染原始配置）
    login = dict(login)
    login["_auth"] = adapter.get("auth") or {}
    login["_auth_login_request_example"] = (adapter.get("auth") or {}).get(
        "login_request_example") or {}
    # 登录后端地址：环境变量 > login.api.backend_url > adapter 的 dev backendUrl
    login["_backend"] = (os.environ.get("BROWSER_LOGIN_BACKEND_URL")
                         or login.get("api", {}).get("backend_url")
                         or ((adapter.get("environmentOverlays") or {})
                             .get("dev", {}).get("backendUrl")
                             or adapter.get("backend_base")
                             or ""))
    return login


# ── 登录态校验 ───────────────────────────────────────────

def _url_not_contains_ok(url: str, paths: list) -> bool:
    """当前 URL 不含列出的路径片段 → 视为已登录。"""
    if not paths:
        return True  # 无判据 → 不拦截
    return not any(p in url for p in paths)


async def _storage_has(adapter: Any, storage: str, key: str) -> bool:
    """指定 storage 中存在该键 → 已登录。异常按未登录保守处理。"""
    try:
        expr = f"({storage} && {storage}.getItem({json.dumps(key)}) !== null)"
        val = await _run_js(adapter, expr)
        return bool(val)
    except Exception:
        return False


async def is_logged_in(adapter: Any, cfg: dict) -> bool:
    """按 verify 判据组合判断当前是否已登录。异常按 False 保守处理。"""
    verify = cfg.get("verify") or {}
    mode = verify.get("mode", "any")
    url_paths = verify.get("url_not_contains") or []
    sh = verify.get("storage_has") or {}
    storage = sh.get("storage") or cfg.get("inject", {}).get("storage") or "sessionStorage"
    key = sh.get("key", "")

    results = []
    if url_paths:
        url = ""
        try:
            url = await _get_url(adapter)
        except Exception:
            url = ""
        results.append(_url_not_contains_ok(url, url_paths))
    if key:
        results.append(await _storage_has(adapter, storage, key))

    if not results:
        return True  # 无判据 → 视为已登录（不注入）
    return any(results) if mode == "any" else all(results)


async def logged_account(adapter: Any, cfg: dict) -> str:
    """读当前已登录账号标识（verify.account_key 配置时）。

    配置形如 `verify.account_key: {storage: "sessionStorage", key: "account"}`。
    未配置/读取失败返回 ''（保持旧行为：不启用账号比对）。
    v2.5 P1：并行同源共享 storage 时，不同账号的 run 靠此兜底避免串号。
    """
    verify = cfg.get("verify") or {}
    ak = verify.get("account_key") or {}
    if not ak.get("key"):
        return ""
    storage = (ak.get("storage")
               or cfg.get("inject", {}).get("storage")
               or "sessionStorage")
    try:
        expr = f"({storage} && {storage}.getItem({json.dumps(ak['key'])}))"
        val = await _run_js(adapter, expr)
        return str(val or "")
    except Exception:
        return ""


# ── token 获取 ───────────────────────────────────────────

def _mask(s: str) -> str:
    """日志脱敏：只保留前 8 字符。"""
    return f"{s[:8]}..." if s and len(s) > 8 else (s or "")


def _get_password(username: str) -> str:
    """读取账号密码环境变量（BROWSER_LOGIN_PASSWORD_<USERNAME> 大写）。"""
    env = f"BROWSER_LOGIN_PASSWORD_{username.upper()}"
    pwd = os.environ.get(env, "")
    if not pwd:
        raise LoginInjectError(
            f"登录注入失败：未设置环境变量 {env}（token_source=api 需要账号密码）。"
            "请 export 后重试，或改用 token_source=env 直供 token。")
    return pwd


def _get_env_token(username: str) -> str:
    """token_source=env 时读环境变量（BROWSER_LOGIN_TOKEN_<U> 或 BROWSER_LOGIN_TOKEN）。"""
    token = os.environ.get(f"BROWSER_LOGIN_TOKEN_{username.upper()}", "")
    if not token:
        token = os.environ.get("BROWSER_LOGIN_TOKEN", "")
    if not token:
        raise LoginInjectError(
            "登录注入失败：未设置 BROWSER_LOGIN_TOKEN（token_source=env 需要直供 token）。")
    return token


def _dot_get(data: dict, path: str):
    """点路径取值（data.accessToken → data["accessToken"]）。"""
    cur: Any = data
    for part in path.split("."):
        if isinstance(cur, dict):
            cur = cur.get(part)
        else:
            return None
    return cur


async def fetch_token(cfg: dict, account: str) -> str:
    """取 token。api = RSA 加密密码 → 免验证码登录 → token_path；env = 环境变量直供。"""
    source = cfg.get("token_source", "api")
    if source == "env":
        return _get_env_token(account)

    if source != "api":
        raise LoginInjectError(f"登录注入失败：未知 token_source={source!r}（仅支持 api/env）")

    import httpx
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import padding

    api = cfg.get("api") or {}
    auth = cfg.get("_auth") or {}
    backend = cfg.get("_backend") or api.get("backend_url") or ""
    if not backend:
        raise LoginInjectError("登录注入失败：缺少登录后端地址（login.api.backend_url 或 BROWSER_LOGIN_BACKEND_URL）")
    # 预检：密码环境变量缺失时在最前面诚实报错，避免先发公钥请求再失败
    _get_password(account)

    endpoints = api.get("endpoints") or auth.get("endpoints") or {}
    pub_key_path = endpoints.get("get_public_key", "/auth/get-public-key")
    login_path = endpoints.get("login_without_captcha",
                                "/auth/login/instance/password-without-captcha")
    timeout = float(api.get("timeout_ms", 15000)) / 1000.0
    token_path = api.get("token_path", "data.accessToken")
    success_code = str(api.get("success_code", "0"))
    req_template = api.get("login_request_template")
    if not req_template:
        # 兜底：从 auth.login_request_example 取（pc 端有完整示例；app 端缺省构造）
        req_template = (cfg.get("_auth_login_request_example") or {})
    rsa_mode = ((api.get("rsa") or auth.get("rsa") or {})
                .get("mode", "RSAES-PKCS1-v1_5"))

    try:
        async with httpx.AsyncClient(timeout=timeout) as c:
            # 1. 获取公钥
            r1 = await c.get(f"{backend}{pub_key_path}", params={"index": ""})
            j1 = r1.json()
            pub_data = j1.get("data") or {}
            index = pub_data.get("index", "")
            pub_pem_b64 = pub_data.get("publicKey") or pub_data.get("public_key") or ""
            if not pub_pem_b64:
                raise LoginInjectError(
                    f"登录注入失败：get-public-key 响应无 publicKey（HTTP {r1.status_code}）")
            pub_pem = ("-----BEGIN PUBLIC KEY-----\n"
                       f"{pub_pem_b64}\n"
                       "-----END PUBLIC KEY-----\n")

            # 2. RSA 加密密码（RSAES-PKCS1-v1_5，与 JSEncrypt 兼容）
            pub = serialization.load_pem_public_key(pub_pem.encode())
            enc = pub.encrypt(_get_password(account).encode(), padding.PKCS1v15())
            import base64
            enc_b64 = base64.b64encode(enc).decode()

            # 3. 免验证码登录（请求体占位符替换，完全配置驱动）
            body = json.loads(json.dumps(req_template))
            for k, v in list(body.items()):
                if isinstance(v, str):
                    body[k] = (v.replace("<loginId>", account)
                                .replace("<RSA 加密后的密码>", enc_b64)
                                .replace("<encodePassword>", enc_b64)
                                .replace("<公钥 index>", index)
                                .replace("<index>", index))
            if not body:
                body = {"username": account, "encodePassword": enc_b64,
                        "index": index}

            r2 = await c.post(f"{backend}{login_path}", json=body)
            j2 = r2.json()
            code = str(j2.get("code", ""))
            if code != success_code:
                raise LoginInjectError(
                    f"登录注入失败：登录接口业务失败 code={code} "
                    f"message={str(j2.get('message', ''))[:120]}")
            token = _dot_get(j2, token_path)
            if not token:
                raise LoginInjectError(
                    f"登录注入失败：响应中无 token（token_path={token_path}）")
            return str(token)
    except LoginInjectError:
        raise
    except Exception as e:
        raise LoginInjectError(f"登录注入失败：免验证码登录请求异常: {e}") from e


# ── storage 注入 ─────────────────────────────────────────

def _build_inject_js(storage: str, key: str, value: str) -> str:
    """构造 storage 写入 JS。value 经 json.dumps 转义，防特殊字符破坏结构/逃逸。"""
    return (f"(() => {{"
            f"try {{ {storage}.setItem({json.dumps(key)}, {json.dumps(value)}); "
            f"return true; }} "
            f"catch(e) {{ return false; }}}})()")


def _fill_template(value_template: str, token: str) -> str:
    """value_template 中 {token} 占位符替换为 JSON 转义后的 token（成品即合法 JSON 值串）。"""
    if "{token}" not in value_template:
        raise LoginInjectError(
            "登录注入失败：inject.value_template 缺少 {token} 占位符。"
            "请按 {\"satoken\": \"{token}\"} 格式配置。")
    # 模板里 {token} 是"值占位符"（未含引号），替换为 json.dumps(token)（含引号转义）
    # 示例：{"satoken": {token}} + token=abc → {"satoken": "abc"}
    # 兼容两种写法：{"satoken": "{token}"}（带引号）与 {"satoken": {token}}（不带）
    if '"' + "{token}" + '"' in value_template:
        # 带引号写法：把 "{token}" 整体换成 json.dumps(token)（保留模板引号外的 JSON 结构）
        return value_template.replace('"{token}"', json.dumps(token, ensure_ascii=False))
    return value_template.replace("{token}", json.dumps(token, ensure_ascii=False))


async def _run_js(adapter: Any, expr: str):
    """统一执行 JS：CDPClient 只有 js()，BridgeAdapter 只有 execute_js()。"""
    fn = getattr(adapter, "js", None) or getattr(adapter, "execute_js", None)
    if fn is None:
        raise LoginInjectError("登录注入失败：适配器不支持 JS 执行（js/execute_js 均缺失）")
    return await fn(expr)


async def _get_url(adapter: Any) -> str:
    """获取当前页 URL。适配器有 read_text 但无 get_url；用 JS location.href。"""
    return str(await _run_js(adapter, "location.href") or "")


async def inject_token(adapter: Any, cfg: dict, token: str,
                       resolve_url) -> None:
    """goto 同源页 → 写 storage → reload → 复验。失败 raise LoginInjectError。"""
    inject = cfg.get("inject") or {}
    storage = inject.get("storage", "sessionStorage")
    key = inject.get("key", "satoken")
    value_template = inject.get("value_template", '{"satoken": "{token}"}')
    url = inject.get("url", "/login")
    reload = bool(inject.get("reload", True))

    # 绝对 URL 拼接（复用 engine resolve_step_url 的 project 模式）
    abs_url = resolve_url(url)
    if not abs_url or abs_url == url:
        raise LoginInjectError(
            f"登录注入失败：无法拼接注入页绝对 URL（url={url}，"
            "需 login.inject.url 为相对路由且 adapter 有 baseUrl）。")

    # 1. goto 注入页（幂等）
    try:
        await adapter.goto(abs_url)
        await adapter.wait_for_load()
    except Exception as e:
        raise LoginInjectError(f"登录注入失败：goto 注入页失败 ({abs_url}): {e}") from e

    # 2. 写 storage
    value = _fill_template(value_template, token)
    expr = _build_inject_js(storage, key, value)
    ok = await _run_js(adapter, expr)
    if not ok:
        raise LoginInjectError(
            f"登录注入失败：写 storage 失败（{storage}.setItem({key}, ...) 被拒绝）")

    # 3. reload（SPA 守卫读 storage 放行）
    if reload:
        try:
            await _run_js(adapter, "location.reload()")
            await adapter.wait_for_load()
        except Exception as e:
            raise LoginInjectError(f"登录注入失败：reload 后等待加载异常: {e}") from e

    # 4. 复验
    if not await is_logged_in(adapter, cfg):
        raise LoginInjectError(
            "登录注入失败：注入后仍处于未登录态（可能 value_template 结构不完整，"
            "缺 account/permissions 等字段，被前端守卫拦截）。")


# ── 会话准备入口 ─────────────────────────────────────────

async def ensure_login(adapter: Any, project_context: dict | None,
                       *, account: str = "", force: bool = False,
                       resolve_url=None, logger=None) -> dict:
    """会话准备入口。返回 action 供日志/结果展示。

    返回:
        {"action": "skip_no_config" | "skip_logged_in" | "inject",
         "account": str, "token_masked": str}
    """
    log = logger or logging.getLogger(__name__)
    cfg = load_login_config(project_context)
    if cfg is None:
        return {"action": "skip_no_config"}

    if resolve_url is None:
        raise LoginInjectError("登录注入失败：缺少 resolve_url 回调（engine 未传入）。")

    # 账号解析 + 白名单校验
    accounts = ((project_context or {}).get("adapter", {})
                .get("auth", {}).get("accounts") or [])
    account = account or cfg.get("account", "")
    if not account:
        raise LoginInjectError("登录注入失败：未配置 login.account 且未传 --login-account")
    usernames = {a.get("username") for a in accounts if a.get("username")}
    if usernames and account not in usernames:
        raise LoginInjectError(
            f"登录注入失败：账号 {account} 不在 auth.accounts 白名单"
            f"（可用: {', '.join(sorted(usernames))}）。拒绝注入任意用户名。")

    # 登录态校验（force=跳过校验强制重注入）
    if not force and await is_logged_in(adapter, cfg):
        # v2.5 P1：配置 verify.account_key 时比对当前账号——
        # 已登录但账号不符 → 视为未登录强制重注入本 run 账号（防并行串号）
        cur = await logged_account(adapter, cfg)
        if cur and account and cur != account:
            log.warning(
                f"已登录账号 {cur} ≠ 期望 {account}，强制重注入本 run 账号")
        elif not cur and account:
            # v2.6 页签治理（D5）：账号切换场景建议配置 account_key，
            # 未配置时无法自检账号，打 WARN 提示（不阻断，避免破坏存量项目）
            verify = (cfg.get("verify") or {})
            if not verify.get("account_key"):
                log.warning(
                    "未配置 login.verify.account_key，无法校验当前登录账号"
                    f"是否等于期望 {account}；如需账号切换自动重登，"
                    "请在 adapter.json 配置该字段")
        else:
            return {"action": "skip_logged_in", "account": account}

    token = await fetch_token(cfg, account)
    await inject_token(adapter, cfg, token, resolve_url)
    return {"action": "inject", "account": account,
            "token_masked": _mask(token)}
