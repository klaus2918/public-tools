# op-browser 页签治理（v2.6）— 专文

> 配套 SKILL.md「会话与页签生命周期」章节：生命周期细则、账号切换时序、
> 回收判定算法、清理命令语义、CDP 与 Bridge 双模式差异、兼容矩阵。
> 供排查与扩展引用。

## 1. 生命周期状态机

```
                    ┌────────────────────────────────────────────┐
                    │                                            ▼
 unknown ──创建──→ open ──run 结束──→ idle ──超保留期──→ reclaimable
                    │                  ▲                          │
                    │                  │                          │
                    │     复用/重登（run 开始）                   │
                    │                  └──────────────────────────┘
                    │                                        │ 被清理
                    ▼                                        ▼
                running ──异常/中断──→ (resumable, 永不回收)   gone
                    │
                    └──completed──→ idle（保留期后可回收）
```

| 状态 | 含义 | 回收资格 |
|------|------|---------|
| `unknown` | 注册表无记录（旧会话/用户手动/外部创建） | **永不自动回收**（防误伤） |
| `open` / `running` | run 执行中 | 永不回收 |
| `idle` | run 结束保留，可复用免重登 | 超保留期后进入 reclaimable |
| `reclaimable` | 空闲超阈值 | 自动回收 / `cleanup --idle` |
| `resumable` | 可接续 run 的会话（interrupted/新鲜 running） | **永不回收**（接续 A 档依赖） |
| `gone` | 已关闭 | — |

## 2. 会话注册表

文件：`tasks/sessions_index.json`（与 runs_index.json 同级；复用 task_store
文件锁 + 原子写，跨进程安全；损坏/缺失读取兜底 `[]`）。

每条记录字段：

```json
{
  "session_id": "uuid",
  "name": "任务A",
  "group_id": 3,
  "main_tab_id": "123",
  "account": "user1",
  "account_confirmed": true,
  "task": "任务A",
  "project": "demo-project",
  "status": "idle | running | reclaimable",
  "lease_run_id": "run-...-ab12",
  "resumable": false,
  "created_at": "...",
  "last_active_at": "..."
}
```

- `account`：最后已知登录账号（`ensure_login` 注入成功回填）。
- `account_confirmed`：true = 经登录注入确认（参与账号匹配）；
  false = 未确认/旧会话（按现状复用，复用后注入补确认）。
- `lease_run_id`：非空 = 并行/命名 run 的 `#r` 租约会话（一次性身份）。

## 3. 账号感知复用（仅限非 exclusive 顺序路径）

`session_decision(url, name, exclusive, account="", ...)` 候选排序：
`alive → accountMatch → originMatch → nameMatch`。

| 场景 | 决策 |
|------|------|
| `account=""` | 与 v2.5 完全一致（零变化） |
| 同账号（confirmed 且相等） | 复用（最高优先） |
| `account_confirmed=false` | 复用 + 复用后登录注入校正账号 |
| 异账号命中 main_tab | 复用 + `relogin_required=true`（同 tab 重登） |
| 异账号、mainTabId 不在 tabIds | 拒绝复用（`skipped_reason="account_mismatch_secondary_tab"`） |
| exclusive=True | 不引入账号维度（隔离红线） |

切换时序（复用 tab → 同 tab 重登 → 复验）：

```
复用候选会话（main_tab）
  → ensure_login(account=期望, force=True)
      ├─ force=True：跳过登录态校验，直接取新账号 token
      ├─ inject_token：goto 注入页（同 tab）→ 写 storage → reload → 复验
      └─ 复验失败 → LoginInjectError → run 诚实失败
  → 注册表更新：account=期望, account_confirmed=true, last_active_at=now
```

前置条件：项目配置 `login.verify.account_key`（未配置打 WARN，账号比对
不可用；配置后账号不符自动重登）。同源多 tab 共享 storage：重登会
改变同会话其他 tab 的登录态——故「异账号不把其他 tab 当作独立账号现场」。

## 4. 回收判定算法

```
可回收集合 = 注册表 status ∈ {idle, reclaimable}
             ∧ resumable != true
             ∧ lease_run_id 为空（租约会话仅显式清理）
             ∧ last_active_at 距今 ≥ OP_BROWSER_SESSION_RETENTION_SECONDS
             ∧ run_state 心跳不新鲜（关联 run 非 running/interrupted 新鲜期）
```

- 自动回收（`OP_BROWSER_AUTO_CLEANUP=true` 默认）：`run` 结束钩子
  `_post_run_gc` 触发，幂等，跳过当前 run 关联会话。
- 手动：`bridge cleanup --idle [--since <分钟>] [--account <账号>]
  [--exclude-running]`；`--all` 连存活一起清（二次确认）。
- 安全三闸：① 仅回收注册表有记录的引擎分组（unknown 跳过）；
  ② `--exclude-running` 默认 True（resumable/心跳新鲜跳过）；
  ③ `--dry-run` 预览 + 交互确认（非交互 EOF 默认取消）。

## 5. 清理命令语义表

| 命令 | 默认 | --idle | --all |
|------|------|--------|-------|
| `bridge cleanup` | 只清陈旧空壳（v2.5 语义不变） | + 清 reclaimable 存活分组 | 连存活一起清（需二次确认） |
| `bridge cleanup --since <分钟>` | 只动最后活跃 ≥ N 分钟的会话 | 同左 | 同左 |
| `bridge cleanup --account <账号>` | 只动指定账号会话 | 同左 | 同左 |
| `bridge cleanup --exclude-running` | 默认 True（resumable/心跳新鲜跳过） | 同左 | 同左 |

## 6. CDP 与 Bridge 双模式差异

| 维度 | CDP | Bridge |
|------|-----|--------|
| 会话概念 | 无分组，`_context.pages` | Chrome tab group + session 元数据 |
| 单页签 | 天然成立（顺序模式复用 `ctxs[0].pages[0]`，goto 不换 tab） | 引擎不主动 new_tab；`--multi-tab` 显式 |
| 回收 | isolated（`_owns_page`）tab 由本 client close；**顺序模式复用的用户页面永不关闭**（红线） | run 后保留期自动回收 / cleanup |
| 账号 | 无注册表；`verify.account_key` 比对兜底 | 注册表 account 维度 |
| 注册表 | CDP 无 session 概念，不写注册表 | 每次 run 回填 |

## 7. 兼容矩阵（v2.5 → v2.6）

| 场景 | v2.5 | v2.6（默认参数） | 变化 |
|------|------|------------------|------|
| 顺序 run，无登录项目 | origin/name 复用 | 完全相同 | 无 |
| 顺序 run，同账号 | 复用（可能未察觉串号） | 复用 + 账号匹配确认 | 更优 |
| 顺序 run，异账号 | 复用同一会话（未检测） | 复用 main_tab + force 重登 | 更优（行为变化，需回归） |
| 并行 taskset | lease + exclusive strict | 完全相同（不引入账号维度） | 无 |
| resume | session_id 直连 + strict 兜底 | 相同 + 注册表标记 resumable | 无 |
| `cleanup` 无参数 | 只清 stale | 只清 stale（--idle 才清空闲） | 无 |
| `groups` 无参数 | 基础列 | 新增 acct/status/reclaimable 列 + --json | 输出变化 |
| `new_tab(url)` | 开新 tab | 开新 tab（行为不变） | 无 |

## 8. 验收清单（GREEN 实测）

1. 默认参数四路径零回归：顺序同账号 / 无登录 / taskset 并行 / run --resume。
2. 账号感知：注册表 account=A → `--login-account B` 顺序 run →
   同 sessionId、main_tab_id 不变、token 为 B、复验通过、注册表 account=B。
3. 异账号异 tab 兜底：mainTabId 不在 tabIds 时拒绝（skipped_reason 命中）。
4. 回收安全：retention=0 时 idle 立即可回收；running/resumable/unknown 永不回收。
5. 并行隔离回归：A/B `#r` 身份各自独立、同源不复用、互不串线。
6. 文件安全：注册表跨进程并发写不丢记录；损坏读取兜底 []。
7. 编码：改动文件 validate-text 通过（UTF-8 无 BOM、无 U+FFFD）。
