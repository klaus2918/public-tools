# CDP 适配器详细规范

> 本文档是 op-browser CDP 适配器的完整技术规范，SKILL.md 的补充文档。

---

## Python API（CDP 相关）

### 基本用法

```python
from op_browser import SmartBrowser

browser = SmartBrowser()
result = await browser.run("收文提取")
if not result.success:
    # run 失败：诚实报告，不假装自动修复
    print(result.error)
```

### v2 项目上下文

```python
browser = SmartBrowser()
result = await browser.run(
    "收文登记测试",
    project="demo-project",
    system="demo-project-pc",
    module="incoming-doc",
)
# 自动加载 projects/demo-project/systems/demo-project-pc/_shared/adapter.json
```

**脚本内 `project` 变量**：CDP 脚本（script.py）执行时，引擎把 `resolve_case` 结果注入命名空间为
`project` 变量（含 `adapter` 配置：baseUrl/fe_base_prefix/routes/buttonAliases 等），
脚本可据此消费项目配置；未传 project/system/module 时为 `{}`，脚本需自行容错。

### 多任务编排

```python
results = await browser.taskset(["任务A", "任务B"], sequential=True)
```

### BrowserResult v2

```python
result.success      # True / False  ← 综合判定
result.data         # extracted data (dict | list) ← 业务数据
result.judge        # "pass" / "warn" / "fail" ← 校验判定
result.verify_mode  # "screenshot" / "dom" / "none" ← 当前使用的校验模式（v2.7）
result.diff_rate    # pixel diff vs baseline（仅 screenshot 模式有效）
result.adapter      # "cdp" / "bridge"
result.a11y_tree    # accessibility tree（仅 Bridge 分支填充）
result.extra["step_checks"]  # 逐步校验明细 [{step, judge, diff_rate}]（screenshot 模式）
result.extra["dom_checks"]   # DOM 校验明细 [{check, type, found, expected, passed}]（dom 模式，v2.7）
```

---

## 锚点系统（v2）

**优先级：** a11y → text → structure → layout → screenshot

flow.json 字段：
- `anchor_priority`: 锚点优先级列表
- `anchor_primary`: 主锚点（a11y role+name+ref）
- `fallback_anchors`: fallback 链（text/XPath/CSS/layout）
- `action_detail`: 可回放动作细节（click/input + selector，供 Bridge 回放/CDP 填值）

跨适配器执行时，CDP run 跳过 a11y 锚点走 fallback 链。

**action_detail schema（v2.4 定稿，Bridge 回放消费）**：`action_detail` 为动作列表，
每项 `{type, ref, selector, role, name, text, key, desc}`。兼容键 `action`（列表）同样识别。
动作类型与定位优先级：

| type | 定位优先级 | 说明 |
|---|---|---|
| `click` | ref → selector → role+name | ref 免疫中文编码；缺定位信息报错 |
| `fill` | selector → role+name | 填值，text 支持 `${ENV:VAR}` 占位（脚本侧展开） |
| `type` | — | 键盘输入文本（computer.type） |
| `key` | — | 按键（computer.key），如 `Enter` |

解析失败（未知 type/字段错误）→ 诚实报错不静默跳过；执行失败（元素未找到）→
记 warn 不阻断，由截图判据兜底。旧 flow 无 `action_detail` 时维持 goto-only。

**步骤 URL 解析（opt-in）**：flow.json 顶层声明 `url_resolution: project` 后，
相对 URL（如 `/login`）用项目 adapter 的 baseUrl(+fe_base_prefix) 拼接；
绝对 URL 或未声明时维持原样（向后兼容）。项目根可经 `OP_BROWSER_PROJECTS_DIR`
环境变量指定，未设置时回退当前工作目录 `projects/`。

---

## Task Storage

任务存放在 `tasks/`（可由 TASKS_DIR 环境变量覆盖）：

```
tasks/<task-name>/
├── task.json           # metadata
├── flow.json           # anchor sequence（v2: a11y 优先 + action_detail）
├── script.py           # CDP deterministic script
├── baselines/          # baseline screenshots（v2: 每步独立）
└── logs/               # daily run logs

tasks/runs/<run_id>/    # v2.5: 一次测试运行的产物命名空间（并行/归档/接续）
├── meta.json           # run 元数据（任务名/adapter/judge/project 上下文）
├── result.json         # BrowserResult 序列化（judge/diff_rate/data/extra）
├── run_state.json      # 断点状态（next_step/heartbeat/step_checks，接续依据）
├── run.log             # 本 run 全量日志（并行双写，不交错）
└── shots/              # step_XX.png / final.png
```

> **资产来源**：v2.4 起引擎不再生成 flow/script（explore 已移除）。
> 任务资产由项目资产库（projects/ 下的模块）或外部工具准备，
> 引擎只负责确定性回放与校验。任务状态非 ready 时 run 会明确报错，
> 不会假装成功。

---

## 并发契约（v2.5）

### 支持范围（哪些并行安全）
- **文件层（跨进程，Windows）**：task.json/flow.json/script.py/baselines 原子写
  （同目录临时文件 + os.replace）+ 文件锁（msvcrt.locking，锁文件常驻防 ABA）；
  `update_task` 跨进程读-改-写安全；计数增量用 `inc_run_count`（锁内读-加-写）
- **test 结果**：按 run_id 分文件（`runs/<run_id>/result.json`），互不覆盖；
  查询「最新」（runs/ 时间序优先，回退旧 `_test_results.json`）与「指定 run」
- **日志**：taskset.log / 每日日志行级互斥，跨进程不交错；编排日志可按 run_id 分文件
- **截图**：run_id 场景落 `runs/<run_id>/shots/`（step_XX.png / final.png），
  双适配器统一 `out_path` 契约
- **并行编排（taskset --parallel / sequential=False）**：每个任务自动 run_id，
  产物隔离；Bridge 每 run 独立适配器实例 + 会话名 `{任务名}#r{短标识}` +
  exclusive 全等匹配（同源站点不复用对方新建分组）；CDP 独立标签页
- **配置/判定**：环境变量运行时生效（按测试切换 headless/CDP_URL）；
  Bridge 可用性每次 run 独立判定（无 30s 残留）
- **进程内缓存**：_TASK_CACHE 线程安全（LRU/mtime 语义不变）

### 限制（哪些不可并行）
- **同源不同账号请勿并行**：Bridge 同一 Chrome 实例下同源页面共享 storage/cookie，
  分组/tab 隔离保证操作句柄隔离，但登录态天然共享。相同账号无串线风险；
  配置 `verify.account_key` 后 `ensure_login` 会对"已登录账号 ≠ 期望账号"
  强制重注入（默认未配置 → 不启用）
- **同一任务名并行 run**：task.json 计数安全（文件锁），但任务资产
  （flow/script/baselines）的并发固化（写）不保证语义一致，固化与回放应错开
- **CDP 自动发现并行**：未指定 BROWSER_CDP_URL 时可能 attach 同一浏览器，
  并行场景应各自指定独立浏览器或依赖 isolated 标签页隔离
- **跨进程锁仅保证于 Windows**（msvcrt）；其他平台退化为进程内锁

### 接续与恢复（v2.5 2R2，三档语义）
| 档位 | 语义 | 入口 |
|------|------|------|
| A 会话级 | 复用已有 Bridge 分组/tab，免重新登录 | `find_or_create_session`（会话名带 `#r{短标识}` + strict 全等，A/B 各自接续不串线） |
| B 任务级 | 从中断步骤续跑，跳过已完成步骤，断点前校验保留 | `run --resume`（run_state.next_step 断点 + flow 指纹防呆） |
| C run 级 | 复用同一 runs/<run_id>/ 命名空间继续追加 | `run --run-id X --resume`（缺省取最近可恢复 run） |

```bash
# 中断后接续（会话级 + 任务级 + run 级一次性完成）
/op-browser run 任务A --resume            # 缺省 run_id = 最近可恢复 run
/op-browser run 任务A --resume --run-id run-20260814-125000-ab12
/op-browser run 任务A --resume --force    # failed 强制续跑；completed 无剩余步骤时
                                          # force 仍会报「无可续步骤」（诚实拒绝）
/op-browser run status [--task 任务A]     # 列出可恢复 run（stale 判定 = 心跳 >10min）
```

**限制**：CDP 接续为尽力续跑（新浏览器无页面状态，脚本经 `resume_ctx={"next_step": N}`
自行决定跳过前置步骤，默认建议直接重跑）；中断后 flow.json 资产变更会被指纹校验拒绝接续。

### 使用示例
```python
# Python API：并行编排（自动 run_id，产物隔离）
results = await browser.taskset(["任务A", "任务B"], sequential=False,
                                adapter="bridge", allow_new=True)
# Python API：接续
result = await browser.run("任务A", resume=True)
```

> 锁文件 `*.lock` 与目标文件同目录常驻（永不删除，防 ABA），体积 <10B，不经 git；
> 旧位置 `_test_results.json` / `taskset.log` 仍被无 run_id 调用方使用（兼容层，不删除）。

---

## 引擎缓存说明（v2.4.2）

### 性能提升

| 场景 | 优化前 | 优化后 |
|------|--------|--------|
| 重复 run 同项目 | 每次磁盘扫描 + YAML 解析（~30-50ms） | project_context 缓存命中（~0ms） |
| 重复 run 同任务 | 每次读 task.json + flow.json + script.py（3 次磁盘 I/O） | 文件缓存命中（mtime 未变，~0ms） |

### 关键改动

- `engine.py`：`SmartBrowser._load_project_context()` 实例级缓存 `(project, system, module)` → ctx；`invalidate_project_cache()` 清空
- `task_store.py`：`load_task/load_flow/load_script` 走内存缓存（key=(name, kind)，value=(结果, mtime)）；mtime 变化自动失效；容量上限 16 LRU；`save_task/save_flow/save_script/update_task/delete_task/rename_task` 写后失效；`invalidate_cache(name="")` 公开失效入口

### 用法

```python
from op_browser import SmartBrowser
b = SmartBrowser()
# 项目文件变更后清缓存（否则同 session 内复用旧上下文）
b.invalidate_project_cache()
# 任务文件外部修改后自动 mtime 失效，无需手动处理；批量刷新可调：
from op_browser import task_store
task_store.invalidate_cache()  # 清空全部任务文件缓存
```

> 缓存全部为进程内内存缓存，无持久化、无外部依赖；读路径零失效风险（mtime 校验），写路径显式失效。

---

## CDP 相关 Red Flags

| Smell | Action |
|-------|--------|
| Hard-coded x/y coordinates in script | Use anchor system; coordinates drift |
| Run fails → fake success | 诚实报告错误；无 flow/script 时明确报"任务未固化" |
| Baseline screenshots missing | Task is not complete without baselines |
| Tasks directory exposed in git | Add `tasks/` to `.gitignore` |
| 沿用旧锚点优先级（text 最优先） | v2 锚点改为 `a11y → text → structure → layout → screenshot` |
| 未用 project/system/module 上下文 | v2 支持项目化管理，传参后自动加载 adapter.json |
| 适配器混用导致定位不一致 | run 在 Bridge/CDP 间切换时需确保 fallback 锚点稳定 |
| 引入 LLM/API Key 依赖 | v2.4 明确零外部 Key；需要 AI 探索时用外部工具生成 flow 资产，再交给本引擎回放 |

---

## CDP 相关 Common Mistakes

- **任务未固化就 run。** 没有 flow.json/script.py 的任务 run 会明确报错；先准备任务资产（外部固化）再回放。
- **Run 失败却假装成功。** v2.4 无 AI 自愈，失败必须诚实报告并给出可执行提示。
- **Hardcoded coordinates.** Use anchor system (a11y → text → structure → layout → screenshot).
- **未使用 project/system/module 上下文.** v2 支持三层项目管理——传参后自动加载 adapter.json，减少手动配置。
