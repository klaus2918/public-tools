# op-knowledge 配置指南

## 概述

本文档说明 op-knowledge 多知识库配置（`knowledge-bases.yaml`）的配置项含义和使用方式。

配置分两层：

| 层 | 文件 | 位置 | 是否随包 |
|----|------|------|---------|
| 模板 | `knowledge-bases.example.yaml` | `skills/op-knowledge/references/` | 是（含占位路径） |
| 真实 | `knowledge-bases.yaml` | `skills/op-knowledge/config/`（挂载点 → `.basic/evolved/op-knowledge/config/`） | 否（本机环境配置） |

> **环境配置不打包原则**：知识库绝对路径属个人环境配置，只写真实配置（evolved 挂载点），
> 不进入 op 体系 zip 包。op-skills 仓库内仅保留模板（example）。

## 配置项说明

### knowledge_bases（多库数组）

每个知识库一项：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `id` | string | 是 | 库唯一标识（如 think-source） |
| `name` | string | 是 | 库显示名 |
| `path` | string | 是 | 知识库根目录绝对路径。op-done Step 2 执行时切换到该目录 |
| `target_categories` | string[] | 是 | 目标分类目录列表，按优先级匹配 |
| `template_path` | string | 是 | 原始素材写入目录 |

### default

默认知识库 id。op-done Step 2 未指定库时使用 `default` 指定的库。

### category_mapping

变更类型 → 目标分类目录的映射。配置变更需调整此映射：

```yaml
category_mapping:
  skill_change: "02-分类/proj-op-skills"    # skill 变更
  business_feature: "02-分类/024-实践总结"   # 业务功能变更
  config_change: "02-分类/026-工作方法"       # 配置变更
  hotfix: "02-分类/027-技术收集"             # hotfix
```

### precipitation_types

可复用沉淀的类型清单，用于 Step 2 采集环节识别变更产出。

### git

知识库 git 自动提交配置（对应 op-knowledge SKILL.md 第八章）：

| 字段 | 说明 |
|------|------|
| `enabled` | 知识库根目录须为 git 仓库 |
| `commit_message` | 提交信息格式 `<type>(<scope>): 【中文标签】<title> @AI G` |
| `add_per_file` | 每次写文件后立即 git add |
| `status_check` | 流水线结束后 git status 确认干净 |

## 首次使用引导

真实配置不存在时，用模板引导：

1. 询问用户知识库路径（支持多个，逐个添加）
2. 校验：目录存在？是 git 仓库？
3. 探测 `02-分类/` 下目录，生成 category_mapping 草案
4. 用户确认 → 写入 `skills/op-knowledge/config/knowledge-bases.yaml`（挂载点 → `.basic/evolved/op-knowledge/config/`）
5. 进入正常流水线

## 故障排查

| 问题 | 原因 | 解决 |
|------|------|------|
| 知识库路径不存在 | 默认库 `path` 配置错误 | 检查路径是否存在、是否可读 |
| 分类目录不存在 | `category_mapping` 指向的目录未创建 | 先手动在知识库中创建目录 |
| 真实配置缺失 | 未做首次引导 | 按「首次使用引导」流程创建 |
| op-knowledge 未生效 | skill 未同步 | `sync-skills.ps1` 建链后 `-Status` 校验 |
