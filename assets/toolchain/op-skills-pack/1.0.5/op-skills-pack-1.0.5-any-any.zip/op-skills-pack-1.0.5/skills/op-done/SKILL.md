---
name: op-done
category: core
status: active
phase_role: done
description: 验收阶段 skill。人工确认结果、知识沉淀、清理噪音、确认提交、归档。独立 5 步流程：验收 → 知识沉淀 → 清理 → 提交 → 归档。G6 事后审视为核心步骤。
version: "5.1.0"
updated_at: 2026-09-14
dispatches:
  - safe-git-write
  - op-html
  - op-design-extract
---

# op-done — 验收阶段 Skill

## Overview

人工确认执行结果 → 知识沉淀 → 清理噪音 → 确认提交 → 归档。不修改实现代码。

---

## Quick Reference

| Command | Action |
|---------|--------|
| `/op-done [<change>]` | 启动或恢复收工流程 |
| `/op-done status [<change>]` | 查看收工待办 |

---

## Core Flow

### 1. 人工验收确认

- **先询问如何查看验收材料**（至少提供以下选项，用户可指定任意方式）：
  1. 打开文件（tasks.md / verify-log.md 直接打开 / 打开目录）
  2. 摘要展示（对话中展示完成情况与验证结果摘要）
  3. HTML 渲染打开
  4. 用户指定任意方式
- 用户确认已查阅后，人确认通过 / 退回 build
- 退回时：说明原因，phase 回退到 build

**必须确认，不确认不继续。**

### 2. 知识沉淀（G6 事后审视）

#### 2a. 事后审视（Agent 自动，不打扰人）

1. **假设验证回顾**：回顾 plan.md「方案自检」中的假设，哪些被验证、哪些被推翻
2. **设计树闭合**：关键决策点是否在实现中实际执行
3. **验证结果总结**：读取 verify-log.md，记录每条验证结果
4. **域语言闭环**：术语是否在实现代码中一致使用
5. **偏离记录**：实际实现与方案之间的偏差及原因

结果写入 archive-summary.md「事后审视」章节。

#### 2b. 知识库更新（op-knowledge）

> 知识库配置缺失时，按 op-knowledge「消费方接入协议」询问用户（引导配置 / 本次跳过），**禁止静默跳过**。

按 change.yaml.type 决定粒度：

| 类型 | 知识库沉淀 |
|------|-----------|
| hotfix | 简化：仅记录修复点 |
| tweak | 简化：记录调整内容 |
| feature | 完整：可复用能力+决策+经验 |
| complex | 完整：含架构决策和模式沉淀 |

**执行步骤**（详见 `references/op-knowledge-guide.md`「op-done 调用实操步骤」）：

1. 读 op-knowledge 的 `config/knowledge-bases.yaml`（skill 内挂载点）确定默认库与路径
2. 按 `category_mapping` 查 `change.yaml.type` 确定目标分类目录
3. 从变更上下文提取素材，生成 `<日期>-<变更名>.md` 写入分类目录
4. 更新 `<库根>/时间线.md` 追加条目
5. 在知识库仓库 `git add` + `git commit`（按库内提交风格）
6. `git status` 确认干净

#### 2c. 设计资产沉淀（op-design-extract 按需）

feature/complex 变更评估是否有可复用设计契约：

1. 查询：`/op-design-extract query-tags --type=<type> --domain=<域>`（type=database/frontend/api 等）
2. 有命中 → 评估是否沉淀新标签或更新已有资产
3. 无命中 → 跳过，不强制

### 3. 清理噪音

> 详细规则与报告模板见 `references/cleanup-checklist.md`。

按检查清单逐项判定（核心原则：**只删过程噪音，不删交付证据**）：

- **保留**：交付材料（SQL/配置/迁移脚本）、方案文档（plan.md）、验证记录、tasks.md、change.yaml
- **删除**：临时脚本（`tmp_*`）、调试日志（`*.log`）、中间产物（`.bak`）、无效截图、编辑器临时文件
- **不确定**：保留，标注「待人工确认」

输出 `cleanup-report.md`（保留 / 删除 / 待确认清单 + 统计）。

### 3.5 运行时资产

归档配置与知识库连接配置写入 skill 内 `config/`（junction 挂载点，实际存于 `.basic/evolved/<skill>/config/`）：**不入 git、不随包分发**；skill 目录内不存环境配置。

### 4. 确认提交（人工授权）

- **先询问如何查看提交内容**（单文件打开 / 多文件打开目录 / 对话摘要 / HTML / 用户指定任意方式）
- 用户确认已查阅后，人确认提交信息和文件
- 人授权 commit（safe-git-write）
- allow_push: true 时才可 push（需单独确认）

**执行约束延续**：
- `allow_commit: false` → 仅展示提交信息，用户授权后才提交
- `allow_commit: true` → 按约束允许提交
- `allow_push: true` → push 需单独确认（默认禁止）

### 5. 归档

- 生成 archive.json + archive-summary.md
- phase = archive
- **物理移出**变更目录至 `.op/archive/YYYY/MM/<change-name>/`
- **不往 index.json 写 archived 摘要**（保持主索引纯进行态）；如 index.json 已有 archived 条目，一并清除

---

## 人工确认点（3 个）

| 确认点 | 位置 | 默认行为 |
|--------|------|----------|
| 结果验收 | 步骤 1 | 必须确认，不确认不继续 |
| 提交确认 | 步骤 4 | 展示信息+文件，人确认后才提交 |
| Git 授权 | 步骤 4 | commit 必须人工授权 |

---

## 归档产物

| 产物 | 说明 |
|------|------|
| archive.json | 结构化元数据 |
| archive-summary.md | 人类可读摘要（含 G6 事后审视） |
| cleanup-report.md | 清理报告 |
| verify-log.md | 验证日志（从 op-build 继承） |
| 执行产物（SQL 等交付材料） | 保留随归档（与 plan.md 平级的任务目录产物） |
| 归档位置 | 物理移出至 `.op/archive/YYYY/MM/<change-name>/` |
| index.json | **不写 archived 摘要**；如已有 archived 条目须清除（保持纯进行态） |
| phase = archive | 状态更新 |

---

## 恢复机制

中断恢复靠：
1. archive.json 是否已生成（已生成则跳过已完成步骤）
2. cleanup-report.md 是否存在
3. 知识库时间线是否已更新（检查 `<库根>/时间线.md` 最新条目日期）

---

## Red Flags — STOP

| Smell | Action |
|-------|--------|
| Incomplete build tasks (done_count < total_count) | Refuse; complete build first |
| User asks to skip archive | Explain archive is mandatory |
| 提交流程中未通过 safe-git-write | 拒绝；强制走 safe-git-write |
| 确认前未询问查看方式就直接要求确认 | STOP：先询问如何查看（打开文件/摘要/HTML/用户指定），用户确认已查阅后再进入确认 |

---

## Common Mistakes

- **Skipping archive metadata.** Every completion produces archive.json.
- **归档时往 index.json 写 archived 摘要。** index.json 只保留进行态；归档查询走 `.op/archive/` 目录扫描（已有 archived 条目须清除）。
- **Modifying implementation code.** op-done is read-only for source.
- **Auto-push.** Never push without user confirmation.
- **确认前不问查看方式。** 验收与提交两处都要先问「如何查看」，再请用户确认。
- **删除交付证据。** 清理只删过程噪音（`tmp_*`/`*.log`/`.bak`/无效截图），交付材料与验证记录一律保留。

---

### 归档汇总引用 ADR

- 归档前读取变更目录下的 `decisions.md`（轻量 ADR；格式见 `op-plan/references/adr-convention.md`）；
- 将 ADR 列表（编号 + 决策一句话）汇总进 `archive-summary.md` 的「关键决策」小节，供后续变更检索引用；
- 无 `decisions.md` 时不报错，记录「本变更无跨变更决策」即可。

## Version

| Field | Value |
|-------|-------|
| Skill | op-done |
| Version | 5.1.0 |
| Updated | 2026-09-14 |
| Key change | v5.1.0: 归档汇总引用 decisions.md 的 ADR 列表；v5.0.0: 知识沉淀补实操 6 步、清理噪音补检查清单（`cleanup-checklist.md`）、设计资产补 `query-tags` 调用命令、修复 References 悬空引用；v4.3.0: 归档改为物理移出且**不写 index.json 摘要**（主索引纯进行态）；v4.2.0: 运行时资产规则（`config/` 归位 evolved 挂载点，不入 git） |
| References | `references/op-knowledge-guide.md`（知识沉淀实操）· `references/op-knowledge-integration.md`（流水线规范）· `references/cleanup-checklist.md`（清理检查清单）· `references/archive-template.md`（归档模板）· `references/git-cheatsheet.md`（git 操作参考）· `references/pause-reference.md`（暂停语义参考） |
