# 清理检查清单（cleanup-checklist）

> 用途：op-done §3「清理噪音」的逐项判定依据与报告模板。
> 核心原则：**只删过程噪音，不删交付证据**；不确定的一律保留并标注「待人工确认」。

---

## 1. 判定总表

| 类别 | 处置 | 典型对象 |
|------|------|---------|
| **交付材料** | 保留（随变更归档） | SQL 脚本、数据迁移脚本、配置变更脚本、校验基线、对账报告 |
| **方案与记录** | 保留 | `change.yaml`、`plan.md`、`tasks.md`、`verify-log.md`、`expert-review.md`、`autonomous-checklist.md` |
| **归档材料** | 保留 | `archive.json`、`archive-summary.md`、`cleanup-report.md` |
| **临时脚本** | 删除 | `tmp_*.py`、`_probe_*`、`scratch_*`、一次性探针（`_m3_*`） |
| **调试日志** | 删除 | `*.log`、`*.stackdump`、`*.out`、`*.lock` |
| **中间产物** | 删除 | `*.bak`、`*.bak-*`、`*.orig`、`*.rej`、`*.tmp` |
| **无效截图** | 删除 | 失败/空白截图、`shots/` 中的一次性产物（保留验收证据截图） |
| **编辑器临时文件** | 删除 | `*~`、`*.swp`、`*.swo`、`.DS_Store`、`Thumbs.db`、`desktop.ini` |
| **运行资产** | 保留在挂载点，不入 git | `.basic/evolved/<skill>/**`（站点、任务、项目、配置） |
| **不确定对象** | 保留 + 标注 | 用途不明但可能被引用的文件 |

---

## 2. 检查项（逐项打勾）

| # | 检查项 | 命令/证据 | 结果 |
|---|--------|----------|------|
| 1 | 变更目录内临时脚本已清理 | `ls .op/changes/<name>/` 无 `tmp_*`/`scratch_*` | |
| 2 | 仓库内临时文件残留 | `content-check 7.7`（skill 目录 tmp/log 防线） | |
| 3 | 探针脚本未被跟踪 | `content-check 7.10`（探针命名约定） | |
| 4 | 无被跟踪的日志/中间产物 | `git ls-files` 后按扩展名过滤（log/bak/orig/rej/tmp） | |
| 5 | 交付材料已归位 | 交付材料在 `.op/changes/<name>/`，未散落项目根/代码目录 | |
| 6 | 运行资产未入库 | `op-000-isolation-check.sh` 的 L2/L3 段（PASS） | |
| 7 | 敏感文件未被跟踪 | `content-check 7.14` + `git status` 无 `.sensitive-terms*`、`*.local.*`、`config.yaml` | |
| 8 | 无打包产物入库 | `content-check 7.16`（zip 防线） | |

---

## 3. 报告模板（`cleanup-report.md`）

```markdown
# 清理报告：<变更名>

- 执行时间：<ISO 时间戳>
- 检查清单版本：cleanup-checklist v1.0

## 一、保留（交付证据）
| 对象 | 类型 | 原因 |
|------|------|------|
| `.op/changes/<name>/xxx.sql` | 交付材料 | 随归档保留 |

## 二、删除（过程噪音）
| 对象 | 类型 | 依据 |
|------|------|------|
| `tmp_probe.py` | 临时脚本 | 清单 §1 |

## 三、待人工确认
| 对象 | 疑虑 | 处理 |
|------|------|------|
| `xxx.json` | 用途不明 | 保留待确认 |

## 四、统计
- 保留 N 项 / 删除 M 项 / 待确认 K 项
- 校验证据：content-check 7.7 / 7.10 / 7.14 / 7.16 结果
```

---

## 4. 禁止事项

- 禁止删除交付材料、方案文档、验证记录、归档材料（属交付证据）。
- 禁止删除 `.basic/evolved/` 下的运行资产（属本地数据，交由用户处理）。
- 禁止以「清理」为名执行 `git rm` 已跟踪的正式资产；如确需解除跟踪，先经用户确认并保留文件。
- 清理前后均不得执行 `--no-verify` 等绕过参数（与 safe-git-write 约束一致）。
