#!/bin/bash
# integrate.sh — op-design-extract v4.0 整合入口
# 吸收外部工作流到 op 体系，如 my-workflow-dev 等
# 用法：integrate.sh --source=<path|url|skill-name> --target=<project-slug> --type=<type> [--diff-only]
# 产物：.op/changes/<change-id>/design-integrate/ 下 integrate-report.md / conflict-report.md（冲突时）

set -euo pipefail

DESIGN_EXTRACT_DIR="$(cd "$(dirname "$0")/.." && pwd)"

# 解析参数
SOURCE=""
TARGET=""
TYPE=""
DIFF_ONLY=false

for arg in "$@"; do
  case "$arg" in
    --source=*)   SOURCE="${arg#*=}" ;;
    --target=*)   TARGET="${arg#*=}" ;;
    --type=*)     TYPE="${arg#*=}" ;;
    --diff-only)  DIFF_ONLY=true ;;
  esac
done

if [ -z "$SOURCE" ] || [ -z "$TARGET" ] || [ -z "$TYPE" ]; then
  echo "错误：--source、--target、--type 均为必填"
  echo "用法：integrate.sh --source=<path|url|skill> --target=<project> --type=<type> [--diff-only]"
  exit 1
fi

echo "🔗 op-design-extract integrate — 外部工作流整合"
echo "来源：$SOURCE"
echo "目标项目：$TARGET"
echo "类型：$TYPE"
echo "模式：$([ "$DIFF_ONLY" = true ] && echo "差异对比（不写入）" || echo "完整整合")"

# 识别外部源类型
if [ -f "$SOURCE/SKILL.md" ]; then
  echo "📦 检测为 skill 目录：$SOURCE"
  EXTERNAL_TYPE="skill"
elif [ -d "$SOURCE" ]; then
  echo "📁 检测为目录：$SOURCE"
  EXTERNAL_TYPE="directory"
else
  echo "📄 检测为 URL/路径：$SOURCE"
  EXTERNAL_TYPE="other"
fi

# 探测 python
PY_CMD=""
for c in py python3 python; do
  if command -v "$c" >/dev/null 2>&1; then
    if "$c" -c 'import json' >/dev/null 2>&1; then
      PY_CMD="$c"
      break
    fi
  fi
done
if [ -z "$PY_CMD" ]; then
  echo "错误：未找到可用 python（py/python3/python）" >&2
  exit 1
fi

# 生成 change-id（时间戳）与产物目录
CHANGE_ID="integrate-$(date +%Y%m%d-%H%M%S)"
OUT_DIR="$DESIGN_EXTRACT_DIR/../.op/changes/$CHANGE_ID/design-integrate"
mkdir -p "$OUT_DIR"

# MSYS 路径转换
WIN_SOURCE=$(cygpath -w "$SOURCE" 2>/dev/null || echo "$SOURCE")
WIN_SHARED=$(cygpath -w "$DESIGN_EXTRACT_DIR/shared" 2>/dev/null || echo "$DESIGN_EXTRACT_DIR/shared")
WIN_OUT=$(cygpath -w "$OUT_DIR" 2>/dev/null || echo "$OUT_DIR")

# 核心逻辑：收集外部资产 → 对比现有 → 生成报告（--diff-only 不写入目标）
"$PY_CMD" - "$WIN_SOURCE" "$WIN_SHARED" "$WIN_OUT" "$TARGET" "$TYPE" "$EXTERNAL_TYPE" "$DIFF_ONLY" <<'PYEOF'
import json, os, sys, shutil
from pathlib import Path
from datetime import datetime

src, shared_dir, out_dir, target, ftype, ext_type, diff_only = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6], sys.argv[7].lower() == 'true'
src_p, shared_p, out_p = Path(src), Path(shared_dir), Path(out_dir)
target_dir = shared_p / target / ftype
now = datetime.now().strftime('%Y-%m-%d %H:%M')

# 1. 收集外部源中的设计资产文件（md/json；类型由 --type 参数决定，不做路径关键词推断）
ext_assets = []
if ext_type in ('skill', 'directory') and src_p.exists():
    for f in src_p.rglob('*'):
        if f.is_file() and f.suffix in ('.md', '.json'):
            parts = f.parts
            if any(p.startswith('.') and p != '.' for p in parts):
                continue  # 跳过隐藏目录
            rel = f.relative_to(src_p).as_posix()
            ext_assets.append((rel, f))
ext_assets.sort()

# 2. 对比现有资产：新增 / 冲突 / 合并
target_files = {}
if target_dir.exists():
    for f in target_dir.rglob('*'):
        if f.is_file():
            target_files[f.name] = f

added, conflict, merged = [], [], []
for rel, f in ext_assets:
    fname = f.name
    if fname in target_files:
        # 同名：内容不同 → 冲突；相同 → 合并
        if target_files[fname].read_bytes() == f.read_bytes():
            merged.append((rel, fname))
        else:
            conflict.append((rel, fname))
    else:
        added.append((rel, fname))

# 3. 写入资产（非 diff-only）
if not diff_only and ext_type in ('skill', 'directory') and src_p.exists():
    target_dir.mkdir(parents=True, exist_ok=True)
    for rel, f in ext_assets:
        dest = target_dir / f.name
        shutil.copy2(f, dest)
    print(f'已写入 {len(added)} 个新增资产到 {target_dir}')
elif diff_only:
    print('差异对比模式：未写入目标目录')

# 4. 生成整合报告
report = f"""# 外部工作流整合报告

> 整合时间：{now}
> 来源：{src}
> 目标项目：{target}
> 类型：{ftype}

## 1. 整合摘要

| 维度 | 统计 |
|------|------|
| 扫描外部资产 | {len(ext_assets)} |
| 新增资产 | {len(added)} |
| 冲突资产 | {len(conflict)} |
| 合并资产 | {len(merged)} |
| 写入模式 | {'差异对比（未写入）' if diff_only else '完整整合'} |

## 2. 新增资产清单

| # | 资产名 | 目标路径 | 说明 |
|---|--------|----------|------|
"""
for i, (rel, fname) in enumerate(added, 1):
    report += f"| {i} | {fname} | {target}/{ftype}/{fname} | 来自 {rel} |\n"

report += f"""
## 3. 冲突资产清单

| # | 资产名 | 外部值 | 现有值 | 建议处理 |
|---|--------|--------|--------|----------|
"""
if conflict:
    for i, (rel, fname) in enumerate(conflict, 1):
        report += f"| {i} | {fname} | {rel}（外部） | {target}/{ftype}/{fname}（现有） | 保留外部/保留现有/手动合并 |\n"
else:
    report += "| - | （无冲突） | - | - | - |\n"

report += f"""
## 4. 标签更新建议

```yaml
tags:
  - key: <key>
    type: {ftype}
    domain: <domain>
    tech: [<tech>]
    reuse: project
```

## 5. 下一步操作

- [ ] 确认标签更新（更新 shared/{target}/tags.yaml）
- [ ] 运行 tag-index.sh 重建索引
- [ ] 验证整合后的设计资产
"""
(Path(out_dir) / 'integrate-report.md').write_text(report, encoding='utf-8')

# 5. 冲突时生成冲突报告
if conflict:
    conf = f"""# 设计规范冲突报告

> 整合时间：{now}
> 来源：{src}
> 目标项目：{target}

## 冲突详情

| # | 维度 | 外部规范 | 现有规范 | 影响范围 | 建议 |
|---|------|----------|----------|----------|------|
"""
    for i, (rel, fname) in enumerate(conflict, 1):
        conf += f"| {i} | {fname} | {rel} | {target}/{ftype}/{fname} | {ftype} 资产 | 需用户决策 |\n"
    conf += """
## 处理建议

1. 严重冲突需手动确认
2. 轻微冲突可按"最新优先"原则自动合并
3. 建议在合并后运行 tag-index.sh 重建索引
"""
    (Path(out_dir) / 'conflict-report.md').write_text(conf, encoding='utf-8')

print(f'报告已生成：{out_dir}/integrate-report.md' + (f'（含 conflict-report.md）' if conflict else ''))
print(f'摘要：新增 {len(added)} / 冲突 {len(conflict)} / 合并 {len(merged)} / 共扫描 {len(ext_assets)}')
PYEOF

echo "✅ 整合完成"
echo "下一步："
echo "  1. 查看整合报告（.op/changes/$CHANGE_ID/design-integrate/）"
echo "  2. 确认冲突处理"
echo "  3. 更新 tags.yaml 后运行 tag-index.sh 更新全局索引"
