#!/bin/bash
# assess.sh — v5 研判引擎（数据层：查询 + 预算 + 缺失/冲突信号）
# 用法：assess.sh --task=<任务描述> [--domain=<domain>] [--tech=<tech>] [--type=<type>] [--project=<slug>] [--budget=<kb>] [--top-k=<N>]
# 说明：脚本只做"数据+预算"（按参数查 index、核算体积、标缺失/冲突信号）；
#      语义研判（任务→领域推断、置信度排序、guidance）由 LLM 按 SKILL.md §assess 流程编排。
# 输出：研判报告 JSON（matched/missing/conflicts/budget）

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
CATALOG_INDEX="$SKILL_DIR/catalog/index.json"

TASK=""; DOMAIN=""; TECH=""; TYPE=""; PROJECT=""; BUDGET=""; TOP_K=""

for arg in "$@"; do
  case "$arg" in
    --task=*)   TASK="${arg#*=}" ;;
    --domain=*) DOMAIN="${arg#*=}" ;;
    --tech=*)   TECH="${arg#*=}" ;;
    --type=*)   TYPE="${arg#*=}" ;;
    --project=*) PROJECT="${arg#*=}" ;;
    --budget=*) BUDGET="${arg#*=}" ;;
    --top-k=*)  TOP_K="${arg#*=}" ;;
  esac
done

# 探测 python
PY_CMD=""
for c in py python3 python; do
  if command -v "$c" >/dev/null 2>&1; then
    if "$c" -c 'import json' >/dev/null 2>&1; then
      PY_CMD="$c"
      break
    fi
  fi
done
if [ -z "$PY_CMD" ]; then
  echo '{"error": "no python"}' >&2
  exit 1
fi

if [ ! -f "$CATALOG_INDEX" ]; then
  echo '{"error": "catalog/index.json 不存在，请先运行 tag-index.sh"}' >&2
  exit 1
fi

WIN_INDEX=$(cygpath -w "$CATALOG_INDEX" 2>/dev/null || echo "$CATALOG_INDEX")

"$PY_CMD" - "$WIN_INDEX" "$TASK" "$DOMAIN" "$TECH" "$TYPE" "$PROJECT" "$BUDGET" "$TOP_K" <<'PYEOF'
import json, sys
from pathlib import Path
from datetime import datetime, timedelta

index_file = Path(sys.argv[1])
task = sys.argv[2]
domain_f, tech_f, type_f, project_f = sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6]
budget = float(sys.argv[7]) if sys.argv[7] else 8.0
top_k = int(sys.argv[8]) if sys.argv[8] else 0

data = json.loads(index_file.read_text(encoding='utf-8'))
tags = data.get('tags', [])

matched = []
for t in tags:
    # 过滤（仅当提供过滤参数时）
    if domain_f and t.get('domain', '') != '*' and domain_f != t.get('domain', ''):
        continue
    if tech_f and tech_f not in t.get('tech', []):
        continue
    if type_f and t.get('type', '') != type_f:
        continue
    if project_f and t.get('project', '') != project_f:
        continue
    # 置信度（数据层粗排：domain 命中>tech 命中>type 命中）
    score = 0.2
    if not domain_f or t.get('domain', '') == '*' or t.get('domain', '') == domain_f:
        score += 0.4
    if not tech_f or tech_f in t.get('tech', []):
        score += 0.3
    if not type_f or t.get('type', '') == type_f:
        score += 0.1
    # stale
    stale = False
    if t.get('updated_at'):
        try:
            stale = (datetime.now() - datetime.fromisoformat(t['updated_at'])) > timedelta(days=90)
        except:
            pass
    matched.append({
        'key': t.get('key', ''),
        'kind': t.get('kind', 'asset'),
        'type': t.get('type', ''),
        'domain': t.get('domain', ''),
        'tech': t.get('tech', []),
        'reuse': t.get('reuse', ''),
        'version': t.get('version', ''),
        'stale': stale,
        'desc': t.get('desc', ''),
        'usage_scenes': t.get('usage_scenes', []),
        'usage_actors': t.get('usage_actors', []),
        'entry_point': t.get('entry_point', ''),
        'usage_flow': t.get('usage_flow', ''),
        'confidence': round(score, 2),
        'suggested_level': 'L1' if score >= 0.8 else 'L0',
    })

matched.sort(key=lambda m: m['confidence'], reverse=True)

# 预算截断
used_kb = 0.0
result = []
truncated = 0
for m in matched:
    approx = len(json.dumps(m, ensure_ascii=False)) / 1024
    if top_k and len(result) >= top_k:
        truncated += 1
        continue
    if used_kb + approx > budget and result:
        truncated += 1
        continue
    used_kb += approx
    result.append(m)

# 缺失信号：任务指定了过滤条件但无匹配
missing = []
if domain_f and not any(m.get('domain') == domain_f for m in matched):
    missing.append({'hint': f'领域 {domain_f} 无匹配资产', 'action': 'suggest-learn'})
if tech_f and not any(tech_f in m.get('tech', []) for m in matched):
    missing.append({'hint': f'技术 {tech_f} 无匹配资产', 'action': 'suggest-learn'})

# 冲突信号：同 domain 多版本
conflicts = []
from collections import Counter
dc = Counter((m['domain'], m['type']) for m in result)
for (dom, typ), cnt in dc.items():
    if cnt > 1 and dom != '*':
        vers = {m['version'] for m in result if m['domain'] == dom and m['type'] == typ}
        if len(vers) > 1:
            conflicts.append({'domain': dom, 'type': typ, 'versions': sorted(vers), 'action': 'suggest-integrate'})

print(json.dumps({
    'task': task,
    'assessment': {
        'matched': result,
        'missing': missing,
        'conflicts': conflicts,
        'budget': {'used_kb': round(used_kb, 2), 'limit_kb': budget},
        'truncated': truncated,
        'hint': f'剩余 {truncated} 条未披露，可 --budget 调大' if truncated else None,
    },
    'guidance': '由 LLM 依据上述数据生成使用指导（SKILL.md §assess 编排）',
}, ensure_ascii=False))
PYEOF
