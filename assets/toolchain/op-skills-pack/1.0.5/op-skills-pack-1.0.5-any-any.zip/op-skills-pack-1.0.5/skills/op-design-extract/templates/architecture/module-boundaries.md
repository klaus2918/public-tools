# 模块边界定义模板
# 位置：shared/<project>/architecture/module-boundaries.md

## 模块清单
<!-- 列出项目的所有模块及其职责边界 -->

## 依赖规则
<!-- 模块间的依赖方向和禁止项 -->

## 接口契约
<!-- 模块间通信的接口约定 -->
