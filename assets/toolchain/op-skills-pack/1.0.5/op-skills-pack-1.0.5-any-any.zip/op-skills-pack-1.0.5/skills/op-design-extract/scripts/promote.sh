#!/bin/bash
# promote.sh — v5 发布资产到全局（跨项目复用）
# 用法：promote.sh --asset=<key> --from=<project-slug> --reuse=global [--confirm]
# 说明：v5 禁直写 catalog/index.json（派生缓存，tag-index.sh 唯一写者）。
#       本脚本改写事实源 shared/<project>/tags.yaml 的 reuse 字段，然后触发 tag-index.sh 重建。

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
SHARED_DIR="$SKILL_DIR/shared"

ASSET=""
FROM_PROJECT=""
REUSE_LEVEL=""
CONFIRM=false

for arg in "$@"; do
  case "$arg" in
    --asset=*) ASSET="${arg#*=}" ;;
    --from=*)  FROM_PROJECT="${arg#*=}" ;;
    --reuse=*) REUSE_LEVEL="${arg#*=}" ;;
    --confirm) CONFIRM=true ;;
  esac
done

if [ -z "$ASSET" ] || [ -z "$FROM_PROJECT" ] || [ -z "$REUSE_LEVEL" ]; then
  echo "Error: --asset, --from, --reuse are required"
  echo "用法：promote.sh --asset=<key> --from=<project> --reuse=global [--confirm]"
  exit 1
fi

if [ "$REUSE_LEVEL" != "global" ] && [ "$REUSE_LEVEL" != "project" ]; then
  echo "Error: --reuse 仅支持 global|project"
  exit 1
fi

PROJECT_DIR="$SHARED_DIR/$FROM_PROJECT"
TAGS_FILE="$PROJECT_DIR/tags.yaml"

if [ ! -f "$TAGS_FILE" ]; then
  echo "Error: $TAGS_FILE not found"
  exit 1
fi

# 探测 python
PY_CMD=""
for c in py python3 python; do
  if command -v "$c" >/dev/null 2>&1; then
    if "$c" -c 'import yaml' >/dev/null 2>&1; then
      PY_CMD="$c"
      break
    fi
  fi
done
if [ -z "$PY_CMD" ]; then
  echo "Error: no python with yaml" >&2
  exit 1
fi

WIN_TAGS=$(cygpath -w "$TAGS_FILE" 2>/dev/null || echo "$TAGS_FILE")

# 改写 tags.yaml 的 reuse 字段（事实源），不碰 index.json
"$PY_CMD" - "$WIN_TAGS" "$ASSET" "$REUSE_LEVEL" "$CONFIRM" <<'PYEOF'
import sys
from pathlib import Path

tags_file = Path(sys.argv[1])
asset_key = sys.argv[2]
reuse_level = sys.argv[3]
confirmed = sys.argv[4] == 'true'

import yaml
data = yaml.safe_load(tags_file.read_text(encoding='utf-8')) or {}
tags = data.get('tags', [])
target = None
for tag in tags:
    if tag.get('key') == asset_key:
        target = tag
        break

if not target:
    print(f"Error: asset {asset_key} not found in {tags_file}")
    sys.exit(1)

if not confirmed:
    print(f"ℹ️  预览：{asset_key} 的 reuse 将改为 {reuse_level}")
    print(f"   当前：{target.get('reuse', '')} → 目标：{reuse_level}")
    print("   确认请加 --confirm")
    sys.exit(0)

old = target.get('reuse', '')
target['reuse'] = reuse_level
tags_file.write_text(yaml.safe_dump(data, allow_unicode=True, sort_keys=False, default_flow_style=False), encoding='utf-8')
print(f"✅ 已更新事实源：{asset_key} reuse {old} → {reuse_level}")
print(f"   文件：{tags_file}")
PYEOF

# 触发 tag-index 重建（唯一写者）
echo ""
echo "📇 重建索引（tag-index.sh 唯一写者）..."
"$SCRIPT_DIR/tag-index.sh" >/dev/null 2>&1 || echo "⚠️ 索引重建失败，请手动运行 tag-index.sh"
echo "✅ promote 完成：$ASSET → reuse=$REUSE_LEVEL（跨项目可查）"
