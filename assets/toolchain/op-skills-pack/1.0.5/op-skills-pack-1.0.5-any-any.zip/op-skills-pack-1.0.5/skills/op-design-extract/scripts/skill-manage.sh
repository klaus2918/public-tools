#!/bin/bash
# skill-manage.sh — v5 内置 skill 生命周期管理（update/deprecate/archive/reactivate）
# 用法：skill-manage.sh --skill=<name> --action=update|deprecate|archive|reactivate [--confirm]
# 说明：skill 状态机 pending →(--confirm)→ active → update → deprecated → archived；deprecated 可 reactivate。
#       update：资产变更后增量同步 references/templates（version+1）；deprecate/archive/reactivate 改 status。

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
SKILLS_DIR="$SKILL_DIR/skills"

SKILL_NAME=""; ACTION=""; CONFIRM=false

for arg in "$@"; do
  case "$arg" in
    --skill=*)  SKILL_NAME="${arg#*=}" ;;
    --action=*) ACTION="${arg#*=}" ;;
    --confirm)  CONFIRM=true ;;
  esac
done

if [ -z "$SKILL_NAME" ] || [ -z "$ACTION" ]; then
  echo "用法：skill-manage.sh --skill=<name> --action=update|deprecate|archive|reactivate [--confirm]"
  exit 1
fi

SKILL_DIR_PATH="$SKILLS_DIR/$SKILL_NAME"
SY_FILE="$SKILL_DIR_PATH/skill.yaml"

if [ ! -f "$SY_FILE" ]; then
  echo "Error: $SY_FILE 不存在"
  exit 1
fi

# 探测 python
PY_CMD=""
for c in py python3 python; do
  if command -v "$c" >/dev/null 2>&1; then
    if "$c" -c 'import yaml' >/dev/null 2>&1; then
      PY_CMD="$c"
      break
    fi
  fi
done
if [ -z "$PY_CMD" ]; then
  echo "Error: no python with yaml" >&2
  exit 1
fi

WIN_SY=$(cygpath -w "$SY_FILE" 2>/dev/null || echo "$SY_FILE")
WIN_INDEX=$(cygpath -w "$SKILL_DIR/scripts/tag-index.sh" 2>/dev/null || echo "$SKILL_DIR/scripts/tag-index.sh")

"$PY_CMD" - "$WIN_SY" "$ACTION" "$CONFIRM" <<'PYEOF'
import sys
from pathlib import Path
from datetime import datetime

sy_file = Path(sys.argv[1])
action = sys.argv[2]
confirmed = sys.argv[3] == 'true'

import yaml
s = yaml.safe_load(sy_file.read_text(encoding='utf-8')) or {}
name = s.get('name', '')
status = s.get('status', 'pending')
now = datetime.now().strftime('%Y-%m-%d')

# 状态机校验
valid = {
    'update': {'pending', 'active', 'deprecated'},
    'deprecate': {'active'},
    'archive': {'deprecated'},
    'reactivate': {'deprecated'},
}
if action not in valid or status not in valid[action]:
    print(f"Error: 状态机不允许 {action}（当前 status={status}）")
    print(f"       允许：{sorted(valid[action])}")
    sys.exit(1)

if not confirmed:
    print(f"ℹ️  预览：{name} {action}（status: {status} → 目标见下）")
    try:
        v_next = float(s.get('version', '1.0.0')) + 0.1
    except (ValueError, TypeError):
        v_next = 1.1
    targets = {'update': f'active(v{v_next:.1f})', 'deprecate': 'deprecated', 'archive': 'archived', 'reactivate': 'active'}
    print(f"   {targets[action]}")
    print("   确认请加 --confirm")
    sys.exit(0)

# 执行
if action == 'update':
    try:
        v = float(s.get('version', '1.0.0'))
    except (ValueError, TypeError):
        v = 1.0
    s['version'] = f'{v + 0.1:.1f}'
    s['status'] = 'active'
    s['updated_at'] = now
    print(f"✅ {name} 更新：version → {s['version']}，status → active")
    print("   （references/templates 增量同步由 LLM 按源资产差异执行）")
elif action == 'deprecate':
    s['status'] = 'deprecated'
    s['updated_at'] = now
    print(f"✅ {name} 已废弃（status=deprecated），可 archive 归档或 reactivate 恢复")
elif action == 'archive':
    s['status'] = 'archived'
    s['updated_at'] = now
    print(f"✅ {name} 已归档（status=archived），从索引移除（tag-index 跳过 archived）")
elif action == 'reactivate':
    s['status'] = 'active'
    s['updated_at'] = now
    print(f"✅ {name} 已恢复（status=active）")

sy_file.write_text(yaml.safe_dump(s, allow_unicode=True, sort_keys=False, default_flow_style=False), encoding='utf-8')
PYEOF

# 重建索引
echo ""
echo "📇 重建索引（tag-index.sh 唯一写者）..."
"$SCRIPT_DIR/tag-index.sh" >/dev/null 2>&1 || echo "⚠️ 索引重建失败，请手动运行 tag-index.sh"
echo "✅ skill-manage 完成：$SKILL_NAME $ACTION"
