#!/bin/bash
# scaffold.sh — 从模板生成代码骨架
# 用法：scaffold.sh --name=<name> --type=<type> [--output=<path>]
# 自动生成自 op-design-extract design-asset

set -euo pipefail

SKILL_DIR="$(cd "$(dirname "$0")/.." && pwd)"
TEMPLATES_DIR="$SKILL_DIR/templates"

# 解析参数
NAME=""
TYPE=""
OUTPUT=""

for arg in "$@"; do
  case "$arg" in
    --name=*)   NAME="${arg#*=}" ;;
    --type=*)   TYPE="${arg#*=}" ;;
    --output=*) OUTPUT="${arg#*=}" ;;
  esac
done

if [ -z "$NAME" ]; then
  echo "错误：--name 参数必填"
  echo "用法：scaffold.sh --name=<name> --type=<type> [--output=<path>]"
  exit 1
fi

OUTPUT="${OUTPUT:-.}"

echo "正在从模板生成代码：$NAME ($TYPE)"
echo "输出路径：$OUTPUT"

# 扫描模板目录，匹配对应类型的模板
for tpl in "$TEMPLATES_DIR"/*."$TYPE"*; do
  if [ -f "$tpl" ]; then
    tpl_name=$(basename "$tpl")
    output_name="${tpl_name%.tpl}"
    sed "s/{{name}}/$NAME/g" "$tpl" > "$OUTPUT/$output_name"
    echo "  生成：$output_name"
  fi
done

echo "✅ 骨架生成完成：$NAME"
