#!/bin/bash
# extract.sh — 从项目源码中提取设计资产
# 用法：extract.sh --project=<slug> [--scope=<path>] [--type=frontend|database|architecture|component]

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_DIR="$(dirname "$SCRIPT_DIR")"
SHARED_DIR="$SKILL_DIR/shared"
TEMPLATES_DIR="$SKILL_DIR/templates"

PROJECT=""
SCOPE=""
TYPE=""

for arg in "$@"; do
  case "$arg" in
    --project=*) PROJECT="${arg#*=}" ;;
    --scope=*)   SCOPE="${arg#*=}" ;;
    --type=*)    TYPE="${arg#*=}" ;;
  esac
done

if [ -z "$PROJECT" ]; then
  echo "Error: --project is required"
  exit 1
fi

PROJECT_DIR="$SHARED_DIR/$PROJECT"
mkdir -p "$PROJECT_DIR"

# 如果项目目录不存在，从模板初始化
if [ ! -f "$PROJECT_DIR/tags.yaml" ]; then
  cp "$TEMPLATES_DIR/tags.yaml" "$PROJECT_DIR/"
  cp -r "$TEMPLATES_DIR/frontend" "$PROJECT_DIR/" 2>/dev/null || true
  cp -r "$TEMPLATES_DIR/database" "$PROJECT_DIR/" 2>/dev/null || true
  cp -r "$TEMPLATES_DIR/architecture" "$PROJECT_DIR/" 2>/dev/null || true
  cp -r "$TEMPLATES_DIR/components" "$PROJECT_DIR/" 2>/dev/null || true
  cp -r "$TEMPLATES_DIR/env" "$PROJECT_DIR/" 2>/dev/null || true
  echo "Initialized project design directory: $PROJECT_DIR"
fi

echo "Design assets extracted to: $PROJECT_DIR"
echo "Next: update tags.yaml with asset metadata, then run tag-index.sh"
