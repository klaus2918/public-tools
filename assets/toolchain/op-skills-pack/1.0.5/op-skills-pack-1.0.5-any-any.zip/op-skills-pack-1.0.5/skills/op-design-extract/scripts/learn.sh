#!/bin/bash
# learn.sh — op-design-extract v4.0 学习入口
# 从现有代码/文档中提取设计规范，生成结构化设计资产
# 用法：learn.sh --project=<slug> [--scope=<path>] [--type=<type>] [--auto-tag] [--incremental]

set -euo pipefail

DESIGN_EXTRACT_DIR="$(cd "$(dirname "$0")/.." && pwd)"

# 解析参数
PROJECT=""
SCOPE=""
TYPE=""
AUTO_TAG=false
INCREMENTAL=false
SINCE=""

for arg in "$@"; do
  case "$arg" in
    --project=*)   PROJECT="${arg#*=}" ;;
    --scope=*)     SCOPE="${arg#*=}" ;;
    --type=*)      TYPE="${arg#*=}" ;;
    --auto-tag)    AUTO_TAG=true ;;
    --incremental) INCREMENTAL=true ;;
    --since=*)     SINCE="${arg#*=}" ;;
  esac
done

if [ -z "$PROJECT" ]; then
  echo "错误：--project 参数必填"
  echo "用法：learn.sh --project=<slug> [--scope=<path>] [--type=<type>] [--auto-tag] [--incremental] [--since=<date>]"
  exit 1
fi

echo "📚 op-design-extract learn — 设计规范学习"
echo "项目：$PROJECT"
echo "类型：${TYPE:-全部}"
echo "模式：$([ "$INCREMENTAL" = true ] && echo "增量（since: ${SINCE:-上次}）" || echo "全量")"

# 步骤 1：扫描源码
echo "📁 扫描阶段..."
# TODO: 实现实际的扫描逻辑
# - frontend: 提取组件结构、Token 使用、页面模式
# - database: 提取表结构、命名规范、索引策略
# - architecture: 提取模块边界、依赖方向
# - component: 提取公共组件、工具类

# 步骤 2：模式识别
echo "🔍 模式识别..."
# TODO: 实现模式识别逻辑
# - 统计命名规范频率
# - 识别重复代码模式
# - 提取架构约束

# 步骤 3：生成契约
echo "📝 生成学习契约..."
LEARN_DIR="$DESIGN_EXTRACT_DIR/shared/$PROJECT"
mkdir -p "$LEARN_DIR"

# 复制模板并填充
cp "$DESIGN_EXTRACT_DIR/templates/learn/learn-contract.json" "$LEARN_DIR/learn-contract.json"
# TODO: 用实际扫描结果填充模板

echo "✅ 学习完成"
echo "产物路径：$LEARN_DIR/"
echo ""
echo "下一步："
echo "  1. 查看学习报告：cat $LEARN_DIR/learn-report.md"
echo "  2. 确认标签建议：cat $LEARN_DIR/suggested-tags.yaml"
echo "  3. 运行 tag-index.sh 更新全局索引"
