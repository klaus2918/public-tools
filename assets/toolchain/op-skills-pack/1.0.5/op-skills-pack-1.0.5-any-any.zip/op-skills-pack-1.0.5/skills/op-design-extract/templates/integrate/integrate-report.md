# 外部工作流整合报告

> 整合时间：<integrated-at>
> 来源：<source>
> 目标项目：<target>
> 类型：<type>

## 1. 整合摘要

| 维度 | 统计 |
|------|------|
| 新增资产 | <count> |
| 冲突资产 | <count> |
| 合并资产 | <count> |
| 跳过资产 | <count> |

## 2. 新增资产清单

| # | 资产名 | 目标路径 | 说明 |
|---|--------|----------|------|
| 1 | <asset> | <path> | <description> |

## 3. 冲突资产清单

| # | 资产名 | 外部值 | 现有值 | 建议处理 |
|---|--------|--------|--------|----------|
| 1 | <asset> | <external> | <existing> | 保留外部/保留现有/手动合并 |

## 4. 标签更新建议

```yaml
tags:
  - key: <key>
    type: <type>
    domain: <domain>
    tech: [<tech>]
    reuse: project
```

## 5. 下一步操作

- [ ] 确认标签更新
- [ ] 运行 tag-index.sh 重建索引
- [ ] 验证整合后的设计资产
