---
name: {{skill_name}}
description: "当需要在 {{project}} 项目中进行 {{type}} 开发时，基于设计资产自动生成代码骨架时使用。"
status: active
phase_role: support
version: "1.0.0"
updated_at: {{generated_at}}
derived_from: op-design-extract/{{asset_key}}
project: {{project}}
dependencies:
  optional:
    - skill: op-design-extract
      condition: "需要查询或更新设计资产"
---

# {{skill_name}}

> 自动生成自 op-design-extract 设计资产（{{asset_key}}）
> 项目：{{project}} | 类型：{{type}}

## 何时使用

- {{trigger_description}}

## 调用入口

```bash
/{{skill_name}} <args>
```

## 输出产物

| 产物 | 模板 | 用途 |
|------|------|------|
| <product-1> | <template-1> | <purpose-1> |

## 模板列表

| 模板 | 说明 |
|------|------|
| <template-1> | <description-1> |
