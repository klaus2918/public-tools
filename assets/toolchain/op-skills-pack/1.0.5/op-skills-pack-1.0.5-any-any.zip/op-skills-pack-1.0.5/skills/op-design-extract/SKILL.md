---
name: op-design-extract
category: support
status: active
phase_role: support
description: 设计资产中枢 + 知识版图管理。从代码提取设计契约，标签索引管理，渐进披露。管理设计聚合体。
version: "6.0.0"
updated_at: 2026-08-20
---

# op-design-extract — 设计资产中枢

## Overview

从项目源码中抽取可复用的设计契约，通过标签索引管理，供 op-plan / op-build / op-done 消费。

两种知识来源中的「代码提供的信息」管理方（op-knowledge 管理「实践验证信息」）。

---

## 核心概念

### 知识版图

知识版图 = 设计聚合体的集合。设计聚合体具备：
- **完整性**：内部各部分相互支撑，形成完整方案
- **连续性**：设计决策之间有逻辑链条
- **可指导性**：本身可作为设计规范使用

### 降级路径

设计聚合体可降级为知识，但必须保持设计完整性和连续性。

---

## 核心命令

| 命令 | 说明 |
|------|------|
| `extract` | 从代码提取设计契约 |
| `query-tags` | 按标签查询资产 |
| `tag-index` | 构建/更新全局索引 |
| `disclose` | 渐进披露 L0/L1/L2 |
| `promote` | 跨项目复用发布 |
| `assess` | 研判引擎（数据层） |

> 高级功能（learn/generate-skill/skill-manage/integrate）见 references/

---

## 标签体系（与 G2 对齐）

| 维度 | 键 | 用途 |
|------|-----|------|
| 技术栈 | `tech` | op-plan 选择技术方案 |
| 业务域 | `domain` | 跨项目复用同域设计 |
| 设计类型 | `type` | 按维度检索 |
| 复用级别 | `reuse` | 控制可见范围 |
| 环境 | `env` | 环境差异隔离 |
| 项目 | `project` | 项目归属 |

**与 G2 术语对齐**：plan.md 术语表中的术语可作为标签维度的补充。

---

## 渐进披露

| Level | 说明 | 预算 |
|-------|------|------|
| L0 | 元数据（top-K） | ≤5KB |
| L1 | 摘要（digest） | ≤2KB |
| L2 | 全文 | ≤32KB |

单次总预算 8KB（--budget 覆盖）。

---

## 核心规则

1. **不修改源码**：只读、只抽、只写产物
2. **不做最终设计决策**：提供研判建议，由用户决策
3. **标签驱动**：所有设计资产必须打标签，否则不可被查询
4. **渐进披露**：默认 L0，按需深入
5. **索引唯一写者**：catalog/index.json 只由 tag-index.sh 产出

---

## 目录结构

```
op-design-extract/           ← Skill 代码（进 Git）
├── SKILL.md
├── scripts/
├── references/
└── templates/

.basic/evolved/op-design-extract/  ← 运行时资产（不进 Git，junction 链接）
├── shared/                  ← 项目级设计资产
├── catalog/                 ← 全局索引
├── skills/                  ← 设计聚合体（生成的业务 skill）
└── landscape/               ← 知识版图元数据
```

项目级设计资产沉淀路径：`op-design-extract/shared/<project-slug>/`（运行时实体在 `.basic/evolved/op-design-extract/shared/<project-slug>/`，skill 内同名目录为 junction）。
其中 `<project-slug>` 是**占位代号**，指目标项目的目录名标识（如 `project-graph`），首次为该项目建档时确定。

junction 由 op-000 统一管理。

---

## Red Flags — STOP

| Smell | Action |
|-------|--------|
| 无标签资产 | 提取后忘记写 tags.yaml → 资产不可被发现 |
| 环境混用 | 把测试环境约束写入基础设计 |
| 过度提取 | 把一次性代码当设计资产 |

---

## Version

| Field | Value |
|-------|-------|
| Skill | op-design-extract |
| Version | 6.0.0 |
| Updated | 2026-08-20 |
| References | extract-workflow.md / learn-workflow.md / generate-skill-workflow.md |
