# 设计规范学习报告 · <project-slug>

> 学习时间：<learned-at> | 扫描范围：<scope> | 深度：<depth>

## 1. 摘要

- 扫描文件数：<count>
- 发现模式数：<count>
- 识别组件数：<count>
- 识别表数：<count>
- 置信度：<confidence>%

## 2. 命名规范

### 2.1 数据库命名

- 表前缀：<prefix>
- 命名约定：<convention>
- 示例：<examples>

### 2.2 组件命名

- 命名约定：<convention>
- 示例：<examples>

### 2.3 文件组织

- 目录结构：<organization>
- 示例：<examples>

## 3. 架构模式

### 3.1 分层结构

- 层级：<layers>
- 依赖方向：<direction>

### 3.2 模块边界

- 规则：<boundary_rule>

## 4. 重复模式

| 模式名 | 类型 | 出现次数 | 置信度 | 可模板化 |
|--------|------|----------|--------|----------|
| <pattern> | <type> | <count> | <confidence>% | ✅/❌ |

## 5. 标签建议

（自动生成的 tags.yaml 条目，需用户确认）

```yaml
tags:
  - key: <suggested-key>
    type: <type>
    domain: "<domain>"
    tech: [<tech-1>]
    reuse: project
    desc: "<description>"
```

## 6. 下一步建议

- <recommendation-1>
- <recommendation-2>
