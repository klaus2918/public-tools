#!/bin/bash
# query-tags.sh — v5 按标签查询设计资产（只读派生缓存 catalog/index.json）
# 用法：query-tags.sh [--tech=<tech>] [--domain=<domain>] [--type=<type>] [--env=<env>] [--project=<slug>] [--reuse=<level>] [--kind=asset|skill] [--top-k=<N>] [--budget=<kb>]
# 输出：JSON 格式的匹配资产清单（L0 元数据；--top-k 按置信度截断控制体积）

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
CATALOG_INDEX="$SKILL_DIR/catalog/index.json"

# 探测 python
PY_CMD=""
for c in py python3 python; do
  if command -v "$c" >/dev/null 2>&1; then
    if "$c" -c 'import json' >/dev/null 2>&1; then
      PY_CMD="$c"
      break
    fi
  fi
done
if [ -z "$PY_CMD" ]; then
  echo '{"matched": [], "total": 0, "error": "no python available"}' >&2
  exit 1
fi

TECH=""; DOMAIN=""; TYPE=""; ENV=""; PROJECT=""; REUSE_LEVEL=""; KIND=""; TOP_K=""; BUDGET=""
for arg in "$@"; do
  case "$arg" in
    --tech=*)    TECH="${arg#*=}" ;;
    --domain=*)  DOMAIN="${arg#*=}" ;;
    --type=*)    TYPE="${arg#*=}" ;;
    --env=*)     ENV="${arg#*=}" ;;
    --project=*) PROJECT="${arg#*=}" ;;
    --reuse=*)   REUSE_LEVEL="${arg#*=}" ;;
    --kind=*)    KIND="${arg#*=}" ;;
    --top-k=*)   TOP_K="${arg#*=}" ;;
    --budget=*)  BUDGET="${arg#*=}" ;;
  esac
done

if [ ! -f "$CATALOG_INDEX" ]; then
  echo '{"matched": [], "total": 0, "error": "catalog/index.json 不存在，请先运行 tag-index.sh"}' >&2
  exit 1
fi

WIN_CATALOG=$(cygpath -w "$CATALOG_INDEX" 2>/dev/null || echo "$CATALOG_INDEX")

"$PY_CMD" - "$WIN_CATALOG" "$TECH" "$DOMAIN" "$TYPE" "$ENV" "$PROJECT" "$REUSE_LEVEL" "$KIND" "$TOP_K" "$BUDGET" <<'PYEOF'
import json, sys
from pathlib import Path
from datetime import datetime, timedelta

index_file = Path(sys.argv[1])
tech_f, domain_f, type_f, env_f, project_f, reuse_f = sys.argv[2:8]
kind_f, top_k, budget = sys.argv[8], sys.argv[9], sys.argv[10]

with open(index_file, encoding='utf-8') as f:
    data = json.load(f)

tags = data.get('tags', [])
matched = []

for tag in tags:
    if kind_f and tag.get('kind', 'asset') != kind_f:
        continue
    if tech_f and tech_f not in tag.get('tech', []):
        continue
    if domain_f and domain_f != '*' and tag.get('domain', '') != '*' and domain_f != tag.get('domain', ''):
        continue
    if type_f and type_f != tag.get('type', ''):
        continue
    if reuse_f and reuse_f != tag.get('reuse', ''):
        continue
    if env_f and tag.get('env', '*') != '*' and env_f != tag.get('env', ''):
        continue
    if project_f and tag.get('project', '') != project_f:
        continue

    # 置信度排序权重（domain 精确 > tech 匹配 > type）
    score = 0.2
    if not domain_f or domain_f == '*' or tag.get('domain', '') == domain_f:
        score += 0.4
    if not tech_f or tech_f in tag.get('tech', []):
        score += 0.3
    if not type_f or tag.get('type', '') == type_f:
        score += 0.1
    tag['_confidence'] = round(score, 2)

    # stale 检测
    updated_at = tag.get('updated_at', '')
    stale = False
    if updated_at:
        try:
            updated = datetime.fromisoformat(updated_at)
            stale = (datetime.now() - updated) > timedelta(days=90)
        except:
            pass
    tag['stale'] = stale
    matched.append(tag)

# 置信度降序
matched.sort(key=lambda t: t['_confidence'], reverse=True)

# 体积控制：--budget（KB，默认 8）或 --top-k（条数）
limit_kb = float(budget) if budget else 8.0
used_kb = 0.0
result = []
truncated = 0
for t in matched:
    approx = len(json.dumps(t, ensure_ascii=False)) / 1024
    if top_k and len(result) >= int(top_k):
        truncated += 1
        continue
    if used_kb + approx > limit_kb and result:
        truncated += 1
        continue
    used_kb += approx
    result.append(t)

# 移除内部字段
for t in result:
    t.pop('_confidence', None)
    t['confidence'] = 0.8  # 简化：真实置信度由 assess 语义层补充

print(json.dumps({
    'matched': result,
    'total': len(result),
    'truncated': truncated,
    'budget': {'used_kb': round(used_kb, 2), 'limit_kb': limit_kb},
    'hint': f'剩余 {truncated} 条未披露（超预算/超 top-k），可 --budget 调大或 --level=1 获取摘要' if truncated else None,
}, ensure_ascii=False))
PYEOF
