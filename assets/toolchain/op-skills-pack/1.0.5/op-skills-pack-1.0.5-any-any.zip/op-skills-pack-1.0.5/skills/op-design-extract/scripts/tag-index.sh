#!/bin/bash
# tag-index.sh — v5 构建/更新全局索引（唯一写者）
# 用法：tag-index.sh [--project=<slug>] [--rebuild-digests]
# 输出：catalog/index.json（资产+skill 统一派生缓存） + skills/index.yaml（skill 注册视图）
# 说明：单遍读取双事实源（shared/*/tags.yaml + skills/*/skill.yaml），一次产出两个平级派生文件。
#       --project 仅用于 --rebuild-digests 限定 digest 范围；索引写入始终全量（修复 v4 截断缺陷）。
#       --rebuild-digests 同时重建 catalog/digests/ 的 L1 摘要校验（标记 stale-digest）。

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
SHARED_DIR="$SKILL_DIR/shared"
SKILLS_DIR="$SKILL_DIR/skills"
CATALOG_DIR="$SKILL_DIR/catalog"
CATALOG_INDEX="$CATALOG_DIR/index.json"
SKILLS_INDEX="$SKILLS_DIR/index.yaml"
DIGESTS_DIR="$CATALOG_DIR/digests"

# 探测可用的 python（Windows 上 python3 可能是 Microsoft Store 占位符）
PY_CMD=""
for c in py python3 python; do
  if command -v "$c" >/dev/null 2>&1; then
    if "$c" -c 'import json, yaml' >/dev/null 2>&1; then
      PY_CMD="$c"
      break
    fi
  fi
done
if [ -z "$PY_CMD" ]; then
  echo "❌ 未找到可用的 python（py/python3/python，含 yaml 模块）" >&2
  exit 1
fi

PROJECT=""
REBUILD_DIGESTS=false
for arg in "$@"; do
  case "$arg" in
    --project=*)    PROJECT="${arg#*=}" ;;
    --rebuild-digests) REBUILD_DIGESTS=true ;;
  esac
done

WIN_SHARED=$(cygpath -w "$SHARED_DIR" 2>/dev/null || echo "$SHARED_DIR")
WIN_SKILLS=$(cygpath -w "$SKILLS_DIR" 2>/dev/null || echo "$SKILLS_DIR")
WIN_CATALOG=$(cygpath -w "$CATALOG_DIR" 2>/dev/null || echo "$CATALOG_DIR")
WIN_INDEX=$(cygpath -w "$CATALOG_INDEX" 2>/dev/null || echo "$CATALOG_INDEX")
WIN_SKILLS_INDEX=$(cygpath -w "$SKILLS_INDEX" 2>/dev/null || echo "$SKILLS_INDEX")

"$PY_CMD" - "$WIN_SHARED" "$WIN_SKILLS" "$WIN_CATALOG" "$WIN_INDEX" "$WIN_SKILLS_INDEX" "$PROJECT" "$REBUILD_DIGESTS" <<'PYEOF'
import json, sys
from pathlib import Path
from datetime import datetime
try:
    import yaml
except ImportError:
    yaml = None

shared_dir, skills_dir, catalog_dir, index_path, skills_index_path = (
    Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]),
    Path(sys.argv[4]), Path(sys.argv[5]))
project_filter = sys.argv[6]
rebuild_digests = sys.argv[7] == 'True'

# ── 事实源 1：shared/*/tags.yaml（资产）──
asset_tags = []
if shared_dir.exists():
    for project_dir in sorted(shared_dir.iterdir()):
        if not project_dir.is_dir():
            continue
        tags_file = project_dir / 'tags.yaml'
        if not tags_file.exists():
            continue
        try:
            data = yaml.safe_load(tags_file.read_text(encoding='utf-8')) or {}
        except Exception as e:
            print(f'⚠️ 解析失败: {tags_file} ({type(e).__name__}: {e})', file=sys.stderr)
            data = {}
        for t in data.get('tags', []):
            t['project'] = project_dir.name
            t['kind'] = 'asset'
            asset_tags.append(t)

# ── 事实源 2：skills/*/skill.yaml（skill）──
skill_entries = []
if skills_dir.exists():
    for skill_dir in sorted(skills_dir.iterdir()):
        if not skill_dir.is_dir() or skill_dir.name.startswith('.'):
            continue
        sy = skill_dir / 'skill.yaml'
        if not sy.exists():
            continue
        try:
            s = yaml.safe_load(sy.read_text(encoding='utf-8')) or {}
        except Exception as e:
            print(f'⚠️ 解析失败: {sy} ({type(e).__name__}: {e})', file=sys.stderr)
            s = {}
        if not s.get('name'):
            continue
        skill_entries.append({
            'key': s['name'],
            'name': s['name'],
            'type': s.get('type', 'skill'),
            'domain': s.get('domain', '*'),
            'tech': s.get('tech', []),
            'reuse': 'internal',          # 内置子层
            'env': '*',
            'version': s.get('version', '1.0.0'),
            'updated_at': s.get('updated_at', ''),
            'status': s.get('status', 'pending'),
            'desc': s.get('description', s.get('note', '')),   # v5: 用 description/note
            'files': [f"skills/{s['name']}/SKILL.md"],
            'project': s.get('source', ''),
            'kind': 'skill',
            'derived_from': s.get('derived_from', ''),
        })

# ── 派生 1：catalog/index.json（资产+skill 统一，纯派生缓存，禁直写）──
index = {
    'version': '1.1.0',
    'updated_at': datetime.now().isoformat(),
    'tags': asset_tags + skill_entries,
}
index_path.write_text(json.dumps(index, ensure_ascii=False, indent=2), encoding='utf-8')

# ── 派生 2：skills/index.yaml（skill 注册视图）──
reg = {
    'version': '1',
    'updated_at': datetime.now().isoformat(),
    'skills': [
        {k: s[k] for k in ('name', 'type', 'domain', 'version', 'status', 'updated_at', 'derived_from') if k in s}
        for s in skill_entries
    ],
}
skills_index_path.write_text(yaml.safe_dump(reg, allow_unicode=True, sort_keys=False, default_flow_style=False), encoding='utf-8')

# ── 派生 3：catalog/digests/ L1 摘要（--rebuild-digests）──
digest_report = []
if rebuild_digests:
    digests_dir = catalog_dir / 'digests'
    digests_dir.mkdir(parents=True, exist_ok=True)
    # 校验现有 digest 的源 version 一致性；缺失则标记待生成
    for t in asset_tags:
        key = t.get('key', '')
        if not key:
            continue
        dpath = digests_dir / t.get('project', 'global') / f'{key}.md'
        if dpath.exists():
            txt = dpath.read_text(encoding='utf-8')
            if f'version: {t.get("version", "")}' not in txt:
                digest_report.append(f'stale-digest: {key}')
        else:
            digest_report.append(f'missing-digest: {key}')

print(f'✅ 索引重建完成: {index_path} — {len(index["tags"])} 条目（资产 {len(asset_tags)} + skill {len(skill_entries)}）')
print(f'✅ skill 注册视图: {skills_index_path} — {len(skill_entries)} skills')
if rebuild_digests:
    if digest_report:
        print('⚠️ digest 校验:')
        for r in digest_report:
            print(f'   {r}')
        print('   提示：运行 disclose --gen-digests 重新生成 L1 摘要')
    else:
        print('✅ digest 校验: 全部一致')
PYEOF
