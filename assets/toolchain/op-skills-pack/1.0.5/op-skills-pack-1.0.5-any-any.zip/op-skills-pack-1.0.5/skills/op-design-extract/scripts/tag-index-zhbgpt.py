# -*- coding: utf-8 -*-
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
SKILL_DIR = SCRIPT_DIR.parent
SHARED_DIR = SKILL_DIR / "shared"
SKILLS_DIR = SKILL_DIR / "skills"
CATALOG_DIR = SKILL_DIR / "catalog"
CATALOG_INDEX = CATALOG_DIR / "index.json"
SKILLS_INDEX = SKILLS_DIR / "index.yaml"

try:
    import yaml
except ImportError:
    sys.stderr.write("需要 pyyaml：pip install pyyaml\n")
    sys.exit(3)

warnings = []

# ── 事实源 1：shared/*/tags.yaml（资产）──
asset_tags = []
if SHARED_DIR.exists():
    for project_dir in sorted(p for p in SHARED_DIR.iterdir() if p.is_dir()):
        tags_file = project_dir / "tags.yaml"
        if not tags_file.exists():
            continue
        try:
            data = yaml.safe_load(tags_file.read_text(encoding="utf-8")) or {}
        except Exception as e:
            warnings.append(f"解析失败: {tags_file} ({type(e).__name__}: {e})")
            data = {}
        for t in data.get("tags", []):
            t["project"] = project_dir.name
            t["kind"] = "asset"
            asset_tags.append(t)

# ── 事实源 2：skills/*/skill.yaml（skill）──
skill_entries = []
if SKILLS_DIR.exists():
    for skill_dir in sorted(p for p in SKILLS_DIR.iterdir() if p.is_dir() and not p.name.startswith(".")):
        sy = skill_dir / "skill.yaml"
        if not sy.exists():
            continue
        try:
            s = yaml.safe_load(sy.read_text(encoding="utf-8")) or {}
        except Exception as e:
            warnings.append(f"解析失败: {sy} ({type(e).__name__}: {e})")
            s = {}
        if not s.get("name"):
            continue
        skill_entries.append({
            "key": s["name"], "name": s["name"], "type": s.get("type", "skill"),
            "domain": s.get("domain", "*"), "tech": s.get("tech", []),
            "reuse": "internal", "env": "*", "version": s.get("version", "1.0.0"),
            "updated_at": s.get("updated_at", ""), "status": s.get("status", "pending"),
            "desc": s.get("description", s.get("note", "")),
            "files": [f"skills/{s['name']}/SKILL.md"],
            "project": s.get("source", ""), "kind": "skill",
            "derived_from": s.get("derived_from", ""),
        })

# ── 派生 1：catalog/index.json（全量写入，与 tag-index.sh 语义一致）──
CATALOG_DIR.mkdir(parents=True, exist_ok=True)
from datetime import datetime
index = {
    "version": "1.1.0",
    "updated_at": datetime.now().isoformat(),
    "tags": asset_tags + skill_entries,
}
with open(CATALOG_INDEX, "w", encoding="utf-8") as f:
    json.dump(index, f, ensure_ascii=False, indent=2)

# ── 派生 2：skills/index.yaml（skill 注册视图）──
reg = {
    "version": "1",
    "updated_at": datetime.now().isoformat(),
    "skills": [
        {k: s[k] for k in ("name", "type", "domain", "version", "status", "updated_at", "derived_from") if k in s}
        for s in skill_entries
    ],
}
SKILLS_DIR.mkdir(parents=True, exist_ok=True)
with open(SKILLS_INDEX, "w", encoding="utf-8") as f:
    yaml.safe_dump(reg, f, allow_unicode=True, sort_keys=False, default_flow_style=False)

print(f"✅ 索引重建完成: {CATALOG_INDEX} — {len(index['tags'])} 条目（资产 {len(asset_tags)} + skill {len(skill_entries)}）")
print(f"✅ skill 注册视图: {SKILLS_INDEX} — {len(skill_entries)} skills")
if warnings:
    print("⚠️ 解析告警:")
    for w in warnings:
        print(f"   {w}")
    sys.exit(2)  # 有告警视为需关注（不阻塞，但非零退出）
