#!/bin/bash
# disclose.sh — v5 渐进披露（L0 元数据 / L1 摘要 / L2 全文）
# 用法：disclose.sh --key=<asset-key> [--project=<slug>] [--level=0|1|2] [--budget=<kb>] [--gen-digests]
# 说明：
#   L0 元数据：index.json 条目（轻量）
#   L1 摘要：catalog/digests/<project|global>/<key>.md（规则 TOP 5-10，≤2KB）
#   L2 全文：资产源文件完整内容（≤32KB，超限分页）
#   --gen-digests：为缺失 digest 的资产生成占位摘要（由 LLM 在 assess 后填充）

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
CATALOG_INDEX="$SKILL_DIR/catalog/index.json"
DIGESTS_DIR="$SKILL_DIR/catalog/digests"
SHARED_DIR="$SKILL_DIR/shared"

KEY=""; PROJECT=""; LEVEL="1"; BUDGET=""; GEN_DIGESTS=false

for arg in "$@"; do
  case "$arg" in
    --key=*)      KEY="${arg#*=}" ;;
    --project=*)  PROJECT="${arg#*=}" ;;
    --level=*)    LEVEL="${arg#*=}" ;;
    --budget=*)   BUDGET="${arg#*=}" ;;
    --gen-digests) GEN_DIGESTS=true ;;
  esac
done

# 探测 python
PY_CMD=""
for c in py python3 python; do
  if command -v "$c" >/dev/null 2>&1; then
    if "$c" -c 'import json, yaml' >/dev/null 2>&1; then
      PY_CMD="$c"
      break
    fi
  fi
done
if [ -z "$PY_CMD" ]; then
  echo '{"error": "no python with yaml"}' >&2
  exit 1
fi

WIN_INDEX=$(cygpath -w "$CATALOG_INDEX" 2>/dev/null || echo "$CATALOG_INDEX")
WIN_DIGESTS=$(cygpath -w "$DIGESTS_DIR" 2>/dev/null || echo "$DIGESTS_DIR")
WIN_SHARED=$(cygpath -w "$SHARED_DIR" 2>/dev/null || echo "$SHARED_DIR")

"$PY_CMD" - "$WIN_INDEX" "$WIN_DIGESTS" "$WIN_SHARED" "$KEY" "$PROJECT" "$LEVEL" "$BUDGET" "$GEN_DIGESTS" <<'PYEOF'
import json, sys
from pathlib import Path

index_file = Path(sys.argv[1])
digests_dir = Path(sys.argv[2])
shared_dir = Path(sys.argv[3])
key = sys.argv[4]
project_f = sys.argv[5]
level = sys.argv[6]
budget = sys.argv[7]
gen_digests = sys.argv[8] == 'true'

def find_asset():
    if not index_file.exists():
        return None
    data = json.loads(index_file.read_text(encoding='utf-8'))
    for t in data.get('tags', []):
        if t.get('key') == key and (not project_f or t.get('project', '') == project_f):
            return t
    return None

asset = find_asset()
if not asset:
    print(json.dumps({'error': f'asset {key} 未找到（index.json）', 'hint': '运行 tag-index.sh 后重试'}, ensure_ascii=False))
    sys.exit(1)

# ── L0 元数据 ──
l0 = {k: asset.get(k) for k in ('key', 'type', 'domain', 'tech', 'reuse', 'env', 'desc', 'files', 'version', 'updated_at', 'stale', 'project', 'kind', 'usage_scenes', 'usage_actors', 'entry_point', 'usage_flow') if k in asset}
l0_kb = len(json.dumps(l0, ensure_ascii=False)) / 1024

if level == '0':
    print(json.dumps({'level': 'L0', 'kb': round(l0_kb, 2), 'asset': l0}, ensure_ascii=False))
    sys.exit(0)

# ── L1 摘要 ──
digest_path = digests_dir / (asset.get('project', 'global')) / f"{key}.md"
if gen_digests and not digest_path.exists():
    digest_path.parent.mkdir(parents=True, exist_ok=True)
    digest_path.write_text(
        f"# {key} digest（自动生成占位，待 LLM 填充）\n\n"
        f"> 源资产：{key} | version: {asset.get('version', '')} | 类型: {asset.get('type', '')}\n\n"
        f"## 关键规则\n- （待填充：从源资产提取 TOP 5-10 条）\n\n"
        f"## 使用场景与流程\n- 业务场景：{asset.get('usage_scenes', [])}\n- 使用角色：{asset.get('usage_actors', [])}\n- 入口：{asset.get('entry_point', '')}\n- 流程：{asset.get('usage_flow', '')}\n- （待填充：分步使用过程，供 build 消费）\n\n"
        f"## 使用提示\n- （待填充）\n",
        encoding='utf-8')
    print(f"✅ 已生成占位 digest：{digest_path}")

if digest_path.exists():
    digest_txt = digest_path.read_text(encoding='utf-8')
    digest_kb = len(digest_txt.encode('utf-8')) / 1024
    if budget and digest_kb > float(budget):
        digest_txt = digest_txt[:int(float(budget) * 1024)] + '\n...[截断]'
    if level == '1':
        print(json.dumps({'level': 'L1', 'kb': round(digest_kb, 2), 'digest_path': str(digest_path), 'content': digest_txt}, ensure_ascii=False))
        sys.exit(0)
else:
    print(json.dumps({'level': 'L1', 'error': f'digest 不存在：{digest_path}', 'hint': '运行 --gen-digests 生成占位后由 LLM 填充'}, ensure_ascii=False))
    if level == '1':
        sys.exit(0)

# ── L2 全文 ──
if level == '2':
    results = []
    total_kb = 0.0
    limit_kb = float(budget) if budget else 32.0
    for f in asset.get('files', []):
        src = shared_dir / asset.get('project', '') / f
        if not src.exists():
            continue
        txt = src.read_text(encoding='utf-8')
        kb = len(txt.encode('utf-8')) / 1024
        if total_kb + kb > limit_kb:
            txt = txt[:int((limit_kb - total_kb) * 1024)] + '\n...[超预算截断]'
            kb = limit_kb - total_kb
        total_kb += kb
        results.append({'file': f, 'kb': round(kb, 2), 'content': txt})
        if total_kb >= limit_kb:
            break
    print(json.dumps({'level': 'L2', 'total_kb': round(total_kb, 2), 'limit_kb': limit_kb, 'files': results}, ensure_ascii=False))
    sys.exit(0)

print(json.dumps({'error': f'unknown level {level}'}, ensure_ascii=False))
PYEOF
