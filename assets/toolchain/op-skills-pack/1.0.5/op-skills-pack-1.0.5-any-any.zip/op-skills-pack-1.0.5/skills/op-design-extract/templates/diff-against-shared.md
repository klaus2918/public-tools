# 差异说明 · <change-id>

> 项目：<project-slug> ｜ 变更：<change-id>
>
> 本文件对比本次变更抽取出的设计契约与项目级共享沉淀 `shared/<project-slug>/` 的差异。

## 1. 新增契约

| 类别 | 名称 | 说明 |
|---|---|---|
| <category> | <name> | <description> |

## 2. 调整契约

| 类别 | 名称 | 项目级原值 | 本次变更值 | 说明 |
|---|---|---|---|---|
| <category> | <name> | <old> | <new> | <description> |

## 3. 删除契约

| 类别 | 名称 | 说明 |
|---|---|---|
| <category> | <name> | <description> |

## 4. 建议晋升项

- <recommendation-1>
- <recommendation-2>

## 5. 保持不变的契约

- <unchanged-1>
- <unchanged-2>
