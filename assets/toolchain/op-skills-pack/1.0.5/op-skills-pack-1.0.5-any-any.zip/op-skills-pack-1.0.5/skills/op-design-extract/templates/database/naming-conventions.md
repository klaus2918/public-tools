# 数据库命名规范模板
# 位置：shared/<project>/database/naming-conventions.md

## 表命名
- 前缀：`<模块>_<实体>`（如 `OA_DOCUMENT`, `PARTY_MEMBER`）
- 全大写，下划线分隔

## 字段命名
- 主键：`ID`（VARCHAR(64)）
- 外键：`<关联表>_ID`
- 时间：`CREATE_TIME`, `UPDATE_TIME`
- 状态：`STATUS`（TINYINT）
- 删除标记：`IS_DELETED`（TINYINT, 0=正常 1=删除）

## 索引命名
- 主键：`PK_<TABLE>`
- 唯一：`UK_<TABLE>_<FIELD>`
- 普通：`IDX_<TABLE>_<FIELD>`
