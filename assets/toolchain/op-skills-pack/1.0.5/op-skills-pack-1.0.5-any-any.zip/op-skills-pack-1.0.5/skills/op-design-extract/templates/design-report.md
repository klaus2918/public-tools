# 设计契约报告 · <change-id>

> 项目：<project-slug> ｜ 变更：<change-id> ｜ 生成时间：<generated-at>

## 1. 摘要

- 扫描范围：<scope-summary>
- 抽取契约数：<count>
- 多端差异：<count>
- 质量门禁：通过 <passed> / 失败 <failed> / 跳过 <skipped>

## 2. Token 摘要

| 语义 | PC 端 | APP 端 | 说明 |
|---|---|---|---|
| <semantic> | <value> | <value> | <note> |

## 3. 组件映射

| 场景 | PC 端 | APP 端 | 说明 |
|---|---|---|---|
| <scene> | <pc> | <app> | <note> |

## 4. 模式摘要

| 模式名 | 适用页面/模块 | 说明 |
|---|---|---|
| <pattern> | <applies> | <description> |

## 5. 多端差异

| 关注点 | PC 端 | APP 端 | 严重程度 | 原因 |
|---|---|---|---|---|
| <focus> | <pc-value> | <app-value> | <severity> | <reason> |

## 6. 质量门禁

| 关注点 | 规则 | 状态 |
|---|---|---|
| <focus> | <rule> | <passed/failed/skipped> |

## 7. 决策建议（非强制）

- <recommendation-1>
- <recommendation-2>

## 8. 产物清单

- `design-contract.json` — 结构化契约
- `diff-against-shared.md` — 与项目级共享沉淀的差异
