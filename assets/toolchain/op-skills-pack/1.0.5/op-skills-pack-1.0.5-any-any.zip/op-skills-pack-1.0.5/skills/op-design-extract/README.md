# op-design-extract · 入门

本 Skill 用于从一次变更中抽取设计契约，输出固定格式的 3 个产物。

## 1. 一句话定义

`/op-design-extract` 把一次变更相关的源码或规划文档，转换成下游可消费的**设计契约**。它只读、只抽、只写产物。

## 2. 调用方式

```
/op-design-extract <change-id> [--project-slug=<slug>] [--scope=<path1,path2>]
```

- `change-id`：变更目录名，例如 `grassroots-dynamics`
- `--project-slug`：项目代号；缺省从 `change.yaml.project_slug` 读取
- `--scope`：扫描路径；缺省从 `change.yaml.scope` 或 `plan.md` 推断

## 3. 输出产物

写入 `.op/changes/<change-id>/design-extract/`：

| 产物 | 文件 | 说明 |
|---|---|---|
| 结构化契约 | `design-contract.json` | 机器可读，下游 Skill 消费 |
| 人类可读报告 | `design-report.md` | 人工审阅 |
| 差异说明 | `diff-against-shared.md` | 与项目级共享沉淀的差异 |

## 4. 目录结构

```
.claude/skills/op-design-extract/
├── SKILL.md              # Skill 自描述
├── README.md             # 本文件
└── templates/            # 产物模板（骨架）
    ├── design-contract.json
    ├── design-report.md
    └── diff-against-shared.md
```

项目级真沉淀目录（不预创建）：

```
<skill-dir>/shared/<project-slug>/
```

## 5. 何时不用

- 纯后端基础设施变更，无 UI 层
- 用户只是想改代码，不需要设计契约
- 变更已经完成且不需要归档设计资产

## 6. 维护约定

- 升级 Skill 时只改 SKILL.md、README.md、templates/
- 严禁在 Skill 本体中写入具体项目名、色值、尺寸、组件版本
- 模板中只出现占位符，例如 `<color-primary>`、`<module-slug>`
