#!/bin/bash
# generate-skill.sh — op-design-extract v4.0 Skill 生成入口（内置子层）
# 基于设计资产自动生成标准化业务 skill，作为 op-design-extract 内置子层（skills/<name>/）
# 用法：generate-skill.sh --from=<project>|--from-tags=<tags>|--from-learn=<change-id> --name=<skill-name> [--type=<type>] [--dry-run]

set -euo pipefail

DESIGN_EXTRACT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
SKILLS_DIR="$DESIGN_EXTRACT_DIR/skills"          # 内置子层目录（非平级对外）
SHARED_DIR="$DESIGN_EXTRACT_DIR/shared"

# 解析参数
FROM=""
FROM_TAGS=""
FROM_LEARN=""
SKILL_NAME=""
SKILL_TYPE=""
DRY_RUN=false
CONFIRM=false

for arg in "$@"; do
  case "$arg" in
    --from=*)        FROM="${arg#*=}" ;;
    --from-tags=*)   FROM_TAGS="${arg#*=}" ;;
    --from-learn=*)  FROM_LEARN="${arg#*=}" ;;
    --name=*)        SKILL_NAME="${arg#*=}" ;;
    --type=*)        SKILL_TYPE="${arg#*=}" ;;
    --dry-run)       DRY_RUN=true ;;
    --confirm)       CONFIRM=true ;;
  esac
done

if [ -z "$SKILL_NAME" ]; then
  echo "错误：--name 参数必填"
  echo "用法：generate-skill.sh --from=<project>|--from-tags=<tags> --name=<skill-name> [--type=<type>] [--dry-run]"
  exit 1
fi

# 探测 python
PY_CMD=""
for c in py python3 python; do
  if command -v "$c" >/dev/null 2>&1; then
    if "$c" -c 'import json, yaml' >/dev/null 2>&1; then
      PY_CMD="$c"
      break
    fi
  fi
done
if [ -z "$PY_CMD" ]; then
  echo "错误：未找到可用 python（含 yaml 模块）" >&2
  exit 1
fi

echo "🔧 op-design-extract generate-skill — 业务 Skill 生成（内置子层）"
echo "Skill 名称：$SKILL_NAME"
echo "来源：${FROM:-${FROM_TAGS:-${FROM_LEARN:-未知}}}"
echo "目标：$SKILLS_DIR/$SKILL_NAME"
echo "模式：$([ "$DRY_RUN" = true ] && echo "预览（不写文件）" || echo "写入")"

WIN_SKILLS=$(cygpath -w "$SKILLS_DIR" 2>/dev/null || echo "$SKILLS_DIR")
WIN_SHARED=$(cygpath -w "$SHARED_DIR" 2>/dev/null || echo "$SHARED_DIR")
WIN_DESIGN=$(cygpath -w "$DESIGN_EXTRACT_DIR" 2>/dev/null || echo "$DESIGN_EXTRACT_DIR")

"$PY_CMD" - "$WIN_SKILLS" "$WIN_SHARED" "$WIN_DESIGN" "$SKILL_NAME" "$FROM" "$FROM_TAGS" "$SKILL_TYPE" "$DRY_RUN" "$CONFIRM" <<'PYEOF'
import json, os, shutil, sys
from pathlib import Path
from datetime import datetime

skills_dir, shared_dir, design_dir, name, src, src_tags, stype, dry_run, confirm = (
    Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]),
    sys.argv[4], sys.argv[5], sys.argv[6], sys.argv[7], sys.argv[8] == 'true', sys.argv[9] == 'true'
)

if dry_run:
    print(f"\n📋 预览：skills/{name}/")
    print("├── SKILL.md")
    print("├── skill.yaml")
    print("├── templates/")
    print("├── references/")
    print("└── scripts/scaffold.sh")
    print("\n✅ dry-run 模式，未写入文件")
    sys.exit(0)

skill_dir = skills_dir / name
if skill_dir.exists():
    print(f"⚠️ 已存在：{skill_dir}，如需重建请先删除")
    sys.exit(1)

# 收集来源资产（--from 项目 或 --from-tags 标签）
assets = []
tags = []
if src:
    proj_dir = shared_dir / src
    if proj_dir.exists() and (proj_dir / 'tags.yaml').exists():
        import yaml
        data = yaml.safe_load((proj_dir / 'tags.yaml').read_text(encoding='utf-8')) or {}
        tags = data.get('tags', [])
        assets = [Path(proj_dir / f) for t in tags for f in t.get('files', []) if (proj_dir / f).exists()]
elif src_tags:
    wanted = [t.strip() for t in src_tags.split(',') if t.strip()]
    import yaml
    for proj_dir in shared_dir.iterdir():
        if not proj_dir.is_dir():
            continue
        tf = proj_dir / 'tags.yaml'
        if not tf.exists():
            continue
        data = yaml.safe_load(tf.read_text(encoding='utf-8')) or {}
        for t in data.get('tags', []):
            if t.get('key') in wanted:
                tags.append(t)
                for f in t.get('files', []):
                    p = proj_dir / f
                    if p.exists():
                        assets.append(p)

if not assets:
    print("错误：未找到来源资产（--from 项目无 tags.yaml 或无匹配文件）")
    sys.exit(1)

# 类型过滤（可选）
if stype:
    assets = [a for a in assets if f'/{stype}/' in a.as_posix()]
    if not assets:
        print(f"错误：类型 {stype} 下无资产文件")
        sys.exit(1)

# 创建目录
skill_dir.mkdir(parents=True)
(skill_dir / 'templates').mkdir()
(skill_dir / 'references').mkdir()
(skill_dir / 'scripts').mkdir()

# 复制资产 md/json → references/（设计规范），模板 → templates/
tpl_count = 0
for a in assets:
    if a.suffix == '.md':
        shutil.copy2(a, skill_dir / 'references' / a.name)
    elif a.suffix == '.json':
        shutil.copy2(a, skill_dir / 'references' / a.name)
    # .tpl / 模板类文件 → templates/
    elif a.suffix == '.tpl' or '.template' in a.name:
        shutil.copy2(a, skill_dir / 'templates' / a.name)
        tpl_count += 1

# 生成 SKILL.md（渲染模板占位符）
tpl_path = design_dir / 'templates' / 'skill' / 'SKILL.md.tpl'
if tpl_path.exists():
    tpl = tpl_path.read_text(encoding='utf-8')
    now = datetime.now().strftime('%Y-%m-%d')
    keys = ','.join(sorted({t.get('key','') for t in tags}))
    placeholders = {
        '{{skill_name}}': name,
        '{{project}}': src or ','.join(sorted({t.get('project','') for t in tags})) or 'oa',
        '{{type}}': stype or ','.join(sorted({t.get('type','') for t in tags})) or 'database',
        '{{asset_key}}': keys,
        '{{generated_at}}': now,
        '{{trigger_description}}': f"基于设计资产 {keys} 生成的标准业务 skill，用于 {src or 'oa'} 项目 {stype or ''} 开发",
    }
    for k, v in placeholders.items():
        tpl = tpl.replace(k, v)
    (skill_dir / 'SKILL.md').write_text(tpl, encoding='utf-8')

# 生成 skill.yaml（内置子层配置，v5 状态机：pending →(--confirm)→ active）
import yaml
skill_yaml = {
    'name': name,
    'derived_from': keys,
    'source': src or 'oa',
    'type': stype or '',
    'domain': sorted({t.get('domain', '*') for t in tags}),
    'tech': sorted({x for t in tags for x in t.get('tech', [])}),
    'assets': [a.name for a in assets],
    'templates_count': tpl_count,
    'references_count': len([a for a in assets if a.suffix in ('.md', '.json')]),
    'version': '1.0.0',
    'status': 'active' if confirm else 'pending',
    'description': f"基于设计资产 {keys} 生成的标准业务 skill，用于 {src or 'oa'} 项目 {stype or ''} 开发",
    'created_at': now,
    'updated_at': now,
    'registered_at': now if confirm else '',
    'manual': False,
    'managed_by': 'op-design-extract',
    'layer': 'builtin-sub',
    'note': '内置子层 skill：由 op-design-extract 生成与管理，不对外平级提供',
}
(skill_dir / 'skill.yaml').write_text(
    yaml.safe_dump(skill_yaml, allow_unicode=True, sort_keys=False, default_flow_style=False),
    encoding='utf-8')

# 复制 scaffold.sh
scaffold_src = design_dir / 'templates' / 'skill' / 'scaffold.sh.tpl'
if scaffold_src.exists():
    shutil.copy2(scaffold_src, skill_dir / 'scripts' / 'scaffold.sh')
    (skill_dir / 'scripts' / 'scaffold.sh').chmod(0o755)

print(f"✅ Skill 生成完成：{skill_dir}")
print(f"   资产复制：{len(assets)} | 模板：{tpl_count} | 标签：{len(tags)}")
print(f"   状态：{'active（--confirm 已确认）' if confirm else 'pending（待 --confirm 激活）'}")
print(f"   SKILL.md + skill.yaml 已生成（内置子层，由 op-design-extract 管理）")
PYEOF

echo ""
echo "📇 重建索引（tag-index.sh 唯一写者）..."
"$DESIGN_EXTRACT_DIR/scripts/tag-index.sh" >/dev/null 2>&1 || echo "⚠️ 索引重建失败，请手动运行 tag-index.sh"

echo ""
echo "✅ 完成：skills/$SKILL_NAME 已生成"
if [ "$CONFIRM" != "true" ]; then
  echo "ℹ️  状态 pending：运行 generate-skill.sh --confirm 激活，或手动改 skill.yaml status=active"
fi
