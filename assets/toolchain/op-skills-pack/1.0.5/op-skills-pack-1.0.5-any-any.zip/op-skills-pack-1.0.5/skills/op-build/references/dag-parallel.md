# DAG 并行详细流程

> 来源：op-build v3.0.0 设计文档

---

## 触发条件

当 `parallel_mode: dag` 且 tasks.md 有 depends 字段时启用 DAG 并行模式。

---

## 执行流程

```
1. 解析 tasks.md 依赖关系
2. 构建依赖图（DAG）
3. 检测循环依赖（A→B→C→A）→ 拒绝
4. 按拓扑排序分 wave
5. 同 wave root task 通过 subagent 并行派发
6. 最大并发数 4
7. 每个 subagent 完成后独立审查
8. 结果合并回 tasks.md
9. 进入下一 wave
```

---

## 依赖规则

| depends value | Meaning |
|---------------|---------|
| `[]` or omitted | Root task — execute immediately |
| `[1, 2]` | Wait until tasks #1 and #2 complete |
| Cycle detected | Reject — cycle must be resolved in plan |

---

## 并发控制

- 最大并发数：4
- 超出时排队等待
- 每个 subagent 独立上下文
- 结果通过 tasks.md 合并

---

## 失败处理

单个 subagent 失败时：
1. 记录失败原因
2. 标记 task 为 in_progress
3. 继续执行其他 wave
4. 等待用户决策
