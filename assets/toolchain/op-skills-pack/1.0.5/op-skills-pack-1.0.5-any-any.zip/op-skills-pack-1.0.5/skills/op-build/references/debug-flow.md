# 调试流程详细步骤

> 来源：op-build v3.0.0 设计文档（吸收 systematic-debugging）

---

## 触发条件

连续 3 次验证失败时触发调试流程。

---

## 四阶段根因分析

### Phase 1: Root Cause Investigation

**BEFORE attempting ANY fix:**

1. **Read Error Messages Carefully**
   - Don't skip past errors or warnings
   - They often contain the exact solution
   - Read stack traces completely

2. **Reproduce Consistently**
   - Can you trigger it reliably?
   - What are the exact steps?

3. **Check Recent Changes**
   - What changed that could cause this?
   - Git diff, recent commits

4. **Gather Evidence**
   - Add diagnostic instrumentation
   - Log what data enters/exits each component

5. **Trace Data Flow**
   - Where does bad value originate?
   - Keep tracing up until you find the source

### Phase 2: Pattern Analysis

1. **Find Working Examples**
   - Locate similar working code in same codebase

2. **Compare Against References**
   - What's different between working and broken?

3. **Identify Differences**
   - List every difference, however small

### Phase 3: Hypothesis and Testing

1. **Form Single Hypothesis**
   - State clearly: "I think X is the root cause because Y"

2. **Test Minimally**
   - Make the SMALLEST possible change to test hypothesis

3. **Verify Before Continuing**
   - Did it work? Yes → Phase 4
   - Didn't work? Form NEW hypothesis

### Phase 4: Implementation

1. **Create Failing Test Case**
   - Simplest possible reproduction

2. **Implement Single Fix**
   - Address the root cause identified

3. **Verify Fix**
   - Test passes now?
   - No other tests broken?

4. **If 3+ Fixes Failed: Question Architecture**
   - Is this pattern fundamentally sound?
   - Should we refactor architecture?

---

## 用户选项

连续 3 次失败后，展示 4 选 1：

```
A. 重试（重置失败计数）
B. 跳过 task（记录原因）
C. 根因分析（四阶段：调查→模式→假设→实现）
D. 放弃执行，回退 plan 阶段
```

---

## Red Flags

- "Quick fix for now, investigate later"
- "Just try changing X and see if it works"
- "Add multiple changes, run tests"
- "One more fix attempt" (when already tried 2+)

**ALL of these mean: STOP. Return to Phase 1.**
