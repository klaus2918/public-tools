# 验证命令速查

> 常见项目类型的验证命令参考

## Java / Maven 项目

| 场景 | 命令 |
|------|------|
| 编译检查 | `mvn compile` |
| 运行全部测试 | `mvn test` |
| 运行单个测试类 | `mvn test -Dtest=ClassNameTest` |
| 运行单个测试方法 | `mvn test -Dtest=ClassNameTest#methodName` |
| 跳过测试编译 | `mvn compile -DskipTests` |
| 依赖解析 | `mvn dependency:resolve` |
| 代码风格检查 | `mvn checkstyle:check` |

## Node.js 项目

| 场景 | 命令 |
|------|------|
| 编译检查 | `npm run build` 或 `npx tsc --noEmit` |
| 运行测试 | `npm test` |
| Lint 检查 | `npm run lint` |
| 依赖安装 | `npm install` |
| 类型检查 | `npx tsc --noEmit` |

## Python 项目

| 场景 | 命令 |
|------|------|
| 语法检查 | `python -m py_compile *.py` |
| 运行测试 | `pytest` |
| Lint 检查 | `flake8` |
| 类型检查 | `mypy .` |

## 通用

| 场景 | 命令 |
|------|------|
| JSON 语法校验 | `python -m json.tool <file>` |
| YAML 语法校验 | `python -c "import yaml; yaml.safe_load(open('<file>'))"` |
| 目录结构快照 | `tree -L 2 --gitignore` |
