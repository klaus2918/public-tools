# 常见错误与处理

> op-build 阶段异常场景速查

| 错误 | 预防 | 处理 |
|------|------|------|
| 跳过验证直接标记完成 | 每个 task 的验证是强制步骤 | 回退 task 状态为未完成，补验证后重新标记 |
| 一次实现多个 task 再提交 | 每完成一个 task 立即执行 commit | 通过 `git rebase -i` 拆分为多个 commit（经 safe-git-write） |
| 任务范围蔓延 | 实现阶段严格遵循 task 描述和涉及文件列表 | 发现项记录到 `.op/findings.md`，而非直接修改 |
| 验证方式选择错误 | 严格按 task 类型选验证方式 | 补充缺失的验证，补录验证日志 |
| 连续失败时未暂停 | op-build 每轮决策检查 `fail_count >= 3`，触发不可跳过 | 手动暂停，加载 `systematic-debugging` |
| tasks.md 与 op.yaml 进度不一致 | 以 op.yaml 的 done_count 为准，tasks.md 用于参考 | 以提交历史为准重新统计，修正两个文件 |
