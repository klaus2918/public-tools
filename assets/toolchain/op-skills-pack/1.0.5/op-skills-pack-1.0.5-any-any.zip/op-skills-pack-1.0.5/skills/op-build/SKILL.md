---
name: op-build
category: core
status: active
phase_role: build
description: 执行阶段 skill。按 plan.md + tasks.md 逐项实现并验证，兑现执行约束，内嵌 G5/G7/G8 质量门禁。
version: "3.6.0"
updated_at: 2026-09-14
dispatches:
  - op-browser
  - op-worktree
---

# op-build — 执行阶段 Skill

## Overview

读取 plan.md 执行约束 + tasks.md 任务清单，逐项实现并验证。完成后 phase 转 done。

---

## Quick Reference

| Command | Action |
|---------|--------|
| `/op-build [<change>]` | 启动或恢复构建流程 |
| `/op-build status [<change>]` | 查看构建进度 |

---

## Core Flow

### 0. 启动守卫（文档优先 P14 / 确认放行 P6）

逐项校验，任一不满足 → **STOP，回 op-plan**，禁止执行：

| 校验项 | 条件 | 不满足时 |
|--------|------|---------|
| 方案存在 | feature/complex：`plan.md` 存在 | STOP 回 plan：先出方案 |
| 用户已确认 | `plan.md` frontmatter `confirmed: true` | STOP 回 plan：等用户确认 |
| 确认来源合法 | `confirmed: true` 必须由用户显式确认后设置，**agent 禁止自行写入** | STOP：等待用户确认 |
| 阶段正确 | `change.yaml.phase == build` | STOP：由 `/op` 路由，不得直接执行 |

**禁止**：无 plan 直接开干（文档优先）；plan 未确认就执行（确认是放行凭证）；绕过 `/op` 进入 build；agent 自行写 `confirmed: true`。

**确认流程**：plan.md 创建后，agent 必须向用户展示方案并请求确认，用户明确同意后才能继续；不得跳过展示，不得以「需求明确 / 改动很小」为由跳过确认。

### 1. 读取执行约束

读取 plan.md 顶部 execution YAML，确认约束：

| 约束 | 行为 |
|------|------|
| `allow_commit: false` | 不提交任何 git 写操作 |
| `allow_commit: true` | 允许 commit，不允许 push（除非 allow_push: true） |
| `use_worktree: false` | 在当前目录执行 |
| `use_worktree: true` | 进入 plan 创建的 worktree |
| `browser_verification: none` | 不做浏览器验证 |
| `browser_verification: optional` | 失败记录 WARN，不阻塞 |
| `browser_verification: required` | 失败阻塞，不标记 done |
| `browser_screenshot_read: false` | 浏览器验证用文本/DOM 断言（verify_mode="dom"），不读截图；`true` 才允许截图对比与读图确认 |
| `parallel_mode: serial` | 逐 task 串行 |
| `parallel_mode: dag` | 同 wave root task 可并行 |

### 2. 知识库检索（强制）

扫描 tasks.md 各 task title 关键词，调 `/op-knowledge search` 检索可复用能力/踩坑经验。
知识库配置缺失时按 op-knowledge「消费方接入协议」询问用户，**禁止静默跳过**。

### 3. 逐任务循环

```
对每个未完成 task：
  │
  ├─ 3a. 读取 task 详情
  ├─ 3a+. 知识库检索（强制）：从 task title 提取关键词检索知识库，命中时先阅读经验再动手
  ├─ 3b. 设计资产按需披露（有 design-contract/design-tags 时）
  ├─ 3c. 执行纪律检查（G5）：确认有验证手段再动手
  ├─ 3d. 术语约束检查（G2 延续）：使用 plan.md 术语表
  ├─ 3e. 实现（含 TDD 红绿循环 G7）
  ├─ 3f. 写后校验（validate-text / validate-java）
  ├─ 3g. 验证（按 verify 字段类型）
  ├─ 3h. 失败处理（3 次 → 调试流程）
  └─ 3i. 标记 done，更新进度
```

**状态标记格式（强制）**：只修改 tasks.md 中对应 task 的 YAML `status` 字段：

| 操作 | 修改方式 |
|------|---------|
| 开始执行 | `status: pending` → `status: in_progress` |
| 验证通过 | `status: in_progress` → `status: done` |
| 主动跳过 | `status: pending/in_progress` → `status: skipped`（需记录跳过原因） |

**禁止**：修改 task 的 `id` / `title` / `depends` / `verify` 等结构性字段——只改 `status`。

**依赖检查（DAG）**：task 的 `depends` 非空时，检查所有依赖 task 的 status 是否为 `done`；未完成 → 当前 task 不可开始。

### 4. 实现审查（G8）

全部 task 完成后，双轴审查：

- **规范轴**：改动文件是否符合项目编码规范
- **实现轴**：对照 plan.md 和 tasks.md，需求覆盖完整性、范围蔓延、验收标准

审查结果写入 `.op/verify-log.md`，供 op-done 阶段人审阅。

### 5. phase = done

所有 task 完成 + 审查通过 → `change.yaml.phase = done`

---

## 产物归位规则

执行过程中产生的文件按类型归位：

| 产物类型 | 归属位置 | 示例 |
|----------|---------|------|
| 变更交付材料 | `.op/changes/<name>/`（与 plan.md 平级） | SQL 脚本、数据迁移脚本、配置变更脚本 |
| 过程记录 | `.op/changes/<name>/`（与 plan.md 平级） | 验证记录、分析报告、verify-log.md |
| 项目源代码 | 项目代码库对应模块 | Java/前端源码、正式 migration |

**禁止**：SQL 等执行产物散落在项目根、代码目录或临时目录——交付材料进任务目录，归档时随变更保留。

---

## DAG 并行模式

当 `parallel_mode: dag` 且 tasks.md 有 depends 字段时：

- 同 wave root task 通过 subagent 并行派发
- 最大并发数 4
- 每个 subagent 完成后独立审查
- 结果合并回 tasks.md

> 详细流程见 references/dag-parallel.md

---

## 连续失败处理

连续 3 次验证失败，触发调试流程：

```
A. 重试（重置失败计数）
B. 跳过 task（记录原因）
C. 根因分析（四阶段：调查→模式→假设→实现）
D. 放弃执行，回退 plan 阶段
```

> 详细步骤见 references/debug-flow.md

---

## 恢复机制

不使用 resume.yaml。恢复靠：
1. tasks.md 中每个 task 的 YAML `status` 字段（唯一事实源）
2. plan.md 中的执行约束
3. change.yaml.phase 确认当前阶段

**恢复流程**：
1. 读取 tasks.md，解析所有 task 的 status 字段
2. 跳过 `status: done` 与 `status: skipped`
3. 从第一个 `status: pending` 或 `status: in_progress` 的 task 继续
4. `status: in_progress` 视为上次中断点，**从该 task 重新开始**（不信任半完成状态）

---

## Red Flags — STOP

| Smell | Action |
|-------|--------|
| Scope extends beyond the current task | Stop; flag as finding |
| User skips verification | Verification is mandatory |
| 在 build 阶段执行 git 操作（allow_commit: false 时） | 禁止 |
| Task makes previous completed tasks invalid | Revert and re-verify |
| plan.md 缺失或非 `confirmed: true` | STOP：回 op-plan，先出方案并等用户确认 |
| agent 自行写入 `confirmed: true` | STOP：确认必须来自用户，agent 禁止自行设置 |
| 创建 plan.md 时直接标记 `confirmed: true` | STOP：先展示方案，等用户确认后再设置 |
| SQL 等执行产物写在变更目录外 | 移入 `.op/changes/<name>/`，与 plan.md 平级 |
| 修改 tasks.md 结构字段（id/title/depends/verify） | STOP：只允许修改 `status` |
| 跳过知识库检索直接实现 | STOP：先 `/op-knowledge search`，有命中先读经验再动手 |

---

## Common Mistakes

- **Skipping verification.** Every task must be verified.
- **Editing plan.md or tasks.md format.** Only mark task status.
- **在 build 阶段执行 git 写操作（allow_commit: false 时）.** Git 提交属于 done 阶段。
- **无 plan 或未确认就执行。** 启动守卫四项校验缺一不可（plan.md 存在 / `confirmed: true` / 确认来源合法 / phase==build）。
- **agent 自行设置 `confirmed: true`。** 确认是用户放行凭证；常见借口「需求很简单」「改动很小」都是 rationalization，必须拒绝。
- **执行产物散落在任务目录外。** SQL 等交付材料写 `.op/changes/<name>/`。
- **修改 tasks.md 的结构字段。** id/title/depends/verify 在 plan 阶段确定后不可改；build 只改 `status`。
- **不查知识库直接实现。** 典型失败：花 2 小时从零实现，而知识库已有完整方案（根因是知识检索曾被标为「可选」）。
- **恢复时信任 in_progress 状态。** `status: in_progress` 表示上次中断，必须从该 task 重新开始。

---

### G7+ 完成即复核（每任务完成时，4 查）

> 来源：外部参考 grill-me 的「/implement 完成即跑 /code-review」位置；纳入 G7 同一步骤执行，不新增独立阶段。

| 查 | 内容 | 不合格处置 |
|:--:|------|-----------|
| 1 | **可追溯**：每行改动都能指回原始请求（宪法「外科式改动」） | 删除不可追溯的改动 |
| 2 | **孤儿产物**：是否留下无用文件 / 临时脚本 / 失效引用 | 清理后重查 |
| 3 | **失效引用**：被改动的文档、调用点是否仍指向存在的目标 | 修正引用 |
| 4 | **影响面一致**：实际改动范围 vs plan.md「影响面」是否一致 | 超范围则回 plan 补记或回退 |

- 复核结果记入任务状态备注；**4 查任一不合格 → 该任务不得标记 done**；
- 与 G6 分工：G6 在阶段末做事后审视（偏离记录 / 清理 / 沉淀 / 归档）；本项在**每个任务完成时**做小循环。

## Version

| Field | Value |
|-------|-------|
| Skill | op-build |
| Version | 3.6.0 |
| Updated | 2026-09-14 |
| Key change | v3.6.0: G7 并入「完成即复核」4 查（可追溯/孤儿产物/失效引用/影响面一致）；v3.5.0: 知识库检索由「可选」改为 task 执行前强制步骤（3a+）；v3.4.0: 状态标记格式强制（只改 YAML `status`）+ DAG 依赖检查 + 恢复流程细化（in_progress 视为中断点重做）；v3.3.0: 启动守卫新增「确认来源合法」校验（agent 禁止自行写入 `confirmed: true`）；v3.1.0: 新增 §0 启动守卫 + 产物归位规则 |
| References | `references/dag-parallel.md`（DAG 并行）· `references/debug-flow.md`（连续失败调试）· `references/verify-commands.md`（验证命令）· `references/verify-mapping.md`（verify 映射）· `references/common-errors.md`（常见错误） |
