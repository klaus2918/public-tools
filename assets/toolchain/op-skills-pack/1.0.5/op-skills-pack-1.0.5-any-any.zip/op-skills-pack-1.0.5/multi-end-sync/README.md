# 多端同步

机制：仓库是唯一事实源（git 管理），各工具 skills 目录经 Junction 指向仓库，修改仓库即各端生效，无需同步动作。

已接入端（tools.yaml 登记 8 端，去重后口径）：claude / codex（C:/E: 同一实体）/ jcode / **opencode**（2026-08-16 接入，skills 目录 `~/.config/opencode/skills`，经 `opencode debug skill` 验证可发现）/ cc-switch（C:/E: 同一实体）/ reasonix（仅 java-fs）/ zcode（2026-08-04 接入）/ **commandcode**（2026-09-13 接入，Command Code npm 全局包 `command-code`，用户级 skills 目录 `~/.commandcode/skills/`，18 条 Junction 经 `command-code skills list -d` 实证可发现）。

端清单由 **`tools.yaml` 单一事实源**驱动（本目录内，随包分发）。各端含 `probe` 探测路径：claude/codex/opencode 等工具并非每台机器都安装，`active: auto` 下 probe 存在才接入，未装端自动跳过。新增工具端只需在 tools.yaml 登记。

## 用法

```powershell
sync-skills.ps1                              # 建/修 Junction（幂等，含悬空链接解链重建）
sync-skills.ps1 -Status                      # 校验各端 Junction + cc-switch 注册表 + 白名单；存在不一致时退出码 1
sync-skills.ps1 -Register <name> -Claude 1 -Codex 1   # 注册并授权
sync-skills.ps1 -CleanBackups -ConfirmClean  # 清理 .bak-* 残留
```

脚本为 UTF-8 BOM 编码（PowerShell 5.1 中文兼容）。路径基于脚本位置与 USERPROFILE 推导，无需手工配置。

`tools.yaml` 字段：`name` / `skills_dir`（Junction 目标）/ `probe`（存在性探测，active: auto 时决定接入）/ `active`（auto=true 探测、true 强制、false 排除）/ `skills`（null=全量白名单，列表=仅该端接入的 skill）/ `constitution`（true=在 skills_dir 父目录维护 constitution junction；false=跳过，适用于指令文件型端）。改端清单只改 tools.yaml，不改脚本。

**指令文件型端（constitution: false）**：Command Code 读取的是用户级记忆文件 `~/.commandcode/AGENTS.md`（非目录），故不走 constitution junction；宪法分发按 `constitution/README.md` 用复制方式完成，由各端自行维护副本。

## 维护规则

1. 修改 skill：只编辑仓库 `<skill>/`，保存即各端生效，禁止直接编辑工具目录
2. 新增 skill：仓库建目录 + SKILL.md → `sync-skills.ps1` 建链 → `-Register` 注册
3. 删除 skill：仓库删目录 → 各端删 Junction
4. `.java` 文件一律用 `/java-fs` 读写（透明加密环境）
5. git 写操作一律经 `/safe-git-write`
6. 非白名单 skill（frontend-design、pdf 等）保留实体，不链接
7. 新增工具端：在 `tools.yaml` 登记（含 probe），跑一次 sync 验证自动建链
8. 提交前：`sync-skills.ps1 -Status` 全 OK

## 演化资产（10 条挂载点映射）

| skill 内路径 | 挂载点（.basic/evolved/） | 说明 |
|-------------|---------------------------|------|
| op-html/sites | op-html/sites | junction（站点资产） |
| op-browser/projects | op-browser/projects | junction（项目资产） |
| op-browser/tasks | op-browser/tasks | junction（任务资产） |
| op-design-extract/shared | op-design-extract/shared | junction（共享资产） |
| op-design-extract/catalog | op-design-extract/catalog | junction（设计目录） |
| op-done/config | op-done/config | junction（配置） |
| op-worktree/workspaces | op-worktree/workspaces | junction（worktree 登记） |
| browser-agent-bridge/runtime | browser-agent-bridge/runtime | junction（运行时） |
| op-knowledge/config | op-knowledge/config | junction（知识库连接配置；模板在 `references/knowledge-bases.example.yaml`） |
| op-release/config | op-release/config | junction（环境实例配置；模板在 `references/config-example.yaml`） |

演化资产（运行产物/个人知识/环境配置）只存在于 `.basic/evolved/`，不随包分发。打包包仅含 10 个挂载点空目录，目标机按上表重建 Junction 指向自己的资产存储。

> **模板与真实配置分离**：所有环境相关模板（`knowledge-bases.example.yaml`、`config-example.yaml` 等）随包放在各 skill 的 `references/`；真实配置写入挂载点 `config/`（即 `.basic/evolved/<skill>/config/`），不入 git、不随包分发。挂载点检查/创建：`powershell -NoProfile -File skills/op-000/scripts/op-000-mount-sync.ps1 [-Status]`；隔离自检：`bash skills/op-000/scripts/op-000-isolation-check.sh`。
