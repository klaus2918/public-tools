﻿# sync-skills.ps1 - op-skills 统一维护入口
# 确保仓库中的 skill 修改/新增/删除在各端生效。

# 五种模式：
# 1. Sync（默认）：将仓库管理的 skill 以 Junction 方式同步到各工具 skills 目录
#    （claude / codex / jcode / cc-switch / zcode / reasonix），幂等。
#    若存在本机接入选择文件 .op/multi-end-selection.yaml，则按选择建链（端 enabled + skill 子集）；
#    选择文件缺失时回退本条默认行为（tools.yaml + probe 全量）。
# 2. Status（-Status）：全面校验并报告一致性（仓库 ↔ .cc-switch/skills ↔ cc-switch
#    skills 表 ↔ 各端 Junction），不做任何修改。存在任何不一致时退出码为 1。
# 3. Plan（-Plan）：只读探测各端可用性并生成接入建议文件
#    .op/multi-end-selection.suggested.yaml（人工确认后另存为 multi-end-selection.yaml 生效）。
# 4. Register（-Register <name>）：把仓库已有、.cc-switch/skills 已有 Junction 的 skill
#    注册进 cc-switch skills 表（授权开关默认 claude=1 / codex=0，可用 -Claude/-Codex 覆盖）。
# 5. CleanBackups（-CleanBackups）：删除各端 skills 目录下 *.bak-* 残留（需 -ConfirmClean）。

# 用法：
#   sync-skills.ps1 -Status                 # 全面校验
#   sync-skills.ps1                          # 同步全部端
#   sync-skills.ps1 -Register java-fs -Claude 1 -Codex 1
#   sync-skills.ps1 -CleanBackups -ConfirmClean
param(
  [string]$Target,
  [switch]$CheckOnly,
  [switch]$Status,
  [switch]$Plan,
  [string]$Register,
  [int]$Claude = 1,
  [int]$Codex = 0,
  [switch]$CleanBackups,
  [switch]$ConfirmClean
)

$ErrorActionPreference = 'Stop'

# ---- 路径推导（可移植：基于脚本位置与 USERPROFILE，接收方无需修改） ----
$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$userName = Split-Path $env:USERPROFILE -Leaf
$ccSwitchDir = Join-Path $env:USERPROFILE '.cc-switch'
$ccSwitchDb = Join-Path $ccSwitchDir 'cc-switch.db'
$ccSwitchSkills = Join-Path $ccSwitchDir 'skills'

# ---- 目标端定义（由 tools.yaml 单一事实源驱动） ----
# tools.yaml 位于脚本同目录（打包后 multi-end-sync/）或仓库 docs/package/multi-end-sync/。
# 各端 probe 路径存在才接入（active: auto），claude/codex/opencode 等未安装端自动跳过。
function Find-ToolsYaml {
  $cand = @(
    (Join-Path $PSScriptRoot 'tools.yaml'),
    (Join-Path $repoRoot 'docs\package\multi-end-sync\tools.yaml')
  )
  foreach ($c in $cand) { if (Test-Path -LiteralPath $c) { return $c } }
  throw 'tools.yaml not found (script dir or docs\package\multi-end-sync\)'
}

function Expand-EnvPath([string]$p) {
  # expand %VAR% placeholders (paths in tools.yaml use %USERPROFILE% etc.)
  foreach ($m in [regex]::Matches($p, '%([^%]+)%')) {
    $name = $m.Groups[1].Value
    $val = [Environment]::GetEnvironmentVariable($name)
    if ($val) { $p = $p.Replace($m.Value, $val) }
  }
  return $p
}

# ---- python 解释器探测 ----
# 背景：Windows 上 `python` 常不在 PATH（可能只有 py launcher 或 python3），
# 硬编码 `python` 会让 -Status / -Register 在 cc-switch 表读取处直接抛异常。
function Get-PyCmd {
  foreach ($c in @('py', 'python3', 'python')) {
    if (-not (Get-Command $c -ErrorAction SilentlyContinue)) { continue }
    try {
      & $c -c 'import sys' 2>$null | Out-Null
      if ($LASTEXITCODE -eq 0) { return $c }
    } catch { }
  }
  return $null
}

function Read-ToolsYaml {
  # parse the simplified tools.yaml subset: name / skills_dir / probe / active / skills / constitution
  $yamlFile = Find-ToolsYaml
  $tools = @()
  $cur = $null
  foreach ($line in [IO.File]::ReadAllLines($yamlFile, [Text.Encoding]::UTF8)) {
    $t = $line.Trim()
    if (-not $t -or $t.StartsWith('#')) { continue }
    if ($t -match '^-\s*name:\s*(.+)$') {
      if ($cur) { $tools += $cur }
      $cur = [PSCustomObject]@{ Name = $Matches[1].Trim(); Path = $null; Probe = $null; Active = 'auto'; Skills = $null; Constitution = 'true' }
      continue
    }
    if (-not $cur) { continue }
    if ($t -match '^skills_dir:\s*"(.+)"\s*$') { $cur.Path = Expand-EnvPath $Matches[1] }
    elseif ($t -match '^probe:\s*"(.+)"\s*$') { $cur.Probe = Expand-EnvPath $Matches[1] }
    elseif ($t -match '^active:\s*(.+)$') { $cur.Active = $Matches[1].Trim() }
    elseif ($t -match '^constitution:\s*(.+)$') { $cur.Constitution = $Matches[1].Trim() }
    elseif ($t -match '^skills:\s*\[(.*)\]\s*$') {
      $inner = $Matches[1].Trim()
      if ($inner) { $cur.Skills = @($inner -split ',' | ForEach-Object { $_.Trim() }) }
    }
  }
  if ($cur) { $tools += $cur }
  return $tools
}

$targets = @()
foreach ($tool in (Read-ToolsYaml)) {
  # active: auto -> probe exists decides; true -> force; false -> exclude
  if ($tool.Active -eq 'false') { continue }
  if ($tool.Active -eq 'auto') {
    if ($tool.Probe -and -not (Test-Path -LiteralPath $tool.Probe)) {
      Write-Output "[skip] tool not installed (probe missing): $($tool.Name) ($($tool.Probe))"
      continue
    }
    if (-not $tool.Probe -and -not (Test-Path -LiteralPath $tool.Path)) { continue }
  }
  $targets += $tool
}

if ($Target) {
  $targets = $targets | Where-Object { $_.Name -eq $Target }
  if (-not $targets) { Write-Error "unknown target: $Target"; exit 1 }
}

# ---- 本机接入选择（.op/multi-end-selection.yaml，本地不入库；缺失 → 回退现状全量）----
function Read-Selection([string]$root) {
  $cands = @(
    (Join-Path $root '.op\multi-end-selection.yaml'),
    (Join-Path (Join-Path $root '..') '.op\multi-end-selection.yaml')
  )
  foreach ($c in $cands) {
    if (Test-Path -LiteralPath $c) {
      $sel = @{}
      $cur = $null
      foreach ($ln in [IO.File]::ReadAllLines($c, [Text.Encoding]::UTF8)) {
        $t = $ln.Trim()
        if (-not $t -or $t.StartsWith('#')) { continue }
        if ($t -match '^-\s*name:\s*(.+)$') {
          $cur = $Matches[1].Trim()
          $sel[$cur] = @{ Enabled = $true; Skills = $null }
          continue
        }
        if (-not $cur) { continue }
        if ($t -match '^enabled:\s*(.+)$') { $sel[$cur].Enabled = ($Matches[1].Trim() -eq 'true') }
        elseif ($t -match '^skills:\s*\[(.*)\]\s*$') {
          $inner = $Matches[1].Trim()
          if ($inner) { $sel[$cur].Skills = @($inner -split ',' | ForEach-Object { $_.Trim() }) }
        }
      }
      return $sel
    }
  }
  return $null
}

$selection = Read-Selection $repoRoot
if ($selection) {
  Write-Output "接入选择已加载（.op/multi-end-selection.yaml）：$($selection.Keys.Count) 个端"
  $targets = $targets | Where-Object {
    $s = $selection[$_.Name]
    if ($null -eq $s) { return $true }   # 未列出的端：保持 probe 默认
    return [bool]$s.Enabled               # 显式选择生效
  }
  foreach ($t in $targets) {
    $s = $selection[$t.Name]
    if ($s -and $s.Skills) { $t.Skills = $s.Skills }   # 选择文件覆盖 skill 子集
  }
}

# ---- skill 启停状态（.op/skill-state.yaml，本地不入库）----
# 契约：skills/op-000/references/skill-classification.md（tier=core 不可停用，由 op-000-skill-toggle.sh 保证）
# 停用的 skill 不建链、不参与 -Status 白名单比对
function Read-DisabledSkills([string]$root) {
  $cands = @((Join-Path $root '.op\skill-state.yaml'), (Join-Path (Join-Path $root '..') '.op\skill-state.yaml'))
  foreach ($c in $cands) {
    if (Test-Path -LiteralPath $c) {
      $names = @()
      foreach ($ln in (Get-Content -LiteralPath $c -Encoding UTF8)) {
        $m = [regex]::Match($ln, '^\s*-\s*(\S+)\s*$')
        if ($m.Success) { $names += $m.Groups[1].Value }
      }
      return $names
    }
  }
  return @()
}
$disabledSkills = Read-DisabledSkills $repoRoot

# ---- 白名单：skills/ 下含 SKILL.md 的目录（排除停用项） ----
$repoSkillsDir = Join-Path $repoRoot 'skills'
$whitelist = Get-ChildItem -Directory $repoSkillsDir -Force |
  Where-Object { $_.Name -notin @('.git', '.op', '.claude', '.basic', '.reasonix', 'docs', '废弃') -and ($_.Name -notin $disabledSkills) -and (Test-Path (Join-Path $_.FullName 'SKILL.md')) } |
  Select-Object -ExpandProperty Name | Sort-Object

# ---- constitution（全局宪法）目标：仓库根 constitution/ ----
$repoConstitution = Join-Path $repoRoot 'constitution'

function Test-IsConstitutionOk([string]$path) {
  if (-not (Test-Path -LiteralPath $path)) { return 'missing' }
  $item = Get-Item -LiteralPath $path -Force
  if ($item.LinkType -eq 'Junction' -and ($item.Target -join '') -eq $repoConstitution) { return 'ok' }
  if ($item.LinkType) { return 'wrong-link' }
  return 'entity'
}

function Sync-Constitution([string]$toolHome, [string]$toolName) {
  # 在工具主目录（skills_dir 的父目录）下维护 constitution junction → 仓库根 constitution/
  $constPath = Join-Path $toolHome 'constitution'
  if (-not (Test-Path -LiteralPath $repoConstitution)) { return }
  $st = Test-IsConstitutionOk $constPath
  if ($st -eq 'ok') { Write-Output "  [constitution] 已就绪 -> $repoConstitution"; return }
  if ($st -eq 'wrong-link') {
    if ($CheckOnly) { Write-Output "  [constitution] 指向错误: $((Get-Item -LiteralPath $constPath -Force).Target -join ';')"; return }
    cmd /c rmdir "$constPath" 2>&1 | Out-Null
    New-Item -ItemType Junction -Path $constPath -Target $repoConstitution | Out-Null
    Write-Output "  [constitution] 修正指向 -> $repoConstitution"
    return
  }
  if ($st -eq 'entity') {
    if ($CheckOnly) { Write-Output '  [constitution] 实体目录（待迁移）'; return }
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    Rename-Item -LiteralPath $constPath -NewName "constitution.bak-$stamp"
    New-Item -ItemType Junction -Path $constPath -Target $repoConstitution | Out-Null
    Write-Output "  [constitution] 实体已备份并链接 -> $repoConstitution"
    return
  }
  if ($CheckOnly) { Write-Output '  [constitution] 缺失（待建）'; return }
  New-Item -ItemType Junction -Path $constPath -Target $repoConstitution | Out-Null
  Write-Output "  [constitution] 新建链接 -> $repoConstitution"
}

function Test-IsJunctionToRepo([string]$path) {
  if (-not (Test-Path -LiteralPath $path)) { return $false }
  $item = Get-Item -LiteralPath $path -Force
  if ($item.LinkType -ne 'Junction') { return $false }
  return ($item.Target -join '') -eq (Join-Path $repoSkillsDir (Split-Path $path -Leaf))
}

function Get-SkillState([string]$targetPath) {
  $item = Get-Item -LiteralPath $targetPath -Force -ErrorAction SilentlyContinue
  if (-not $item) { return 'missing' }
  if ($item.LinkType -eq 'Junction') {
    if (-not (Test-Path -LiteralPath $targetPath)) { return 'dangling' }
    if (Test-IsJunctionToRepo $targetPath) { return 'ok' } else { return 'wrong-link' }
  }
  return 'entity'
}

function Get-CcSwitchSkillsTable {
  # 用 python 读取 cc-switch skills 表，返回行数组（解释器经 Get-PyCmd 探测）
  $pyCmd = Get-PyCmd
  if (-not $pyCmd) {
    Write-Output '  [警告] 未找到可用 python 解释器（尝试 py/python3/python），跳过 cc-switch 表读取'
    return
  }
  $env:CCSWITCH_DB = $ccSwitchDb
  $py = 'import os,sqlite3; conn=sqlite3.connect(os.environ["CCSWITCH_DB"]); cur=conn.cursor(); cur.execute("SELECT directory, enabled_claude, enabled_codex FROM skills ORDER BY directory"); [print(r[0]+"|claude="+str(r[1])+"|codex="+str(r[2])) for r in cur.fetchall()]; conn.close()'
  $prevOE = $OutputEncoding
  $OutputEncoding = New-Object System.Text.UTF8Encoding($false)  # 无 BOM，防 U+FEFF 泄漏到 python stdin
  try { $result = ($py | & $pyCmd -) } finally { $OutputEncoding = $prevOE }
  return $result
}

# ================= Plan 模式（只读：探测 + 生成接入建议） =================
if ($Plan) {
  Write-Output '========== 接入建议 (Plan) =========='
  $sugPath = Join-Path $repoRoot '.op\multi-end-selection.suggested.yaml'
  $lines = @()
  $lines += '# 多端接入建议（由 sync-skills.ps1 -Plan 生成；确认/编辑后另存为 multi-end-selection.yaml 生效）'
  $lines += '# 本机文件：不入库、不随包分发'
  $lines += 'version: 1'
  $lines += "generated_at: `"$((Get-Date).ToString('yyyy-MM-ddTHH:mm:sszzz'))`""
  $lines += 'tools:'
  foreach ($tool in (Read-ToolsYaml)) {
    $probeOk = $true
    if ($tool.Probe) { $probeOk = Test-Path -LiteralPath $tool.Probe }
    $sugEnabled = (($tool.Active -ne 'false') -and $probeOk)
    $lines += "  - name: $($tool.Name)"
    if ($sugEnabled) { $lines += '    enabled: true' } else { $lines += '    enabled: false' }
    if ($tool.Skills) { $lines += "    skills: [$($tool.Skills -join ', ')]" } else { $lines += '    skills: null' }
    $mark = if ($probeOk) { '可用' } else { '未安装（建议跳过）' }
    Write-Output ("  {0,-14} {1}" -f $tool.Name, $mark)
  }
  $sugDir = Split-Path $sugPath -Parent
  if (-not (Test-Path -LiteralPath $sugDir)) { New-Item -ItemType Directory -Path $sugDir -Force | Out-Null }
  [IO.File]::WriteAllText($sugPath, (($lines -join "`n") + "`n"), (New-Object Text.UTF8Encoding($false)))
  Write-Output ''
  Write-Output "建议文件已生成：$sugPath"
  Write-Output '（确认/编辑后另存为 multi-end-selection.yaml 即生效；不保存则保持现状全量）'
  exit 0
}

# ================= Status 模式 =================
if ($Status) {
  Write-Output '========== 全面校验 (Status) =========='
  Write-Output "仓库白名单（$($whitelist.Count) 个）: $($whitelist -join ', ')"
  if ($disabledSkills.Count -gt 0) {
    Write-Output "已停用（按 .op/skill-state.yaml 跳过，不建链）: $($disabledSkills -join ', ')"
  }
  Write-Output ''
  $problemFound = $false

  foreach ($t in $targets) {
    Write-Output "--- 端: $($t.Name) ($($t.Path)) ---"
    if (-not (Test-Path -LiteralPath $t.Path)) { Write-Output '  [跳过] 目录不存在'; continue }
    $skills = if ($t.Skills) { $t.Skills } else { $whitelist }
    $ok = @(); $entity = @(); $missing = @(); $wrong = @(); $dangling = @()
    foreach ($skill in $skills) {
      $st = Get-SkillState (Join-Path $t.Path $skill)
      if ($st -eq 'ok') { $ok += $skill }
      elseif ($st -eq 'entity') { $entity += $skill }
      elseif ($st -eq 'wrong-link') { $wrong += $skill }
      elseif ($st -eq 'dangling') { $dangling += $skill }
      else { $missing += $skill }
    }
    if ($ok.Count -gt 0) { Write-Output "  [OK] $($ok.Count) 个: $($ok -join ', ')" }
    if ($entity.Count -gt 0) { Write-Output "  [实体残留] $($entity -join ', ')" }
    if ($missing.Count -gt 0) { Write-Output "  [缺失] $($missing -join ', ')" }
    if ($wrong.Count -gt 0) { Write-Output "  [链接指向错误] $($wrong -join ', ')" }
    if ($dangling.Count -gt 0) { Write-Output "  [悬空链接] $($dangling -join ', ')" }
    if ($entity.Count -gt 0 -or $missing.Count -gt 0 -or $wrong.Count -gt 0 -or $dangling.Count -gt 0) { $problemFound = $true }

    # constitution 校验（skills_dir 父目录下的 constitution junction）
    if ($t.Constitution -ne 'false') {
      $constState = Test-IsConstitutionOk (Join-Path (Split-Path $t.Path -Parent) 'constitution')
      if ($constState -ne 'ok') {
        Write-Output "  [constitution-$constState] 全局宪法链接异常"
        $problemFound = $true
      }
    }
  }
  Write-Output ''

  Write-Output '--- cc-switch skills 表 vs 目录 vs 仓库 ---'
  if (Test-Path $ccSwitchDb) {
    $dbRows = Get-CcSwitchSkillsTable
    $regDirs = @()
    $registered = @()
    foreach ($line in $dbRows) {
      $parts = $line -split '\|'
      if ($parts[0]) {
        $regDirs += $parts[0]
        $registered += [PSCustomObject]@{ Dir = $parts[0]; Claude = $parts[1]; Codex = $parts[2] }
      }
    }
    $dirInCc = Get-ChildItem -Directory $ccSwitchSkills -Force | Where-Object { $_.Name -notlike '*.bak-*' } | Select-Object -ExpandProperty Name
    $inRepoNotReg = $whitelist | Where-Object { $_ -notin $regDirs }
    $regNotInRepo = $regDirs | Where-Object { $_ -notin $whitelist }
    $inCcNotReg = $dirInCc | Where-Object { $_ -notin $regDirs -and $_ -in $whitelist }
    Write-Output "  注册表共 $($regDirs.Count) 条"
    Write-Output "  仓库有但未注册: $(if ($inRepoNotReg) { $inRepoNotReg -join ', ' } else { '无' })"
    Write-Output "  已注册但仓库无: $(if ($regNotInRepo) { $regNotInRepo -join ', ' } else { '无' })"
    Write-Output "  目录有 Junction 但未注册: $(if ($inCcNotReg) { $inCcNotReg -join ', ' } else { '无' })"
    $codexEnabled = $registered | Where-Object { $_.Codex -eq "codex=1" }
    Write-Output "  codex 已授权: $(if ($codexEnabled) { ($codexEnabled | ForEach-Object { $_.Dir }) -join ', ' } else { '无' })"
  } else {
    Write-Output "  [警告] cc-switch db 不存在: $ccSwitchDb"
  }
  Write-Output '========== 校验完成 =========='
  if ($problemFound) {
    Write-Error '校验未通过：存在实体残留/缺失/链接错误/悬空链接，请修复后重跑'
    exit 1
  }
  Write-Output '全部一致，校验通过'
  exit 0
}

# ================= Register 模式 =================
if ($Register) {
  $name = $Register
  $repoSkill = Join-Path $repoSkillsDir $name
  $ccJunction = Join-Path $ccSwitchSkills $name
  if (-not (Test-Path $repoSkill)) { Write-Error "仓库中无此 skill: $name"; exit 1 }
  if (-not (Test-Path $ccJunction)) { Write-Error ".cc-switch/skills 中无 Junction: $name（先跑 sync 建链接）"; exit 1 }
  if (-not (Test-Path $ccSwitchDb)) { Write-Error 'cc-switch db 不存在'; exit 1 }

  $hash = (Get-FileHash (Join-Path $repoSkill 'SKILL.md') -Algorithm SHA256).Hash.ToLower()
  $ts = [int][double]::Parse((Get-Date -UFormat %s))
  $py = 'import sqlite3; db=r"' + $ccSwitchDb + '"; conn=sqlite3.connect(db); cur=conn.cursor(); cur.execute("SELECT id FROM skills WHERE directory=?;", ("' + $name + '",)); exists=cur.fetchone();' +
        ' cur.execute("UPDATE skills SET enabled_claude=?, enabled_codex=?, content_hash=?, updated_at=? WHERE directory=?;", (' + $Claude + ', ' + $Codex + ', "' + $hash + '", ' + $ts + ', "' + $name + '")); print("updated") if exists else None;' +
        ' cur.execute("INSERT OR IGNORE INTO skills (id, name, description, directory, repo_owner, repo_name, repo_branch, readme_url, enabled_claude, enabled_codex, enabled_gemini, enabled_opencode, enabled_hermes, enabled_grokbuild, installed_at, content_hash, updated_at) VALUES (?, ?, ?, ?, NULL, NULL, ''main'', NULL, ?, 0, 0, 0, 0, 0, ?, ?, 0);", ("local:' + $name + '", "' + $name + '", "", "' + $name + '", ' + $Claude + ', ' + $ts + ', "' + $hash + '")); print("inserted") if not exists else None; conn.commit(); conn.close()'
  $pyCmd = Get-PyCmd
  if (-not $pyCmd) { Write-Error '未找到可用 python 解释器（尝试 py/python3/python），无法写入 cc-switch 注册表'; exit 1 }
  $prevOE = $OutputEncoding
  $OutputEncoding = New-Object System.Text.UTF8Encoding($false)  # 无 BOM
  try { $py | & $pyCmd - } finally { $OutputEncoding = $prevOE }
  Write-Output "已注册 $name 到 cc-switch（claude=$Claude, codex=$Codex）"
  Write-Output '提示：若 cc-switch 正在运行，UI 中可见变化；授权开关后续可在 cc-switch UI 中调整。'
  exit 0
}

# ================= CleanBackups 模式 =================
if ($CleanBackups) {
  if (-not $ConfirmClean) { Write-Error '破坏性操作：需加 -ConfirmClean 确认'; exit 1 }
  foreach ($t in $targets) {
    if (-not (Test-Path -LiteralPath $t.Path)) { continue }
    Get-ChildItem -Directory $t.Path -Force | Where-Object { $_.Name -like '*.bak-*' } | ForEach-Object {
      Write-Output "删除: $($_.FullName)"
      Remove-Item -LiteralPath $_.FullName -Recurse -Force
    }
  }
  Write-Output '备份清理完成'
  exit 0
}

# ================= Sync 模式（默认） =================
Write-Output "白名单（仓库管理的 skill，共 $($whitelist.Count) 个）："
Write-Output ($whitelist -join ', ')
Write-Output ''

$summary = @()
foreach ($t in $targets) {
  Write-Output "======== 目标端: $($t.Name) ($($t.Path)) ========"
  if (-not (Test-Path -LiteralPath $t.Path)) {
    # Tool installed (probe exists) but skills dir missing: create it, then
    # proceed with linking. Otherwise skip (e.g. probe itself missing).
    if ($t.Probe -and (Test-Path -LiteralPath $t.Probe)) {
      New-Item -ItemType Directory -Path $t.Path -Force | Out-Null
      Write-Output "  [建目录] skills 目录不存在，已创建: $($t.Path)"
    } else {
      Write-Output "  [跳过] skills 目录不存在: $($t.Path)"
      $summary += "$($t.Name): 目录不存在"
      continue
    }
  }
  $skills = if ($t.Skills) { $t.Skills } else { $whitelist }
  $okCount = 0; $skipCount = 0; $warnCount = 0; $linkCount = 0
  foreach ($skill in $skills) {
    $targetPath = Join-Path $t.Path $skill
    $repoSkill = Join-Path $repoSkillsDir $skill
    if (-not (Test-Path -LiteralPath $repoSkill)) { continue }
    if (Test-IsJunctionToRepo $targetPath) {
      $skipCount++
    } elseif ((Test-Path -LiteralPath $targetPath) -or ((Get-Item -LiteralPath $targetPath -Force -ErrorAction SilentlyContinue).LinkType -eq 'Junction')) {
      $item = Get-Item -LiteralPath $targetPath -Force
      if ($item.LinkType) {
        if (-not (Test-Path -LiteralPath $targetPath)) {
          if ($CheckOnly) {
            Write-Output "  [悬空链接] $skill (目标已删除，需解链)"
            $warnCount++
          } else {
            Write-Output "  [解链] $skill (悬空 junction，目标已删除)"
            Remove-Item -LiteralPath $targetPath -Force
            New-Item -ItemType Junction -Path $targetPath -Target $repoSkill | Out-Null
            Write-Output "  [链接] $skill -> $repoSkill"
            $linkCount++
          }
        } else {
          Write-Output "  [警告] $skill 是 $($item.LinkType) 但指向非仓库: $($item.Target -join ';')"
          $warnCount++
        }
      } else {
        if ($CheckOnly) {
          Write-Output "  [待迁移] $skill (实体目录)"
        } else {
          $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
          $backupPath = "$targetPath.bak-$stamp"
          Write-Output "  [备份] $skill -> $backupPath (同卷原子重命名)"
          Rename-Item -LiteralPath $targetPath -NewName (Split-Path $backupPath -Leaf)
          New-Item -ItemType Junction -Path $targetPath -Target $repoSkill | Out-Null
          Write-Output "  [链接] $skill -> $repoSkill"
          $linkCount++
        }
      }
    } else {
      if ($CheckOnly) {
        Write-Output "  [待建] $skill (不存在)"
      } else {
        New-Item -ItemType Junction -Path $targetPath -Target $repoSkill | Out-Null
        Write-Output "  [链接] $skill -> $repoSkill"
        $linkCount++
      }
    }
  }
  # constitution 同步（skills_dir 父目录下维护 constitution junction）
  if ($t.Constitution -ne 'false') {
    Sync-Constitution (Split-Path $t.Path -Parent) $t.Name
  }
  Write-Output "  -- 小结: 已就绪 $skipCount / 新建链接 $linkCount / 警告 $warnCount"
  $summary += "$($t.Name): 就绪 $skipCount, 新建 $linkCount, 警告 $warnCount"
  Write-Output ''
}

Write-Output '======== 汇总 ========'
$summary | ForEach-Object { Write-Output $_ }
if ($CheckOnly) { Write-Output '(检查模式，未做任何修改)' }
Write-Output '完成'
