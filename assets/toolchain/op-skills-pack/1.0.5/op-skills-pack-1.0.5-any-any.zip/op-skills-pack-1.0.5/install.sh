#!/bin/sh
# op-skills installer / updater (Linux / macOS)
# Usage:
#   ./install.sh [target-dir]              run inside the unpacked pack (target defaults to ./op-skills)
#   ./install.sh <pack.zip> [target-dir]   run outside the pack
set -e

FIRST="$1"
SELF_DIR=$(cd "$(dirname "$0")" && pwd)
TMP=""

if [ -n "$FIRST" ] && [ -f "$FIRST" ] && [ "${FIRST##*.}" = "zip" ]; then
  TMP="_op_skills_unpack"
  rm -rf "$TMP"
  mkdir -p "$TMP"
  echo "[1/3] Extracting $FIRST ..."
  if command -v unzip >/dev/null 2>&1; then
    unzip -q -o "$FIRST" -d "$TMP"
  elif command -v python3 >/dev/null 2>&1; then
    python3 -m zipfile -e "$FIRST" "$TMP"
  else
    echo "[ERROR] need unzip or python3"
    exit 1
  fi
  SRC=""
  for d in "$TMP"/op-skills-pack-*; do
    if [ -d "$d" ]; then SRC="$d"; fi
  done
  if [ -z "$SRC" ]; then SRC="$TMP"; fi
  TARGET="${2:-op-skills}"
else
  echo "[1/3] Using current pack directory ..."
  SRC="$SELF_DIR"
  TARGET="${1:-op-skills}"
fi

if [ ! -d "$SRC/skills" ]; then
  echo "[ERROR] not an op-skills pack: $SRC"
  if [ -n "$TMP" ]; then rm -rf "$TMP"; fi
  exit 1
fi

echo "[2/3] Installing to $TARGET ..."
mkdir -p "$TARGET"
for d in skills constitution multi-end-sync; do
  if [ -d "$SRC/$d" ]; then
    mkdir -p "$TARGET/$d"
    cp -R "$SRC/$d/." "$TARGET/$d/"
  fi
done
for f in README.md CHANGELOG.md requirements.txt .gitignore VERSION.txt; do
  if [ -f "$SRC/$f" ]; then cp "$SRC/$f" "$TARGET/$f"; fi
done
if [ -n "$TMP" ]; then rm -rf "$TMP"; fi

echo "[3/3] Done. Target: $TARGET"
echo ""
echo "Next steps:"
echo "  1) pip install -r $TARGET/requirements.txt"
echo "  2) Windows: powershell -NoProfile -ExecutionPolicy Bypass -File $TARGET/multi-end-sync/sync-skills.ps1"
echo "  3) Upgrade: unpack the new pack and run this script again (runtime data in .basic/ is kept)"
echo "  Docs: docs/INSTALL-GUIDE.md"
exit 0
