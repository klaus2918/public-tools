# op-skills

AI 协作工作流管理框架：19 个 skill 组成 op 体系（需求到收工的完整变更闭环），配套全局行为宪法与多端同步机制。

## 目录

| 目录 | 内容 |
|------|------|
| skills/ | 19 个 skill（14 个 op 系列 + 5 个支撑），入口为 skills/op/SKILL.md |
| constitution/ | 全局宪法 AGENTS.md，各端 AI 最高行为约束（中文、safe-git-write、java-fs） |
| multi-end-sync/ | 多端同步：仓库唯一事实源 + Junction 共享，sync-skills.ps1 一键建链/校验 |
| .basic/evolved/ | 运行资产实体根（10 个挂载点的落点）：运行数据不入 git、不随包分发；挂载点由 `skills/op-000/scripts/op-000-mount-sync.ps1` 按机重建 |

## 快速部署

1. 解压至目标目录（`<repo-root>`）
2. 建多端链接：`powershell -NoProfile -ExecutionPolicy Bypass -File multi-end-sync\sync-skills.ps1`
3. 分发宪法：复制 constitution/AGENTS.md 到各端（详见 constitution/README.md）
4. 校验：`sync-skills.ps1 -Status` 全 OK

## 环境依赖

| 依赖 | 说明 |
|------|------|
| Python 3.11+ | op-browser / op-docgen / java-fs 运行时（当前实测环境 3.11） |
| pip | 见根 `requirements.txt`（httpx / playwright / Pillow / PyYAML / jinja2 / python-docx；零 LLM/API Key 依赖） |
| Chrome | bridge 模式可选（需 browser-agent-bridge 扩展，见 skills/browser-agent-bridge/） |
| 透明加密客户端 | 仅 java-fs 加密态需要（明文态可原生读写，见 skills/java-fs/SKILL.md） |

## 文档导航

- skills/op/SKILL.md：op 工作流入口（/op 启动变更）
- skills/op-000/SKILL.md：skill 体系注册与管理
- skills/op-000/registry.yaml：skill 注册表（单一事实源为各 SKILL.md frontmatter）
- skills/op-000/references/isolation-spec.md：三层隔离规范（工作区级 / 运行资产级 / 分发级）
- multi-end-sync/README.md：多端同步机制与维护规则
- constitution/README.md：宪法部署指引
- skills/java-fs/SKILL.md：透明加密环境 Java 文件读写强制规则
- requirements.txt：运行时依赖声明（最小版本约束）
- CHANGELOG.md：版本更新说明

## 隔离与外部版本

| 场景 | 约定 | 工具 |
|------|------|------|
| 外部独立迭代版本（解压目录） | 置于仓库根并以 `op-skills-pack-*` 命名：不入库、不参与校验扫描、不参与多端建链 | `.gitignore` + `content-check` 的 `is_external_path()` |
| 运行资产 | 实体在 `.basic/evolved/<skill>/<挂载点>/`；skill 内同名目录为 junction；运行数据不入 git | `op-000-mount-sync.ps1`（创建/修复）、`op-000-isolation-check.sh`（三层自检） |
| 分发包 | 包内零运行资产、零本地配置、零敏感词清单 | `content-check 7.22`（evolved 零跟踪）+ `scan-sensitive.py` |

引入外部版本前，先按 `skills/safe-git-write/references/sensitive-terms.example` 的「外部内容引入禁入清单」逐类判定并占位化。

## 环境适配

本仓库为环境无关骨架：环境相关模板（如 `skills/op-release/references/config-example.yaml`、
`skills/op-knowledge/references/knowledge-bases.example.yaml`）只含占位值并随仓库分发；
真实环境参数写入对应 skill 的挂载点 `config/`（即 `.basic/evolved/<skill>/config/`），
该类文件已被 `.gitignore` 排除，严禁入库、严禁随包分发。新增本地实例配置时请同步更新忽略规则。

## 构建信息

本仓库以 git HEAD 为准；多端分发通过 `multi-end-sync/` 的 Junction 链接完成。
版本与变更记录见 CHANGELOG.md。

## 发布

纯净发布包（零运行资产、零本地配置、零敏感词清单）由 `build-pack.py` 构建：

| 场景 | 命令 |
|------|------|
| GitHub 自动发布 | `git tag v1.0.0` + `git push origin v1.0.0`（或 Actions → Release Pack → Run workflow） |
| 本地构建 | `py build-pack.py 1.0.0`（Windows）／`python3 build-pack.py 1.0.0`（Linux、macOS） |

产物 `op-skills-pack-<version>.zip` 内含安装/升级脚本（`install.cmd` / `install.sh`）与 `VERSION.txt`，
安装、升级与发布说明见 `docs/INSTALL-GUIDE.md`。
