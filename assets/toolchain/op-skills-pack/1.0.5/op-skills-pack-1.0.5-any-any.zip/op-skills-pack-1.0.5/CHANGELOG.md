# 更新说明

op-skills 仓库与可移植包（op-skills-pack）的权威版本记录。格式：日期 + 内容摘要，最新在前。

## 2026-09-21（分发边界与占位化：环境内部材料屏蔽 + 内部代号清理）

- **环境内部材料屏蔽**（不随发布包分发）：`build-pack.py` 新增 `EXCLUDE_PREFIXES` —— `skills/op-design-extract/skills/**`（插件式子层 op-oa-workflow，按用户指定）、`skills/op-browser/docs/**`（内部项目分析文档 11~25）、`skills/op-deploy-prep/kits/**`（内部业务部署套件）；对应引用位置（op-deploy-prep SKILL.md / references/index.md / oa-examples.md / reuse-sources.yaml、op-000 skill-classification）同步加「环境内部材料，不随发布包分发」标注
- **内部代号占位化**（随包文件，32 文件 / 176 处，大小写不敏感）：按 `sensitive-terms.example` 判定口径——环境类与内部制品名一律占位化：项目代号 → `demo-project` / `demo`，镜像与工程名 → `demo-backend` / `demo-frontend`；覆盖 op-release 模板与脚本、op-orchestrate 示例、op-browser 源码与 references、op-docgen / op-knowledge / op-html / op-plan / op-worktree 等
- **CHANGELOG 历史条目**：原内部代号技能名 → 现名 `op-release`，并把「改名迁移」段落中已无意义的自指改写为 `<原代号>`
- **保留项**：`Sa-Token`（`sa-token`）框架的注入键名保留在 `op-browser/src/op_browser/login_inject.py` 的默认值与示例中——属技术专名，改写会影响登录注入行为
- **示例地址收紧**：op-browser 文档（SKILL.md、references/session-reuse.md）中的内网段示例地址改为 RFC 5737 文档地址 `192.0.2.10`，消除文档示例里的内网网段写法
- **验证口径**：验收以「包内扫描」为准（`scan-sensitive.py --path <解压目录>` → 阻断级与提示级均无内部代号）；仓库内被屏蔽材料保留原代号（环境内部使用），故仓库级 `--all` 仍会命中，属预期

## 2026-09-21（发布机制：GitHub Actions 纯净包流水线）

- **打包器收敛为单一实现**：新增 `build-pack.py`（跨平台），以 `git ls-files` 为事实源 + 分发白名单，排除运行资产（`.basic/evolved/**`、挂载点实体、`sites/`、`__pycache__`）、本地配置（`config.yaml`、`*.local.*`）与敏感词清单（`.sensitive-terms*`）；内置门禁：禁止项残留=0、U+FFFD 乱码=0、`scan-sensitive.py --path` 通过、zip 完整性校验
- **薄封装避免漂移**：`build-pack.cmd`（Windows）/ `build-pack.sh`（Linux、macOS）只做解释器探测与转发，逻辑只在 `build-pack.py`（吸取历史 v22 线「文档/实现漂移」教训）
- **CI 自动发布**：`.github/workflows/release.yml` 支持 `v*` tag 推送与手动触发 → 构建 → 门禁校验 → `softprops/action-gh-release@v2` 发布到 GitHub Releases；显式声明 `permissions: contents: write`（缺此项时 Release 静默不出现，是此前「Releases 看不到产物」的直接原因）
- **包内自服务**：包内自动生成 `install.cmd` / `install.sh`（解压后在包目录内直接运行即可，默认安装到 `./op-skills`；覆盖式升级不触碰 `.basic/` 运行资产）与 `VERSION.txt`（版本 / 构建时间 / 来源提交，ASCII 输出以避免编码歧义）
- **文档**：新增 `docs/INSTALL-GUIDE.md`（获取、包结构、安装、挂载点配置、升级、FAQ；该指南随包分发），README 补「发布」小节
- **验证**：`py build-pack.py 1.0.0` → 357 条目 / 19 skills / 敏感扫描 pass / zip 完整性 OK；暂存区 `scan-sensitive.py` 阻断级通过、`validate-text` 6/6 PASS

## 2026-09-21（op-release：内部代号版改名并通用化）

- **改名迁移**（变更 `.op/changes/<原代号>-rename-generic/`，方案 B）：`skills/<原代号>` → `skills/op-release`；全仓引用、注册治理（registry / isolation-spec / skill-classification / mount-sync / isolation-check）、跨 skill 契约与根级忽略规则同步收口
- **物理资产**：`.basic/evolved/<原代号>` → `.basic/evolved/op-release`；挂载点 junction 重建（mount-sync 10/10）
- **存量配置兼容**：现有 `config.yaml`（三端 backend/pc/app）无需改动即可运行；v2 schema（`build_cmd` / `artifact_glob` / `remote_script`）登记为后续变更
- **验证**：全仓 grep 白名单外零残留；`op-000-validate.sh`（op-release 结构 / 注册 / 隔离 ok）

## 2026-09-19（op-release 2.2.0：后端构建切换 mvnd 并行）

- **构建加速**（变更 `.op/changes/op-release-mvnd-build/`）：后端构建命令由 `mvn clean package -DskipTests` 升级为 **`mvnd clean package -DskipTests -T 4`**（`scripts/build.sh`，执行行 + 头注释 + 日志三处同步）；新增构建器探测——未安装 mvnd 时**降级 `mvn` 并打印 WARN**（不静默降级），并行度由环境变量 `MVN_T` 覆盖（默认 `4`，兼容 `1C` 等写法）
- **契约不变**：JDK17 硬校验、增量缓存判定（产物新鲜时整段跳过构建）、`--force`/`--dir`/`--jdk-path`/`--tool`/`--no-typecheck`、`end=all` 多端并行与上传/远程 Docker 构建流程均未改动
- **文档同步**：`SKILL.md`（端-命令表「构建命令」列 + 约束第 4 条 + Version 表）、`registry.yaml`（`env_requirements` 补 JDK17 与 mvnd，version 2.2.0）与脚本口径三处一致
- **与参考包的关系**：包侧 `op-skills-pack-20260912/skills/op-release/SKILL.md:54` 已写 `mvnd clean package -DskipTests`，但同包 `scripts/build.sh:178` 仍是 `mvn`（包侧文档/实现漂移）；本条目是**实现与文档同时落地**。两侧同号 `2.2.0` 但内容不同（包侧另含 `download.sh`、`lib/config.sh` 等）
- **未验收项**：真实构建计时对照（mvnd vs mvn）需在具备 mvnd 与目标工程的机器执行，本机无 mvnd 且 `config.yaml` 指向的工程路径不存在，已登记未验收

## 2026-09-14（v22，对齐独立迭代版本 op-skills-pack-20260912 + 四阶段治理）

> 背景：`op-skills-pack-20260912/` 是同一体系在另一环境的**独立迭代版本**（该线自编 v22 = 打包器缺陷修复：`.claude/evolved` → `.basic/evolved` 迁移遗留、`build-pack.cmd` 计数行 `find` 被 Git 自带 GNU find 遮蔽）。本条目记录本仓库线对该版本的分析、对齐与治理。

- **分析整理**（变更 `.op/changes/op-skills-pack-20260912/`）：全量比对 314 个共有文件（68 个内容不同 / 21 个仅包侧 / 25 个仅仓库侧），逐项判定采纳 / 改造 / 拒绝，识别 13 处敏感禁入项
- **P0 隔离与基线恢复**（6760af3）：新增三层隔离规范（`skills/op-000/references/isolation-spec.md`）与 2 个脚本；`content-check` 排除外部版本目录；修复 5 个既有缺陷（本机无 `python` 的解释器探测、GBK 输出崩溃、`set -e` 吞版本漂移、检查 8 管道中止、3 处内容层缺陷）
- **P1 机制对齐**（4c6312a）：op 3.2.0（文档优先 P14 / 执行产物归位 / index.json 纯进行态）、op-plan 4.5.0（确认留痕 + `browser_screenshot_read` + tasks.md 6 项校验 + 补回 §1.1b/§1.2）、op-build 3.5.0（启动守卫 / 知识检索强制 / 状态标记）、op-done 5.0.0（清理清单 / 知识沉淀实操 6 步）、op-000 4.2.0（optimize 方案确认门禁）、op-knowledge 2.2.0（消费方接入协议）、op-html 4.2.0；constitution 补「证据链」条款；`validate.sh` 新增检查 3.5（SKILL.md ≤300 行）；registry 与 19 个 SKILL.md 版本三方对齐
- **P2 运行资产与命名治理**（a4141ea）：`.claude/evolved` → `.basic/evolved`；**修正挂载点忽略规则（补 `**/` 前缀）**——原规则按仓库根锚定、从不匹配 `skills/` 层级，即历史「evolved 88 文件被跟踪」问题根因；10 个挂载点建链（新增 `op-knowledge/config`、`op-release/config`）；evolved 全库零跟踪；`content-check` 新增 7.22
- **P3 安全与合规**（e282f44）：环境类信息占位化 3 处；固化「外部内容引入禁入清单」（`sensitive-terms.example`）；产出防线接入评估（不新增内网 IP 阻塞级校验，避免合法样例误报）
- **验证**：`validate.sh` / `content-check` 全绿、`isolation-check` PASS 17 / WARN 0 / FAIL 0、版本漂移 0、`scan-sensitive.py` 阻断级通过（暂存区与全仓库 `--all`）；回归套件 7/14 与变更前 pristine HEAD 基线失败集逐条一致（环境性既有问题：本机无 `python` 命令、未配置知识库、docgen 依赖缺失），**无回归**

## 2026-08-16（v21，打包链路修复 + 第10轮后续优化）

- **打包链路修复**（轮121-123，3 提交 743ac59 / 71a59f0 / 75988ba）：
  - CHANGELOG 补 v19/v20 完整段落；v11 zip 解除跟踪（git rm --cached）
  - build-pack.cmd 两处裸括号修复（if 块内裸括号致 cmd 块配对错乱），9 处中文注释/echo 英文化（中文版 cmd 解析风险）
- **打包产物与验证**（轮124）：op-skills-pack-20260816.zip（1.25 MB、421 条目目标、25 skills、534 文件），完整验证全过（SELF-CHECK skills=25 / evolved-dirs=9 / probes=0、84 py 语法、FFFD=0、zip testzip 完整）
- **第10轮后续优化三方向**（轮125）：
  - **java-fs 机器双态（v1.3.0）**：CDG 透明加密为机器级 2 态全局属性（encrypted/plain）。java_fs_io.py 新增 `env`/`mode` 命令（注册表/进程/写探针三通道探测，固化 `~/.java_fs_mode`）；ps1/cmd/sh 增加入口；plain 态 read/write/read-b64/write-b64 走 .NET 原生 IO 不经 python 中转（本机实测往返字节级一致）；SKILL.md/AGENTS.md 双态化章节
  - **tools.yaml 单一事实源**：multi-end-sync/tools.yaml 登记 9 端（新增 opencode）；sync-skills.ps1 改由清单驱动 + probe 存在性探测跳过未装端 + Sync 自动创建缺失 skills 目录；修复 sync-skills.ps1 丢失的 UTF-8 BOM（PS 5.1 按 GBK 解析中文全乱码的根因）；build-pack.cmd 打包 tools.yaml
  - **opencode 接入**：skills 目录 `~/.config/opencode/skills` 建 25 条 Junction，`opencode debug skill` 实测可发现；constitution/README.md 分发表 + 复制命令；java-fs SKILL.md 安装位置表；multi-end-sync README 9 端说明
- **基线**：docs/system/02-历史报告/工具与环境适配基线-2026-08-16.md（P1-P4 问题建模、java-fs 双态方案、tools.yaml 单一事实源、opencode 登记）
- **验证**：sync-skills.ps1 -Status 全绿（9 端）、selftest-text 24/24、java-fs plain 读写/b64 往返字节级一致、validate-text 全过、FFFD=0

## 2026-08-15（v20，第十轮 双模执行完成）

- **第十轮 12 轮审查**（轮109-120，双模执行组）完成，12 提交：
  - 轮109 双模执行规范设计定稿（46ac6dc）：约束执行=现有强制阻断 / 自主执行=无确认开发闭环但硬禁 Git 写操作，新建执行模式基线文档（模式定义/行为契约/专家组/防呆/提交路径/第10组路线），FFFD 3处修复
  - 轮110 宪法「执行模式」章节落地（0e432f6）：双模执行定义/自主执行硬禁 Git 写操作 + 不询问 + 专家组 + 质量底线不变/提交权唯一保留人工确认，同步 jcode 端
  - 轮111 执行模式声明机制落地（61b8e42）：change.yaml 新增 execution_mode 字段契约（op-plan §1.2）、content-check 7.20 执行模式契约（白名单校验阻塞级 + autonomous 提示级）、冒烟扩展至 30 用例（28-30 RED/GREEN 三态）
  - 轮112 专家组机制落地（9372c28）：op-plan §1.1b（触发条件 complex-epic/autonomous/跨 skill 依赖面/边界模糊；autonomous+complex 前置门禁）、评估模板 expert-review-template.md（风险/一致性/边界/假设/结论/交付复核清单）
  - 轮113 自主执行防呆落地（d401b51）：op-autonomous-guard.py 守卫（活跃 autonomous 阻断 exit1）、pre-commit 第 5 道闸接入、content-check 7.21 活跃检测提示级、冒烟扩展至 32 用例（31 WARN/32 GREEN）、三态验证通过
  - 轮114 自主执行交付检查表落地（e25300f）：autonomous-delivery-checklist.md 六域自检（Git 禁令/功能边界/系统一致性/质量底线/专家组假设/交付确认）、op-plan §1.1b 接入步骤6，FFFD 3处修复
  - 轮115-116 自主执行真实演练：op-find.py 按执行模式过滤功能开发（--execution-mode all/constrained/autonomous 白名单 + 缺省 constrained + 向后兼容），全程零 Git 写操作，生成 expert-review.md/autonomous-checklist.md/delivery-manifest.md
  - 轮117 自主执行演练人工确认收口（75583d0）：用户确认后 op-find-exec-mode 功能交付、基线追加 9.7 演练记录、变更收尾 phase=done、守卫放行、safe-git-write 约束路径提交
  - 轮118 双模回归与共存验证（9d455bc）：13 套件 13/13 全绿、双模共存（constrained+autonomous 收尾）守卫/7.20/7.21 全通过、op-find 双模过滤正确、自主执行闭环实证、基线追加 9.8
  - 轮119 基线固化 + 守卫冒烟套件（fbe59fe）：test_autonomous_guard.py 5 用例全过、回归入口扩展 13->14 套件、执行模式基线定稿（双模契约/专家组/防呆/检查表全链路），FFFD 3处修复
  - 轮120 组内总体验证归档（c93129f）：CHANGELOG v20 总结、ThinkSource round10 归档（knowledge-health 100/100）、回归 14/14 全绿、content-check 7.1-7.21 全绿、_exp 第10组临时文件清理

- **第10组双模执行成果**：
  - 机制：双模执行（约束/自主）、change.yaml execution_mode 契约、专家组前置门禁、自主执行防呆（守卫 + pre-commit 第 5 道闸 + 7.21 活跃检测）、交付检查表六域、op-find 按执行模式过滤功能
  - 校验能力：content-check 7.1-7.21（新增 7.20 执行模式契约 + 7.21 自主执行活跃检测）
  - 基线：执行模式基线归档（模式定义/行为契约/专家组/防呆/提交路径/路线八节）
- **测试资产**：content-check 冒烟 32 用例 + test_autonomous_guard.py 5 用例 + 回归入口 14 套件

- **回归**：run_all_tests.py 14/14、content-check 全绿（7.1-7.21）、FFFD 零命中

## 2026-08-15（v19，第九轮 生态集成完成）

- **第九轮 12 轮审查**（轮97-108，生态集成组）完成，12 提交：
  - 轮97 外部集成点全景盘点（b2f18e2）：命令检测/端口配置/路径边界/探针隔离四维合规
  - 轮98 跨 skill 依赖契约核查（1300d74）：**修复 8 处 frontmatter/registry 不一致**
  - 轮99 知识库集成闭环核查（c3acfc9）：op-knowledge ↔ ThinkSource 零修复
  - 轮100 打包与分发生态核查（60da7dd）：**修复 package CHANGELOG v15-v18 缺失**
  - 轮101 外部服务集成核查（2a24157）：java-fs/browser-bridge/CDP/MCP 四维健康
  - 轮102 外部命令依赖核查（3ec88ff）：Python returncode/超时 + shell set -euo 双层防护充分
  - 轮103 跨 skill 数据流与契约核查（fd2693b）：change.yaml/产物传递链闭环，零修复
  - 轮104 生态错误传播核查（ce112e4）：退出码约定统一/错误消息前缀一致/op-build required-optional 失败语义分级/聚合退出码正确/RF-08 兜底护栏，基线追加第九章
  - 轮105 版本兼容生态核查（e4ec0c2）：Python3 统一 + PY_CMD 探测/declare-A 唯一 bash4 约束/依赖声明完整/缺依赖必用-可选语义统一/Python3.14 前瞻兼容已修复，基线追加第十章
  - 轮106 7.19 生态防线固化（9364f55）：基线文档完整性阻塞级 + 退出码约定漂移提示级，冒烟扩展至 25 用例（RED/GREEN/WARN 全三态覆盖），基线追加第十一章
  - 轮107 7.19c 跨 skill 依赖完整性防线固化（5cec380）：frontmatter skill 引用须存在阻塞级，冒烟扩展至 27 用例，**修复 7.19a 空目录误报**（未初始化 WARN 跳过），回归 13/13 全绿，基线追加第十二章
  - 轮108 组内总体验证归档（4e2a9fe）：CHANGELOG v19 总结、ThinkSource round9 归档（knowledge-health 100/100）、回归 13/13 全绿、content-check 7.1-7.19 全绿、_exp 第9组临时文件清理

- **第9组生态集成成果**：
  - 修复 3 类：8 处 frontmatter/registry 依赖不一致、package CHANGELOG v15-v18 缺失、7.19a 空目录误报
  - 校验能力：content-check 7.1-7.19（新增 7.19 生态防线：基线文档完整性阻塞级 + 退出码约定提示级 + 跨 skill 依赖完整性阻塞级）
  - 基线：生态集成十二维审计归档（集成点/依赖契约/知识库/打包分发/外部服务/命令/数据流/错误传播/版本兼容/防线）
- **测试资产**：content-check 冒烟测试 27 用例（新增 7.19 RED/GREEN/WARN 三态用例）

- **回归**：run_all_tests.py 13/13、content-check 全绿（7.1-7.19）、FFFD 零命中

## 2026-08-15（v18，第八轮 健壮性与边界完成）

- **第八轮 12 轮审查**（轮85-96，健壮性与边界组）完成，12 提交：
  - 轮85 边界输入深挖（be8f376）：content-check 对 9 类极端输入实测零崩溃（空 SKILL/无 frontmatter/emoji 文件名/超长文件名/10 层嵌套/0 字节 json/10MB 单行）；新建健壮性基线文档
  - 轮86 错误恢复核查（b8e5b51）：java-fs 启动 10 次重试、run-all.sh 并发失败隔离、22 文件超时参数、52 文件优雅降级；RPC 无重试为本地服务合理设计
  - 轮87 并发竞态核查（46cb348）：content-check git_ls_files 缓存主线程独占无竞态、7.11 worker 无共享状态、task_store 锁 finally 释放；java_fs_io 非原子写记录为合理权衡
  - 轮88 资源生命周期（2f2dcc2）：**修复 validate.py mkdtemp 无清理**（补 temp_dir 初始化 + exit 前 rmtree + import shutil）
  - 轮89 编码与时区（dbebcf1）：**修复 2 处 naive/aware 混用 TypeError 防御缺口**（run_state/session_registry 的 except ValueError → except (ValueError, TypeError)）；编码扫描健康（零 errors=ignore）
  - 轮90 大输入深度（e944369）：40 层深目录实测无崩溃（50 层受 Windows MAX_PATH 限制无法构造，外部约束）
  - 轮91 依赖健壮性（36c55a1）：可选依赖降级 7 文件、核心依赖硬失败合理、requirements 9 包全部版本约束
  - 轮92 环境差异（719577f）：路径 join 规范化、平台 API 有检测分支；硬编码路径命中全为误报（shebang/注释/URL）
  - 轮93 超时覆盖（e4d0c67）：无 timeout 处均为本地服务/长任务合理取舍；Popen communicate 零使用无死锁
  - 轮94 输入验证（b3bd2ff）：CLI（choices/type/required）+ 结构（7.6 phase_role 白名单/7.9 category）双层全覆盖
  - 轮95 健壮性防线（6f44d3b）：content-check 新增 **7.18 健壮性健康**（裸 open 非 with 且无 close → WARN；errors=ignore → WARN；AST 扫描 + task_store 锁句柄 close 配对豁免）；**修复自伤问题**（检测模式字符串匹配检查器自身，abspath 跳过）；冒烟测试新增 2 用例
  - 轮96 组内总体验证归档：13 套件回归全过、FFFD 零命中、content-check 7.1-7.18 全绿

- **第8组健壮性成果**：
  - 修复 3 处：validate.py 临时目录残留、2 处 TypeError 防御缺口、7.18 检查器自伤
  - 校验能力：content-check 7.1-7.18（新增 7.18 裸 open/errors=ignore 警告防线）
  - 基线：健壮性十二维审计归档（边界/错误恢复/并发/资源/编码时区/大输入/依赖/环境/超时/输入验证/防线）
- **测试资产**：content-check 冒烟测试 21 用例（新增 7.18 RED/GREEN 2 用例）

- **回归**：run_all_tests.py 13/13、content-check 全绿（7.1-7.18）、FFFD 零命中

## 2026-08-15（v17，第七轮 可维护性完成）

- **第七轮 12 轮审查**（轮73-84，可维护性组）完成，11 提交：
  - 轮73 文档可维护性审计（ad5d924）：README/registry/SKILL 三方一致（25/25/25，分类 5/9/6/5）；修复 op-knowledge frontmatter name 引号风格；活跃文档 41 相对链接零断裂；归档区 2 处断裂记录不修（冻结原则）；新建可维护性基线文档
  - 轮74 配置管理核查（e19b606）：本机路径仅 sync-skills E:\Users 为 C/E 双盘真实配置保留；端口/URL 默认值+环境变量覆盖跨 skill 解耦；timeout 13 处语义清晰无集中化需求
  - 轮75 错误消息质量核查（7b4763a）：raise 5 处全带上下文；assert 6/7 带消息 + 1 处不变量；except 静默 pass 53 处抽查为容错设计（可选文件/单文件跳过/Windows chmod 兼容）
  - 轮76 代码重复核查（75a112e）：_setup_stdio 5 处一致但为独立脚本自包含模式（无包结构，单文件可移植是设计目标）；find_files 有语义差异；无 DRY 违规不抽取
  - 轮77 命名一致性核查（5549b92）：Python PEP8 100% 规范（0 camelCase 函数/类名小写）；25 skill 目录命名统一；模板 -dark 变体与 ECMA XSD 为设计/外部标准例外
  - 轮78 模块化与职责划分核查（890d823）：无职责混合；AST 精确统计 15 个超大函数（engine.run 642 行/cli.main 600 行为主流程）列为低优先级重构候选，当前稳定不拆
  - 轮79 死代码清理（150d8e1）：AST 扫描 38 处未使用 import 中清理 14 处真死代码（9 文件：content-check _ET 历史遗留、op-oa-workflow 8 个 os/io、docgen 3 处行内+整行）；103 孤立脚本候选均为 gitignore 保护探针；注释死代码 0
  - 轮80 注释质量核查（f238b12）：TODO 16 处语义清晰（11 处生成模板占位符合理）；**修复 learn.sh 骨架 vs SKILL.md 文档声明不一致**（9 节加实现状态标注）
  - 轮81 版本管理一致性核查（82fb689）：frontmatter/registry 版本 25/25 全量同步；CHANGELOG v1-v16 连续；包 v11 独立编号为设计
  - 轮82 升级兼容与迁移路径核查（6e797d2）：归档可恢复性完整（my-workflow-dev 含模板/参考/历史版本）；25 active 零滞留 deprecated（归档代替弃用）
  - 轮83 可维护性防线（cd8dd97）：content-check 新增 **7.17 可维护性健康**（frontmatter/registry 版本不一致 ERROR 阻断 + 活跃文档 markdown 断裂链接 WARN，archive 豁免）；冒烟测试新增 2 用例
  - 轮84 组内总体验证归档：13 套件回归全过、FFFD 零命中、content-check 7.1-7.17 全绿

- **第7组可维护性成果**：
  - 校验能力：content-check 7.1-7.17（新增 7.17 版本漂移阻断 + 活跃文档链接警告）
  - 代码治理：14 处死 import 清理、1 处命名风格统一、learn.sh 文档声明修复
  - 基线：文档一致性/配置/错误消息/DRY/命名/模块化/版本/迁移 八维审计归档
- **测试资产**：content-check 冒烟测试 19 用例（新增 7.17 RED/GREEN 2 用例）

- **回归**：run_all_tests.py 13/13、content-check 全绿（7.1-7.17）、FFFD 零命中

## 2026-08-15（v16，第六轮 性能与规模完成）

- **第六轮 12 轮审查**（轮61-72，性能与规模组）完成，12 提交：
  - 轮61 仓库体积基线（c026831）：工作区 102.76 MB（其中 91 MB 为未跟踪 .log 日志）；git 跟踪 834 文件 ≈8.4 MB；.gitignore 补 op-skills-pack-*.zip 打包产物防线
  - 轮62 包体积基线（933060b）：v11 包 zip 1.16 MB 压缩 / 3.63 MB 解压；docx XSD 套件 0.93 MB（39 文件，合理占比保留）；创建体积规模基线文档（docs/system/02-历史报告/）
  - 轮63 git 对象优化（93c8dc3）：git gc 15.38 MB→10.15 MB（4197 loose→3835 in-pack，361 loose）；fsck 干净；定位历史超大 blob（1.66 MB 旧 junction index.html + 2 个 zip）
  - 轮64 脚本耗时基线（1e43e1e + 93a76d4）：content-check 0.63s / metrics 0.7s / health 0.4s；run_all_tests 11-12 分钟；**修复 3 个回归失败**（_exp/hook_normal_test.md 误入库从 HEAD 移除、ThinkSource 顶层残留 _exp_tmp 清理、根目录 probes 移入 _exp）
  - 轮65 缓存机制（cb19ca6）：git ls-files 模块级缓存（每次测量 461ms→0）；7.11 js 单进程批量 vm.Script（102 文件 43s→0.45s）+ sh/ps1 ThreadPool 16 并行；**content-check 64.9s→11.9s（5.5 倍加速）**
  - 轮66 压缩与归档策略（f6735e8）：docs/archive 2.9 MB 健康；0 个被跟踪 __pycache__/.out/.lock 残留；无需压缩
  - 轮67 大文件清理（cb20863）：91 MB AutoPlan 日志保留（docs/plan 中 111 处引用存在性）；补 docs/progress/logs/ + docs/archive/process-artifacts/**/*.log 目录级 gitignore 防线；134 个 .last.txt 确认仍被跟踪
  - 轮68 索引与搜索（01888c0）：registry.yaml 22 KB / 0.03s；metrics 0.58s 纯文件遍历（无 subprocess）；index.json 9.5 KB（version/updated_at/tags[16]）——全部健康
  - 轮69 加载时间（ee8e26b）：Python 启动 0.293s；content-check 仅标准库 import；sh/ps1 外部进程启动为固有瓶颈（cygpath 批量方案 17.5s 更慢，维持现状）
  - 轮70 内存占用（3188ec9）：content-check 峰值 37.3 MB（psutil 实测）；91 MB 日志不加载（无 .log 处理分支）；15 处 read() 均为小文件
  - 轮71 体积防线（a55f211）：content-check 新增 **7.16 体积与规模健康**（跟踪文件 ≥5MB 阻断 / ≥2MB 警告 / 非 docs/archive/package/ 跟踪 zip 警告）；冒烟测试新增 RED/GREEN 2 用例
  - 轮72 组内总体验证归档：13 套件回归全过、FFFD 零命中、content-check 7.1-7.16 全绿

- **第6组性能规模成果**：
  - 性能：content-check 64.9s→11.9s（5.5 倍，git ls-files 缓存 + js 单进程批量 + sh/ps1 并行）
  - 体积：git 对象 15.38→10.15 MB（gc）；91 MB 未跟踪日志识别为历史产物（保留 + 目录级 gitignore 防线）
  - 规模防线：content-check 7.16 体积健康（超大跟踪文件阻断 + zip 警告）
  - 基线：体积 / 包体积 / 耗时 / 内存 / 加载 / 索引 六维基线归档至 docs/system/02-历史报告/
- **校验能力**：content-check 7.1-7.16 全覆盖（新增 7.16 体积防线）

- **回归**：run_all_tests.py 13/13、content-check 全绿（7.1-7.16）、FFFD 零命中

## 2026-08-15（v15，第五轮 安全加固完成）

- **第五轮 12 轮审查**（轮49-60，安全加固组）完成，12 提交：
  - 轮49 敏感信息脱敏（cb836dd）：28 文件 43 处本机路径（<仓库根> / <知识库根> / <用户主目录>）→ 占位符；保留 3 个真实运行配置（build-pack SRC、knowledge-health DEFAULT_KB）；git 跟踪零本机路径残留
  - 轮50 依赖治理：新增根 requirements.txt（6 类第三方依赖按 skill 分组声明）；op-browser frontmatter 补 Pillow 声明；content-check 新增 **7.13 依赖声明健康**（glob 收集 + stdlib/本地模块识别 + 大小写归一，4/4 组含第三方依赖全声明；RED/GREEN 冒烟测试 2 用例）
  - 轮51 java-fs 服务加固：HTTP read/write 加 Origin 跨源校验（恶意网页 403）；/shutdown 加 ~/.java_fs_token 随机令牌认证（secrets.compare_digest）；500 错误脱敏（不回显路径）；新增测试套件 test_server_security.py（9 用例）并注册 run_all_tests 第 11 套件
  - 轮52 zip slip 防护（docx 模块）：新增 helpers/zip_safe.py 安全解压（校验条目路径必须落在目标目录内，拒绝绝对路径/../ 逃逸/ADS 冒号条目）；docx 5 处 extractall 统一替换（unpack/validate/base/docx/redlining 校验器）；新增测试套件 test_zip_safe.py（5 用例）并注册 run_all_tests 第 12 套件
  - 轮53 文件权限加固：.gitignore 补密钥/证书/凭据扩展名防线（*.pem/*.key/*.p12/*.pfx/*.jks/*.keystore/*.htpasswd/*id_rsa/*.secret）；init-ssh.sh 加固（StrictHostKeyChecking no→accept-new 防 TOFU、密钥生成后显式 chmod 600）；content-check 新增 **7.14 敏感文件跟踪防线**（git 跟踪密钥/凭据文件即阻塞；冒烟 RED/GREEN 2 用例）；轮53b 清除 java-fs/tmp 误入库临时文件并 gitignore 整体忽略
  - 轮54 日志脱敏：全库扫描确认无敏感值打印（token/password/secret 零泄露）；op-browser task_store write_error_log 加固（凭据形打码 _mask_sensitive 覆盖 token/password/api_key/Bearer + 堆栈 4000 字符截断防膨胀）
  - 轮55 供应链加固：全库核查无外部下载命令（仅 java-fs 内部 127.0.0.1 curl）；requirements.txt 全部包行加最低版本约束（>=，防御已知漏洞版本、不锁上限）；7.13 追加版本约束核查；install-deps.sh 确认按 lockfile 类型分派（pnpm/yarn/npm）为合理实现
  - 轮56 sh 参数卫生：33 个 sh 严格模式（set -euo pipefail）覆盖率 29/33 核查，补全 theme-detect.sh / op-orchestrate-validate.sh / orchestrate-status.sh（均实测运行正常）；build.sh 因交互式参数解析（--dir/--tool/--force）豁免并记录理由；参数空值守卫逐一核查（${1:-default}/[ -z ] 覆盖，无裸参数直接使用）
  - 轮57 备份/恢复安全：java-fs restore 加快照完整性校验（restore 前按 metadata.json sha256 校验 original.b64，快照损坏/被篡改拒绝恢复 fail-closed，绝不写坏数据）；cleanup_snapshots 负值边界防御（max_hours<0 退化为 24h）；新增测试套件 test_snapshot_security.py（6 用例）并注册 run_all_tests 第 13 套件
  - 轮58 错误处理核查：全库扫描裸 except: 零（全部指定异常类型）；约 60 处裸吞逐一抽查为容错设计（可选解析/优雅降级，无静默吞关键错误）；task_store 文件锁在 finally 正确释放（无句柄泄露）；knowledge-health 2 处一次性读取规范为 with（实测 health 100/100 不受影响）
  - 轮59 网络传输安全：全库核查零证书校验绕过（verify=False/CERT_NONE 零命中）、零真实明文外传 http（全部本机 127.0.0.1 / XML 命名空间标识符）；content-check 新增 **7.15 网络传输卫生**（git 跟踪脚本扫非本机明文 http + 证书绕过，豁免本机/模板变量/XML 命名空间；冒烟 RED/GREEN 2 用例）

  - 轮60 组内总体验证归档：13 套件回归全过（run_all_tests）、FFFD 全库零命中、敏感文件跟踪零、content-check 7.1-7.15 全绿；CHANGELOG 元描述路径脱敏为占位符

- **第5组安全加固成果**：12 项安全检查与加固全覆盖——
  - 敏感信息：28 文件 43 处本机路径脱敏、敏感文件跟踪防线（7.14）
  - 服务加固：java-fs Origin 校验 + shutdown token + 错误脱敏
  - 路径安全：docx zip slip 防护（zip_safe 助手 + 5 处替换）
  - 权限与密钥：gitignore 密钥扩展名防线、init-ssh TOFU 加固
  - 日志与备份：task_store 凭据打码 + 堆栈截断、restore 快照 sha256 完整性校验
  - 供应链与输入：requirements 最低版本约束、sh 严格模式补全、7.15 网络传输卫生
- **校验能力**：content-check 7.1-7.15 全覆盖（新增 7.13 依赖声明/7.14 敏感文件/7.15 网络卫生）
- **测试资产**：13 套件（新增 java-fs server 安全、java-fs 快照安全、docx zip 安全）

- **回归**：run_all_tests.py 13/13、content-check 全绿（7.1-7.15）、FFFD 零命中

## 2026-08-15（v14，第四轮 12 轮自动化测试）

- **第四轮 12 轮审查**（轮37-48，自动化测试组）：11 提交，构建完整自动化测试体系：
  - 轮37 脚本语法全量校验（145d0d7）：content-check 新增 **7.11 脚本语法健康**（py/js/ps1/sh/cmd 全语言，Git Bash 自动探测、WSL 存根排除）；230 脚本语法全过
  - 轮38 单元测试覆盖（b509f01）：补建 content-check 冒烟测试（RED/GREEN 4 用例）
  - 轮39 校验能力全项验证（637e29d）：补 7.6/7.7/7.8/7.9 RED/WARN 用例（共 8 项）
  - 轮40 hook 真实触发（5e76d33）：pre-commit 冒烟测试固化（空提交放行/FFFD 拦截/探针拦截/正常放行）
  - 轮41 exit code 错误路径（9cc4b7c）：12 用例（argparse 缺参数 exit 2 / 坏路径 exit 1 / 正常 exit 0）
  - 轮42 结构化解析（874afbc）：content-check 新增 **7.12 结构化文件解析健康**（json/yaml/xml 全量 + 2 类历史/展示例外豁免）；坏 registry YAML 被 7.12 兜底检出
  - 轮43 模板渲染（038e9e1）：docgen 4 骨架渲染 + op-html 6 对 day/night 配对
  - 轮44 边界输入（13bedfd）：空目录/空 registry/坏 YAML/空 SKILL/特殊字符/空 KB 6 用例
  - 轮45 幂等性（4cf0b2b）：content-check/health/docgen 幂等（metrics 剔除时间戳快照语义）
  - 轮46 跨平台 + 探针治理（82eec91）：**P0 资产治理补漏**——op-browser/src/_m3_smoke98~101 4 个探针（含本机路径）解除跟踪 + gitignore/_m3_ 防线 + 7.10 前缀扩展
  - 轮47 回归入口（be2c13c）：run_all_tests.py 一键全跑 10 套件
  - 轮48 总体验证归档：回归 10/10、FFFD 零命中、content-check 全绿、v14 条目

- **测试资产**：op-000/scripts/tests/ 7 个测试文件 + op-orchestrate 2 个 + java-fs selftest，共 10 套件
- **校验能力**：content-check 7.1-7.12 全覆盖（引用/资产/版本/白名单/对称性/tmp/探针/语法/结构化解析）

## 2026-08-15（v13，第三轮 12 轮内容质量深挖）

- **第三轮 12 轮审查**（轮25-36，内容质量深挖组）：6 提交 + 4 项 PASS 核实 + 2 项本地修复：
  - 轮25 frontmatter 全量校验（f39666e）：7 skill 补 depended_by；op-brainstorming invoked_by 补 registry（修 YAML 缩进破坏解析事故）
  - 轮26 正文结构规范（c43a18a）：skill-creator/webapp-testing 补 When to Use/Dependencies
  - 轮27 命令示例可执行性：8 处脚本引用全数核实为上游资产声明或路径误报（browser-agent-bridge 扩展上游、op-browser with_server.py 在 webapp-testing/）
  - 轮28 模板变量完整性（4e4ad6f）：op-docgen 示例引用改 user-manual/data.json（原 api-sample.json 不存在），端到端渲染验证通过
  - 轮29 错误处理覆盖（8da6e13）：knowledge-health.py 补退出码（P1 存在返回 1）
  - 轮30 降级策略：SKILL.md 降级声明与脚本实现全一致（java-fs/op-docgen/op-release/orchestrate 等）
  - 轮31 引用完整性（45983d1）：op-plan digest 示例路径、op-browser with_server 路径 3 处真实断裂修正
  - 轮32 术语一致性（1e6d7a8）：全体系术语分层一致（使用故事/使用场景、usage_scene/usage_scenes、created/created_at），修 op-html user stories 中英混用
  - 轮33 编号连续性：章节/版本/RF 编号引用全有效；oa 资产 CHANGELOG 1.2.1 乱序修复（junction 资产本地生效）
  - 轮34 文档导览：README/docs 链接与结构图全有效，导览全覆盖
  - 轮35 版本历史追溯（53268cb）：frontmatter↔registry 版本 25/25 一致；version 引号格式统一（browser-agent-bridge/safe-git-write）
  - 轮36 总体验证归档：constitution 教学性 U+FFFD 改文字（消除扫描命中）；v13 条目

## 2026-08-15（v12，第二轮 12 轮系统审查优化）

- **第一轮 12 轮收尾**（提交 45f7847/f57ada0）：v10 脏包归档 docs/archive/package/（标注勿用）；根目录 install-hook.cmd + README 引导；op-000-metrics.py 度量脚本 + docs/metrics.md；12 轮系统审查（demo 标记/docs 治理/op-browser 依赖规范化/bridge 分发声明/build-pack 探针泄漏断言/install-hook fresh-upgrade 检测/知识库 health 100/scripts 语法全过/安全脱敏/链接检查/metrics 扩展/总体验证）
- **第二轮 12 轮深层审查**（本记录）：元数据全链路一致性（registry↔frontmatter）、双副本同步（install-hook/CHANGELOG 主从）、op-html 白天/黑夜模板配对、git 历史健康（历史 AutoPlan 日志/plan 脱敏 660 处）、依赖可运行性（docx Python 依赖声明补全）、中文化（hook 乱码修复）、内容重复边界、版本同步（本记录），共 6 提交（b328b1c/772a5e5/bea832d/502aee5/ccc1334 及本轮收尾）

## 2026-08-15（v11，专家组整合 v3）

- **专家组整合 v3**（五视角等价审计：完整性/协同性/知识库/资产/打包）——体系完整且逻辑自洽：
  - registry v3：新增 category 资产分层（core 5 / support 9 / foundation 6 / generic 5），与 phase_role 流程角色互补；op-done 补交付三件套自动触发（op-deploy-prep/op-docgen/op-release）；skill-creator↔writing-skills 分工声明
  - 25 SKILL.md frontmatter 同步：补 category；修复 op-orchestrate description YAML 语法错误（`enabled: true` 冒号无引号）；op-build/done/plan/knowledge 补 invoked_by/status/phase_role（与 registry 对齐）
  - content-check 新增 7.9（category 白名单 + registry↔frontmatter 一致性，防漂移复发）、7.10（探针跟踪防线）
  - hook 新增第 4 项探针/过程产物拦截（仅拦新增/修改，放行解除跟踪的删除）；模板同步
  - **P0 资产治理**：`git rm --cached` 解除 115 个历史探针跟踪（browser-agent-bridge 104 + docs 12）；gitignore 追加探针防线；v11 包探针归零（v10 含 104 个）
  - 新增 docs/design/usage-chain.html（完整使用链路 + 主动覆盖率分析：自动编排覆盖 13/25）
- 提交：7362866（整合 v3）+ 6968508（hook 修正）

## 2026-08-14（v10，本次优化）

- **5 人专家组 × 7 阶段 × 3 迭代** op 体系全面优化（完整性/协同性/知识库闭环/资产隔离/打包分发），允许整合/拆分/重构：
  - 阶段1 全量盘点：registry 25↔磁盘 25 零漂移；发现 P0（evolved 121 资产被 git 跟踪）+ P1 若干
  - 阶段2 完整性：`废弃/` 4 项 skill 归档至 `docs/archive/obsolete-skills/`；`_exp/` 16 份历史报告归档至 `docs/archive/expert-rounds/`；删除空目录 `-p`/`tasks`；`_exp/` 转为活动实验区并 gitignore；根目录建立权威 CHANGELOG.md（合并 docs/package 历史 + 补 v9）
  - 阶段3 协同性：content-check.py 新增 7.8 调度关系对称性检查；registry 补 9 处反向声明（op-knowledge/orchestrate/op-html/brainstorming/design-extract/safe-git-write 的 invoked_by/depended_by），关系图双向可遍历
  - 阶段4 知识库闭环：真实触发缺口回填闭环（01-收集/知识缺口.md 创建 → 3 条缺口 → 回填 3 份沉淀 → KQ 检索命中验证）；self-update 缺口驱动通道实测打通
  - 阶段5 资产隔离（P0 根治）：`git rm --cached` 解除 121 个 evolved 资产跟踪（工作区保留）；.gitignore 强化 `.claude/evolved/**` 全量忽略；junction 挂载点语义恢复
  - 阶段6 打包分发：build-pack.cmd 前置 evolved 零跟踪校验 + 产物自检（evolved 零泄漏断言、SELF-CHECK skills=25/evolved-dirs=9）+ CHANGELOG 改取根目录权威主源；PACKAGING.md 同步
  - 阶段7 整合重构：全链路集成验证（content-check 全绿 / 知识库 health / 打包模拟）+ v10 包交付
- 知识库沉淀：op-registry-relation-map / evolved-asset-isolation / op-pack-extract-flow 三份新知识入库，3 条缺口全部回填

## 2026-08-14（v9）

- 知识库自愈与演进收尾：knowledge-health.py 死链判定修复（全局文件名匹配 + 排除行内代码/路径/日期/TODO 误报、同目录重复检测）
- ThinkSource 知识库健康 0→100（A 级）：死链移入 TODO、FFFD 清理、遗留归档、游离 skill 实体 .gitignore 隔离
- 打包 25 skill / 509 条目审计通过；registry 25/25 零漂移
- op-knowledge v1.2.0 健康体检/自愈/生命周期/自更新四章节 + 知识缺口回填机制落地

## 2026-08-14（v8）

- 专家组 3 阶段×5 轮知识库治理：知识库检索/复用机制落地（op-knowledge v1.1.0 + op-plan 5.1.0 KQ + op-build 任务前检索 + op-done 检索关键词 + registry 依赖联动）
- op-knowledge v1.1.0：/op-knowledge search/init 命令、来源变更元信息模板（与 kb-archive.md 双向回链）
- 知识库使用演练：入库/更新/检索/多库四类，端到端链路贯通（变更→plan KQ→build 复用→done 归档→检索闭环）
- registry 25/25 零漂移；打包 25 skill + op-knowledge/config 挂载点
- op-knowledge v1.2.0 自愈与演进：/op-knowledge health/heal/lifecycle 命令 + scripts/knowledge-health.py（7 维度体检评分 A-D / 自愈预览 / 生命周期 active-stale-archived / 检索缺口回填 / 定时自检）；op-done 归档后轻量 health，op-plan KQ 未命中记知识缺口

## 2026-08-14（v7）

- 知识库纳入 op 体系：dialogue-keeper 迁移为 op-knowledge（v1.0.0），skill 实体集中于 skills/op-knowledge/；多知识库配置（knowledge-bases.yaml），模板随包、真实配置走 evolved 挂载点（环境配置不打包）；op-done Step 2 改读 op-knowledge 真实配置默认库；registry 24→25 条
- 环境配置不打包根治：knowledge-archive.yaml 从 git 移除（含 ThinkSource 绝对路径），.gitignore 增补 .claude/evolved/op-done/config/ 与 .claude/evolved/op-knowledge/config/；挂载点 8→9（新增 op-knowledge/config）
- 打包清单同步 25 个 skill（15 op 系列 + 10 支撑）

## 2026-08-14（v6）

- op-browser v2.6 页签治理：session_registry 会话注册表（会话状态机 + 保留期回收）、adapter_bridge 账号感知复用（同账号优先 / 异账号同 tab 重登 / 异 tab 拒绝）、engine 运行后 GC、SKILL.md 2.6.0 + references/tab-governance.md
- op-write-verify 写后验证系统化：java-fs 1.2.0（validate-text 写后强制校验 + validate-java）、op-build 2.7.0（写后校验步骤 + RF-15/16）、op-done 3.6.0（Pre-commit 卫生兜底）、op-000 3.5.0（GREEN 强制校验）、safe-git-write 2.1.0（提交前暂存区批量校验）；.ps1 BOM 误判修复（validate-text 对 .ps1 的 BOM 检查降为 WARN）
- 宪法更新：转义卫生实操细则（跨语言转义对照表）、提交前兜底校验章节
- op-browser v2.5 并发隔离（3R 演进）：run_id 产物 / 跨进程锁 / 并行架构、run 断点续跑与 resume 锁、并发契约文档与演练脚本
- registry.yaml 版本联动 + 去 BOM；全仓 U+FFFD 与 BOM 治理
- 打包清单修复：build-pack.cmd / PACKAGING.md / README.md 同步至 24 个 skill（14 op 系列 + 10 支撑），补入 op-deploy-prep 与 op-orchestrate（v5 打包白名单遗漏，registry 已 24 条）

## 2026-08-05（v5）

- 新增 op-deploy-prep skill：生产部署材料提取与管理（DB 变更 SQL / 环境配置增量 / 手动维护三分类，三段式模板，多模块索引），注册 registry 达 23 条
- op-oa-workflow 内置子层已生成（op-design-extract v5 资产生成）
- oa-deploy-kit 设计资产沉淀（OA 部署材料包规范：三档分类 / PT_MENU / PT_OPERATION / 字典幂等 / 校验基线）

## 2026-08-01（v4）

按三视角审查提案（docs/op-生态优化提案-2026-08-01.md）实施优化：

- registry 与 SKILL.md 版本/描述漂移修复：op-browser 对齐 2.3.0，validate.sh 版本一致性检查推广到全部条目
- 补注册 5 个支撑 skill（browser-use / skill-creator / dispatching-parallel-agents / webapp-testing / writing-skills），registry 达 23 条
- 14 个 SKILL.md 补齐 frontmatter（status / phase_role / version）
- build-pack.cmd：工作区干净前置检查 + 各步骤错误中止
- PACKAGING.md：压缩命令修正为 `%TEMP%\opsk-build\*`
- sync-skills.ps1：路径可移植化（USERPROFILE 推导）、悬空 junction 识别与解链、Status 不一致时退出码 1
- op-000-register.sh：补齐 warn 函数定义
- java-fs/SKILL.md：移除 python 直写绕过示例、补充白名单验证命令
- op-browser/SKILL.md：dependencies 补 browser-agent-bridge
- docs/system 精简：三份长文档移入 02-历史报告/，README 改为归档入口

## 2026-08-01（v3）

打包结构重构，目标：纯净、可移植、项目管理化。

- 结构：去掉 opsk-build 嵌套层，解压即内容，README.md 在根
- 顶层新增 README.md 项目总览（是什么 / 目录 / 快速部署 / 环境依赖 / 文档导航）
- 新增 CHANGELOG.md 更新说明
- multi-end-sync 精简为 2 项（README.md + sync-skills.ps1），删除环境配置指导、操作流程、治理方案、历史报告
- .claude/evolved/ 改为仅 8 个挂载点空目录，移除全部个人演化资产
- constitution 保留（AGENTS.md + README.md）
- 新增 docs/package/（仓库内打包规则源）：README.md、PACKAGING.md、CHANGELOG.md、build-pack.cmd

## 2026-08-01（v2）

- docs/system 工程化整改：标准命名、去除装饰材料，审查报告移入 02-历史报告/
- 新增 constitution/（全局宪法 AGENTS.md + README.md）
- java-fs/SKILL.md 移除 BOM

## 2026-08-01（v1，初始包）

- 23 个 skill（12 op 系列 + 11 支撑）
- op-browser v2.3：Bridge 分组复用（URL 同源 + 业务名匹配、仅存活分组）、--new 显式新建、bridge groups/cleanup 命令、中文名支持
- .claude/evolved/ 88 个演化资产（后续版本改为空挂载点）
- multi-end-sync 文档集（后续版本精简）
