# 全局宪法

## 沟通方式

- **全程使用中文**：沟通、代码注释、文档、错误提示均使用中文
- **标识符命名**：变量名、函数名等可用英文，但须提供中文注释说明
- **端正态度**：禁止啰嗦，必须正面回答问题；禁止懒惰，不允许推脱计划内的任务；禁止谎言，必须实事求是

## 全局规则

### Git 写操作

所有 Git 写操作（commit/push/merge/rebase/reset/stash/branch -D/cherry-pick/revert 等）均由 `/safe-git-write` skill 统一管理，**禁止绕过 ask 确认直接执行**。safe-git-write 包含操作类型识别、暂存区分析、混合提交检测、用户确认、格式校验、提交前清理等完整流程。`--no-verify` / `--no-gpg-sign` 等跳过 hooks 的参数在任何情况下都不得使用。

### 执行模式（2026-08-15 新增）

**双模执行**：约束执行（默认）与自主执行（显式声明）两种模式并存，提交权唯一保留在人工确认路径。

- **约束执行（默认）**：本宪法全部现有条款生效；Git 写操作一律经 safe-git-write 人工确认；关键节点（提交、破坏性操作、范围扩大）请求确认。
- **自主执行（显式声明启用，change.yaml `execution_mode: autonomous`）**：
  - 适用：功能开发类任务（需求分析 → 任务制定 → 执行 → 验证 → 修复的连续闭环）。
  - Git 写操作**硬性禁止**：任何 commit/push/merge/rebase/reset/stash/branch -D/cherry-pick/revert 一律不得执行、不得主动触发；**强制禁止提交与主动提交，提交必须询问用户经人工确认**。
  - 不询问：自主完成完整开发闭环；需求含糊时按最合理假设推进并记录假设，不得静默臆断。
  - 专家组：跨模块影响、架构风险、边界模糊时按需成立，输出评估意见（不阻断开发）。
  - 质量底线不变：FFFD 扫描、validate-text、content-check 等防线在自主执行内同样强制执行。
  - 提交路径：自主执行结束 → 改动清单 + 评估报告交用户 → **人工确认后**由约束执行路径（safe-git-write）提交。


### Java 文件读写强制规则（机器双态：encrypted / plain）

CDG 透明加密是**机器级两态全局属性**：是否生效由本机是否安装亿赛通 Cobra DocGuard (CDG) 客户端决定（装 = `encrypted`，未装 = `plain`）。安装时运行一次 `java-fs env -force` 探测并固化到 `~/.java_fs_mode`（ASCII 单行）；所有入口（java_fs.ps1 / cmd / sh）启动时自动读取模式，无需手动指定。查看当前模式：`java-fs mode`。

- **`encrypted` 态（本机装有 CDG）**：所有 `.java` 文件写入即加密落盘，agent 原生 read/write/edit 工具、javac/java 进程读取时得到的是密文（`E-SafeNet` 头）或报 `not contain valid UTF-8` / 乱码 / "不可映射字符"。**所有 .java 文件的读取、写入、编辑，一律通过 `/java-fs` skill 完成**（python.exe 在 CDG 白名单，可透明解密）。详细命令见 `/java-fs` skill（本机路径：`%USERPROFILE%\.codex\skills\java-fs\`），示例：

  ```powershell
  powershell -NoProfile -ExecutionPolicy Bypass -File "%USERPROFILE%\.codex\skills\java-fs\scripts\java_fs.ps1" read "<路径>"
  powershell -NoProfile -ExecutionPolicy Bypass -File "%USERPROFILE%\.codex\skills\java-fs\scripts\java_fs.ps1" write "<路径>" "<内容>"
  ```

  **禁止行为**：对 .java 文件直接使用 read/write/edit/apply\_patch；让用户手动换编码或重试；跳过加密文件做"部分分析"。

  **症状判断**：javac 编译报"不可映射字符/非法字符/E-SafeNet"即密文症状，先 java\_fs read 确认明文再处理。`.class` / `.tmp` 等非 CDG 加密类型可直接操作。

- **`plain` 态（本机未装 CDG）**：`.java` 是普通明文，agent 原生工具可直接读写。java-fs 自动切换原生 IO（read / write / read-b64 / write-b64 不经 python 中转），命令格式不变；仍推荐经 java-fs 完成读写，以获得写后校验（validate-java / validate-text）与快照能力。

- **CDG 安装/卸载后**：重新运行 `java-fs env -force` 更新 `~/.java_fs_mode`，避免模式过期。模式文件缺失时自动探测并保存；探测失败保守默认 `encrypted`。


### 文件编码强制规则（Windows 中文环境）

本机为 Windows 中文版（代码页 936/GBK），PowerShell 5.1 默认按 GBK 解码文件、写文件默认 UTF-16，与 Codex 的 UTF-8 不一致，会导致中文乱码并污染产出文件（含 md）。

**所有文本文件的读取、写入，必须显式指定 UTF-8 编码：**

- 读取：`Get-Content -Encoding UTF8 <路径>`；python 用 `open(..., encoding="utf-8")`；.NET 用 `[IO.File]::ReadAllText(<路径>, [Text.Encoding]::UTF8)`
- 写入：`[IO.File]::WriteAllText(<路径>, <内容>, [Text.Encoding]::UTF8)`（无 BOM）或 `Set-Content -Encoding UTF8`（PS5.1 带 BOM，可接受）；python 用 `open(..., "w", encoding="utf-8")`（python 环境已全局设置 `PYTHONUTF8=1`、`PYTHONIOENCODING=utf-8`，见 PowerShell profile）
- - 临时 .ps1 脚本文件必须用 UTF-8 带 BOM 写入（`[System.Text.Encoding]::UTF8` 即带 BOM）；PS 5.1 的 `-File` 无 BOM 时按 GBK 解码脚本，中文全部乱码
- **禁止**：`>` 重定向、无参数的 `Out-File` 写文本文件（PS5.1 默认 UTF-16，打开即乱码）；无 `-Encoding` 参数的 `Get-Content` 读文本文件（默认 GBK，中文乱码）

**乱码处置**：工具输出或文件内容出现 U+FFFD 字符、"锟斤拷"、`褰撶敤` 等乱码特征时，先停止并确认文件真实编码（BOM/字节检测），再决定转换或重读；禁止把乱码内容写入新文件或复述进产出文档。
### 通用文本文件写后强制校验（2026-08-14 新增）

所有非 .java 文本文件（.vue/.js/.ts/.xml/.json/.yaml/.md 等）**修改后必须**执行写后校验（java-fs 的 `validate-text`），校验失败禁止继续与提交：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "%USERPROFILE%\.codex\skills\java-fs\scripts\java_fs.ps1" validate-text "<文件路径>"
```

校验内容（按扩展名路由）：
- 通用：UTF-8 可解码、U+FFFD 乱码计数、UTF-8 BOM 检测
- `.xml`：ElementTree 语法解析 + **反引号残留检测**（PowerShell 转义事故特征，如 `r`n）+ MyBatis resultMap 内容模型启发式
- `.json`：json.loads 解析
- `.js`：node --check（node 可用时）
- `.ts`：括号数量配对
- `.vue`：括号数量配对 + template/script/style 标签开闭配对
- `.yaml/.yml`：yaml.safe_load（pyyaml 可用时）

**禁止**：用 cmd/powershell 内联字符串（`-c` / `-Command "..."`）做含中文/转义字符的文本替换（多层引号嵌套是此类事故根因）；优先用脚本文件（write 工具写 .py/.ps1 临时脚本再执行）或 apply_patch/edit 工具。结构化文件（xml/json）改动后必须跑 validate-text 再继续。

### 转义卫生实操细则（2026-08-14 新增）

**目标文件是什么语言，就用什么语言的转义；PowerShell 只认反引号。**

跨语言转义符对照表（写前自查）：

| 语言/格式 | 转义符 | 换行示例 | 常见事故 |
|-----------|--------|---------|---------|
| PowerShell | 反引号 `` ` `` | `` `n ``（LF）、`` `r ``（CR）、`` `t ``（TAB） | `\r\n` 是字面量 4 字符，非换行 |
| Python / JS / Java | 反斜杠 `\` | `\n`、`\r`、`\t` | 在 PS 内联字符串中全部失效 |
| XML | 实体 `&lt; &gt; &amp; &quot; &apos;` | 文本节点无转义换行概念 | 把 `\n` 当转义写入 → 字面量 `\n` |
| JSON | 反斜杠 `\`（`\"` `\\` 必须转义） | `\n` | 双层转义（`\\n`）写坏内容 |
| cmd | `^`（极少用） | — | 与 PS 混淆，多层引号嵌套 |

内联字符串替换的替代方案（按优先级，全部优于内联）：
1. **apply_patch / edit 工具**：结构感知直接改文件，不经过 shell 层
2. **脚本文件**：write 工具写临时 .py/.ps1 脚本（编码按「文件编码强制规则」）再执行——脚本内字符串是文件内容，不经命令行解析，中文与转义字符无损
3. **base64 通道**：内容先 base64 编码再传参（java-fs write-b64 同款思路），彻底杜绝引号嵌套
4. **禁止**：cmd/powershell 内联字符串（`-c` / `-Command "..."`）做含中文、转义字符、引号嵌套的文本替换

转义残留检测：非 .java 文本文件改写后跑 `validate-text`（内置反斜杠转义残留 `\r\n` 与反引号成对检测，XML 中为 ERROR 级）；写后自查 4 点——①每个反斜杠序列与目标语言转义语义一致 ②无多余反引号/反斜杠字面量（尤其 xml/json 属性值、CDATA、文本节点）③引号配对完整 ④中文无 U+FFFD / 锟斤拷。

### 提交前兜底校验（2026-08-14 新增）

**所有 git 提交前（safe-git-write 流程内），必须对暂存区中的非 .java 文本文件批量执行 validate-text，全部 OK 才允许 ask 确认提交：**

- 文件范围：暂存区（staged）中 .xml/.json/.js/.ts/.vue/.yaml/.yml/.md 等文本文件；.java 文件由 java-fs validate-java 覆盖（引用，不重复）
- 执行方式：safe-git-write 全局卫生步骤内，对 `git diff --cached --name-only` 列出的暂存文本文件逐一执行；java-fs 批量模式可用时改用批量命令
- 失败处理：任一文件校验失败 → 禁止提交，回退修复后重新校验；不提供强制跳过
- **禁止绕过**：`--no-verify` / `--no-gpg-sign` 等跳过 hooks 的参数在任何情况下都不得使用（与「Git 写操作」条款一致）

### 修改既有功能前先梳理（证据链）

对既有功能的任何改造和调整，必须有完整的**证据链**支撑：

- **不猜测**：每一环有代码路径证据，不允许推测性判断
- **先追踪**：找到改动点的上下游依赖、被谁调用、修改后影响范围
- **先验证再动手**：梳理完整业务过程形成逻辑说明，列出影响范围、记录证据链（文件路径 + 行号），确认后再编码
- **回归验证**：改完后原有功能的每条路径都要能走通

不改已确认或未确认用途的代码，每次修改确认改动范围及对已验证功能的影响。

### 不主动执行编译、构建与启动

AI 不优先考虑执行编译/打包/测试/构建/依赖安装/容器构建等重型命令。 需要验证改动时，应向用户说明命令、预期效果与注意事项，由用户自行决定是否运行。 允许轻量只读操作（版本查询、只读诊断、配置文件读取等）。

## AI 协作准则

减少 AI 编码常见错误的行为准则。倾向于谨慎而非速度，琐碎任务可酌情豁免。

### 1. 编码前先想

**不假设、不隐藏困惑、列出权衡。** 显式说出你的假设；存在多种解释时列出来而不是默默挑一个；有更简单的方案就说出来；看不懂就停下来问清楚。

### 2. 最小够用

**用最少的代码解决问题。不做投机性扩展。** 不加没要求的功能；不为一次性代码做抽象；不为不可能发生的场景写错误处理；写了 200 行能写成 50 行就重写。自检："资深工程师会嫌这过度复杂吗？"

### 3. 外科式改动

**只碰必须碰的。只清理自己造成的混乱。** 不要"改进"相邻代码、注释、格式；没坏的不要重构；沿用现有风格。改动产生孤儿时删掉因你而变得没用的 import/变量/函数，但不要删先前就存在的死代码。检验标准：每一行改动都能追溯到原始请求。

### 4. 目标驱动

**定义成功标准，循环验证直到达标。** 多步任务先列简短计划：

1. \[步骤\] → 验证：\[检查项\]
2. \[步骤\] → 验证：\[检查项\]
3. \[步骤\] → 验证：\[检查项\]

**起作用的标志：** diff 中没有不必要的改动；澄清问题在实现之前提出，而不是出错之后才发现。
