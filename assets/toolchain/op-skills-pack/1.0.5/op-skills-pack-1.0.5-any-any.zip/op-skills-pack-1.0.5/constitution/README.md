# 全局宪法部署指引

宪法是各工具 AI agent 的最高行为约束。本目录提供完整版宪法（含透明加密 java-fs 强制规则与 Windows UTF-8 编码规则），部署到新环境后分发到各端。

## 1. 文件位置

| 工具 | 文件 | 路径 |
|------|------|------|
| Claude Code | CLAUDE.md | ~/.claude/CLAUDE.md（全局）或仓库根 CLAUDE.md（项目级） |
| Codex | AGENTS.md | ~/.codex/AGENTS.md（C: 与 E: 各一份） |
| jcode | AGENTS.md | ~/.jcode/AGENTS.md |
| opencode | AGENTS.md | ~/.config/opencode/AGENTS.md（opencode 自动加载全局指令，或经 opencode.json 的 `instructions` 引用） |
| jcode（备份副本） | AGENTS.md | ~/.jcode/external/AGENTS.md（与 jcode 主版同步，防外部进程读取旧版） |
| Command Code | AGENTS.md | ~/.commandcode/AGENTS.md（用户级记忆文件；同目录 AGENTS.md 亦被项目级 `.commandcode/AGENTS.md` 覆盖） |
| reasonix | AGENTS.md | 随各项目 |

## 2. 内容

AGENTS.md（完整版）包含：

1. 沟通方式：全程中文
2. Git 写操作强制走 /safe-git-write
3. 执行模式（2026-08-15 新增）：约束执行（默认）/ 自主执行（execution_mode: autonomous，硬禁 Git 写）双模并存
4. Java 文件读写强制规则（机器双态 encrypted / plain）：所有 .java 必须经 /java-fs
5. 文件编码强制规则（Windows 中文环境）：显式 UTF-8 读写、乱码处置
6. 通用文本文件写后强制校验（2026-08-14 新增）：非 .java 文本文件修改后必须执行 java-fs validate-text
7. 转义卫生实操细则 + 提交前兜底校验（2026-08-14 新增）
8. 修改既有功能前先梳理（证据链）：不猜测 / 先追踪 / 先验证再动手 / 回归验证
9. 不主动执行编译、构建与启动
10. AI 协作准则：编码前先想、最小够用、外科式改动、目标驱动

## 3. 部署步骤

复制 AGENTS.md 为各端宪法文件：

```powershell
Copy-Item "constitution\AGENTS.md" "$env:USERPROFILE\.claude\CLAUDE.md" -Force
Copy-Item "constitution\AGENTS.md" "$env:USERPROFILE\.codex\AGENTS.md" -Force
Copy-Item "constitution\AGENTS.md" "$env:USERPROFILE\.jcode\AGENTS.md" -Force
Copy-Item "$env:USERPROFILE\.jcode\AGENTS.md" "$env:USERPROFILE\.jcode\external\AGENTS.md" -Force
Copy-Item "constitution\AGENTS.md" "$env:USERPROFILE\.config\opencode\AGENTS.md" -Force
Copy-Item "constitution\AGENTS.md" "$env:USERPROFILE\.commandcode\AGENTS.md" -Force
```

**标题已通用化**（「全局宪法」，不按端命名）：各端分发同一份文件内容，不做逐端改写，防止副本漂移。
java-fs 路径仍按端硬编码（`.codex`/`.jcode`，见 §4 已知缺口）。仓库根 CLAUDE.md 是项目级约定，与全局宪法互补。

Command Code 的指令文件层级（从其 `dist/cli.mjs` 的 `getUserMemoryPath` /
`getProjectMemoryPaths` 实证）：企业级 `C:\ProgramData\CommandCode\AGENTS.md` →
用户级 `<home>\.commandcode\AGENTS.md` → 项目级 `<project>\AGENTS.md`，项目级优先。

## 4. 注意事项

- 宪法与 java-fs skill 配套：宪法声明必须用 /java-fs，java-fs 提供命令实现
- 工具升级或重装可能重置配置目录，需重新复制宪法
- **宪法修改必须先在仓库统一维护（唯一事实源），再按上表分发各端——禁止直接改各端副本**（2026-08-14 曾发生只改 ~/.jcode 导致事实源漂移，已修复）
- **已知缺口**：宪法内 java-fs 路径按端硬编码（`.codex`/`.jcode`），复制型分发无法自动改写；复制后需按端调整，或等 P2 期改为模板变量 + 可校验分发
