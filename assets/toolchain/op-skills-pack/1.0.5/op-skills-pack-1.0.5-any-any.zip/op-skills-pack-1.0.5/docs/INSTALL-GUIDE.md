# op-skills 安装与升级指南

> 适用：`op-skills-pack-<version>.zip` 纯净发布包（由 GitHub Actions 构建，见 `.github/workflows/release.yml`）

---

## 一、获取发布包

### 方式 1：GitHub Releases（推荐）

1. 打开仓库 Releases 页面：`https://github.com/klaus2918/op-skills/releases`
2. 下载目标版本的 `op-skills-pack-<version>.zip`

触发方式（维护者）：

```bash
# 打 tag 自动发布
git tag v1.0.0
git push origin v1.0.0
```

或在 GitHub 仓库 → Actions → `Release Pack` → `Run workflow` → 输入版本号（不带 `v`）。

### 方式 2：本地构建

```cmd
REM Windows
build-pack.cmd 1.0.0
py build-pack.py 1.0.0

REM Linux / macOS
./build-pack.sh 1.0.0
python3 build-pack.py 1.0.0
```

产物：仓库根 `op-skills-pack-1.0.0.zip`（该文件名已被 `.gitignore` 排除，不入库）。

---

## 二、包内结构

```
op-skills-pack-1.0.0/
├── skills/                   # 19 个 skill
├── constitution/             # 全局宪法 AGENTS.md
├── multi-end-sync/           # 多端同步机制（含 tools.yaml）
├── install.cmd / install.sh  # 安装 / 升级脚本
├── docs/INSTALL-GUIDE.md     # 本指南（随包分发）
├── VERSION.txt               # 版本、构建时间、来源提交
├── requirements.txt
├── README.md
├── CHANGELOG.md
└── .gitignore
```

**纯净口径**（与 README「隔离与外部版本」一致）：

| 类别 | 说明 |
|------|------|
| 零运行资产 | 不含 `.basic/evolved/**`、`skills/*/config`（挂载点实体）、`sites/`、`workspaces/`、`__pycache__` 等 |
| 零本地配置 | 不含 `config.yaml`、`*.local.*`、`.env*` |
| 零敏感词清单 | 不含 `.sensitive-terms*`（组织专有敏感词只保留在本机，不随包分发） |
| 零环境内部材料 | 不含插件式子层 `skills/op-design-extract/skills/**`、内部项目分析文档 `skills/op-browser/docs/**`、内部业务部署套件 `skills/op-deploy-prep/kits/**` |
| 构建门禁 | 打包时执行自检：禁止项残留=0、U+FFFD 乱码=0、`scan-sensitive.py --path` 扫描通过、zip 完整性校验 |

> 内容来源为 `git ls-files`（受跟踪文件）中的分发白名单路径，天然与 `.gitignore` 一致。

---

## 三、安装

### Windows

```cmd
install.cmd op-skills-pack-1.0.0.zip            REM 默认安装到 .\op-skills
install.cmd op-skills-pack-1.0.0.zip D:\tools\op-skills
```

### Linux / macOS

```bash
./install.sh op-skills-pack-1.0.0.zip           # 默认安装到 ./op-skills
./install.sh op-skills-pack-1.0.0.zip ~/op-skills
```

### 手动安装（等价）

解压后将 `skills/`、`constitution/`、`multi-end-sync/`、`README.md`、`CHANGELOG.md`、`requirements.txt` 放入目标目录即可（与 README「快速部署」一致）。

### 安装后必做

```bash
# 1) Python 运行时依赖（Python 3.11+）
pip install -r <目标目录>/requirements.txt

# 2) 多端建链（Windows；其他端见 multi-end-sync/README.md）
powershell -NoProfile -ExecutionPolicy Bypass -File <目标目录>\multi-end-sync\sync-skills.ps1

# 3) 校验建链结果
powershell -NoProfile -ExecutionPolicy Bypass -File <目标目录>\multi-end-sync\sync-skills.ps1 -Status
```

---

## 四、配置各 Skill

真实环境参数**不进包、不入库**，写入对应 skill 的挂载点：

```
<目标目录>/.basic/evolved/<skill>/config/config.yaml
```

模板随包分发，位于 `skills/<skill>/references/`（如 `skills/op-release/references/config-example.yaml`）。
挂载点由 `skills/op-000/scripts/op-000-mount-sync.ps1` 按机创建，换机后重新执行即可恢复。

---

## 五、升级

```bash
# 用新版本包重复执行安装脚本即可（覆盖 skills/、constitution/、multi-end-sync/）
install.cmd op-skills-pack-1.1.0.zip <同一目标目录>
./install.sh   op-skills-pack-1.1.0.zip <同一目标目录>
```

升级不触碰：
- `.basic/evolved/**`（运行资产与本机配置）
- `.op/**`、`.claude/**` 等本机目录

安装脚本采用**覆盖式**复制，不会删除目标目录中你自行新增的 skill 或文件。
如需与发布包完全一致（清理已移除的旧 skill），请删除 `skills/` 后重新安装。

---

## 六、常见问题

**Q：GitHub Releases 里看不到发布包？**
依次确认：① 工作流文件已推送到默认分支；② `permissions: contents: write` 存在（工作流已内置）；③ tag 已推送（`git push origin v1.0.0`）；④ Actions 运行成功（失败时看构建日志中的自检输出）。

**Q：`config.yaml` 在哪？**
在 `.basic/evolved/<skill>/config/config.yaml`（安装后由挂载点机制创建），不随包分发。

**Q：包内为什么没有敏感词清单？**
组织专有敏感词属阻断级本地信息，只存在于本机 `.sensitive-terms`。发布包只含通用扫描器（`skills/safe-git-write/scripts/scan-sensitive.py`）与示例文件 `sensitive-terms.example`。
