@echo off
setlocal enabledelayedexpansion
REM op-skills installer / updater (Windows)
REM Usage:
REM   install.cmd [target-dir]              run inside the unpacked pack (target defaults to .\op-skills)
REM   install.cmd <pack.zip> [target-dir]   run outside the pack

set "ZIP="
set "TARGET="
set "SRC="
set "TMP="

if not "%~1"=="" (
  if /i "%~x1"==".zip" (
    set "ZIP=%~1"
    set "TARGET=%~2"
  ) else (
    set "TARGET=%~1"
  )
)
if "%TARGET%"=="" set "TARGET=op-skills"

if not "%ZIP%"=="" (
  if not exist "%ZIP%" (
    echo [ERROR] zip not found: %ZIP%
    exit /b 1
  )
  set "TMP=_op_skills_unpack"
  if exist "%TMP%" rmdir /s /q "%TMP%"
  echo [1/3] Extracting %ZIP% ...
  powershell -NoProfile -Command "Expand-Archive -LiteralPath '%ZIP%' -DestinationPath '%TMP%' -Force"
  for /d %%d in ("%TMP%\op-skills-pack-*") do if exist "%%~fd\" set "SRC=%%~fd"
  if "!SRC!"=="" set "SRC=%TMP%"
) else (
  set "SRC=%~dp0"
  if "!SRC:~-1!"=="\" set "SRC=!SRC:~0,-1!"
  echo [1/3] Using current pack directory ...
)

if not exist "%SRC%\skills" (
  echo [ERROR] not an op-skills pack: %SRC%
  exit /b 1
)

echo [2/3] Installing to %TARGET% ...
if not exist "%TARGET%" mkdir "%TARGET%"
robocopy "%SRC%\skills" "%TARGET%\skills" /E /NFL /NDL /NJH /NJS /NP >nul
robocopy "%SRC%\constitution" "%TARGET%\constitution" /E /NFL /NDL /NJH /NJS /NP >nul
robocopy "%SRC%\multi-end-sync" "%TARGET%\multi-end-sync" /E /NFL /NDL /NJH /NJS /NP >nul
for %%f in (README.md CHANGELOG.md requirements.txt .gitignore VERSION.txt) do (
  if exist "%SRC%\%%f" copy /y "%SRC%\%%f" "%TARGET%\%%f" >nul
)
if not "%TMP%"=="" if exist "%TMP%" rmdir /s /q "%TMP%"

echo [3/3] Done. Target: %TARGET%
echo.
echo Next steps:
echo   1^) pip install -r "%TARGET%\requirements.txt"
echo   2^) powershell -NoProfile -ExecutionPolicy Bypass -File "%TARGET%\multi-end-sync\sync-skills.ps1"
echo   3^) Upgrade: unpack the new pack and run this script again (runtime data in .basic\ is kept)
echo   Docs: docs/INSTALL-GUIDE.md
exit /b 0
